import discord
import aiohttp
import asyncio
from datetime import datetime, timezone
from config import Config

class StatusWebhook:
    def __init__(self, bot):
        self.bot = bot
        self.webhook_url = getattr(Config, "STATUS_WEBHOOK_URL", None)
        self.notification_role = getattr(Config, "STATUS_NOTIFICATION_ROLE", None)
        self.start_time = None
        self.last_status = None

    async def start(self):
        if not self.webhook_url:
            print("[StatusWebhook] ❌ No webhook URL configured. Status updates disabled.")
            return

        print(f"[StatusWebhook] 📡 Webhook URL: {self.webhook_url[:50]}...")
        self.start_time = datetime.now(timezone.utc)
        self.bot.loop.create_task(self._status_loop())
        print("[StatusWebhook] ✅ Status updates started (every 10 minutes)")

    async def _status_loop(self):
        await self.bot.wait_until_ready()
        print("[StatusWebhook] 🔄 Bot is ready, sending initial status...")

        await self._send_status(is_initial=True)

        while not self.bot.is_closed():
            try:
                await asyncio.sleep(600)
                await self._send_status()
            except Exception as e:
                print(f"[StatusWebhook] ❌ Error in status loop: {e}")

    async def _send_status(self, is_initial: bool = False):
        if not self.webhook_url:
            return

        print(f"[StatusWebhook] 📤 Sending status... (Initial: {is_initial})")

        guilds = len(self.bot.guilds)
        users = sum(g.member_count for g in self.bot.guilds)
        ping = round(self.bot.latency * 1000, 2)

        if self.start_time:
            uptime = (datetime.now(timezone.utc) - self.start_time).total_seconds()
            uptime_str = self._format_uptime(uptime)
        else:
            uptime_str = "Unknown"

        commands = len(self.bot.commands) + len(self.bot.tree.get_commands())

        if ping < 100:
            color = 0x2ECC71
            status_emoji = "🟢"
            status_text = "Online"
        elif ping < 300:
            color = 0xF39C12
            status_emoji = "🟡"
            status_text = "Degraded"
        else:
            color = 0xE74C3C
            status_emoji = "🔴"
            status_text = "Slow"

        embed = discord.Embed(
            title="🤖 Bot Status",
            color=color,
            timestamp=datetime.now(timezone.utc)
        )
        embed.set_author(name=self.bot.user.name, icon_url=self.bot.user.display_avatar.url)

        embed.add_field(name="📊 Status", value=f"{status_emoji} **{status_text}**", inline=True)
        embed.add_field(name="🏠 Servers", value=f"**{guilds:,}**", inline=True)
        embed.add_field(name="👥 Users", value=f"**{users:,}**", inline=True)
        embed.add_field(name="⚡ Ping", value=f"**{ping}ms**", inline=True)
        embed.add_field(name="⏰ Uptime", value=f"**{uptime_str}**", inline=True)
        embed.add_field(name="📋 Commands", value=f"**{commands}**", inline=True)

        if is_initial:
            embed.set_footer(text="🟢 Bot started • Updates every 10 minutes")
        else:
            embed.set_footer(text="Updates every 10 minutes")

        content = None
        if self.notification_role and not is_initial:
            current_status = f"{status_text}_{ping}"
            if self.last_status != current_status:
                content = f"<@&{self.notification_role}> Bot status update"
                self.last_status = current_status

        try:
            async with aiohttp.ClientSession() as session:
                webhook = discord.Webhook.from_url(self.webhook_url, session=session)
                await webhook.send(content=content, embed=embed)
                print("[StatusWebhook] ✅ Status sent successfully!")
        except Exception as e:
            print(f"[StatusWebhook] ❌ Failed to send: {e}")

    def _format_uptime(self, seconds):
        days = int(seconds // 86400)
        hours = int((seconds % 86400) // 3600)
        minutes = int((seconds % 3600) // 60)

        parts = []
        if days:
            parts.append(f"{days}d")
        if hours:
            parts.append(f"{hours}h")
        if minutes:
            parts.append(f"{minutes}m")

        return " ".join(parts) if parts else "Just started"

    async def send_manual_status(self):
        await self._send_status()

    async def send_error_status(self, error_message: str):
        if not self.webhook_url:
            return

        embed = discord.Embed(
            title="⚠️ Bot Error",
            description=f"```py\n{error_message[:1000]}\n```",
            color=0xE74C3C,
            timestamp=datetime.now(timezone.utc)
        )
        embed.set_author(name=self.bot.user.name, icon_url=self.bot.user.display_avatar.url)
        embed.set_footer(text="Please check the logs")

        try:
            async with aiohttp.ClientSession() as session:
                webhook = discord.Webhook.from_url(self.webhook_url, session=session)
                await webhook.send(embed=embed)
                print("[StatusWebhook] ✅ Error status sent successfully!")
        except Exception as e:
            print(f"[StatusWebhook] ❌ Failed to send error status: {e}")
