class Emojis:
    # All custom emoji IDs replaced with standard Unicode

    TICK = "✅"          # was <:tick:1532052259998011553>
    WRONG = "❌"         # was <:wrong:1532052094981509191>
    DOLLAR = "💰"        # was <:dollar:1532053933047156997>
    GIVEAWAY = "🎁"      # was <:giveaway:1532053520302215418>
    TICKET = "🎟️"        # was <:ticket:1532052392303001641>
    ARROW = "➡️"         # was <:darkbluearrow:1532051917230838061>
    TOPGG = "⭐"         # was <:topgg:1532051523989930094>
    CHAIN = "🔗"         # was <:chain_messi:1532051342510788708>
    GLOBE = "🌐"         # was <:globe_messi:1532051165595046029>
    YOUTUBE = "📹"       # was <:youtube_logo:1532054252569231753>
    COUNTING = "🔢"      # was <:counting:1532056181583904999>

    # Aliases (unchanged, just referencing the above)
    SUCCESS = TICK
    DENY = WRONG
    ERROR = WRONG
    ARROW_RIGHT = ARROW
    LOADING = "⏳"

    # Standard Unicode emojis (unchanged)
    STAR = "✦"
    BULLET = "▸"
    DOT = "•"
    DASH = "─"

    SHIELD = "🛡️"
    LOCK = "🔒"
    UNLOCK = "🔓"
    CROWN = "👑"
    MIC = "🎙️"
    MUSIC = "🎧"
    SETTINGS = "⚙️"
    MOD = "🔨"
    BAN = "🔨"
    KICK = "👢"
    MUTE = "🔇"
    WARN = "⚠️"
    INFO = "ℹ️"
    CLOCK = "⏱️"
    LEVEL = "📈"
    INVITE = "📨"
    ROLE = "🎭"
    WELCOME = "🚪"
    LOG = "📜"
    REPORT = "🚩"
    APPLICATION = "📋"
    TRANSLATE = "🌐"
    VERIFY = "✅"
    FORUM = "💬"
    REACTION = "🎯"
    JTC = "🔊"
    ANTINUKE = "🧨"
    AUTOMOD = "🧹"
    HELP = "🧭"
    OWNER = "👑"
    ECONOMY = DOLLAR   # uses DOLLAR (now 💰)
    FUN = "🎲"
    ADMIN = "🛠️"
    PREFIX = "⌨️"