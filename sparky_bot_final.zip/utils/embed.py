import discord
from datetime import datetime, timezone
from utils.emojis import Emojis
from utils.theme import Theme


def _footer(embed: discord.Embed, bot=None, note: str = None):
    text = Theme.FOOTER if not note else f"{Theme.FOOTER} {Emojis.DOT} {note}"
    icon = bot.user.display_avatar.url if bot and getattr(bot, "user", None) else None
    embed.set_footer(text=text, icon_url=icon)
    embed.timestamp = datetime.now(timezone.utc)
    return embed


def build(*, title: str = None, description: str = None, color: int = Theme.COLOR_PRIMARY,
          emoji: str = None, bot=None, note: str = None) -> discord.Embed:
    heading = f"{emoji}  {title}" if (emoji and title) else title
    e = discord.Embed(title=heading, description=description, color=color)
    return _footer(e, bot=bot, note=note)


def success_embed(title: str = "Success", description: str = "", bot=None) -> discord.Embed:
    return build(title=title, description=description, color=Theme.COLOR_SUCCESS,
                 emoji=Emojis.TICK, bot=bot)


def error_embed(description: str, bot=None) -> discord.Embed:
    return build(title="Error", description=description, color=Theme.COLOR_ERROR,
                 emoji=Emojis.WRONG, bot=bot)


def info_embed(title: str, description: str = "", bot=None) -> discord.Embed:
    return build(title=title, description=description, color=Theme.COLOR_INFO,
                 emoji=Emojis.STAR, bot=bot)


def warning_embed(title: str, description: str = "", bot=None) -> discord.Embed:
    return build(title=title, description=description, color=Theme.COLOR_WARNING,
                 emoji="⚠️", bot=bot)


def mod_embed(title: str, description: str = "", bot=None) -> discord.Embed:
    return build(title=title, description=description, color=Theme.COLOR_MOD,
                 emoji=Emojis.SHIELD, bot=bot)


def gold_embed(title: str, description: str = "", bot=None) -> discord.Embed:
    return build(title=title, description=description, color=Theme.COLOR_GOLD,
                 emoji=Emojis.CROWN, bot=bot)


def panel_embed(title: str, description: str = "", color: int = Theme.COLOR_PRIMARY,
                 emoji: str = Emojis.STAR, bot=None, note: str = None) -> discord.Embed:
    return build(title=title, description=description, color=color, emoji=emoji, bot=bot, note=note)
