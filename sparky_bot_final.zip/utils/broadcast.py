from typing import List
from fastapi import WebSocket

connections: List[WebSocket] = []

def set_connections(ws_list: List[WebSocket]):
    global connections
    connections = ws_list

async def broadcast(data: dict):
    if not connections:
        return
    disconnected = []
    for ws in connections:
        try:
            await ws.send_json(data)
        except Exception:
            disconnected.append(ws)
    for ws in disconnected:
        if ws in connections:
            connections.remove(ws)
