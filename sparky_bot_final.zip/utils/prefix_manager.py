import json
import discord
import os
from utils.data import load, save

PREFIX_FILE = "prefixes.json"

def get_prefixes(guild_id: int) -> list:
    data = load(PREFIX_FILE)
    prefixes = data.get(str(guild_id), [])

    if not prefixes:
        return ["//"]

    return prefixes

def set_prefixes(guild_id: int, prefixes: list):
    data = load(PREFIX_FILE)
    data[str(guild_id)] = prefixes
    save(PREFIX_FILE, data)

def add_prefix(guild_id: int, prefix: str):
    prefixes = get_prefixes(guild_id)
    if prefix not in prefixes:
        prefixes.append(prefix)
        set_prefixes(guild_id, prefixes)
        return True
    return False

def remove_prefix(guild_id: int, prefix: str):
    prefixes = get_prefixes(guild_id)
    if len(prefixes) <= 1:
        return False

    if prefix in prefixes:
        prefixes.remove(prefix)
        set_prefixes(guild_id, prefixes)
        return True
    return False

async def get_prefixed_command(bot, message: discord.Message) -> tuple[str, str]:
    if not message.guild:
        return None, None

    prefixes = get_prefixes(message.guild.id)

    for prefix in prefixes:
        if message.content.startswith(prefix):
            command = message.content[len(prefix):].strip()
            return prefix, command

    return None, None
