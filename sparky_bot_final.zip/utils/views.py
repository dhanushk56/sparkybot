import discord
from discord import ui
from utils.emojis import Emojis


class ConfirmView(ui.View):

    def __init__(self, author_id: int, timeout: int = 30):
        super().__init__(timeout=timeout)
        self.author_id = author_id
        self.value = None

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.author_id:
            await interaction.response.send_message(
                f"{Emojis.WRONG} This confirmation isn't for you.", ephemeral=True
            )
            return False
        return True

    @ui.button(label="Confirm", emoji=Emojis.TICK, style=discord.ButtonStyle.success)
    async def confirm(self, interaction: discord.Interaction, button: ui.Button):
        self.value = True
        for child in self.children:
            child.disabled = True
        await interaction.response.edit_message(view=self)
        self.stop()

    @ui.button(label="Cancel", emoji=Emojis.WRONG, style=discord.ButtonStyle.danger)
    async def cancel(self, interaction: discord.Interaction, button: ui.Button):
        self.value = False
        for child in self.children:
            child.disabled = True
        await interaction.response.edit_message(view=self)
        self.stop()

    async def on_timeout(self):
        for child in self.children:
            child.disabled = True


class PaginatorView(ui.View):

    def __init__(self, pages: list, author_id: int, timeout: int = 120):
        super().__init__(timeout=timeout)
        self.pages = pages
        self.author_id = author_id
        self.index = 0
        self.message = None
        self._sync_buttons()

    def _sync_buttons(self):
        self.first.disabled = self.index == 0
        self.previous.disabled = self.index == 0
        self.next.disabled = self.index >= len(self.pages) - 1
        self.last.disabled = self.index >= len(self.pages) - 1
        self.counter.label = f"{self.index + 1} / {len(self.pages)}"

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.author_id:
            await interaction.response.send_message(
                f"{Emojis.WRONG} This menu isn't for you.", ephemeral=True
            )
            return False
        return True

    async def _update(self, interaction: discord.Interaction):
        self._sync_buttons()
        await interaction.response.edit_message(embed=self.pages[self.index], view=self)

    @ui.button(emoji="⏮️", style=discord.ButtonStyle.secondary, row=0)
    async def first(self, interaction: discord.Interaction, button: ui.Button):
        self.index = 0
        await self._update(interaction)

    @ui.button(emoji="◀️", style=discord.ButtonStyle.secondary, row=0)
    async def previous(self, interaction: discord.Interaction, button: ui.Button):
        self.index = max(0, self.index - 1)
        await self._update(interaction)

    @ui.button(label="1 / 1", style=discord.ButtonStyle.primary, disabled=True, row=0)
    async def counter(self, interaction: discord.Interaction, button: ui.Button):
        pass

    @ui.button(emoji="▶️", style=discord.ButtonStyle.secondary, row=0)
    async def next(self, interaction: discord.Interaction, button: ui.Button):
        self.index = min(len(self.pages) - 1, self.index + 1)
        await self._update(interaction)

    @ui.button(emoji="⏭️", style=discord.ButtonStyle.secondary, row=0)
    async def last(self, interaction: discord.Interaction, button: ui.Button):
        self.index = len(self.pages) - 1
        await self._update(interaction)

    async def on_timeout(self):
        for child in self.children:
            child.disabled = True
        if self.message:
            try:
                await self.message.edit(view=self)
            except discord.HTTPException:
                pass
