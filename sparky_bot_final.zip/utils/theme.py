from config import Config
from utils.emojis import Emojis

class Theme:

    NAME = "Sparky"
    TAGLINE = "Sparky Bot"
    ACCENT = 0x2B2D31

    COLOR_SUCCESS = Config.COLOR_OK
    COLOR_ERROR = Config.COLOR_ERR
    COLOR_WARNING = Config.COLOR_WARN
    COLOR_INFO = Config.COLOR_INFO
    COLOR_MOD = Config.COLOR_MOD
    COLOR_GOLD = Config.COLOR_GOLD
    COLOR_PRIMARY = 0x5865F2

    FOOTER = "Sparky"

    @staticmethod
    def footer_icon(bot):
        return bot.user.display_avatar.url if bot and bot.user else None
