import discord
from discord.ext import commands
from discord import app_commands
import asyncio
import re
from collections import defaultdict, deque
from datetime import datetime, timezone, timedelta
from config import Config
from utils.embed import build
from utils.theme import Theme
from utils.data import load, save

INVITE_RE = re.compile(r"discord(?:\.gg|app\.com/invite|\.com/invite)/[a-zA-Z0-9\-]+", re.IGNORECASE)
URL_RE    = re.compile(r"https?://[^\s]+", re.IGNORECASE)

ALL_MODULES = ["anti_spam", "anti_invite", "anti_links", "caps_filter", "bad_words", "mention_limit"]

MODULE_CHOICES = [
    app_commands.Choice(name="Anti-Links",    value="anti_links"),
    app_commands.Choice(name="Anti-Invite",   value="anti_invite"),
    app_commands.Choice(name="Anti-Spam",     value="anti_spam"),
    app_commands.Choice(name="Caps Filter",   value="caps_filter"),
    app_commands.Choice(name="Bad Words",     value="bad_words"),
    app_commands.Choice(name="Mention Limit", value="mention_limit"),
]

MODULE_LABELS = {
    "anti_links":    "Anti-Links",
    "anti_invite":   "Anti-Invite",
    "anti_spam":     "Anti-Spam",
    "caps_filter":   "Caps Filter",
    "bad_words":     "Bad Words",
    "mention_limit": "Mention Limit",
}

PUNISHMENT_TYPES = {
    "delete": "Delete Message",
    "warn": "Warn",
    "timeout": "Timeout",
    "kick": "Kick",
    "ban": "Ban",
}

PUNISHMENT_CHOICES = [
    app_commands.Choice(name="Delete Message", value="delete"),
    app_commands.Choice(name="Warn", value="warn"),
    app_commands.Choice(name="Timeout", value="timeout"),
    app_commands.Choice(name="Kick", value="kick"),
    app_commands.Choice(name="Ban", value="ban"),
]

DEFAULT_PUNISHMENTS = {
    "anti_spam": "timeout",
    "anti_invite": "delete",
    "anti_links": "delete",
    "caps_filter": "delete",
    "bad_words": "delete",
    "mention_limit": "timeout",
}

DEFAULT_WARN_THRESHOLDS = {
    "anti_spam": 3,
    "anti_invite": 2,
    "anti_links": 2,
    "caps_filter": 3,
    "bad_words": 2,
    "mention_limit": 3,
}

ESCALATION_PUNISHMENTS = {
    "anti_spam": "timeout",
    "anti_invite": "kick",
    "anti_links": "kick",
    "caps_filter": "timeout",
    "bad_words": "kick",
    "mention_limit": "timeout",
}

WARN_FILE = "automod_warns.json"

def _get_warns(guild_id: int, user_id: int, module: str) -> list:
    data = load(WARN_FILE)
    return data.get(str(guild_id), {}).get(str(user_id), {}).get(module, [])

def _add_warn(guild_id: int, user_id: int, module: str, reason: str):
    data = load(WARN_FILE)
    guild_data = data.setdefault(str(guild_id), {})
    user_data = guild_data.setdefault(str(user_id), {})
    module_data = user_data.setdefault(module, [])

    now = datetime.now(timezone.utc)
    module_data = [
        w for w in module_data
        if (now - datetime.fromisoformat(w["time"])).total_seconds() < 604800
    ]

    module_data.append({
        "time": now.isoformat(),
        "reason": reason
    })
    user_data[module] = module_data
    guild_data[str(user_id)] = user_data
    data[str(guild_id)] = guild_data
    save(WARN_FILE, data)
    return len(module_data)

def _clear_warns(guild_id: int, user_id: int, module: str):
    data = load(WARN_FILE)
    if str(guild_id) in data:
        if str(user_id) in data[str(guild_id)]:
            if module in data[str(guild_id)][str(user_id)]:
                del data[str(guild_id)][str(user_id)][module]
                save(WARN_FILE, data)
                return True
    return False

def _clear_all_warns(guild_id: int, user_id: int):
    data = load(WARN_FILE)
    if str(guild_id) in data:
        if str(user_id) in data[str(guild_id)]:
            del data[str(guild_id)][str(user_id)]
            save(WARN_FILE, data)
            return True
    return False

def _empty_module_wl() -> dict:
    return {"users": [], "roles": [], "channels": [], "categories": []}

class AutoMod(commands.Cog):

    slash = app_commands.Group(name="am", description="AutoMod configuration commands")

    def __init__(self, bot):
        self.bot = bot
        self._spam_tracker: dict[int, dict[int, deque]] = defaultdict(lambda: defaultdict(deque))

    def _settings(self, guild_id: int) -> dict:
        data = load("guild_settings.json")
        return data.get(str(guild_id), {}).get("automod", {
            "enabled":          True,
            "anti_spam":        True,
            "anti_invite":      True,
            "anti_links":       False,
            "caps_filter":      True,
            "mention_limit":    Config.MAX_MENTIONS,
            "bad_words":        Config.BAD_WORDS,
            "log_channel":      None,
            "ignored_roles":    [],
            "ignored_channels": [],
            "module_whitelist": {},

            "punishments":      DEFAULT_PUNISHMENTS.copy(),
            "warn_thresholds":  DEFAULT_WARN_THRESHOLDS.copy(),
            "escalations":      ESCALATION_PUNISHMENTS.copy(),
        })

    def _save_am(self, guild_id: int, am: dict):
        data = load("guild_settings.json")
        data.setdefault(str(guild_id), {})["automod"] = am
        save("guild_settings.json", data)

    def _toggle(self, guild_id: int, key: str) -> bool:
        data = load("guild_settings.json")
        am   = data.setdefault(str(guild_id), {}).setdefault("automod", {})
        am[key] = not am.get(key, True)
        save("guild_settings.json", data)
        return am[key]

    def _toggle_wl_entry(self, guild_id: int, module: str, key: str, entry_id: int) -> bool:
        data   = load("guild_settings.json")
        am     = data.setdefault(str(guild_id), {}).setdefault("automod", {})
        wl     = am.setdefault("module_whitelist", {}).setdefault(module, _empty_module_wl())
        bucket = wl.setdefault(key, [])
        if entry_id in bucket:
            bucket.remove(entry_id)
            added = False
        else:
            bucket.append(entry_id)
            added = True
        save("guild_settings.json", data)
        return added

    def _is_module_whitelisted(self, message: discord.Message, module: str, am: dict) -> bool:
        wl       = am.get("module_whitelist", {}).get(module, {})
        user_id  = message.author.id
        role_ids = {r.id for r in getattr(message.author, "roles", [])}
        ch_id    = message.channel.id
        cat_id   = getattr(message.channel, "category_id", None)
        if user_id  in wl.get("users",      []): return True
        if role_ids & set(wl.get("roles",   [])): return True
        if ch_id    in wl.get("channels",   []): return True
        if cat_id and cat_id in wl.get("categories", []): return True
        return False

    def _is_globally_ignored(self, message: discord.Message, am: dict) -> bool:
        if message.channel.id in am.get("ignored_channels", []): return True
        if any(r.id in am.get("ignored_roles", []) for r in getattr(message.author, "roles", [])): return True
        if message.author.guild_permissions.manage_messages: return True
        return False

    async def _punish(self, message: discord.Message, reason: str, module: str):
        am = self._settings(message.guild.id)

        try:
            await message.delete()
        except Exception:
            pass

        punishments = am.get("punishments", DEFAULT_PUNISHMENTS)
        punishment = punishments.get(module, "delete")

        warn_thresholds = am.get("warn_thresholds", DEFAULT_WARN_THRESHOLDS)
        threshold = warn_thresholds.get(module, 3)

        escalations = am.get("escalations", ESCALATION_PUNISHMENTS)
        escalation = escalations.get(module, "timeout")

        warn_count = _add_warn(message.guild.id, message.author.id, module, reason)

        if warn_count >= threshold:
            actual_punishment = escalation
            extra_reason = f" (escalated from {punishment} after {threshold} warnings)"
        else:
            actual_punishment = punishment
            extra_reason = ""

        try:
            if actual_punishment == "delete":

                action_desc = "Message deleted"

            elif actual_punishment == "warn":

                action_desc = f"Warning issued ({warn_count}/{threshold})"

            elif actual_punishment == "timeout":
                if message.guild.me.guild_permissions.moderate_members:
                    duration = min(warn_count * 5, 60)
                    until = discord.utils.utcnow() + timedelta(minutes=duration)
                    await message.author.timeout(until, reason=f"AutoMod: {reason}{extra_reason}")
                    action_desc = f"Timed out for {duration} minutes ({warn_count}/{threshold} warnings)"
                else:
                    action_desc = "Timeout attempted (missing permissions)"

            elif actual_punishment == "kick":
                if message.guild.me.guild_permissions.kick_members:
                    await message.author.kick(reason=f"AutoMod: {reason}{extra_reason}")
                    action_desc = f"Kicked ({warn_count}/{threshold} warnings)"
                else:
                    action_desc = "Kick attempted (missing permissions)"

            elif actual_punishment == "ban":
                if message.guild.me.guild_permissions.ban_members:
                    await message.author.ban(reason=f"AutoMod: {reason}{extra_reason}")
                    action_desc = f"Banned ({warn_count}/{threshold} warnings)"
                else:
                    action_desc = "Ban attempted (missing permissions)"
            else:
                action_desc = f"Unknown punishment: {actual_punishment}"

        except Exception as e:
            action_desc = f"Failed to apply punishment: {str(e)[:50]}"

        log_id = am.get("log_channel")
        if log_id:
            ch = message.guild.get_channel(int(log_id))
            if ch:
                e = build(title="🛡️ AutoMod Action", description=(
                        f"**User:** {message.author.mention}\n"
                        f"**Channel:** {message.channel.mention}\n"
                        f"**Module:** {MODULE_LABELS.get(module, module)}\n"
                        f"**Reason:** {reason}\n"
                        f"**Action:** {action_desc}\n"
                        f"**Content:** {message.content[:200]}"
                    ), color=Config.COLOR_ERR if actual_punishment in ["kick", "ban"] else Config.COLOR_WARN, bot=self.bot)
                await ch.send(embed=e)

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild:
            return
        am = self._settings(message.guild.id)
        if not am.get("enabled", True):
            return
        if self._is_globally_ignored(message, am):
            return

        content = message.content

        if am.get("anti_spam", True) and not self._is_module_whitelisted(message, "anti_spam", am):
            tracker = self._spam_tracker[message.guild.id][message.author.id]
            now     = asyncio.get_event_loop().time()
            tracker.append(now)
            cutoff  = now - Config.SPAM_INTERVAL
            while tracker and tracker[0] < cutoff:
                tracker.popleft()
            if len(tracker) >= Config.SPAM_MESSAGE_COUNT:
                tracker.clear()
                await self._punish(message, "Spam detected", "anti_spam")
                return

        if am.get("anti_invite", True) and not self._is_module_whitelisted(message, "anti_invite", am):
            if INVITE_RE.search(content):
                await self._punish(message, "Discord invite link", "anti_invite")
                return

        if am.get("anti_links", False) and not self._is_module_whitelisted(message, "anti_links", am):
            if URL_RE.search(content):
                await self._punish(message, "External link", "anti_links")
                return

        if am.get("caps_filter", True) and not self._is_module_whitelisted(message, "caps_filter", am):
            if len(content) > 10:
                upper = sum(1 for c in content if c.isupper())
                if upper / len(content) * 100 >= Config.MAX_CAPS_PERCENT:
                    await self._punish(message, "Excessive caps", "caps_filter")
                    return

        if not self._is_module_whitelisted(message, "mention_limit", am):
            limit = am.get("mention_limit", Config.MAX_MENTIONS)
            if len(message.mentions) + len(message.role_mentions) > limit:
                await self._punish(message, f"Mention spam ({len(message.mentions)} pings)", "mention_limit")
                return

        if not self._is_module_whitelisted(message, "bad_words", am):
            bad_words     = am.get("bad_words", Config.BAD_WORDS)
            lower_content = content.lower()
            if any(word in lower_content for word in bad_words):
                await self._punish(message, "Prohibited word", "bad_words")
                return

    @commands.group(name="am", invoke_without_command=True)
    @commands.has_permissions(administrator=True)
    async def am_prefix(self, ctx):
        am = self._settings(ctx.guild.id)
        e  = build(title="🛡️ AutoMod Config", color=Config.COLOR_MOD, bot=self.bot)
        e.add_field(name="Enabled",      value="✅" if am.get("enabled") else "❌")
        e.add_field(name="Anti-Spam",    value="✅" if am.get("anti_spam") else "❌")
        e.add_field(name="Anti-Invite",  value="✅" if am.get("anti_invite") else "❌")
        e.add_field(name="Anti-Links",   value="✅" if am.get("anti_links") else "❌")
        e.add_field(name="Caps Filter",  value="✅" if am.get("caps_filter") else "❌")
        e.add_field(name="Max Mentions", value=am.get("mention_limit", Config.MAX_MENTIONS))
        e.set_footer(text=f"Use {Config.PREFIX}am <subcommand> to configure")
        await ctx.reply(embed=e)

    @am_prefix.command(name="toggle")
    @commands.has_permissions(administrator=True)
    async def prefix_toggle(self, ctx):
        state = self._toggle(ctx.guild.id, "enabled")
        await ctx.reply(f"🛡️ AutoMod is now **{'enabled' if state else 'disabled'}**.")

    @am_prefix.command(name="spam")
    @commands.has_permissions(administrator=True)
    async def prefix_antispam(self, ctx):
        state = self._toggle(ctx.guild.id, "anti_spam")
        await ctx.reply(f"🛡️ Anti-spam: **{'on' if state else 'off'}**.")

    @am_prefix.command(name="invite")
    @commands.has_permissions(administrator=True)
    async def prefix_antiinvite(self, ctx):
        state = self._toggle(ctx.guild.id, "anti_invite")
        await ctx.reply(f"🛡️ Anti-invite: **{'on' if state else 'off'}**.")

    @am_prefix.command(name="links")
    @commands.has_permissions(administrator=True)
    async def prefix_antilinks(self, ctx):
        state = self._toggle(ctx.guild.id, "anti_links")
        await ctx.reply(f"🛡️ Anti-links: **{'on' if state else 'off'}**.")

    @am_prefix.command(name="caps")
    @commands.has_permissions(administrator=True)
    async def prefix_caps(self, ctx):
        state = self._toggle(ctx.guild.id, "caps_filter")
        await ctx.reply(f"🛡️ Caps filter: **{'on' if state else 'off'}**.")

    @am_prefix.command(name="mentions")
    @commands.has_permissions(administrator=True)
    async def prefix_mentions(self, ctx, limit: int):
        data = load("guild_settings.json")
        data.setdefault(str(ctx.guild.id), {}).setdefault("automod", {})["mention_limit"] = limit
        save("guild_settings.json", data)
        await ctx.reply(f"🛡️ Max mentions per message set to **{limit}**.")

    @am_prefix.command(name="addword")
    @commands.has_permissions(administrator=True)
    async def prefix_addword(self, ctx, *, word: str):
        data  = load("guild_settings.json")
        am    = data.setdefault(str(ctx.guild.id), {}).setdefault("automod", {})
        words = am.setdefault("bad_words", list(Config.BAD_WORDS))
        word  = word.lower()
        if word not in words: words.append(word)
        am["bad_words"] = words
        save("guild_settings.json", data)
        await ctx.reply(f"✅ Added `{word}` to bad words list.")

    @am_prefix.command(name="delword")
    @commands.has_permissions(administrator=True)
    async def prefix_removeword(self, ctx, *, word: str):
        data  = load("guild_settings.json")
        am    = data.setdefault(str(ctx.guild.id), {}).setdefault("automod", {})
        words = am.get("bad_words", [])
        word  = word.lower()
        if word in words:
            words.remove(word)
            am["bad_words"] = words
            save("guild_settings.json", data)
            await ctx.reply(f"✅ Removed `{word}` from bad words.")
        else:
            await ctx.reply(f"❌ `{word}` not in bad words list.")

    @am_prefix.command(name="log")
    @commands.has_permissions(administrator=True)
    async def prefix_log(self, ctx, channel: discord.TextChannel):
        data = load("guild_settings.json")
        data.setdefault(str(ctx.guild.id), {}).setdefault("automod", {})["log_channel"] = channel.id
        save("guild_settings.json", data)
        await ctx.reply(f"✅ AutoMod logs will be sent to {channel.mention}.")

    @am_prefix.command(name="ignorech")
    @commands.has_permissions(administrator=True)
    async def prefix_ignorechannel(self, ctx, channel: discord.TextChannel = None):
        ch   = channel or ctx.channel
        data = load("guild_settings.json")
        am   = data.setdefault(str(ctx.guild.id), {}).setdefault("automod", {})
        ignored = am.setdefault("ignored_channels", [])
        if ch.id in ignored:
            ignored.remove(ch.id)
            msg = f"✅ AutoMod **enabled** in {ch.mention}."
        else:
            ignored.append(ch.id)
            msg = f"🚫 AutoMod **globally disabled** in {ch.mention}."
        save("guild_settings.json", data)
        await ctx.reply(msg)

    @am_prefix.command(name="ignorerole")
    @commands.has_permissions(administrator=True)
    async def prefix_ignorerole(self, ctx, role: discord.Role):
        data = load("guild_settings.json")
        am   = data.setdefault(str(ctx.guild.id), {}).setdefault("automod", {})
        ignored = am.setdefault("ignored_roles", [])
        if role.id in ignored:
            ignored.remove(role.id)
            msg = f"✅ AutoMod **applies** to {role.mention} again."
        else:
            ignored.append(role.id)
            msg = f"🚫 AutoMod **globally ignores** {role.mention}."
        save("guild_settings.json", data)
        await ctx.reply(msg)

    @am_prefix.command(name="punishment")
    @commands.has_permissions(administrator=True)
    async def prefix_punishment(self, ctx, module: str, action: str):
        if module not in ALL_MODULES:
            modules = ", ".join(ALL_MODULES)
            return await ctx.reply(f"❌ Invalid module. Choose from: `{modules}`")

        if action not in PUNISHMENT_TYPES:
            types = ", ".join(PUNISHMENT_TYPES.keys())
            return await ctx.reply(f"❌ Invalid action. Choose from: `{types}`")

        data = load("guild_settings.json")
        am = data.setdefault(str(ctx.guild.id), {}).setdefault("automod", {})
        punishments = am.setdefault("punishments", DEFAULT_PUNISHMENTS.copy())
        punishments[module] = action
        am["punishments"] = punishments
        save("guild_settings.json", data)

        module_label = MODULE_LABELS.get(module, module)
        action_label = PUNISHMENT_TYPES.get(action, action)
        await ctx.reply(f"✅ **{module_label}** punishment set to: **{action_label}**")

    @am_prefix.command(name="threshold")
    @commands.has_permissions(administrator=True)
    async def prefix_threshold(self, ctx, module: str, threshold: int):
        if module not in ALL_MODULES:
            modules = ", ".join(ALL_MODULES)
            return await ctx.reply(f"❌ Invalid module. Choose from: `{modules}`")

        if threshold < 1 or threshold > 10:
            return await ctx.reply("❌ Threshold must be between 1 and 10.")

        data = load("guild_settings.json")
        am = data.setdefault(str(ctx.guild.id), {}).setdefault("automod", {})
        thresholds = am.setdefault("warn_thresholds", DEFAULT_WARN_THRESHOLDS.copy())
        thresholds[module] = threshold
        am["warn_thresholds"] = thresholds
        save("guild_settings.json", data)

        module_label = MODULE_LABELS.get(module, module)
        await ctx.reply(f"✅ **{module_label}** warn threshold set to: **{threshold}** warnings")

    @am_prefix.command(name="escalation")
    @commands.has_permissions(administrator=True)
    async def prefix_escalation(self, ctx, module: str, action: str):
        if module not in ALL_MODULES:
            modules = ", ".join(ALL_MODULES)
            return await ctx.reply(f"❌ Invalid module. Choose from: `{modules}`")

        if action not in PUNISHMENT_TYPES:
            types = ", ".join(PUNISHMENT_TYPES.keys())
            return await ctx.reply(f"❌ Invalid action. Choose from: `{types}`")

        data = load("guild_settings.json")
        am = data.setdefault(str(ctx.guild.id), {}).setdefault("automod", {})
        escalations = am.setdefault("escalations", ESCALATION_PUNISHMENTS.copy())
        escalations[module] = action
        am["escalations"] = escalations
        save("guild_settings.json", data)

        module_label = MODULE_LABELS.get(module, module)
        action_label = PUNISHMENT_TYPES.get(action, action)
        await ctx.reply(f"✅ **{module_label}** escalation punishment set to: **{action_label}**")

    @am_prefix.command(name="warns")
    @commands.has_permissions(administrator=True)
    async def prefix_warns(self, ctx, member: discord.Member, module: str = None):
        if module and module not in ALL_MODULES:
            modules = ", ".join(ALL_MODULES)
            return await ctx.reply(f"❌ Invalid module. Choose from: `{modules}`")

        if module:
            warns = _get_warns(ctx.guild.id, member.id, module)
            if not warns:
                return await ctx.reply(f"✅ {member.mention} has no warnings for **{MODULE_LABELS.get(module, module)}**.")

            embed = build(title=f"⚠️ Warnings for {member.display_name} - {MODULE_LABELS.get(module, module)}", color=Config.COLOR_WARN, bot=self.bot)
            embed.set_thumbnail(url=member.display_avatar.url)

            lines = []
            for i, w in enumerate(warns, 1):
                time_str = datetime.fromisoformat(w["time"]).strftime("%Y-%m-%d %H:%M")
                lines.append(f"**{i}.** {time_str} • {w['reason']}")
            embed.description = "\n".join(lines)
            embed.set_footer(text=f"Total: {len(warns)} warnings")
            await ctx.reply(embed=embed)
        else:

            data = load(WARN_FILE)
            user_data = data.get(str(ctx.guild.id), {}).get(str(member.id), {})
            if not user_data:
                return await ctx.reply(f"✅ {member.mention} has no warnings.")

            embed = build(title=f"⚠️ All Warnings for {member.display_name}", color=Config.COLOR_WARN, bot=self.bot)
            embed.set_thumbnail(url=member.display_avatar.url)

            total = 0
            for mod, warns in user_data.items():
                mod_label = MODULE_LABELS.get(mod, mod)
                embed.add_field(
                    name=f"📋 {mod_label}",
                    value=f"{len(warns)} warning(s)",
                    inline=True
                )
                total += len(warns)
            embed.set_footer(text=f"Total: {total} warnings across {len(user_data)} modules")
            await ctx.reply(embed=embed)

    @am_prefix.command(name="clearwarns")
    @commands.has_permissions(administrator=True)
    async def prefix_clearwarns(self, ctx, member: discord.Member, module: str = None):
        if module and module not in ALL_MODULES:
            modules = ", ".join(ALL_MODULES)
            return await ctx.reply(f"❌ Invalid module. Choose from: `{modules}`")

        if module:
            if _clear_warns(ctx.guild.id, member.id, module):
                mod_label = MODULE_LABELS.get(module, module)
                await ctx.reply(f"✅ Cleared warnings for {member.mention} in **{mod_label}**.")
            else:
                await ctx.reply(f"✅ {member.mention} has no warnings in that module.")
        else:
            if _clear_all_warns(ctx.guild.id, member.id):
                await ctx.reply(f"✅ Cleared all warnings for {member.mention}.")
            else:
                await ctx.reply(f"✅ {member.mention} has no warnings.")

    @am_prefix.command(name="punishmentinfo")
    @commands.has_permissions(administrator=True)
    async def prefix_punishmentinfo(self, ctx):
        am = self._settings(ctx.guild.id)
        punishments = am.get("punishments", DEFAULT_PUNISHMENTS)
        thresholds = am.get("warn_thresholds", DEFAULT_WARN_THRESHOLDS)
        escalations = am.get("escalations", ESCALATION_PUNISHMENTS)

        embed = build(title="⚙️ AutoMod Punishment Configuration", color=Config.COLOR_INFO, bot=self.bot)

        for module in ALL_MODULES:
            mod_label = MODULE_LABELS.get(module, module)
            punishment = punishments.get(module, "delete")
            threshold = thresholds.get(module, 3)
            escalation = escalations.get(module, "timeout")

            pun_label = PUNISHMENT_TYPES.get(punishment, punishment)
            esc_label = PUNISHMENT_TYPES.get(escalation, escalation)

            embed.add_field(
                name=f"📋 {mod_label}",
                value=(
                    f"**Action:** {pun_label}\n"
                    f"**Threshold:** {threshold} warnings\n"
                    f"**Escalation:** {esc_label}"
                ),
                inline=True
            )

        embed.set_footer(text="Use /am punishment, /am threshold, /am escalation to modify")
        await ctx.reply(embed=embed)

    @am_prefix.group(name="wl", invoke_without_command=True)
    @commands.has_permissions(administrator=True)
    async def prefix_wl(self, ctx):
        await ctx.reply(
            f"**Per-module whitelist subcommands:**\n"
            f"`{Config.PREFIX}am wl user <module> <@user>` • toggle user exemption\n"
            f"`{Config.PREFIX}am wl role <module> <@role>` • toggle role exemption\n"
            f"`{Config.PREFIX}am wl channel <module> [#channel]` • toggle channel exemption\n"
            f"`{Config.PREFIX}am wl category <module> <category_id>` • toggle category exemption\n"
            f"`{Config.PREFIX}am wl list [module]` • view whitelists\n\n"
            f"**Modules:** `anti_links` `anti_invite` `anti_spam` `caps_filter` `bad_words` `mention_limit`"
        )

    @prefix_wl.command(name="user")
    @commands.has_permissions(administrator=True)
    async def prefix_wl_user(self, ctx, module: str, member: discord.Member):
        if module not in ALL_MODULES:
            return await ctx.reply(f"❌ Invalid module. Choose from: `{'`, `'.join(ALL_MODULES)}`")
        added = self._toggle_wl_entry(ctx.guild.id, module, "users", member.id)
        label = MODULE_LABELS[module]
        if added:
            await ctx.reply(f"✅ {member.mention} whitelisted from **{label}**.")
        else:
            await ctx.reply(f"➖ {member.mention} removed from **{label}** whitelist.")

    @prefix_wl.command(name="role")
    @commands.has_permissions(administrator=True)
    async def prefix_wl_role(self, ctx, module: str, role: discord.Role):
        if module not in ALL_MODULES:
            return await ctx.reply(f"❌ Invalid module. Choose from: `{'`, `'.join(ALL_MODULES)}`")
        added = self._toggle_wl_entry(ctx.guild.id, module, "roles", role.id)
        label = MODULE_LABELS[module]
        if added:
            await ctx.reply(f"✅ {role.mention} whitelisted from **{label}**.")
        else:
            await ctx.reply(f"➖ {role.mention} removed from **{label}** whitelist.")

    @prefix_wl.command(name="channel")
    @commands.has_permissions(administrator=True)
    async def prefix_wl_channel(self, ctx, module: str, channel: discord.TextChannel = None):
        if module not in ALL_MODULES:
            return await ctx.reply(f"❌ Invalid module. Choose from: `{'`, `'.join(ALL_MODULES)}`")
        ch    = channel or ctx.channel
        added = self._toggle_wl_entry(ctx.guild.id, module, "channels", ch.id)
        label = MODULE_LABELS[module]
        if added:
            await ctx.reply(f"✅ {ch.mention} whitelisted from **{label}**.")
        else:
            await ctx.reply(f"➖ {ch.mention} removed from **{label}** whitelist.")

    @prefix_wl.command(name="category")
    @commands.has_permissions(administrator=True)
    async def prefix_wl_category(self, ctx, module: str, category_id: int):
        if module not in ALL_MODULES:
            return await ctx.reply(f"❌ Invalid module. Choose from: `{'`, `'.join(ALL_MODULES)}`")
        cat = ctx.guild.get_channel(category_id)
        if not isinstance(cat, discord.CategoryChannel):
            return await ctx.reply("❌ That is not a valid category ID.")
        added = self._toggle_wl_entry(ctx.guild.id, module, "categories", cat.id)
        label = MODULE_LABELS[module]
        if added:
            await ctx.reply(f"✅ Category **{cat.name}** whitelisted from **{label}**.")
        else:
            await ctx.reply(f"➖ Category **{cat.name}** removed from **{label}** whitelist.")

    @prefix_wl.command(name="list")
    @commands.has_permissions(administrator=True)
    async def prefix_wl_list(self, ctx, module: str = None):
        am      = self._settings(ctx.guild.id)
        modules = [module] if module and module in ALL_MODULES else ALL_MODULES
        e = build(title="🛡️ AutoMod Per-Module Whitelists", color=Config.COLOR_MOD, bot=self.bot)
        for mod in modules:
            wl    = am.get("module_whitelist", {}).get(mod, {})
            lines = []
            for uid in wl.get("users", []): lines.append(f"👤 <@{uid}>")
            for rid in wl.get("roles", []): lines.append(f"🎭 <@&{rid}>")
            for cid in wl.get("channels", []): lines.append(f"📢 <#{cid}>")
            for cat_id in wl.get("categories", []):
                cat = ctx.guild.get_channel(cat_id)
                lines.append(f"📁 {cat.name if cat else f'Category {cat_id}'}")
            e.add_field(name=MODULE_LABELS[mod], value="\n".join(lines) if lines else "*None*", inline=True)
        await ctx.reply(embed=e)

    @slash.command(name="status", description="Show current AutoMod configuration.")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def slash_status(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        am = self._settings(interaction.guild.id)
        e  = build(title="🛡️ AutoMod Config", color=Config.COLOR_MOD, bot=self.bot)
        e.add_field(name="Enabled",      value="✅" if am.get("enabled") else "❌")
        e.add_field(name="Anti-Spam",    value="✅" if am.get("anti_spam") else "❌")
        e.add_field(name="Anti-Invite",  value="✅" if am.get("anti_invite") else "❌")
        e.add_field(name="Anti-Links",   value="✅" if am.get("anti_links") else "❌")
        e.add_field(name="Caps Filter",  value="✅" if am.get("caps_filter") else "❌")
        e.add_field(name="Max Mentions", value=am.get("mention_limit", Config.MAX_MENTIONS))
        e.add_field(
            name="⚙️ Punishments",
            value="Use `/am punishmentinfo` to view details",
            inline=False
        )
        await interaction.followup.send(embed=e, ephemeral=True)

    @slash.command(name="toggle", description="Enable or disable AutoMod entirely.")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def slash_toggle(self, interaction: discord.Interaction):
        state = self._toggle(interaction.guild.id, "enabled")
        await interaction.response.send_message(f"🛡️ AutoMod is now **{'enabled' if state else 'disabled'}**.", ephemeral=True)

    @slash.command(name="spam", description="Toggle anti-spam filter.")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def slash_antispam(self, interaction: discord.Interaction):
        state = self._toggle(interaction.guild.id, "anti_spam")
        await interaction.response.send_message(f"🛡️ Anti-spam: **{'on' if state else 'off'}**.", ephemeral=True)

    @slash.command(name="invite", description="Toggle anti-invite link filter.")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def slash_antiinvite(self, interaction: discord.Interaction):
        state = self._toggle(interaction.guild.id, "anti_invite")
        await interaction.response.send_message(f"🛡️ Anti-invite: **{'on' if state else 'off'}**.", ephemeral=True)

    @slash.command(name="links", description="Toggle anti-external-links filter.")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def slash_antilinks(self, interaction: discord.Interaction):
        state = self._toggle(interaction.guild.id, "anti_links")
        await interaction.response.send_message(f"🛡️ Anti-links: **{'on' if state else 'off'}**.", ephemeral=True)

    @slash.command(name="caps", description="Toggle excessive-caps filter.")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def slash_capsfilter(self, interaction: discord.Interaction):
        state = self._toggle(interaction.guild.id, "caps_filter")
        await interaction.response.send_message(f"🛡️ Caps filter: **{'on' if state else 'off'}**.", ephemeral=True)

    @slash.command(name="mentions", description="Set max mentions allowed per message.")
    @app_commands.describe(limit="Maximum number of mentions before action is taken")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def slash_mentions(self, interaction: discord.Interaction, limit: int):
        data = load("guild_settings.json")
        data.setdefault(str(interaction.guild.id), {}).setdefault("automod", {})["mention_limit"] = limit
        save("guild_settings.json", data)
        await interaction.response.send_message(f"🛡️ Max mentions per message set to **{limit}**.", ephemeral=True)

    @slash.command(name="addword", description="Add a word to the bad words filter.")
    @app_commands.describe(word="Word to block")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def slash_addword(self, interaction: discord.Interaction, word: str):
        data  = load("guild_settings.json")
        am    = data.setdefault(str(interaction.guild.id), {}).setdefault("automod", {})
        words = am.setdefault("bad_words", list(Config.BAD_WORDS))
        word  = word.lower()
        if word not in words: words.append(word)
        am["bad_words"] = words
        save("guild_settings.json", data)
        await interaction.response.send_message(f"✅ Added `{word}` to bad words list.", ephemeral=True)

    @slash.command(name="delword", description="Remove a word from the bad words filter.")
    @app_commands.describe(word="Word to unblock")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def slash_removeword(self, interaction: discord.Interaction, word: str):
        data  = load("guild_settings.json")
        am    = data.setdefault(str(interaction.guild.id), {}).setdefault("automod", {})
        words = am.get("bad_words", [])
        word  = word.lower()
        if word in words:
            words.remove(word)
            am["bad_words"] = words
            save("guild_settings.json", data)
            await interaction.response.send_message(f"✅ Removed `{word}` from bad words.", ephemeral=True)
        else:
            await interaction.response.send_message(f"❌ `{word}` not in bad words list.", ephemeral=True)

    @slash.command(name="log", description="Set the AutoMod log channel.")
    @app_commands.describe(channel="Channel to log AutoMod actions to")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def slash_logchannel(self, interaction: discord.Interaction, channel: discord.TextChannel):
        data = load("guild_settings.json")
        data.setdefault(str(interaction.guild.id), {}).setdefault("automod", {})["log_channel"] = channel.id
        save("guild_settings.json", data)
        await interaction.response.send_message(f"✅ AutoMod logs → {channel.mention}.", ephemeral=True)

    @slash.command(name="ignorech", description="Globally disable ALL AutoMod in a channel.")
    @app_commands.describe(channel="Channel to toggle global ignore (defaults to current)")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def slash_ignorechannel(self, interaction: discord.Interaction, channel: discord.TextChannel = None):
        ch   = channel or interaction.channel
        data = load("guild_settings.json")
        am   = data.setdefault(str(interaction.guild.id), {}).setdefault("automod", {})
        ignored = am.setdefault("ignored_channels", [])
        if ch.id in ignored:
            ignored.remove(ch.id)
            msg = f"✅ AutoMod **enabled** in {ch.mention}."
        else:
            ignored.append(ch.id)
            msg = f"🚫 AutoMod **globally disabled** in {ch.mention}."
        save("guild_settings.json", data)
        await interaction.response.send_message(msg, ephemeral=True)

    @slash.command(name="ignorerole", description="Globally exempt a role from ALL AutoMod modules.")
    @app_commands.describe(role="Role to globally ignore")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def slash_ignorerole(self, interaction: discord.Interaction, role: discord.Role):
        data = load("guild_settings.json")
        am   = data.setdefault(str(interaction.guild.id), {}).setdefault("automod", {})
        ignored = am.setdefault("ignored_roles", [])
        if role.id in ignored:
            ignored.remove(role.id)
            msg = f"✅ AutoMod **applies** to {role.mention} again."
        else:
            ignored.append(role.id)
            msg = f"🚫 AutoMod **globally ignores** {role.mention}."
        save("guild_settings.json", data)
        await interaction.response.send_message(msg, ephemeral=True)

    @slash.command(name="punishment", description="Set punishment for a specific module.")
    @app_commands.describe(
        module="The module to configure",
        action="The punishment action"
    )
    @app_commands.choices(
        module=MODULE_CHOICES,
        action=PUNISHMENT_CHOICES
    )
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def slash_punishment(self, interaction: discord.Interaction, module: str, action: str):
        data = load("guild_settings.json")
        am = data.setdefault(str(interaction.guild.id), {}).setdefault("automod", {})
        punishments = am.setdefault("punishments", DEFAULT_PUNISHMENTS.copy())
        punishments[module] = action
        am["punishments"] = punishments
        save("guild_settings.json", data)

        module_label = MODULE_LABELS.get(module, module)
        action_label = PUNISHMENT_TYPES.get(action, action)
        await interaction.response.send_message(
            f"✅ **{module_label}** punishment set to: **{action_label}**",
            ephemeral=True
        )

    @slash.command(name="threshold", description="Set warn threshold for a specific module.")
    @app_commands.describe(
        module="The module to configure",
        threshold="Number of warnings before escalation (1-10)"
    )
    @app_commands.choices(module=MODULE_CHOICES)
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def slash_threshold(self, interaction: discord.Interaction, module: str, threshold: int):
        if threshold < 1 or threshold > 10:
            return await interaction.response.send_message(
                "❌ Threshold must be between 1 and 10.",
                ephemeral=True
            )

        data = load("guild_settings.json")
        am = data.setdefault(str(interaction.guild.id), {}).setdefault("automod", {})
        thresholds = am.setdefault("warn_thresholds", DEFAULT_WARN_THRESHOLDS.copy())
        thresholds[module] = threshold
        am["warn_thresholds"] = thresholds
        save("guild_settings.json", data)

        module_label = MODULE_LABELS.get(module, module)
        await interaction.response.send_message(
            f"✅ **{module_label}** warn threshold set to: **{threshold}** warnings",
            ephemeral=True
        )

    @slash.command(name="escalation", description="Set escalation punishment for a specific module.")
    @app_commands.describe(
        module="The module to configure",
        action="The escalation punishment"
    )
    @app_commands.choices(
        module=MODULE_CHOICES,
        action=PUNISHMENT_CHOICES
    )
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def slash_escalation(self, interaction: discord.Interaction, module: str, action: str):
        data = load("guild_settings.json")
        am = data.setdefault(str(interaction.guild.id), {}).setdefault("automod", {})
        escalations = am.setdefault("escalations", ESCALATION_PUNISHMENTS.copy())
        escalations[module] = action
        am["escalations"] = escalations
        save("guild_settings.json", data)

        module_label = MODULE_LABELS.get(module, module)
        action_label = PUNISHMENT_TYPES.get(action, action)
        await interaction.response.send_message(
            f"✅ **{module_label}** escalation punishment set to: **{action_label}**",
            ephemeral=True
        )

    @slash.command(name="punishmentinfo", description="Show current punishment configuration.")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def slash_punishmentinfo(self, interaction: discord.Interaction):
        am = self._settings(interaction.guild.id)
        punishments = am.get("punishments", DEFAULT_PUNISHMENTS)
        thresholds = am.get("warn_thresholds", DEFAULT_WARN_THRESHOLDS)
        escalations = am.get("escalations", ESCALATION_PUNISHMENTS)

        embed = build(title="⚙️ AutoMod Punishment Configuration", color=Config.COLOR_INFO, bot=self.bot)

        for module in ALL_MODULES:
            mod_label = MODULE_LABELS.get(module, module)
            punishment = punishments.get(module, "delete")
            threshold = thresholds.get(module, 3)
            escalation = escalations.get(module, "timeout")

            pun_label = PUNISHMENT_TYPES.get(punishment, punishment)
            esc_label = PUNISHMENT_TYPES.get(escalation, escalation)

            embed.add_field(
                name=f"📋 {mod_label}",
                value=(
                    f"**Action:** {pun_label}\n"
                    f"**Threshold:** {threshold} warnings\n"
                    f"**Escalation:** {esc_label}"
                ),
                inline=True
            )

        embed.set_footer(text="Use /am punishment, /am threshold, /am escalation to modify")
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @slash.command(name="warns", description="View warnings for a user.")
    @app_commands.describe(
        member="User to check",
        module="Specific module (optional)"
    )
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def slash_warns(self, interaction: discord.Interaction, member: discord.Member, module: str = None):
        if module and module not in ALL_MODULES:
            modules = ", ".join(ALL_MODULES)
            return await interaction.response.send_message(
                f"❌ Invalid module. Choose from: `{modules}`",
                ephemeral=True
            )

        if module:
            warns = _get_warns(interaction.guild.id, member.id, module)
            if not warns:
                return await interaction.response.send_message(
                    f"✅ {member.mention} has no warnings for **{MODULE_LABELS.get(module, module)}**.",
                    ephemeral=True
                )

            embed = build(title=f"⚠️ Warnings for {member.display_name} - {MODULE_LABELS.get(module, module)}", color=Config.COLOR_WARN, bot=self.bot)
            embed.set_thumbnail(url=member.display_avatar.url)

            lines = []
            for i, w in enumerate(warns, 1):
                time_str = datetime.fromisoformat(w["time"]).strftime("%Y-%m-%d %H:%M")
                lines.append(f"**{i}.** {time_str} • {w['reason']}")
            embed.description = "\n".join(lines)
            embed.set_footer(text=f"Total: {len(warns)} warnings")
            await interaction.response.send_message(embed=embed, ephemeral=True)
        else:
            data = load(WARN_FILE)
            user_data = data.get(str(interaction.guild.id), {}).get(str(member.id), {})
            if not user_data:
                return await interaction.response.send_message(
                    f"✅ {member.mention} has no warnings.",
                    ephemeral=True
                )

            embed = build(title=f"⚠️ All Warnings for {member.display_name}", color=Config.COLOR_WARN, bot=self.bot)
            embed.set_thumbnail(url=member.display_avatar.url)

            total = 0
            for mod, warns in user_data.items():
                mod_label = MODULE_LABELS.get(mod, mod)
                embed.add_field(
                    name=f"📋 {mod_label}",
                    value=f"{len(warns)} warning(s)",
                    inline=True
                )
                total += len(warns)
            embed.set_footer(text=f"Total: {total} warnings across {len(user_data)} modules")
            await interaction.response.send_message(embed=embed, ephemeral=True)

    @slash.command(name="clearwarns", description="Clear warnings for a user.")
    @app_commands.describe(
        member="User to clear warnings for",
        module="Specific module (optional)"
    )
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def slash_clearwarns(self, interaction: discord.Interaction, member: discord.Member, module: str = None):
        if module and module not in ALL_MODULES:
            modules = ", ".join(ALL_MODULES)
            return await interaction.response.send_message(
                f"❌ Invalid module. Choose from: `{modules}`",
                ephemeral=True
            )

        if module:
            if _clear_warns(interaction.guild.id, member.id, module):
                mod_label = MODULE_LABELS.get(module, module)
                await interaction.response.send_message(
                    f"✅ Cleared warnings for {member.mention} in **{mod_label}**.",
                    ephemeral=True
                )
            else:
                await interaction.response.send_message(
                    f"✅ {member.mention} has no warnings in that module.",
                    ephemeral=True
                )
        else:
            if _clear_all_warns(interaction.guild.id, member.id):
                await interaction.response.send_message(
                    f"✅ Cleared all warnings for {member.mention}.",
                    ephemeral=True
                )
            else:
                await interaction.response.send_message(
                    f"✅ {member.mention} has no warnings.",
                    ephemeral=True
                )

    @slash.command(name="wlu", description="Toggle a user's exemption for ONE automod module.")
    @app_commands.describe(module="The specific module to whitelist for", user="User to whitelist/unwhitelist")
    @app_commands.choices(module=MODULE_CHOICES)
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def slash_wl_user(self, interaction: discord.Interaction, module: str, user: discord.Member):
        added = self._toggle_wl_entry(interaction.guild.id, module, "users", user.id)
        label = MODULE_LABELS[module]
        msg = f"✅ {user.mention} whitelisted from **{label}**." if added else f"➖ {user.mention} removed from **{label}** whitelist."
        await interaction.response.send_message(msg, ephemeral=True)

    @slash.command(name="wlr", description="Toggle a role's exemption for ONE automod module.")
    @app_commands.describe(module="The specific module to whitelist for", role="Role to whitelist/unwhitelist")
    @app_commands.choices(module=MODULE_CHOICES)
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def slash_wl_role(self, interaction: discord.Interaction, module: str, role: discord.Role):
        added = self._toggle_wl_entry(interaction.guild.id, module, "roles", role.id)
        label = MODULE_LABELS[module]
        msg = f"✅ {role.mention} whitelisted from **{label}**." if added else f"➖ {role.mention} removed from **{label}** whitelist."
        await interaction.response.send_message(msg, ephemeral=True)

    @slash.command(name="wlc", description="Toggle a channel's exemption for ONE automod module.")
    @app_commands.describe(module="The specific module to whitelist for", channel="Channel to whitelist (defaults to current)")
    @app_commands.choices(module=MODULE_CHOICES)
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def slash_wl_channel(self, interaction: discord.Interaction, module: str, channel: discord.TextChannel = None):
        ch    = channel or interaction.channel
        added = self._toggle_wl_entry(interaction.guild.id, module, "channels", ch.id)
        label = MODULE_LABELS[module]
        msg = f"✅ {ch.mention} whitelisted from **{label}**." if added else f"➖ {ch.mention} removed from **{label}** whitelist."
        await interaction.response.send_message(msg, ephemeral=True)

    @slash.command(name="wlcat", description="Toggle a category's exemption for ONE automod module.")
    @app_commands.describe(module="The specific module to whitelist for", category="Category to whitelist")
    @app_commands.choices(module=MODULE_CHOICES)
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def slash_wl_category(self, interaction: discord.Interaction, module: str, category: discord.CategoryChannel):
        added = self._toggle_wl_entry(interaction.guild.id, module, "categories", category.id)
        label = MODULE_LABELS[module]
        msg = f"✅ Category **{category.name}** whitelisted from **{label}**." if added else f"➖ Category **{category.name}** removed from **{label}** whitelist."
        await interaction.response.send_message(msg, ephemeral=True)

    @slash.command(name="wllist", description="Show per-module whitelists.")
    @app_commands.describe(module="Filter to a specific module (leave empty to show all)")
    @app_commands.choices(module=MODULE_CHOICES)
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def slash_wl_list(self, interaction: discord.Interaction, module: str = None):
        await interaction.response.defer(ephemeral=True)
        am      = self._settings(interaction.guild.id)
        modules = [module] if module else ALL_MODULES
        e = build(title="🛡️ AutoMod Per-Module Whitelists", color=Config.COLOR_MOD, bot=self.bot)
        for mod in modules:
            wl    = am.get("module_whitelist", {}).get(mod, {})
            lines = []
            for uid in wl.get("users", []): lines.append(f"👤 <@{uid}>")
            for rid in wl.get("roles", []): lines.append(f"🎭 <@&{rid}>")
            for cid in wl.get("channels", []): lines.append(f"📢 <#{cid}>")
            for cat_id in wl.get("categories", []):
                cat = interaction.guild.get_channel(cat_id)
                lines.append(f"📁 {cat.name if cat else f'Category {cat_id}'}")
            e.add_field(name=MODULE_LABELS[mod], value="\n".join(lines) if lines else "*None*", inline=True)
        await interaction.followup.send(embed=e, ephemeral=True)

    @slash.command(name="wlclear", description="Clear ALL whitelist entries for a specific module.")
    @app_commands.describe(module="Module to clear whitelists for")
    @app_commands.choices(module=MODULE_CHOICES)
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def slash_wl_clear(self, interaction: discord.Interaction, module: str):
        data = load("guild_settings.json")
        am   = data.setdefault(str(interaction.guild.id), {}).setdefault("automod", {})
        am.setdefault("module_whitelist", {})[module] = _empty_module_wl()
        save("guild_settings.json", data)
        await interaction.response.send_message(f"🗑️ Cleared all whitelist entries for **{MODULE_LABELS[module]}**.", ephemeral=True)

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            missing = ", ".join(p.replace("_", " ").title() for p in error.missing_permissions)
            print(f"[AutoMod] {interaction.user} ({interaction.user.id}) missing permissions: {missing}")
            try:
                await interaction.response.send_message(
                    f"❌ You are missing the required permissions: **{missing}**.",
                    ephemeral=True,
                )
            except discord.InteractionResponded:
                await interaction.followup.send(
                    f"❌ You are missing the required permissions: **{missing}**.",
                    ephemeral=True,
                )

async def setup(bot):
    await bot.add_cog(AutoMod(bot))
