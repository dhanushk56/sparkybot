import discord
from discord.ext import commands
from discord import app_commands
from datetime import datetime, timezone
from config import Config
from utils.embed import build
from utils.theme import Theme
from utils.data import load, save

def _settings(guild_id: int) -> dict:
    data = load("guild_settings.json")
    return data.get(str(guild_id), {})

def _format(template: str, member: discord.Member) -> str:
    if not template:
        return ""
    return (
        template
        .replace("{user}",        member.mention)
        .replace("{username}",    str(member))
        .replace("{displayname}", member.display_name)
        .replace("{servername}",  member.guild.name)
        .replace("{server}",      member.guild.name)
        .replace("{membercount}", str(member.guild.member_count))
        .replace("{id}",          str(member.id))
    )

class WelcomeConfigModal(discord.ui.Modal, title="⚙️ Welcome Configuration"):

    embed_title = discord.ui.TextInput(
        label="Embed Title",
        placeholder="Welcome to {servername}!",
        required=False,
        max_length=256
    )

    embed_description = discord.ui.TextInput(
        label="Embed Description",
        placeholder="👋 Welcome {user} to **{servername}**!\nYou are member #{membercount}.",
        style=discord.TextStyle.paragraph,
        required=False,
        max_length=4000
    )

    embed_footer = discord.ui.TextInput(
        label="Embed Footer",
        placeholder="ID: {id} • {servername}",
        required=False,
        max_length=2048
    )

    outside_content = discord.ui.TextInput(
        label="Text Outside Embed (pings the user)",
        placeholder="{user}",
        required=False,
        max_length=2000
    )

    dm_message = discord.ui.TextInput(
        label="DM Message (leave empty to disable)",
        placeholder="Welcome to {servername}, {user}! 🎉",
        style=discord.TextStyle.paragraph,
        required=False,
        max_length=2000
    )

    def __init__(self, guild_id: int, bot):
        super().__init__()
        self.guild_id = guild_id
        self.bot = bot

        settings = _settings(guild_id)
        self.embed_title.default = settings.get("welcome_embed_title", "Welcome to {servername}!")
        self.embed_description.default = settings.get("welcome_embed_description", "👋 Welcome {user} to **{servername}**!\nYou are member #{membercount}.")
        self.embed_footer.default = settings.get("welcome_embed_footer", "ID: {id} • {servername}")
        self.outside_content.default = settings.get("welcome_outside_content", "{user}")
        self.dm_message.default = settings.get("welcome_dm", "Welcome to {servername}, {user}! 🎉")

    async def on_submit(self, interaction: discord.Interaction):
        data = load("guild_settings.json")
        gd = data.setdefault(str(self.guild_id), {})

        gd["welcome_embed_title"] = self.embed_title.value.strip() or None
        gd["welcome_embed_description"] = self.embed_description.value.strip() or None
        gd["welcome_embed_footer"] = self.embed_footer.value.strip() or None
        gd["welcome_outside_content"] = self.outside_content.value.strip() or None
        gd["welcome_dm"] = self.dm_message.value.strip() or None

        save("guild_settings.json", data)

        embed = build(title="✅ Welcome Configuration Saved", description="Your welcome message settings have been updated.", color=Config.COLOR_OK, bot=self.bot)
        embed.add_field(name="📤 Outside Embed", value=gd.get("welcome_outside_content", "{user}") or "None", inline=False)
        embed.add_field(name="📊 Embed Title", value=gd.get("welcome_embed_title", "Welcome to {servername}!") or "None", inline=False)
        embed.add_field(name="📝 Embed Description", value=gd.get("welcome_embed_description", "👋 Welcome {user} to **{servername}**!\nYou are member #{membercount}.")[:200] + "..." or "None", inline=False)
        embed.add_field(name="💬 DM Message", value=gd.get("welcome_dm", "Welcome to {servername}, {user}! 🎉") or "Disabled", inline=False)
        embed.set_footer(text="Use /wel preview to see the actual message")
        await interaction.response.send_message(embed=embed, ephemeral=True)

class GoodbyeConfigModal(discord.ui.Modal, title="⚙️ Goodbye Configuration"):
    embed_description = discord.ui.TextInput(
        label="Embed Description",
        placeholder="👋 Goodbye {username}!\nWe now have {membercount} members.",
        style=discord.TextStyle.paragraph,
        required=False,
        max_length=4000
    )
    embed_footer = discord.ui.TextInput(
        label="Embed Footer",
        placeholder="ID: {id}",
        required=False,
        max_length=2048
    )
    outside_content = discord.ui.TextInput(
        label="Text Outside Embed",
        placeholder="{username} has left.",
        required=False,
        max_length=2000
    )

    def __init__(self, guild_id: int, bot):
        super().__init__()
        self.guild_id = guild_id
        self.bot = bot
        settings = _settings(guild_id)
        self.embed_description.default = settings.get("goodbye_embed_description", "👋 Goodbye {username}!\nWe now have {membercount} members.")
        self.embed_footer.default = settings.get("goodbye_embed_footer", "ID: {id}")
        self.outside_content.default = settings.get("goodbye_outside_content", "")

    async def on_submit(self, interaction: discord.Interaction):
        data = load("guild_settings.json")
        gd = data.setdefault(str(self.guild_id), {})
        gd["goodbye_embed_description"] = self.embed_description.value.strip() or None
        gd["goodbye_embed_footer"] = self.embed_footer.value.strip() or None
        gd["goodbye_outside_content"] = self.outside_content.value.strip() or None
        save("guild_settings.json", data)
        embed = build(title="✅ Goodbye Configuration Saved", description="Your goodbye message settings have been updated.", color=Config.COLOR_OK, bot=self.bot)
        embed.add_field(name="📤 Outside Embed", value=gd.get("goodbye_outside_content", "") or "None", inline=False)
        embed.add_field(name="📝 Embed Description", value=gd.get("goodbye_embed_description", "👋 Goodbye {username}!\nWe now have {membercount} members.")[:200] + "..." or "None", inline=False)
        embed.set_footer(text="Use /wel preview goodbye to see the actual message")
        await interaction.response.send_message(embed=embed, ephemeral=True)

class Welcome(commands.Cog):

    slash = app_commands.Group(name="wel", description="Welcome and auto-role configuration")

    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        s = _settings(member.guild.id)

        if not s.get("welcome_enabled", True):
            return

        for role_id in s.get("autoroles", []):
            role = member.guild.get_role(int(role_id))
            if role:
                try:
                    await member.add_roles(role, reason="Auto-role on join")
                except Exception:
                    pass
        ch_id = s.get("welcome_channel")
        if not ch_id:
            return
        ch = member.guild.get_channel(int(ch_id))
        if not ch:
            return
        title = _format(s.get("welcome_embed_title", "Welcome to {servername}!"), member)
        desc = _format(s.get("welcome_embed_description", "👋 Welcome {user} to **{servername}**!\nYou are member #{membercount}."), member)
        footer = _format(s.get("welcome_embed_footer", "ID: {id} • {servername}"), member)
        outside = _format(s.get("welcome_outside_content", "{user}"), member)
        dm = _format(s.get("welcome_dm", ""), member)
        if s.get("welcome_embed", True):
            e = build(title=title or None, description=desc or None, color=Config.COLOR_OK, bot=self.bot)
            if footer:
                e.set_footer(text=footer)
            e.set_author(name=f"Welcome to {member.guild.name}!", icon_url=member.guild.icon.url if member.guild.icon else None)
            e.set_thumbnail(url=member.display_avatar.url)
            await ch.send(content=outside or None, embed=e)
        else:
            if desc:
                await ch.send(desc)
        if dm:
            try:
                await member.send(dm)
            except Exception:
                pass

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        s = _settings(member.guild.id)
        ch_id = s.get("goodbye_channel")
        if not ch_id:
            return
        ch = member.guild.get_channel(int(ch_id))
        if not ch:
            return
        desc = _format(s.get("goodbye_embed_description", "👋 Goodbye {username}!\nWe now have {membercount} members."), member)
        footer = _format(s.get("goodbye_embed_footer", "ID: {id}"), member)
        outside = _format(s.get("goodbye_outside_content", ""), member)
        if s.get("goodbye_embed", True):
            e = build(description=desc or None, color=Config.COLOR_ERR, bot=self.bot)
            if footer:
                e.set_footer(text=footer)
            e.set_thumbnail(url=member.display_avatar.url)
            await ch.send(content=outside or None, embed=e)
        else:
            if desc:
                await ch.send(desc)

    @commands.command(name="welset")
    @commands.has_permissions(manage_guild=True)
    async def welset(self, ctx, channel: discord.TextChannel):
        data = load("guild_settings.json")
        data.setdefault(str(ctx.guild.id), {})["welcome_channel"] = channel.id
        save("guild_settings.json", data)
        await ctx.reply(f"✅ Welcome channel set to {channel.mention}.")

    @commands.command(name="goodbyeset")
    @commands.has_permissions(manage_guild=True)
    async def goodbyeset(self, ctx, channel: discord.TextChannel):
        data = load("guild_settings.json")
        data.setdefault(str(ctx.guild.id), {})["goodbye_channel"] = channel.id
        save("guild_settings.json", data)
        await ctx.reply(f"✅ Goodbye channel set to {channel.mention}.")

    @commands.command(name="welmsg")
    @commands.has_permissions(manage_guild=True)
    async def welmsg(self, ctx, *, message: str):
        data = load("guild_settings.json")
        data.setdefault(str(ctx.guild.id), {})["welcome_embed_description"] = message
        save("guild_settings.json", data)
        await ctx.reply(f"✅ Welcome message updated:\n> {message}")

    @commands.command(name="goodbyemsg")
    @commands.has_permissions(manage_guild=True)
    async def goodbyemsg(self, ctx, *, message: str):
        data = load("guild_settings.json")
        data.setdefault(str(ctx.guild.id), {})["goodbye_embed_description"] = message
        save("guild_settings.json", data)
        await ctx.reply(f"✅ Goodbye message updated:\n> {message}")

    @commands.command(name="weldm")
    @commands.has_permissions(manage_guild=True)
    async def weldmset(self, ctx, *, message: str = None):
        data = load("guild_settings.json")
        data.setdefault(str(ctx.guild.id), {})["welcome_dm"] = message
        save("guild_settings.json", data)
        if message:
            await ctx.reply(f"✅ Welcome DM set:\n> {message}")
        else:
            await ctx.reply("✅ Welcome DM disabled.")

    @commands.command(name="autorole")
    @commands.has_permissions(manage_roles=True)
    async def autorole(self, ctx, role: discord.Role):
        data = load("guild_settings.json")
        gd = data.setdefault(str(ctx.guild.id), {})
        roles = gd.setdefault("autoroles", [])
        if role.id in roles:
            roles.remove(role.id)
            msg = f"➖ Removed {role.mention} from auto-roles."
        else:
            roles.append(role.id)
            msg = f"➕ Added {role.mention} to auto-roles."
        gd["autoroles"] = roles
        save("guild_settings.json", data)
        await ctx.reply(msg)

    @commands.command(name="autoroles")
    @commands.has_permissions(manage_roles=True)
    async def autoroles_list(self, ctx):
        s = _settings(ctx.guild.id)
        role_ids = s.get("autoroles", [])
        if not role_ids:
            return await ctx.reply("No auto-roles configured.")
        roles = [ctx.guild.get_role(rid) for rid in role_ids]
        await ctx.reply("**Auto-roles:** " + ", ".join(r.mention for r in roles if r))

    @commands.command(name="welembed")
    @commands.has_permissions(manage_guild=True)
    async def welembed_toggle(self, ctx):
        data = load("guild_settings.json")
        gd = data.setdefault(str(ctx.guild.id), {})
        gd["welcome_embed"] = not gd.get("welcome_embed", True)
        save("guild_settings.json", data)
        await ctx.reply(f"✅ Welcome embed: **{'on' if gd['welcome_embed'] else 'off'}**.")

    @commands.command(name="welpreview")
    @commands.has_permissions(manage_guild=True)
    async def welpreview(self, ctx):
        s = _settings(ctx.guild.id)
        desc = _format(s.get("welcome_embed_description", "👋 Welcome {user} to **{servername}**! You are member **#{membercount}**."), ctx.author)
        title = _format(s.get("welcome_embed_title", "Welcome to {servername}!"), ctx.author)
        footer = _format(s.get("welcome_embed_footer", "ID: {id} • {servername}"), ctx.author)
        outside = _format(s.get("welcome_outside_content", "{user}"), ctx.author)
        if s.get("welcome_embed", True):
            e = build(title=title or None, description=desc or None, color=Config.COLOR_OK, bot=self.bot)
            if footer:
                e.set_footer(text=footer)
            e.set_author(name=f"Welcome to {ctx.guild.name}!", icon_url=ctx.guild.icon.url if ctx.guild.icon else None)
            e.set_thumbnail(url=ctx.author.display_avatar.url)
            await ctx.reply(content=f"**Preview (Outside Embed):** {outside or 'None'}", embed=e)
        else:
            await ctx.reply(f"**Preview:**\n{desc}")

    @commands.command(name="goodbyepreview")
    @commands.has_permissions(manage_guild=True)
    async def goodbyepreview(self, ctx):
        s = _settings(ctx.guild.id)
        desc = _format(s.get("goodbye_embed_description", "👋 Goodbye {username}!\nWe now have {membercount} members."), ctx.author)
        footer = _format(s.get("goodbye_embed_footer", "ID: {id}"), ctx.author)
        outside = _format(s.get("goodbye_outside_content", ""), ctx.author)
        if s.get("goodbye_embed", True):
            e = build(description=desc or None, color=Config.COLOR_ERR, bot=self.bot)
            if footer:
                e.set_footer(text=footer)
            e.set_thumbnail(url=ctx.author.display_avatar.url)
            e.set_author(name="Goodbye Preview", icon_url=ctx.guild.icon.url if ctx.guild.icon else None)
            await ctx.reply(content=f"**📤 Outside Embed:** {outside or 'None'}" if outside else None, embed=e)
        else:
            await ctx.reply(f"**Preview:**\n{desc}")

    @commands.command(name="weltoggle")
    @commands.has_permissions(manage_guild=True)
    async def weltoggle(self, ctx, enabled: bool = None):
        data = load("guild_settings.json")
        gd = data.setdefault(str(ctx.guild.id), {})
        current = gd.get("welcome_enabled", True)
        if enabled is None:
            new_state = not current
        else:
            new_state = enabled
        gd["welcome_enabled"] = new_state
        save("guild_settings.json", data)
        await ctx.reply(f"✅ Welcome system {'enabled' if new_state else 'disabled'}.")

    @slash.command(name="set", description="Set the welcome message channel.")
    @app_commands.describe(channel="Channel to send welcome messages to")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def setwelcome_slash(self, interaction: discord.Interaction, channel: discord.TextChannel):
        ctx = await commands.Context.from_interaction(interaction)
        await self.welset.callback(self, ctx, channel)

    @slash.command(name="setgoodbye", description="Set the goodbye message channel.")
    @app_commands.describe(channel="Channel to send goodbye messages to")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def setgoodbye_slash(self, interaction: discord.Interaction, channel: discord.TextChannel):
        ctx = await commands.Context.from_interaction(interaction)
        await self.goodbyeset.callback(self, ctx, channel)

    @slash.command(name="config", description="Configure welcome message with a modal popup.")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def welcome_config(self, interaction: discord.Interaction):
        try:
            await interaction.response.send_modal(WelcomeConfigModal(interaction.guild.id, self.bot))
        except Exception as e:
            print(f"[Welcome] Error opening modal: {e}")
            await interaction.response.send_message("❌ Failed to open configuration modal. Please try again.", ephemeral=True)

    @slash.command(name="goodbyeconfig", description="Configure goodbye message with a modal popup.")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def goodbye_config(self, interaction: discord.Interaction):
        try:
            await interaction.response.send_modal(GoodbyeConfigModal(interaction.guild.id, self.bot))
        except Exception as e:
            print(f"[Welcome] Error opening modal: {e}")
            await interaction.response.send_message("❌ Failed to open configuration modal. Please try again.", ephemeral=True)

    @slash.command(name="setmsg", description="Set the welcome message text.")
    @app_commands.describe(message="Message text. Use {user} {servername} {membercount} etc.")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def setmsg_slash(self, interaction: discord.Interaction, message: str):
        ctx = await commands.Context.from_interaction(interaction)
        await self.welmsg.callback(self, ctx, message=message)

    @slash.command(name="setgoodbyemsg", description="Set the goodbye message text.")
    @app_commands.describe(message="Message text. Use {username} {servername} {membercount} etc.")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def setgoodbyemsg_slash(self, interaction: discord.Interaction, message: str):
        ctx = await commands.Context.from_interaction(interaction)
        await self.goodbyemsg.callback(self, ctx, message=message)

    @slash.command(name="setdm", description="Set the DM sent to new members (leave empty to disable).")
    @app_commands.describe(message="DM message text, or leave empty to disable")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def setdm_slash(self, interaction: discord.Interaction, message: str = None):
        ctx = await commands.Context.from_interaction(interaction)
        await self.weldmset.callback(self, ctx, message=message)

    @slash.command(name="autorole", description="Add or remove an auto-role assigned on join.")
    @app_commands.describe(role="Role to add/remove from auto-roles")
    @app_commands.default_permissions(manage_roles=True)
    @app_commands.checks.has_permissions(manage_roles=True)
    async def autorole_slash(self, interaction: discord.Interaction, role: discord.Role):
        ctx = await commands.Context.from_interaction(interaction)
        await self.autorole.callback(self, ctx, role)

    @slash.command(name="listautoroles", description="List all auto-roles assigned on join.")
    @app_commands.default_permissions(manage_roles=True)
    @app_commands.checks.has_permissions(manage_roles=True)
    async def listautoroles_slash(self, interaction: discord.Interaction):
        ctx = await commands.Context.from_interaction(interaction)
        await self.autoroles_list.callback(self, ctx)

    @slash.command(name="toggleembed", description="Toggle embed style for welcome/goodbye messages.")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def toggleembed_slash(self, interaction: discord.Interaction):
        ctx = await commands.Context.from_interaction(interaction)
        await self.welembed_toggle.callback(self, ctx)

    @slash.command(name="preview", description="Preview the welcome or goodbye message.")
    @app_commands.describe(message_type="Which message to preview")
    @app_commands.choices(message_type=[
        app_commands.Choice(name="Welcome", value="welcome"),
        app_commands.Choice(name="Goodbye", value="goodbye"),
    ])
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def preview_slash(self, interaction: discord.Interaction, message_type: str = "welcome"):
        s = _settings(interaction.guild.id)
        if message_type == "goodbye":
            desc = _format(s.get("goodbye_embed_description", "👋 Goodbye {username}!\nWe now have {membercount} members."), interaction.user)
            footer = _format(s.get("goodbye_embed_footer", "ID: {id}"), interaction.user)
            outside = _format(s.get("goodbye_outside_content", ""), interaction.user)
            color = Config.COLOR_ERR
            title = "Goodbye Preview"
        else:
            desc = _format(s.get("welcome_embed_description", "👋 Welcome {user} to **{servername}**! You are member #{membercount}."), interaction.user)
            title = _format(s.get("welcome_embed_title", "Welcome to {servername}!"), interaction.user)
            footer = _format(s.get("welcome_embed_footer", "ID: {id} • {servername}"), interaction.user)
            outside = _format(s.get("welcome_outside_content", "{user}"), interaction.user)
            color = Config.COLOR_OK
        if s.get("welcome_embed", True):
            e = build(title=title or None, description=desc or None, color=color, bot=self.bot)
            if footer:
                e.set_footer(text=footer)
            e.set_thumbnail(url=interaction.user.display_avatar.url)
            e.set_author(name=f"{message_type.title()} Preview", icon_url=interaction.guild.icon.url if interaction.guild.icon else None)
            await interaction.response.send_message(content=f"**📤 Outside Embed:** {outside or 'None'}" if outside else None, embed=e, ephemeral=True)
        else:
            await interaction.response.send_message(f"**Preview:**\n{desc}", ephemeral=True)

    @slash.command(name="toggle", description="Enable or disable the welcome system entirely.")
    @app_commands.describe(enabled="True to enable, False to disable (leave empty to toggle)")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def welcome_toggle(self, interaction: discord.Interaction, enabled: bool = None):
        data = load("guild_settings.json")
        gd = data.setdefault(str(interaction.guild.id), {})
        current = gd.get("welcome_enabled", True)
        if enabled is None:
            new_state = not current
        else:
            new_state = enabled
        gd["welcome_enabled"] = new_state
        save("guild_settings.json", data)
        embed = build(title="✅ Welcome System " + ("Enabled" if new_state else "Disabled"), description=f"Welcome messages are now **{'ON' if new_state else 'OFF'}**.", color=Config.COLOR_OK if new_state else Config.COLOR_ERR, bot=self.bot)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            missing = ", ".join(p.replace("_", " ").title() for p in error.missing_permissions)
            print(f"[Welcome] {interaction.user} ({interaction.user.id}) missing permissions: {missing}")
            try:
                await interaction.response.send_message(f"❌ You are missing the required permissions: **{missing}**.", ephemeral=True)
            except discord.InteractionResponded:
                await interaction.followup.send(f"❌ You are missing the required permissions: **{missing}**.", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Welcome(bot))
