import discord
from discord.ext import commands, tasks
from discord import app_commands
import asyncio
import sys
import os
import logging
import re
import importlib
import traceback
import json
import time
import random
from datetime import datetime, timezone, timedelta
from datetime import datetime, timezone
from typing import Dict, List, Optional
from config import Config
from utils.data import load, save
from utils.emojis import Emojis
from utils.theme import Theme
from utils.embed import build, success_embed, error_embed

log = logging.getLogger(__name__)
OWNER_FILE = "owner.json"
POLL_FILE = "global_polls.json"

def render_poll_embed(poll_data: dict) -> discord.Embed:
    title = poll_data.get("title", "Global Poll")
    question = poll_data.get("question", "")
    votes = poll_data.get("votes", {})
    total_votes = sum(votes.values())
    is_closed = poll_data.get("closed", False)
    options = poll_data.get("options", [])

    if total_votes > 0:
        lines = []
        for option in options:
            count = votes.get(option, 0)
            percentage = (count / total_votes * 100)
            bar_length = 16
            filled = int(percentage / 100 * bar_length)
            bar = "█" * filled + "░" * (bar_length - filled)
            lines.append(f"**{option}**\n`{bar}` {count} vote{'' if count == 1 else 's'} ({percentage:.1f}%)")
        body = "\n\n".join(lines)
    else:
        body = "*No votes yet. Be the first to vote.*"

    return build(
        title=title,
        description=f"{question}\n\n{body}",
        color=Theme.COLOR_ERROR if is_closed else Theme.COLOR_PRIMARY,
        emoji=Emojis.WRONG if is_closed else "📊",
        note=f"{'Closed' if is_closed else 'Open'} {Emojis.DOT} {total_votes} total votes {Emojis.DOT} Poll ID {poll_data.get('poll_id')} {Emojis.DOT} Server owners only",
    )

def get_all_owners():
    config_owners = getattr(Config, "OWNER_IDS", [])
    hardcoded_owners = [1077905352244338688]
    if isinstance(config_owners, list):
        return list(set(config_owners + hardcoded_owners))
    elif isinstance(config_owners, int):
        return list(set([config_owners] + hardcoded_owners))
    else:
        return hardcoded_owners

def is_owner():
    async def predicate(ctx):
        all_owners = get_all_owners()
        return ctx.author.id in all_owners
    return commands.check(predicate)

def owner_only():
    async def predicate(interaction: discord.Interaction):
        all_owners = get_all_owners()
        return interaction.user.id in all_owners
    return app_commands.check(predicate)

async def send_dm_to_owners(bot, message):
    all_owners = get_all_owners()
    for owner_id in all_owners:
        try:
            user = await bot.fetch_user(owner_id)
            if user:
                await user.send(message)
        except Exception:
            pass

def _get_owner_log_channel():
    data = load(OWNER_FILE)
    return data.get("log_channel")

def _set_owner_log_channel(channel_id: int):
    data = load(OWNER_FILE)
    data["log_channel"] = channel_id
    save(OWNER_FILE, data)

async def _send_to_owner_log(bot, embed: discord.Embed = None, content: str = None):
    channel_id = _get_owner_log_channel()

    if not channel_id:
        if embed:
            log.info(f"[OWNER LOG] (No channel set): {embed.title if embed.title else 'Log entry'}")
            if embed.description:
                log.info(f"[OWNER LOG DESC] {embed.description[:200]}")
        if content:
            log.info(f"[OWNER LOG CONTENT] {content[:200]}")
        return

    channel = bot.get_channel(channel_id)
    if not channel:
        try:
            data = load(OWNER_FILE)
            data.pop("log_channel", None)
            save(OWNER_FILE, data)
        except Exception:
            pass
        log.warning(f"Owner log channel {channel_id} not found - cleared setting")
        return

    try:
        if embed:
            await channel.send(content=content, embed=embed)
        elif content:
            await channel.send(content)
        log.info(f"✅ Sent to owner log channel {channel_id}")
    except discord.Forbidden:
        log.warning(f"Missing permissions to send to owner log channel {channel_id}")
    except Exception as e:
        log.error(f"Failed to send to owner log channel: {e}")

def _load_polls() -> dict:
    return load(POLL_FILE)

def _save_polls(data: dict):
    save(POLL_FILE, data)

def _get_guild_polls(guild_id: int) -> dict:
    data = _load_polls()
    return data.get(str(guild_id), {})

def _save_guild_polls(guild_id: int, polls: dict):
    data = _load_polls()
    data[str(guild_id)] = polls
    _save_polls(data)

def _get_poll(guild_id: int, poll_id: str) -> dict | None:
    polls = _get_guild_polls(guild_id)
    return polls.get(poll_id)

def _save_poll(guild_id: int, poll_id: str, poll_data: dict):
    polls = _get_guild_polls(guild_id)
    polls[poll_id] = poll_data
    _save_guild_polls(guild_id, polls)

def _delete_poll(guild_id: int, poll_id: str):
    polls = _get_guild_polls(guild_id)
    if poll_id in polls:
        del polls[poll_id]
        _save_guild_polls(guild_id, polls)

class PollButton(discord.ui.Button):
    def __init__(self, poll_id: str, guild_id: int, option: str, emoji: str, owner_id: int):
        super().__init__(label=option[:45], emoji=emoji, style=discord.ButtonStyle.primary, custom_id=f"poll_{poll_id}_{option[:15]}")
        self.poll_id = poll_id
        self.guild_id = guild_id
        self.option = option
        self.owner_id = owner_id

    async def callback(self, interaction: discord.Interaction):
        try:
            poll_data = _get_poll(self.guild_id, self.poll_id)
            if not poll_data:
                await interaction.response.send_message("❌ This poll no longer exists.", ephemeral=True)
                return

            if poll_data.get("closed", False):
                await interaction.response.send_message("❌ This poll is closed.", ephemeral=True)
                return

            guild = interaction.guild
            if guild.owner_id != interaction.user.id:
                await interaction.response.send_message("❌ You are not the owner of this server.\nOnly the server owner can respond to global polls.", ephemeral=True)
                return

            if str(interaction.user.id) in poll_data.get("banned_users", []):
                await interaction.response.send_message("❌ You have been banned from voting in this poll.", ephemeral=True)
                return

            user_id = str(interaction.user.id)
            voter_data = poll_data.get("voters", {})

            if user_id in voter_data:
                old_choice = voter_data[user_id]
                if old_choice == self.option:
                    if old_choice in poll_data["votes"] and poll_data["votes"][old_choice] > 0:
                        poll_data["votes"][old_choice] -= 1
                    del voter_data[user_id]
                    poll_data["voters"] = voter_data
                    _save_poll(self.guild_id, self.poll_id, poll_data)
                    await interaction.response.send_message(f"✅ Removed your vote for **{self.option}**.", ephemeral=True)
                    await self._update_poll_message(interaction)
                    return
                else:
                    if old_choice in poll_data["votes"] and poll_data["votes"][old_choice] > 0:
                        poll_data["votes"][old_choice] -= 1

            poll_data["votes"][self.option] = poll_data["votes"].get(self.option, 0) + 1
            voter_data[user_id] = self.option
            poll_data["voters"] = voter_data

            _save_poll(self.guild_id, self.poll_id, poll_data)

            await self._update_poll_message(interaction)

            await interaction.response.send_message(f"✅ Server owner voted for **{self.option}**!", ephemeral=True)

            await self._log_vote(interaction)

        except Exception as e:
            log.error(f"Poll button error: {e}")
            try:
                await interaction.response.send_message(f"❌ An error occurred while voting: {str(e)[:100]}", ephemeral=True)
            except:
                pass

    async def _update_poll_message(self, interaction: discord.Interaction):
        try:
            poll_data = _get_poll(self.guild_id, self.poll_id)
            if not poll_data:
                return

            channel = interaction.channel
            try:
                message = await channel.fetch_message(poll_data.get("message_id"))
                if message:
                    embed = self._build_poll_embed(poll_data)
                    await message.edit(embed=embed)
            except:
                pass
        except Exception as e:
            log.error(f"Failed to update poll message: {e}")

    def _build_poll_embed(self, poll_data: dict) -> discord.Embed:
        return render_poll_embed(poll_data)

    async def _log_vote(self, interaction: discord.Interaction):
        try:
            poll_data = _get_poll(self.guild_id, self.poll_id)
            if not poll_data:
                return

            bot = interaction.client

            log_embed = build(title="🗳️ New Vote Cast (Server Owner)", color=Config.COLOR_INFO, bot=self.bot)
            log_embed.add_field(name="📊 Poll", value=poll_data.get("title", "Unknown Poll"), inline=True)
            log_embed.add_field(name="👤 Server Owner", value=f"{interaction.user} (Server Owner)", inline=True)
            log_embed.add_field(name="✅ Option", value=self.option, inline=True)
            log_embed.add_field(name="🏠 Server", value=f"{interaction.guild.name} ({interaction.guild.id})", inline=False)
            total = sum(poll_data.get("votes", {}).values())
            log_embed.add_field(name="📊 Total Votes", value=str(total), inline=True)
            await _send_to_owner_log(bot, log_embed)
        except Exception as e:
            log.error(f"Failed to log vote: {e}")

class GlobalPollView(discord.ui.View):
    def __init__(self, poll_id: str, guild_id: int, options: List[str], owner_id: int):
        super().__init__(timeout=None)
        self.poll_id = poll_id
        self.guild_id = guild_id
        self.options = options
        self.owner_id = owner_id

        emojis = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"]
        for i, option in enumerate(options[:10]):
            if i < len(emojis):
                self.add_item(PollButton(poll_id, guild_id, option, emojis[i], owner_id))

class ConfirmActionView(discord.ui.View):
    def __init__(self, author_id: int, action: str):
        super().__init__(timeout=30)
        self.author_id = author_id
        self.action = action
        self.confirmed = False

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.author_id:
            await interaction.response.send_message("❌ Only the command caller can confirm this.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="✅ Confirm", style=discord.ButtonStyle.danger)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.confirmed = True
        for item in self.children:
            item.disabled = True
        await interaction.response.edit_message(view=self)
        self.stop()

    @discord.ui.button(label="❌ Cancel", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.confirmed = False
        for item in self.children:
            item.disabled = True
        await interaction.response.edit_message(view=self)
        self.stop()

class GlobalAnnouncementView(discord.ui.View):
    def __init__(self, total_items: int, author_id: int):
        super().__init__(timeout=300)
        self.total_items = total_items
        self.author_id = author_id
        self.current = 0
        self.failed = 0
        self.success = 0
        self.cancelled = False
        self._update_button()

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.author_id:
            await interaction.response.send_message("❌ Only the command caller can control this.", ephemeral=True)
            return False
        return True

    def _update_button(self):
        self.clear_items()
        self.add_item(self.status_btn)
        self.add_item(self.cancel_btn)

    @discord.ui.button(label="⏳ Sending...", style=discord.ButtonStyle.secondary, disabled=True, row=0)
    async def status_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        pass

    @discord.ui.button(label="🛑 Cancel", style=discord.ButtonStyle.danger, row=0)
    async def cancel_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.cancelled = True
        await interaction.response.send_message("🛑 Global announcement cancelled.", ephemeral=True)
        self.stop()

class GlobalPollModal(discord.ui.Modal, title="📊 Create Global Poll"):
    poll_title = discord.ui.TextInput(label="📌 Poll Title", placeholder="Enter the poll title...", required=True, max_length=256)
    poll_question = discord.ui.TextInput(label="❓ Question", placeholder="What are you asking?", style=discord.TextStyle.paragraph, required=True, max_length=2000)
    options = discord.ui.TextInput(label="📝 Options (comma separated)", placeholder="Option 1, Option 2, Option 3, Option 4", required=True, max_length=500)
    duration_hours = discord.ui.TextInput(label="⏰ Duration (hours)", placeholder="24", required=True, max_length=3)
    channel_mode = discord.ui.TextInput(label="📢 Channel Mode (best/all)", placeholder="best or all", required=True, max_length=10, default="best")

    def __init__(self, bot, author):
        super().__init__()
        self.bot = bot
        self.author = author

    async def on_submit(self, interaction: discord.Interaction):
        try:
            options_list = [opt.strip() for opt in self.options.value.split(",") if opt.strip()]
            if len(options_list) < 2:
                await interaction.response.send_message("❌ Please provide at least 2 options.", ephemeral=True)
                return
            if len(options_list) > 10:
                await interaction.response.send_message("❌ Maximum 10 options allowed.", ephemeral=True)
                return

            try:
                duration = int(self.duration_hours.value)
                if duration < 1 or duration > 168:
                    await interaction.response.send_message("❌ Duration must be between 1 and 168 hours (7 days).", ephemeral=True)
                    return
            except ValueError:
                await interaction.response.send_message("❌ Please enter a valid number for duration.", ephemeral=True)
                return

            mode = self.channel_mode.value.strip().lower()
            if mode not in ["best", "all"]:
                await interaction.response.send_message("❌ Channel mode must be 'best' or 'all'.", ephemeral=True)
                return

            total_guilds = len(self.bot.guilds)
            if total_guilds == 0:
                await interaction.response.send_message("❌ The bot is not in any servers.", ephemeral=True)
                return

            preview_embed = build(title=f"📊 {self.poll_title.value}", description=self.poll_question.value, color=Config.COLOR_INFO, bot=self.bot)
            for i, opt in enumerate(options_list, 1):
                preview_embed.add_field(name=f"Option {i}", value=opt, inline=False)
            preview_embed.set_footer(text=f"Duration: {duration} hours • Mode: {mode} • Will be sent to {total_guilds} servers")

            confirm_embed = build(title="⚠️ Confirm Global Poll", description=f"You are about to send a poll to **{total_guilds}** servers.\n\n**Title:** {self.poll_title.value}\n**Options:** {len(options_list)}\n**Duration:** {duration} hours\n**Mode:** {mode}\n\nReview the preview below and confirm.", color=Config.COLOR_WARN, bot=self.bot)

            view = ConfirmActionView(interaction.user.id, "global_poll")
            await interaction.response.send_message(embed=confirm_embed, view=view, ephemeral=True)
            await interaction.followup.send(content="📌 **Preview of your poll:**", embed=preview_embed, ephemeral=True)
            await view.wait()

            if view.confirmed:
                await self._send_polls(interaction, options_list, duration, mode, total_guilds)
            else:
                await interaction.edit_original_response(embed=build(title="❌ Cancelled", description="Global poll creation cancelled.", color=Config.COLOR_ERR, bot=self.bot), view=None)

        except Exception as e:
            log.error(f"Global poll creation error: {e}")
            try:
                await interaction.response.send_message(f"❌ An error occurred: {str(e)[:100]}", ephemeral=True)
            except:
                pass

    async def _send_polls(self, interaction: discord.Interaction, options: List[str], duration: int, mode: str, total_guilds: int):
        try:
            # FIX: Generate 4-digit poll ID (0001-9999)
            all_polls = _load_polls()
            existing_ids = set()
            for guild_polls in all_polls.values():
                for poll_id in guild_polls.keys():
                    if poll_id.startswith("poll_"):
                        existing_ids.add(poll_id)

            # Generate a unique 4-digit number
            attempts = 0
            while attempts < 50:
                poll_num = random.randint(1, 9999)
                poll_id = f"poll_{poll_num:04d}_{int(time.time())}_{interaction.user.id}"
                if poll_id not in existing_ids:
                    break
                attempts += 1

            if attempts >= 50:
                poll_id = f"poll_{random.randint(1, 9999):04d}_{int(time.time())}_{interaction.user.id}"

            poll_data = {
                "poll_id": poll_id,
                "title": self.poll_title.value,
                "question": self.poll_question.value,
                "options": options,
                "votes": {opt: 0 for opt in options},
                "voters": {},
                "banned_users": [],
                "created_by": interaction.user.id,
                "created_at": datetime.now(timezone.utc).isoformat(),
                "closed": False,
                "duration_hours": duration,
                "mode": mode,
                "total_guilds": total_guilds,
                "sent_to": 0,
                "failed": 0,
                "message_ids": {}
            }

            await interaction.edit_original_response(content=f"⏳ Sending poll to **{total_guilds}** servers...", embed=None, view=None)

            success_count = 0
            failed_count = 0

            for guild in self.bot.guilds:
                try:
                    channel = None
                    if mode == "best":
                        if guild.system_channel:
                            try:
                                if guild.system_channel.permissions_for(guild.me).send_messages:
                                    channel = guild.system_channel
                            except:
                                pass

                        if not channel:
                            priority_names = ["announcements", "announcement", "general", "chat", "main"]
                            for name in priority_names:
                                for ch in guild.text_channels:
                                    if ch.name.lower() == name:
                                        try:
                                            if ch.permissions_for(guild.me).send_messages:
                                                channel = ch
                                                break
                                        except:
                                            continue
                                if channel:
                                    break

                        if not channel:
                            for ch in guild.text_channels:
                                try:
                                    if ch.permissions_for(guild.me).send_messages:
                                        channel = ch
                                        break
                                except:
                                    continue
                    else:
                        channels = []
                        for ch in guild.text_channels:
                            try:
                                if ch.permissions_for(guild.me).send_messages:
                                    channels.append(ch)
                            except:
                                continue

                        if not channels:
                            failed_count += 1
                            continue

                        for ch in channels:
                            try:
                                await self._send_single_poll(ch, poll_id, interaction.user)
                                success_count += 1
                            except:
                                failed_count += 1
                        continue

                    if not channel:
                        failed_count += 1
                        continue

                    await self._send_single_poll(channel, poll_id, interaction.user)
                    success_count += 1

                except Exception as e:
                    failed_count += 1
                    log.error(f"Failed to send poll to {guild.name}: {e}")

                if (success_count + failed_count) % 5 == 0:
                    try:
                        await interaction.edit_original_response(content=f"⏳ Sending poll... **{success_count + failed_count}/{total_guilds}** servers (✅ {success_count} | ❌ {failed_count})")
                    except:
                        pass

                await asyncio.sleep(0.3)

            for guild_id, msg_id in poll_data["message_ids"].items():
                guild_poll_data = poll_data.copy()
                guild_poll_data["message_id"] = msg_id
                guild_poll_data["guild_id"] = guild_id
                _save_poll(int(guild_id), poll_id, guild_poll_data)

            result_embed = discord.Embed(
                title="📊 Global Poll Created",
                description=f"✅ **Sent to:** {success_count} servers\n❌ **Failed:** {failed_count} servers\n📊 **Total:** {success_count + failed_count} servers\n⏰ **Duration:** {duration} hours\n🆔 **Poll ID:** `{poll_id}`",
                color=Config.COLOR_OK if failed_count == 0 else Config.COLOR_WARN,
                timestamp=datetime.now(timezone.utc)
            )
            result_embed.add_field(name="📊 Options", value="\n".join([f"{i+1}. {opt}" for i, opt in enumerate(options)]), inline=False)
            result_embed.set_footer(text=f"Created by {interaction.user}")

            await interaction.edit_original_response(content=None, embed=result_embed, view=None)

            log_embed = discord.Embed(
                title="📊 Global Poll Created",
                description=f"By: {interaction.user}\nSent to: **{success_count}** servers\nFailed: **{failed_count}** servers",
                color=Config.COLOR_INFO,
                timestamp=datetime.now(timezone.utc)
            )
            log_embed.add_field(name="Title", value=self.poll_title.value, inline=False)
            log_embed.add_field(name="Options", value="\n".join(options), inline=False)
            log_embed.add_field(name="Duration", value=f"{duration} hours", inline=True)
            log_embed.add_field(name="Poll ID", value=poll_id, inline=True)
            await _send_to_owner_log(self.bot, log_embed)

        except Exception as e:
            log.error(f"Error sending polls: {e}")
            await interaction.edit_original_response(content=f"❌ An error occurred: {str(e)[:100]}", embed=None, view=None)

    async def _send_single_poll(self, channel: discord.TextChannel, poll_id: str, author: discord.User):
        embed = build(title=f"📊 {self.poll_title.value}", description=self.poll_question.value, color=Config.COLOR_INFO, bot=self.bot)

        options_list = [opt.strip() for opt in self.options.value.split(",") if opt.strip()]
        for i, opt in enumerate(options_list, 1):
            embed.add_field(name=f"Option {i}", value=opt, inline=False)

        embed.set_footer(text=f"Vote using the buttons below • Poll ID: {poll_id} • Server owners only")

        view = GlobalPollView(poll_id, channel.guild.id, options_list, author.id)

        try:
            message = await channel.send(embed=embed, view=view)

            poll_data = _get_poll(channel.guild.id, poll_id)
            if not poll_data:
                poll_data = {
                    "poll_id": poll_id,
                    "title": self.poll_title.value,
                    "question": self.poll_question.value,
                    "options": options_list,
                    "votes": {opt: 0 for opt in options_list},
                    "voters": {},
                    "banned_users": [],
                    "created_by": author.id,
                    "created_at": datetime.now(timezone.utc).isoformat(),
                    "closed": False,
                    "duration_hours": int(self.duration_hours.value),
                    "mode": self.channel_mode.value.strip().lower(),
                    "message_id": message.id
                }
                _save_poll(channel.guild.id, poll_id, poll_data)
            else:
                poll_data["message_id"] = message.id
                _save_poll(channel.guild.id, poll_id, poll_data)

            log.info(f"✅ Sent poll {poll_id} to {channel.guild.name} - #{channel.name}")
            return True
        except Exception as e:
            log.error(f"❌ Failed to send poll to {channel.guild.name}: {e}")
            return False

class GlobalAnnouncementModal(discord.ui.Modal, title="📢 Global Announcement"):
    message = discord.ui.TextInput(label="📝 Message", placeholder="Enter the announcement message...", style=discord.TextStyle.paragraph, required=True, max_length=4000)
    use_embed = discord.ui.TextInput(label="🎨 Use Embed? (yes/no)", placeholder="yes or no", required=True, max_length=3, default="yes")
    send_to_all_channels = discord.ui.TextInput(label="📢 Send to ALL channels? (yes/no)", placeholder="yes or no", required=True, max_length=3, default="no")
    embed_title = discord.ui.TextInput(label="📌 Embed Title", placeholder="Optional title for the embed", required=False, max_length=256)
    embed_color = discord.ui.TextInput(label="🎨 Embed Color (hex)", placeholder="#5865F2 or leave empty", required=False, max_length=7)

    def __init__(self, bot, author):
        super().__init__()
        self.bot = bot
        self.author = author
        self.data = {}

    async def on_submit(self, interaction: discord.Interaction):
        self.data = {
            "message": self.message.value.strip(),
            "use_embed": self.use_embed.value.strip().lower() in ("yes", "y", "true", "1"),
            "send_to_all_channels": self.send_to_all_channels.value.strip().lower() in ("yes", "y", "true", "1"),
            "embed_title": self.embed_title.value.strip() or None,
            "embed_color": self.embed_color.value.strip() or None,
        }

        if self.use_embed.value.strip().lower() not in ("yes", "no", "y", "n", "true", "false", "1", "0"):
            await interaction.response.send_message("❌ Please enter 'yes' or 'no' for the embed option.", ephemeral=True)
            return

        if self.send_to_all_channels.value.strip().lower() not in ("yes", "no", "y", "n", "true", "false", "1", "0"):
            await interaction.response.send_message("❌ Please enter 'yes' or 'no' for the 'Send to ALL channels' option.", ephemeral=True)
            return

        total_guilds = len(self.bot.guilds)
        if total_guilds == 0:
            await interaction.response.send_message("❌ The bot is not in any servers.", ephemeral=True)
            return

        preview_embed = self._build_preview()
        channel_preview = self._get_channel_preview()

        confirm_embed = build(title="⚠️ Confirm Global Announcement", description=f"You are about to send an announcement to **{total_guilds}** servers.\n\n**Format:** {'Embed' if self.data['use_embed'] else 'Plain Text'}\n**Channel Mode:** {'ALL Channels' if self.data['send_to_all_channels'] else 'One Channel Per Server'}\n\n**Channel Preview:**\n{channel_preview}\n\n**Message Preview:**\n{self.data['message'][:300]}{'...' if len(self.data['message']) > 300 else ''}\n\nReview the preview below and confirm.", color=Config.COLOR_WARN, bot=self.bot)

        view = ConfirmActionView(interaction.user.id, "global_announce")
        await interaction.response.send_message(embed=confirm_embed, view=view, ephemeral=True)

        if preview_embed:
            await interaction.followup.send(content="📌 **Preview of your announcement:**", embed=preview_embed, ephemeral=True)
        else:
            await interaction.followup.send(content=f"📌 **Preview of your announcement:**\n\n{self.data['message']}", ephemeral=True)

        await view.wait()

        if view.confirmed:
            await self._send_announcement(interaction)
        else:
            await interaction.edit_original_response(embed=build(title="❌ Cancelled", description="Global announcement cancelled.", color=Config.COLOR_ERR, bot=self.bot), view=None)

    def _get_channel_preview(self) -> str:
        preview_parts = []
        sample_servers = self.bot.guilds[:3]

        for guild in sample_servers:
            if self.data["send_to_all_channels"]:
                total_text = len(guild.text_channels)
                channel_names = []
                for ch in guild.text_channels[:3]:
                    channel_names.append(f"#{ch.name}")
                if len(guild.text_channels) > 3:
                    channel_names.append(f"... and {len(guild.text_channels) - 3} more")
                preview_parts.append(f"• **{guild.name}** → {', '.join(channel_names)} ({total_text} channels)")
            else:
                channel = self._get_best_channel(guild)
                if channel:
                    preview_parts.append(f"• **{guild.name}** → #{channel.name}")
                else:
                    preview_parts.append(f"• **{guild.name}** → No channel")

        preview = "\n".join(preview_parts)
        if len(self.bot.guilds) > 3:
            preview += f"\n• ... and {len(self.bot.guilds) - 3} more servers"

        return preview

    def _get_best_channel(self, guild: discord.Guild) -> discord.TextChannel | None:
        if guild.system_channel:
            try:
                if guild.system_channel.permissions_for(guild.me).send_messages:
                    return guild.system_channel
            except:
                pass

        priority_names = ["announcements", "announcement", "general", "chat", "main"]
        for name in priority_names:
            for channel in guild.text_channels:
                if channel.name.lower() == name:
                    try:
                        if channel.permissions_for(guild.me).send_messages:
                            return channel
                    except:
                        continue

        for channel in guild.text_channels:
            try:
                if channel.permissions_for(guild.me).send_messages:
                    return channel
            except:
                continue

        return None

    def _build_preview(self) -> discord.Embed | None:
        if not self.data["use_embed"]:
            return None

        color = Config.COLOR_INFO
        if self.data["embed_color"]:
            try:
                color = int(self.data["embed_color"].replace("#", ""), 16)
            except:
                pass

        embed = build(title=self.data["embed_title"] or "Global Announcement", description=self.data["message"], color=color, bot=self.bot)
        embed.set_footer(text=f"Announcement by {self.author} • Sparky Bot", icon_url=self.author.display_avatar.url)

        return embed

    async def _send_announcement(self, interaction: discord.Interaction):
        total_guilds = len(self.bot.guilds)

        total_channels = 0
        if self.data["send_to_all_channels"]:
            for guild in self.bot.guilds:
                total_channels += len(guild.text_channels)
        else:
            total_channels = total_guilds

        await interaction.edit_original_response(content=f"⏳ Sending announcements to **{total_channels}** channels across **{total_guilds}** servers...", embed=None, view=None)

        if self.data["use_embed"]:
            announce_embed = self._build_preview()
        else:
            announce_embed = None

        success_count = 0
        failed_count = 0
        failed_guilds = []

        for guild in self.bot.guilds:
            try:
                if self.data["send_to_all_channels"]:
                    channels = []
                    for channel in guild.text_channels:
                        try:
                            if channel.permissions_for(guild.me).send_messages:
                                channels.append(channel)
                        except:
                            continue

                    for channel in channels:
                        try:
                            if announce_embed:
                                await channel.send(embed=announce_embed)
                            else:
                                await channel.send(f"📢 **Global Announcement**\n\n{self.data['message']}")
                            success_count += 1
                        except Exception:
                            failed_count += 1
                            failed_guilds.append(f"{guild.name} - #{channel.name}")

                        await asyncio.sleep(0.2)

                else:
                    channel = self._get_best_channel(guild)

                    if not channel:
                        failed_count += 1
                        failed_guilds.append(f"{guild.name} (no channel)")
                        continue

                    if announce_embed:
                        await channel.send(embed=announce_embed)
                    else:
                        await channel.send(f"📢 **Global Announcement**\n\n{self.data['message']}")

                    success_count += 1

            except Exception as e:
                failed_count += 1
                failed_guilds.append(f"{guild.name} ({str(e)[:30]})")

            if (success_count + failed_count) % 5 == 0:
                try:
                    await interaction.edit_original_response(content=f"⏳ Sending announcements... **{success_count + failed_count}/{total_channels}** channels (✅ {success_count} | ❌ {failed_count})")
                except:
                    pass

            await asyncio.sleep(0.3)

        result_embed = build(title="📢 Global Announcement Complete", description=f"✅ **Sent to:** {success_count} channels\n❌ **Failed:** {failed_count} channels\n📊 **Total:** {success_count + failed_count} channels\n🏠 **Servers Affected:** {total_guilds} servers", color=Config.COLOR_OK if failed_count == 0 else Config.COLOR_WARN, bot=self.bot)

        if failed_guilds:
            failed_list = "\n".join(f"• {g}" for g in failed_guilds[:10])
            if len(failed_guilds) > 10:
                failed_list += f"\n... and {len(failed_guilds) - 10} more"
            result_embed.add_field(name="❌ Failed Servers/Channels", value=failed_list, inline=False)

        result_embed.set_footer(text=f"Announcement by {interaction.user}")

        await interaction.edit_original_response(content=None, embed=result_embed, view=None)

        log.info(f"📢 Global announcement sent by {interaction.user} to {success_count} channels ({failed_count} failed)")

        log_embed = discord.Embed(
            title="📢 Global Announcement Sent",
            description=f"By: {interaction.user}\nSent to: **{success_count}** channels\nFailed: **{failed_count}** channels",
            color=Config.COLOR_INFO,
            timestamp=datetime.now(timezone.utc)
        )
        log_embed.add_field(name="Message Preview", value=self.data["message"][:500] + ("..." if len(self.data["message"]) > 500 else ""), inline=False)
        log_embed.add_field(name="Format", value="Embed" if self.data["use_embed"] else "Plain Text", inline=True)
        log_embed.add_field(name="Mode", value="All Channels" if self.data["send_to_all_channels"] else "Single Channel", inline=True)
        await _send_to_owner_log(self.bot, log_embed)

class Owner(commands.Cog):
    slash = app_commands.Group(name="owner", description="Bot owner commands")

    def __init__(self, bot):
        self.bot = bot
        self._global_announcement_tasks = {}
        self._check_polls.start()

    def cog_unload(self):
        self._check_polls.cancel()

    @tasks.loop(minutes=5)
    async def _check_polls(self):
        try:
            all_polls = _load_polls()
            now = datetime.now(timezone.utc)

            for guild_id_str, guild_polls in all_polls.items():
                for poll_id, poll_data in guild_polls.items():
                    if poll_data.get("closed", False):
                        continue

                    created_at = datetime.fromisoformat(poll_data.get("created_at"))
                    duration_hours = poll_data.get("duration_hours", 24)
                    expiry_time = created_at + timedelta(hours=duration_hours)

                    if now >= expiry_time:
                        poll_data["closed"] = True
                        _save_poll(int(guild_id_str), poll_id, poll_data)

                        try:
                            guild = self.bot.get_guild(int(guild_id_str))
                            if guild:
                                channel = guild.get_channel(poll_data.get("channel_id"))
                                if channel:
                                    try:
                                        message = await channel.fetch_message(poll_data.get("message_id"))
                                        if message:
                                            from cogs.owner import _get_poll
                                            poll_data = _get_poll(int(guild_id_str), poll_id)
                                            if poll_data:
                                                embed = self._build_poll_embed(poll_data)
                                                await message.edit(embed=embed)
                                    except:
                                        pass
                        except:
                            pass

                        log_embed = build(title="🔒 Poll Closed Automatically", description=f"Poll **{poll_data.get('title')}** has closed.", color=Config.COLOR_INFO, bot=self.bot)
                        log_embed.add_field(name="Poll ID", value=poll_id, inline=True)
                        log_embed.add_field(name="Duration", value=f"{duration_hours} hours", inline=True)
                        total = sum(poll_data.get("votes", {}).values())
                        log_embed.add_field(name="Total Votes", value=str(total), inline=True)
                        await _send_to_owner_log(self.bot, log_embed)

        except Exception as e:
            log.error(f"Poll check task error: {e}")

    def _build_poll_embed(self, poll_data: dict) -> discord.Embed:
        return render_poll_embed(poll_data)

    @commands.Cog.listener()
    async def on_guild_join(self, guild: discord.Guild):
        if not _get_owner_log_channel():
            return

        bots = sum(m.bot for m in guild.members)
        humans = guild.member_count - bots
        online = sum(m.status != discord.Status.offline and not m.bot for m in guild.members)

        embed = build(title="✅ Bot Added to Server", color=Config.COLOR_OK, bot=self.bot)

        embed.add_field(name="📛 Server Name", value=guild.name, inline=False)
        embed.add_field(name="🆔 Server ID", value=str(guild.id), inline=True)
        embed.add_field(name="👑 Owner", value=str(guild.owner) if guild.owner else "Unknown", inline=True)
        embed.add_field(name="👥 Members", value=f"**{guild.member_count:,}** total", inline=True)
        embed.add_field(name="🧑 Humans", value=f"**{humans:,}**", inline=True)
        embed.add_field(name="🤖 Bots", value=f"**{bots:,}**", inline=True)
        embed.add_field(name="🟢 Online", value=f"**{online:,}**", inline=True)
        embed.add_field(name="📅 Created", value=discord.utils.format_dt(guild.created_at, "R"), inline=True)
        embed.add_field(name="📺 Channels", value=f"**{len(guild.channels):,}**", inline=True)
        embed.add_field(name="🎭 Roles", value=f"**{len(guild.roles):,}**", inline=True)
        embed.add_field(name="😀 Emojis", value=f"**{len(guild.emojis):,}**", inline=True)
        embed.add_field(name="📊 Boosts", value=f"Level {guild.premium_tier} ({guild.premium_subscription_count} boosts)", inline=True)

        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)

        embed.set_footer(text=f"Now in {len(self.bot.guilds)} servers")

        await _send_to_owner_log(self.bot, embed, f"📥 **Joined:** {guild.name}")

    @commands.Cog.listener()
    async def on_guild_remove(self, guild: discord.Guild):
        if not _get_owner_log_channel():
            return

        embed = build(title="❌ Bot Removed from Server", color=Config.COLOR_ERR, bot=self.bot)

        embed.add_field(name="📛 Server Name", value=guild.name, inline=False)
        embed.add_field(name="🆔 Server ID", value=str(guild.id), inline=True)
        embed.add_field(name="👑 Owner", value=str(guild.owner) if guild.owner else "Unknown", inline=True)
        embed.add_field(name="👥 Members", value=f"**{guild.member_count:,}**", inline=True)
        embed.add_field(name="📅 Created", value=discord.utils.format_dt(guild.created_at, "R"), inline=True)

        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)

        embed.set_footer(text=f"Now in {len(self.bot.guilds)} servers")

        await _send_to_owner_log(self.bot, embed, f"📤 **Left:** {guild.name}")

    @commands.command(name="ownersetlog")
    @is_owner()
    async def ownersetlog(self, ctx, channel: discord.TextChannel):
        _set_owner_log_channel(channel.id)
        embed = build(title="✅ Owner Log Channel Set", description=f"All bot updates and logs will be sent to {channel.mention}.", color=Config.COLOR_OK, bot=self.bot)
        await ctx.reply(embed=embed)
        log.info(f"Owner log channel set to {channel.id} by {ctx.author}")

    @slash.command(name="setlog", description="Set the owner log channel. (Owner only)")
    @app_commands.describe(channel="The channel to send bot logs to")
    @owner_only()
    async def setlog_slash(self, interaction: discord.Interaction, channel: discord.TextChannel):
        _set_owner_log_channel(channel.id)
        embed = build(title="✅ Owner Log Channel Set", description=f"All bot updates and logs will be sent to {channel.mention}.", color=Config.COLOR_OK, bot=self.bot)
        await interaction.response.send_message(embed=embed, ephemeral=True)
        log.info(f"Owner log channel set to {channel.id} by {interaction.user}")

    @commands.command(name="ownerremovelog")
    @is_owner()
    async def ownerremovelog(self, ctx):
        _set_owner_log_channel(None)
        embed = build(title="✅ Owner Log Channel Removed", description="Bot logs will no longer be sent to a channel.", color=Config.COLOR_OK, bot=self.bot)
        await ctx.reply(embed=embed)
        log.info(f"Owner log channel removed by {ctx.author}")

    @slash.command(name="removelog", description="Remove the owner log channel. (Owner only)")
    @owner_only()
    async def removelog_slash(self, interaction: discord.Interaction):
        _set_owner_log_channel(None)
        embed = build(title="✅ Owner Log Channel Removed", description="Bot logs will no longer be sent to a channel.", color=Config.COLOR_OK, bot=self.bot)
        await interaction.response.send_message(embed=embed, ephemeral=True)
        log.info(f"Owner log channel removed by {interaction.user}")

    @slash.command(name="checklog", description="Check the current owner log channel status. (Owner only)")
    @owner_only()
    async def checklog_slash(self, interaction: discord.Interaction):
        channel_id = _get_owner_log_channel()
        embed = build(title="📋 Owner Log Channel Status", color=Config.COLOR_INFO, bot=self.bot)

        if channel_id:
            channel = interaction.guild.get_channel(channel_id)
            if channel:
                embed.add_field(name="✅ Channel Set", value=f"Log channel: {channel.mention}\nID: `{channel_id}`", inline=False)
                try:
                    test_embed = build(title="🧪 Test Message", description="This is a test message to confirm the log channel is working.", color=Config.COLOR_OK, bot=self.bot)
                    await channel.send(embed=test_embed)
                    embed.add_field(name="✅ Test", value="Test message sent successfully!", inline=False)
                except Exception as e:
                    embed.add_field(name="❌ Test Failed", value=f"Error: {e}", inline=False)
            else:
                embed.add_field(name="❌ Channel Not Found", value=f"Channel ID: `{channel_id}`\nThe channel may have been deleted.", inline=False)
                embed.add_field(name="💡 Solution", value="Run `/owner removelog` then `/owner setlog #channel` again.", inline=False)
        else:
            embed.add_field(name="❌ No Channel Set", value="No owner log channel is currently configured.", inline=False)
            embed.add_field(name="💡 Solution", value="Run `/owner setlog #channel` to set one.", inline=False)

        await interaction.response.send_message(embed=embed, ephemeral=True)

    @commands.command(name="listservers")
    @is_owner()
    async def listservers(self, ctx):
        await self._send_server_list(ctx.author)
        await ctx.reply("📬 Server list has been sent to your DMs!")

    @slash.command(name="listservers", description="List all servers the bot is in. (Owner only - No invites)")
    @owner_only()
    async def listservers_slash(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        await self._send_server_list(interaction.user)
        await interaction.followup.send("📬 Server list has been sent to your DMs!", ephemeral=True)

    async def _send_server_list(self, user: discord.User):
        try:
            await user.send("📊 **Generating server list...**")
        except discord.Forbidden:
            if isinstance(user, discord.Member) and user.guild:
                channel = user.guild.get_channel(user.guild.id) or user.guild.system_channel
                if channel:
                    await channel.send("⚠️ Please enable DMs from server members to receive the server list.")
            return

        guilds = sorted(self.bot.guilds, key=lambda g: g.member_count, reverse=True)
        total_guilds = len(guilds)
        total_members = sum(g.member_count for g in guilds)

        server_info = []

        for i, guild in enumerate(guilds, 1):
            owner = guild.owner
            owner_name = str(owner) if owner else "Unknown"

            server_lines = [
                f"**{i}.** {guild.name}",
                f"   **ID:** `{guild.id}`",
                f"   **Members:** {guild.member_count:,}",
                f"   **Owner:** {owner_name}",
                f"   **Created:** {discord.utils.format_dt(guild.created_at, 'R')}",
                f"   **Channels:** {len(guild.channels)}",
                f"   **Roles:** {len(guild.roles)}",
                f"   **Emojis:** {len(guild.emojis)}",
                f"   **Boosts:** Level {guild.premium_tier} ({guild.premium_subscription_count})",
            ]

            server_info.append("\n".join(server_lines))

        chunks = [server_info[i:i+10] for i in range(0, len(server_info), 10)]
        total_chunks = len(chunks)

        for chunk_index, chunk in enumerate(chunks, 1):
            embed = build(title=f"📊 Server List • {total_guilds} Servers", description=f"**Total Members:** {total_members:,}\n\n" + "\n\n".join(chunk), color=Config.COLOR_INFO, bot=self.bot)
            embed.set_footer(text=f"Page {chunk_index}/{total_chunks} • Generated for {user}\n⚠️ Invites not included for security reasons")

            try:
                await user.send(embed=embed)
            except discord.Forbidden:
                try:
                    await user.send(f"**Page {chunk_index}/{total_chunks}**\n\n" + "\n\n".join(chunk))
                except:
                    break
            except discord.HTTPException:
                for line in chunk:
                    try:
                        await user.send(line)
                    except:
                        pass
                continue

    @commands.command(name="reload")
    @is_owner()
    async def reload(self, ctx, cog_name: str = None):
        await self._do_reload(ctx, cog_name)

    @slash.command(name="reload", description="Reload a cog (or all if none specified). (Owner only)")
    @app_commands.describe(cog="Cog name to reload (e.g. welcome, tickets). Leave empty to reload all.")
    @owner_only()
    async def reload_slash(self, interaction: discord.Interaction, cog: str = None):
        await interaction.response.defer(ephemeral=True)
        await self._do_reload_slash(interaction, cog)

    async def _do_reload(self, ctx, cog_name: str = None):
        if cog_name is None:
            cogs = list(self.bot.extensions.keys())

            if not cogs:
                await ctx.reply("❌ No cogs found to reload.")
                return

            success = []
            failed = []

            for cog in cogs:
                try:
                    await self._reload_cog_advanced(cog)
                    success.append(cog.replace("cogs.", ""))
                except Exception as e:
                    failed.append(f"{cog.replace('cogs.', '')}: {str(e)[:50]}")

            embed = build(title="🔄 Reloaded All Cogs", color=Config.COLOR_OK if not failed else Config.COLOR_WARN, bot=self.bot)

            if success:
                embed.add_field(name="✅ Success", value="\n".join([f"`{c}`" for c in success]) or "None", inline=False)
            if failed:
                embed.add_field(name="❌ Failed", value="\n".join([f"`{f}`" for f in failed]) or "None", inline=False)

            embed.set_footer(text=f"Requested by {ctx.author}")
            await ctx.reply(embed=embed)
            log.info(f"🔄 Reloaded all cogs requested by {ctx.author}")

            log_embed = build(title="🔄 Cogs Reloaded", description=f"All cogs reloaded by {ctx.author}", color=Config.COLOR_INFO, bot=self.bot)
            if success:
                log_embed.add_field(name="✅ Success", value=", ".join(success[:10]) + (f" and {len(success)-10} more" if len(success) > 10 else ""), inline=False)
            if failed:
                log_embed.add_field(name="❌ Failed", value=", ".join(failed), inline=False)
            await _send_to_owner_log(self.bot, log_embed)

        else:
            cog_path = f"cogs.{cog_name}" if not cog_name.startswith("cogs.") else cog_name

            try:
                await self._reload_cog_advanced(cog_path)
                embed = build(title="✅ Reloaded Cog", description=f"Successfully reloaded `{cog_name}`", color=Config.COLOR_OK, bot=self.bot)
                embed.set_footer(text=f"Requested by {ctx.author}")
                await ctx.reply(embed=embed)
                log.info(f"🔄 Reloaded {cog_path} requested by {ctx.author}")

                log_embed = build(title="🔄 Cog Reloaded", description=f"`{cog_name}` reloaded by {ctx.author}", color=Config.COLOR_INFO, bot=self.bot)
                await _send_to_owner_log(self.bot, log_embed)

            except commands.ExtensionNotLoaded:
                await ctx.reply(f"❌ Cog `{cog_name}` is not loaded.")
            except commands.ExtensionNotFound:
                await ctx.reply(f"❌ Cog `{cog_name}` not found.")
            except Exception as e:
                await ctx.reply(f"❌ Failed to reload `{cog_name}`: {e}")

    async def _do_reload_slash(self, interaction: discord.Interaction, cog_name: str = None):
        if cog_name is None:
            cogs = list(self.bot.extensions.keys())

            if not cogs:
                await interaction.followup.send("❌ No cogs found to reload.")
                return

            success = []
            failed = []

            for cog in cogs:
                try:
                    await self._reload_cog_advanced(cog)
                    success.append(cog.replace("cogs.", ""))
                except Exception as e:
                    failed.append(f"{cog.replace('cogs.', '')}: {str(e)[:50]}")

            embed = build(title="🔄 Reloaded All Cogs", color=Config.COLOR_OK if not failed else Config.COLOR_WARN, bot=self.bot)

            if success:
                embed.add_field(name="✅ Success", value="\n".join([f"`{c}`" for c in success]) or "None", inline=False)
            if failed:
                embed.add_field(name="❌ Failed", value="\n".join([f"`{f}`" for f in failed]) or "None", inline=False)

            embed.set_footer(text=f"Requested by {interaction.user}")
            await interaction.followup.send(embed=embed)
            log.info(f"🔄 Reloaded all cogs requested by {interaction.user}")

            log_embed = build(title="🔄 Cogs Reloaded", description=f"All cogs reloaded by {interaction.user}", color=Config.COLOR_INFO, bot=self.bot)
            if success:
                log_embed.add_field(name="✅ Success", value=", ".join(success[:10]) + (f" and {len(success)-10} more" if len(success) > 10 else ""), inline=False)
            if failed:
                log_embed.add_field(name="❌ Failed", value=", ".join(failed), inline=False)
            await _send_to_owner_log(self.bot, log_embed)

        else:
            cog_path = f"cogs.{cog_name}" if not cog_name.startswith("cogs.") else cog_name

            try:
                await self._reload_cog_advanced(cog_path)
                embed = build(title="✅ Reloaded Cog", description=f"Successfully reloaded `{cog_name}`", color=Config.COLOR_OK, bot=self.bot)
                embed.set_footer(text=f"Requested by {interaction.user}")
                await interaction.followup.send(embed=embed)
                log.info(f"🔄 Reloaded {cog_path} requested by {interaction.user}")

                log_embed = build(title="🔄 Cog Reloaded", description=f"`{cog_name}` reloaded by {interaction.user}", color=Config.COLOR_INFO, bot=self.bot)
                await _send_to_owner_log(self.bot, log_embed)

            except commands.ExtensionNotLoaded:
                await interaction.followup.send(f"❌ Cog `{cog_name}` is not loaded.")
            except commands.ExtensionNotFound:
                await interaction.followup.send(f"❌ Cog `{cog_name}` not found.")
            except Exception as e:
                await interaction.followup.send(f"❌ Failed to reload `{cog_name}`: {e}")

    async def _reload_cog_advanced(self, cog_path: str) -> str:
        cog_name = cog_path.replace("cogs.", "")

        if cog_name in self.bot.cogs:
            await self.bot.remove_cog(cog_name)
            log.info(f"Unloaded cog: {cog_name}")

        if cog_path in sys.modules:
            del sys.modules[cog_path]
            log.info(f"Removed {cog_path} from sys.modules")

        importlib.invalidate_caches()
        log.info(f"Invalidated import caches")

        await self.bot.reload_extension(cog_path)
        log.info(f"Reloaded extension: {cog_path}")

        return f"✅ Successfully reloaded `{cog_name}`"

    @commands.command(name="globalpoll")
    @is_owner()
    async def globalpoll(self, ctx):
        await ctx.reply("📊 Please use `/owner globalpoll` to create a global poll.", ephemeral=True)

    @slash.command(name="globalpoll", description="Create a global poll and send it to all servers. (Owner only)")
    @owner_only()
    async def globalpoll_slash(self, interaction: discord.Interaction):
        await interaction.response.send_modal(GlobalPollModal(self.bot, interaction.user))

    @slash.command(name="pollclose", description="Close a global poll early. (Owner only)")
    @app_commands.describe(poll_id="The ID of the poll to close")
    @owner_only()
    async def pollclose_slash(self, interaction: discord.Interaction, poll_id: str):
        await interaction.response.defer(ephemeral=True)

        all_polls = _load_polls()
        found = False
        closed_count = 0

        for guild_id_str, guild_polls in all_polls.items():
            if poll_id in guild_polls:
                poll_data = guild_polls[poll_id]
                if poll_data.get("closed", False):
                    continue

                poll_data["closed"] = True
                _save_poll(int(guild_id_str), poll_id, poll_data)
                found = True
                closed_count += 1

                try:
                    guild = self.bot.get_guild(int(guild_id_str))
                    if guild:
                        channel = guild.get_channel(poll_data.get("channel_id"))
                        if channel:
                            try:
                                message = await channel.fetch_message(poll_data.get("message_id"))
                                if message:
                                    embed = self._build_poll_embed(poll_data)
                                    await message.edit(embed=embed)
                            except:
                                pass
                except:
                    pass

        if not found:
            await interaction.followup.send(f"❌ Poll `{poll_id}` not found or already closed.", ephemeral=True)
            return

        embed = build(title="🔒 Poll Closed", description=f"Poll `{poll_id}` has been closed in **{closed_count}** servers.", color=Config.COLOR_OK, bot=self.bot)
        await interaction.followup.send(embed=embed, ephemeral=True)

        log_embed = build(title="🔒 Poll Closed Manually", description=f"Poll `{poll_id}` closed by {interaction.user}", color=Config.COLOR_INFO, bot=self.bot)
        await _send_to_owner_log(self.bot, log_embed)

    @slash.command(name="pollresults", description="Get results of a global poll. (Owner only)")
    @app_commands.describe(poll_id="The ID of the poll to get results for")
    @owner_only()
    async def pollresults_slash(self, interaction: discord.Interaction, poll_id: str):
        await interaction.response.defer(ephemeral=True)

        all_polls = _load_polls()
        results = {}
        total_votes = 0
        guild_count = 0

        for guild_id_str, guild_polls in all_polls.items():
            if poll_id in guild_polls:
                poll_data = guild_polls[poll_id]
                guild_count += 1
                votes = poll_data.get("votes", {})
                for option, count in votes.items():
                    results[option] = results.get(option, 0) + count
                    total_votes += count

        if not results:
            await interaction.followup.send(f"❌ Poll `{poll_id}` not found.", ephemeral=True)
            return

        embed = build(title=f"📊 Poll Results: {poll_id}", color=Config.COLOR_INFO, bot=self.bot)

        embed.add_field(name="📊 Total Votes", value=f"**{total_votes}** votes (server owners) across **{guild_count}** servers", inline=False)

        if total_votes > 0:
            for option, count in sorted(results.items(), key=lambda x: x[1], reverse=True):
                percentage = (count / total_votes * 100)
                bar_length = 20
                filled = int(percentage / 100 * bar_length)
                bar = "█" * filled + "░" * (bar_length - filled)
                embed.add_field(name=option, value=f"`{bar}` **{count}** votes ({percentage:.1f}%)", inline=False)
        else:
            embed.add_field(name="No votes", value="No votes have been cast yet.", inline=False)

        embed.set_footer(text=f"Poll ID: {poll_id}")

        await interaction.followup.send(embed=embed, ephemeral=True)

    @slash.command(name="pollban", description="Ban a user from voting in a specific poll. (Owner only)")
    @app_commands.describe(poll_id="The ID of the poll", user="The user to ban from voting")
    @owner_only()
    async def pollban_slash(self, interaction: discord.Interaction, poll_id: str, user: discord.User):
        await interaction.response.defer(ephemeral=True)

        all_polls = _load_polls()
        found = False
        banned_count = 0

        for guild_id_str, guild_polls in all_polls.items():
            if poll_id in guild_polls:
                poll_data = guild_polls[poll_id]
                if user.id not in poll_data.get("banned_users", []):
                    poll_data.setdefault("banned_users", []).append(user.id)
                    _save_poll(int(guild_id_str), poll_id, poll_data)
                    found = True
                    banned_count += 1

        if not found:
            await interaction.followup.send(f"❌ Poll `{poll_id}` not found.", ephemeral=True)
            return

        embed = build(title="✅ User Banned from Poll", description=f"**{user}** has been banned from voting in poll `{poll_id}`.", color=Config.COLOR_OK, bot=self.bot)
        embed.add_field(name="👤 User", value=f"{user} ({user.id})", inline=True)
        embed.add_field(name="📊 Poll", value=poll_id, inline=True)
        await interaction.followup.send(embed=embed, ephemeral=True)

        log_embed = build(title="🚫 User Banned from Poll", description=f"{user} banned from poll `{poll_id}` by {interaction.user}", color=Config.COLOR_WARN, bot=self.bot)
        await _send_to_owner_log(self.bot, log_embed)

    @slash.command(name="pollunban", description="Unban a user from a poll. (Owner only)")
    @app_commands.describe(poll_id="The ID of the poll", user="The user to unban")
    @owner_only()
    async def pollunban_slash(self, interaction: discord.Interaction, poll_id: str, user: discord.User):
        await interaction.response.defer(ephemeral=True)

        all_polls = _load_polls()
        found = False
        unbanned_count = 0

        for guild_id_str, guild_polls in all_polls.items():
            if poll_id in guild_polls:
                poll_data = guild_polls[poll_id]
                if user.id in poll_data.get("banned_users", []):
                    poll_data["banned_users"].remove(user.id)
                    _save_poll(int(guild_id_str), poll_id, poll_data)
                    found = True
                    unbanned_count += 1

        if not found:
            await interaction.followup.send(f"❌ Poll `{poll_id}` not found or user not banned.", ephemeral=True)
            return

        embed = build(title="✅ User Unbanned from Poll", description=f"**{user}** has been unbanned from voting in poll `{poll_id}`.", color=Config.COLOR_OK, bot=self.bot)
        embed.add_field(name="👤 User", value=f"{user} ({user.id})", inline=True)
        embed.add_field(name="📊 Poll", value=poll_id, inline=True)
        await interaction.followup.send(embed=embed, ephemeral=True)

        log_embed = build(title="✅ User Unbanned from Poll", description=f"{user} unbanned from poll `{poll_id}` by {interaction.user}", color=Config.COLOR_OK, bot=self.bot)
        await _send_to_owner_log(self.bot, log_embed)

    @slash.command(name="polldelete", description="Delete a global poll completely. (Owner only)")
    @app_commands.describe(poll_id="The ID of the poll to delete")
    @owner_only()
    async def polldelete_slash(self, interaction: discord.Interaction, poll_id: str):
        await interaction.response.defer(ephemeral=True)

        all_polls = _load_polls()
        found = False
        deleted_count = 0

        for guild_id_str in list(all_polls.keys()):
            if poll_id in all_polls[guild_id_str]:
                del all_polls[guild_id_str][poll_id]
                found = True
                deleted_count += 1

                if not all_polls[guild_id_str]:
                    del all_polls[guild_id_str]

        if not found:
            await interaction.followup.send(f"❌ Poll `{poll_id}` not found.", ephemeral=True)
            return

        _save_polls(all_polls)

        embed = build(title="🗑️ Poll Deleted", description=f"Poll `{poll_id}` has been deleted from **{deleted_count}** servers.", color=Config.COLOR_OK, bot=self.bot)
        await interaction.followup.send(embed=embed, ephemeral=True)

        log_embed = build(title="🗑️ Poll Deleted", description=f"Poll `{poll_id}` deleted by {interaction.user}", color=Config.COLOR_ERR, bot=self.bot)
        await _send_to_owner_log(self.bot, log_embed)

    @slash.command(name="polllist", description="List all active global polls. (Owner only)")
    @owner_only()
    async def polllist_slash(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)

        all_polls = _load_polls()
        active_polls = []
        closed_polls = []

        for guild_id_str, guild_polls in all_polls.items():
            for poll_id, poll_data in guild_polls.items():
                title = poll_data.get("title", "Untitled")
                is_closed = poll_data.get("closed", False)
                total = sum(poll_data.get("votes", {}).values())
                entry = {
                    "id": poll_id,
                    "title": title,
                    "votes": total,
                    "guilds": 1,
                    "closed": is_closed
                }

                if is_closed:
                    if poll_id not in [p["id"] for p in closed_polls]:
                        closed_polls.append(entry)
                else:
                    if poll_id not in [p["id"] for p in active_polls]:
                        active_polls.append(entry)

        if not active_polls and not closed_polls:
            await interaction.followup.send("📋 No polls found.", ephemeral=True)
            return

        embed = build(title="📊 Global Polls", color=Config.COLOR_INFO, bot=self.bot)

        if active_polls:
            active_list = []
            for poll in active_polls[:10]:
                active_list.append(f"**{poll['title']}**\n🆔 `{poll['id']}` • Votes: {poll['votes']}")
            embed.add_field(name=f"🟢 Active Polls ({len(active_polls)})", value="\n\n".join(active_list) or "None", inline=False)

        if closed_polls:
            closed_list = []
            for poll in closed_polls[:5]:
                closed_list.append(f"**{poll['title']}**\n🆔 `{poll['id']}` • Votes: {poll['votes']}")
            embed.add_field(name=f"🔒 Closed Polls ({len(closed_polls)})", value="\n\n".join(closed_list) or "None", inline=False)

        embed.set_footer(text="Use /owner pollresults <id> to see full results")
        await interaction.followup.send(embed=embed, ephemeral=True)

    @commands.command(name="restart")
    @is_owner()
    async def restart(self, ctx):
        embed = build(title="🔄 Restarting Bot", description="The bot is restarting... Please wait a moment.", color=Config.COLOR_WARN, bot=self.bot)
        embed.set_footer(text=f"Requested by {ctx.author}")

        await ctx.reply(embed=embed)

        log.info(f"🔄 Bot restart initiated by {ctx.author} (ID: {ctx.author.id})")

        log_embed = build(title="🔄 Bot Restarting", description=f"Restart initiated by {ctx.author}", color=Config.COLOR_WARN, bot=self.bot)
        await _send_to_owner_log(self.bot, log_embed)

        await send_dm_to_owners(self.bot, f"🔄 Bot restart initiated by {ctx.author} (ID: {ctx.author.id})")

        await self._restart_bot()

    @slash.command(name="restart", description="Restart the bot. (Owner only)")
    @owner_only()
    async def restart_slash(self, interaction: discord.Interaction):
        embed = build(title="🔄 Restarting Bot", description="The bot is restarting... Please wait a moment.", color=Config.COLOR_WARN, bot=self.bot)
        embed.set_footer(text=f"Requested by {interaction.user}")

        await interaction.response.send_message(embed=embed)

        log.info(f"🔄 Bot restart initiated by {interaction.user} (ID: {interaction.user.id})")

        log_embed = build(title="🔄 Bot Restarting", description=f"Restart initiated by {interaction.user}", color=Config.COLOR_WARN, bot=self.bot)
        await _send_to_owner_log(self.bot, log_embed)

        await send_dm_to_owners(self.bot, f"🔄 Bot restart initiated by {interaction.user} (ID: {interaction.user.id})")

        await self._restart_bot()

    async def _restart_bot(self):
        await asyncio.sleep(2)

        python = sys.executable
        script = os.path.abspath(sys.argv[0])
        args = sys.argv[1:]

        log.info(f"🔄 Restarting with command: {' '.join([python, script] + args)}")

        try:
            os.execv(python, [python, script] + args)
        except Exception as e:
            log.error(f"❌ Failed to restart: {e}")
            sys.exit(0)

    @commands.command(name="shutdown")
    @is_owner()
    async def shutdown(self, ctx):
        embed = build(title="⚠️ Shutdown Confirmation", description="Are you sure you want to shut down the bot?", color=Config.COLOR_ERR, bot=self.bot)

        view = ConfirmActionView(ctx.author.id, "shutdown")
        await ctx.reply(embed=embed, view=view)
        await view.wait()

        if view.confirmed:
            embed = build(title="🛑 Shutting Down", description="The bot is shutting down... Goodbye! 👋", color=Config.COLOR_ERR, bot=self.bot)
            await ctx.reply(embed=embed)

            log.info(f"🛑 Bot shutdown initiated by {ctx.author} (ID: {ctx.author.id})")

            log_embed = build(title="🛑 Bot Shutting Down", description=f"Shutdown initiated by {ctx.author}", color=Config.COLOR_ERR, bot=self.bot)
            await _send_to_owner_log(self.bot, log_embed)

            await send_dm_to_owners(self.bot, f"🛑 Bot shutdown initiated by {ctx.author} (ID: {ctx.author.id})")

            await asyncio.sleep(2)
            await self.bot.close()

    @slash.command(name="shutdown", description="Shut down the bot. (Owner only)")
    @owner_only()
    async def shutdown_slash(self, interaction: discord.Interaction):
        embed = build(title="⚠️ Shutdown Confirmation", description="Are you sure you want to shut down the bot?", color=Config.COLOR_ERR, bot=self.bot)

        view = ConfirmActionView(interaction.user.id, "shutdown")
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)
        await view.wait()

        if view.confirmed:
            embed = build(title="🛑 Shutting Down", description="The bot is shutting down... Goodbye! 👋", color=Config.COLOR_ERR, bot=self.bot)
            await interaction.edit_original_response(embed=embed, view=None)

            log.info(f"🛑 Bot shutdown initiated by {interaction.user} (ID: {interaction.user.id})")

            log_embed = build(title="🛑 Bot Shutting Down", description=f"Shutdown initiated by {interaction.user}", color=Config.COLOR_ERR, bot=self.bot)
            await _send_to_owner_log(self.bot, log_embed)

            await send_dm_to_owners(self.bot, f"🛑 Bot shutdown initiated by {interaction.user} (ID: {interaction.user.id})")

            await asyncio.sleep(2)
            await self.bot.close()
        else:
            await interaction.edit_original_response(embed=build(title="❌ Cancelled", description="Shutdown cancelled.", color=Config.COLOR_OK, bot=self.bot), view=None)

    @commands.command(name="globalannounce")
    @is_owner()
    async def globalannounce(self, ctx, *, message: str):
        await self._do_global_announce_prefix(ctx, message)

    @slash.command(name="globalannounce", description="Open a modal to send a global announcement. (Owner only)")
    @owner_only()
    async def globalannounce_slash(self, interaction: discord.Interaction):
        await interaction.response.send_modal(GlobalAnnouncementModal(self.bot, interaction.user))

    async def _do_global_announce_prefix(self, ctx, message: str):
        total_guilds = len(self.bot.guilds)

        if total_guilds == 0:
            await ctx.reply("❌ The bot is not in any servers.")
            return

        embed = build(title="⚠️ Confirm Global Announcement", description=f"You are about to send an announcement to **{total_guilds}** servers.\n**Mode:** One channel per server (best channel)\n\n**Message:**\n{message[:500]}{'...' if len(message) > 500 else ''}\n\nThis action cannot be undone. Are you sure?", color=Config.COLOR_WARN, bot=self.bot)

        view = ConfirmActionView(ctx.author.id, "global_announce")
        await ctx.reply(embed=embed, view=view)
        await view.wait()

        if not view.confirmed:
            await ctx.reply("❌ Global announcement cancelled.")
            return

        await ctx.reply(f"📢 Starting global announcement to **{total_guilds}** servers...")

        success_count = 0
        failed_count = 0
        failed_guilds = []

        for guild in self.bot.guilds:
            try:
                channel = None
                if guild.system_channel:
                    try:
                        if guild.system_channel.permissions_for(guild.me).send_messages:
                            channel = guild.system_channel
                    except:
                        pass

                if not channel:
                    priority_names = ["announcements", "announcement", "general", "chat", "main"]
                    for name in priority_names:
                        for ch in guild.text_channels:
                            if ch.name.lower() == name:
                                try:
                                    if ch.permissions_for(guild.me).send_messages:
                                        channel = ch
                                        break
                                except:
                                    continue
                        if channel:
                            break

                if not channel:
                    for ch in guild.text_channels:
                        try:
                            if ch.permissions_for(guild.me).send_messages:
                                channel = ch
                                break
                        except:
                            continue

                if not channel:
                    failed_count += 1
                    failed_guilds.append(f"{guild.name} (no channel)")
                    continue

                await channel.send(f"📢 **Global Announcement**\n\n{message}")
                success_count += 1

            except discord.Forbidden:
                failed_count += 1
                failed_guilds.append(f"{guild.name} (missing permissions)")
            except Exception as e:
                failed_count += 1
                failed_guilds.append(f"{guild.name} ({str(e)[:30]})")

            await asyncio.sleep(0.3)

        result_embed = build(title="📢 Global Announcement Complete", description=f"✅ **Sent to:** {success_count} servers\n❌ **Failed:** {failed_count} servers\n📊 **Total:** {success_count + failed_count} servers", color=Config.COLOR_OK if failed_count == 0 else Config.COLOR_WARN, bot=self.bot)

        if failed_guilds:
            failed_list = "\n".join(f"• {g}" for g in failed_guilds[:10])
            if len(failed_guilds) > 10:
                failed_list += f"\n... and {len(failed_guilds) - 10} more"
            result_embed.add_field(name="❌ Failed Servers", value=failed_list, inline=False)

        result_embed.set_footer(text=f"Announcement by {ctx.author}")
        await ctx.reply(embed=result_embed)

        log.info(f"📢 Global announcement sent by {ctx.author} to {success_count} servers ({failed_count} failed)")

        log_embed = discord.Embed(
            title="📢 Global Announcement Sent",
            description=f"By: {ctx.author}\nSent to: **{success_count}** servers\nFailed: **{failed_count}** servers",
            color=Config.COLOR_INFO,
            timestamp=datetime.now(timezone.utc)
        )
        log_embed.add_field(name="Message Preview", value=message[:500] + ("..." if len(message) > 500 else ""), inline=False)
        await _send_to_owner_log(self.bot, log_embed)

    @commands.command(name="leaveserver")
    @is_owner()
    async def leaveserver(self, ctx, guild_id: int):
        guild = self.bot.get_guild(guild_id)
        if not guild:
            await ctx.reply(f"❌ No server found with ID: `{guild_id}`")
            return

        embed = build(title="⚠️ Leave Server", description=f"You are about to make the bot leave **{guild.name}** (`{guild.id}`).\n\nThis action cannot be undone.", color=Config.COLOR_WARN, bot=self.bot)

        view = ConfirmActionView(ctx.author.id, "leave_server")
        await ctx.reply(embed=embed, view=view)
        await view.wait()

        if view.confirmed:
            try:
                await guild.leave()
                await ctx.reply(f"✅ Left server: **{guild.name}** (`{guild.id}`)")
                log.info(f"👋 Bot left server {guild.name} ({guild.id}) requested by {ctx.author}")

                log_embed = build(title="👋 Left Server", description=f"Left **{guild.name}** (`{guild.id}`)\nRequested by {ctx.author}", color=Config.COLOR_INFO, bot=self.bot)
                await _send_to_owner_log(self.bot, log_embed)

            except Exception as e:
                await ctx.reply(f"❌ Failed to leave server: {e}")

    @slash.command(name="leaveserver", description="Make the bot leave a server by ID. (Owner only)")
    @app_commands.describe(guild_id="The ID of the server to leave")
    @owner_only()
    async def leaveserver_slash(self, interaction: discord.Interaction, guild_id: str):
        await interaction.response.defer(ephemeral=True)

        try:
            gid = int(guild_id)
        except ValueError:
            await interaction.followup.send("❌ Invalid server ID. Please provide a valid numeric ID.", ephemeral=True)
            return

        guild = self.bot.get_guild(gid)
        if not guild:
            await interaction.followup.send(f"❌ No server found with ID: `{gid}`", ephemeral=True)
            return

        embed = build(title="⚠️ Leave Server", description=f"You are about to make the bot leave **{guild.name}** (`{guild.id}`).\n\nThis action cannot be undone.", color=Config.COLOR_WARN, bot=self.bot)

        view = ConfirmActionView(interaction.user.id, "leave_server")
        await interaction.followup.send(embed=embed, view=view, ephemeral=True)
        await view.wait()

        if view.confirmed:
            try:
                await guild.leave()
                await interaction.edit_original_response(embed=build(title="✅ Left Server", description=f"Left server: **{guild.name}** (`{guild.id}`)", color=Config.COLOR_OK, bot=self.bot), view=None)
                log.info(f"👋 Bot left server {guild.name} ({guild.id}) requested by {interaction.user}")

                log_embed = build(title="👋 Left Server", description=f"Left **{guild.name}** (`{guild.id}`)\nRequested by {interaction.user}", color=Config.COLOR_INFO, bot=self.bot)
                await _send_to_owner_log(self.bot, log_embed)

            except Exception as e:
                await interaction.edit_original_response(embed=build(title="❌ Failed", description=f"Failed to leave server: {e}", color=Config.COLOR_ERR, bot=self.bot), view=None)

    @commands.command(name="serverstats")
    @is_owner()
    async def serverstats(self, ctx):
        await self._send_server_stats(ctx)

    @slash.command(name="serverstats", description="Show bot statistics. (Owner only)")
    @owner_only()
    async def serverstats_slash(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        await self._send_server_stats_slash(interaction)

    async def _send_server_stats(self, ctx):
        total_guilds = len(self.bot.guilds)
        total_members = sum(g.member_count for g in self.bot.guilds)
        total_channels = sum(len(g.channels) for g in self.bot.guilds)
        total_emojis = sum(len(g.emojis) for g in self.bot.guilds)

        shard_id = ctx.bot.shard_id if ctx.bot.shard_id is not None else 0
        shard_count = ctx.bot.shard_count if ctx.bot.shard_count is not None else 1

        embed = build(title="📊 Bot Statistics", color=Config.COLOR_INFO, bot=self.bot)

        embed.add_field(name="🏠 Servers", value=f"**{total_guilds:,}**", inline=True)
        embed.add_field(name="👥 Users", value=f"**{total_members:,}**", inline=True)
        embed.add_field(name="📺 Channels", value=f"**{total_channels:,}**", inline=True)
        embed.add_field(name="😀 Emojis", value=f"**{total_emojis:,}**", inline=True)
        embed.add_field(name="🔀 Shard", value=f"**{shard_id+1}/{shard_count}**", inline=True)
        embed.add_field(name="📦 Cogs Loaded", value=f"**{len(self.bot.extensions)}**", inline=True)

        embed.set_footer(text="Sparky Bot")

        await ctx.reply(embed=embed)

    async def _send_server_stats_slash(self, interaction: discord.Interaction):
        total_guilds = len(self.bot.guilds)
        total_members = sum(g.member_count for g in self.bot.guilds)
        total_channels = sum(len(g.channels) for g in self.bot.guilds)
        total_emojis = sum(len(g.emojis) for g in self.bot.guilds)

        shard_id = interaction.client.shard_id if interaction.client.shard_id is not None else 0
        shard_count = interaction.client.shard_count if interaction.client.shard_count is not None else 1

        embed = build(title="📊 Bot Statistics", color=Config.COLOR_INFO, bot=self.bot)

        embed.add_field(name="🏠 Servers", value=f"**{total_guilds:,}**", inline=True)
        embed.add_field(name="👥 Users", value=f"**{total_members:,}**", inline=True)
        embed.add_field(name="📺 Channels", value=f"**{total_channels:,}**", inline=True)
        embed.add_field(name="😀 Emojis", value=f"**{total_emojis:,}**", inline=True)
        embed.add_field(name="🔀 Shard", value=f"**{shard_id+1}/{shard_count}**", inline=True)
        embed.add_field(name="📦 Cogs Loaded", value=f"**{len(self.bot.extensions)}**", inline=True)

        embed.set_footer(text="Sparky Bot")

        await interaction.followup.send(embed=embed)

    @commands.command(name="247approve")
    @is_owner()
    async def p_247_approve(self, ctx, guild_id: int):
        await self._do_247_approve(ctx, guild_id)

    @commands.command(name="247unapprove")
    @is_owner()
    async def p_247_unapprove(self, ctx, guild_id: int):
        await self._do_247_unapprove(ctx, guild_id)

    @commands.command(name="247list")
    @is_owner()
    async def p_247_list(self, ctx):
        await self._do_247_list(ctx)

    @slash.command(name="247approve", description="[OWNER] Approve a server for 24/7 mode")
    @app_commands.describe(guild_id="The ID of the server to approve")
    @owner_only()
    async def slash_247_approve(self, interaction: discord.Interaction, guild_id: str):
        await interaction.response.defer(ephemeral=True)
        try:
            gid = int(guild_id)
        except ValueError:
            await interaction.followup.send("❌ Invalid server ID. Please provide a valid numeric ID.", ephemeral=True)
            return
        await self._do_247_approve_slash(interaction, gid)

    @slash.command(name="247unapprove", description="[OWNER] Remove 24/7 mode approval from a server")
    @app_commands.describe(guild_id="The ID of the server to unapprove")
    @owner_only()
    async def slash_247_unapprove(self, interaction: discord.Interaction, guild_id: str):
        await interaction.response.defer(ephemeral=True)
        try:
            gid = int(guild_id)
        except ValueError:
            await interaction.followup.send("❌ Invalid server ID. Please provide a valid numeric ID.", ephemeral=True)
            return
        await self._do_247_unapprove_slash(interaction, gid)

    @slash.command(name="247list", description="[OWNER] List all approved 24/7 servers")
    @owner_only()
    async def slash_247_list(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        await self._do_247_list_slash(interaction)

    async def _do_247_approve(self, ctx, guild_id: int):
        music_cog = self.bot.get_cog("Music")
        if not music_cog:
            await ctx.reply("❌ Music cog is not loaded.")
            return

        guild = self.bot.get_guild(guild_id)
        if not guild:
            await ctx.reply(f"❌ Server with ID `{guild_id}` not found.")
            return

        if guild_id in music_cog._247_approved_servers:
            await ctx.reply(f"✅ Server `{guild.name}` (`{guild_id}`) is already approved.")
            return

        music_cog._247_approved_servers.add(guild_id)
        music_cog._save_247_approvals()

        embed = build(title="✅ Server Approved for 24/7 Mode", description=f"Server **{guild.name}** (`{guild_id}`) can now use 24/7 mode.", color=Config.COLOR_OK, bot=self.bot)
        embed.add_field(name="👤 Approved By", value=str(ctx.author), inline=True)
        embed.add_field(name="🏠 Server Name", value=guild.name, inline=True)
        embed.add_field(name="👥 Members", value=f"{guild.member_count:,}", inline=True)
        await ctx.reply(embed=embed)

        log.info(f"✅ 24/7 mode approved for guild {guild_id} by {ctx.author}")

        log_embed = build(title="✅ 24/7 Mode Approved", description=f"Server **{guild.name}** (`{guild_id}`) approved by {ctx.author}", color=Config.COLOR_OK, bot=self.bot)
        await _send_to_owner_log(self.bot, log_embed)

    async def _do_247_approve_slash(self, interaction: discord.Interaction, guild_id: int):
        music_cog = self.bot.get_cog("Music")
        if not music_cog:
            await interaction.followup.send("❌ Music cog is not loaded.", ephemeral=True)
            return

        guild = self.bot.get_guild(guild_id)
        if not guild:
            await interaction.followup.send(f"❌ Server with ID `{guild_id}` not found.", ephemeral=True)
            return

        if guild_id in music_cog._247_approved_servers:
            await interaction.followup.send(f"✅ Server `{guild.name}` (`{guild_id}`) is already approved.", ephemeral=True)
            return

        music_cog._247_approved_servers.add(guild_id)
        music_cog._save_247_approvals()

        embed = build(title="✅ Server Approved for 24/7 Mode", description=f"Server **{guild.name}** (`{guild_id}`) can now use 24/7 mode.", color=Config.COLOR_OK, bot=self.bot)
        embed.add_field(name="👤 Approved By", value=str(interaction.user), inline=True)
        embed.add_field(name="🏠 Server Name", value=guild.name, inline=True)
        embed.add_field(name="👥 Members", value=f"{guild.member_count:,}", inline=True)
        await interaction.followup.send(embed=embed, ephemeral=True)

        log.info(f"✅ 24/7 mode approved for guild {guild_id} by {interaction.user}")

        log_embed = build(title="✅ 24/7 Mode Approved", description=f"Server **{guild.name}** (`{guild_id}`) approved by {interaction.user}", color=Config.COLOR_OK, bot=self.bot)
        await _send_to_owner_log(self.bot, log_embed)

    async def _do_247_unapprove(self, ctx, guild_id: int):
        music_cog = self.bot.get_cog("Music")
        if not music_cog:
            await ctx.reply("❌ Music cog is not loaded.")
            return

        if guild_id not in music_cog._247_approved_servers:
            await ctx.reply(f"❌ Server with ID `{guild_id}` is not approved.")
            return

        guild = self.bot.get_guild(guild_id)
        guild_name = guild.name if guild else f"Unknown ({guild_id})"

        was_enabled = music_cog.twenty_four_seven.get(guild_id, False)

        music_cog._247_approved_servers.remove(guild_id)
        music_cog._save_247_approvals()

        if was_enabled:
            music_cog.twenty_four_seven.pop(guild_id, None)
            music_cog._save_guild_data(guild_id)

            if guild:
                voice_client = discord.utils.get(ctx.bot.voice_clients, guild=guild)
                if voice_client and voice_client.is_connected():
                    members = [m for m in voice_client.channel.members if not m.bot]
                    if len(members) == 0:
                        await voice_client.disconnect()
                        print(f"[Music] Disconnected from {guild.name} after 24/7 unapproval")

        embed = build(title="❌ Server Unapproved for 24/7 Mode", description=f"Server **{guild_name}** (`{guild_id}`) can no longer use 24/7 mode.", color=Config.COLOR_ERR, bot=self.bot)
        embed.add_field(name="👤 Unapproved By", value=str(ctx.author), inline=True)
        if was_enabled:
            embed.add_field(name="🔄 24/7 Mode", value="✅ **Disabled** (was enabled, now turned off)", inline=True)
        await ctx.reply(embed=embed)

        log.info(f"❌ 24/7 mode unapproved for guild {guild_id} by {ctx.author}")

        log_embed = build(title="❌ 24/7 Mode Unapproved", description=f"Server **{guild_name}** (`{guild_id}`) unapproved by {ctx.author}", color=Config.COLOR_ERR, bot=self.bot)
        if was_enabled:
            log_embed.add_field(name="🔄 24/7 Mode", value="Disabled (was active)", inline=True)
        await _send_to_owner_log(self.bot, log_embed)

    async def _do_247_unapprove_slash(self, interaction: discord.Interaction, guild_id: int):
        music_cog = self.bot.get_cog("Music")
        if not music_cog:
            await interaction.followup.send("❌ Music cog is not loaded.", ephemeral=True)
            return

        if guild_id not in music_cog._247_approved_servers:
            await interaction.followup.send(f"❌ Server with ID `{guild_id}` is not approved.", ephemeral=True)
            return

        guild = self.bot.get_guild(guild_id)
        guild_name = guild.name if guild else f"Unknown ({guild_id})"

        was_enabled = music_cog.twenty_four_seven.get(guild_id, False)

        music_cog._247_approved_servers.remove(guild_id)
        music_cog._save_247_approvals()

        if was_enabled:
            music_cog.twenty_four_seven.pop(guild_id, None)
            music_cog._save_guild_data(guild_id)

            if guild:
                voice_client = discord.utils.get(interaction.client.voice_clients, guild=guild)
                if voice_client and voice_client.is_connected():
                    members = [m for m in voice_client.channel.members if not m.bot]
                    if len(members) == 0:
                        await voice_client.disconnect()
                        print(f"[Music] Disconnected from {guild.name} after 24/7 unapproval")

        embed = build(title="❌ Server Unapproved for 24/7 Mode", description=f"Server **{guild_name}** (`{guild_id}`) can no longer use 24/7 mode.", color=Config.COLOR_ERR, bot=self.bot)
        embed.add_field(name="👤 Unapproved By", value=str(interaction.user), inline=True)
        if was_enabled:
            embed.add_field(name="🔄 24/7 Mode", value="✅ **Disabled** (was enabled, now turned off)", inline=True)
        await interaction.followup.send(embed=embed, ephemeral=True)

        log.info(f"❌ 24/7 mode unapproved for guild {guild_id} by {interaction.user}")

        log_embed = build(title="❌ 24/7 Mode Unapproved", description=f"Server **{guild_name}** (`{guild_id}`) unapproved by {interaction.user}", color=Config.COLOR_ERR, bot=self.bot)
        if was_enabled:
            log_embed.add_field(name="🔄 24/7 Mode", value="Disabled (was active)", inline=True)
        await _send_to_owner_log(interaction.client, log_embed)

    async def _do_247_list(self, ctx):
        music_cog = self.bot.get_cog("Music")
        if not music_cog:
            await ctx.reply("❌ Music cog is not loaded.")
            return

        if not music_cog._247_approved_servers:
            await ctx.reply("📋 No servers are currently approved for 24/7 mode.")
            return

        approved_list = []
        for guild_id in music_cog._247_approved_servers:
            guild = self.bot.get_guild(guild_id)
            guild_name = guild.name if guild else f"Unknown ({guild_id})"
            is_enabled = "✅" if music_cog.twenty_four_seven.get(guild_id, False) else "❌"
            member_count = guild.member_count if guild else "N/A"
            approved_list.append(f"{is_enabled} `{guild_name}` (`{guild_id}`) - {member_count} members")

        chunks = [approved_list[i:i+20] for i in range(0, len(approved_list), 20)]

        for i, chunk in enumerate(chunks):
            embed = build(title=f"📋 Approved 24/7 Servers ({i+1}/{len(chunks)})", description="\n".join(chunk), color=Config.COLOR_INFO, bot=self.bot)
            embed.set_footer(text=f"Total: {len(approved_list)} servers • ✅ = 24/7 Enabled, ❌ = 24/7 Disabled")
            await ctx.reply(embed=embed)

    async def _do_247_list_slash(self, interaction: discord.Interaction):
        music_cog = self.bot.get_cog("Music")
        if not music_cog:
            await interaction.followup.send("❌ Music cog is not loaded.", ephemeral=True)
            return

        if not music_cog._247_approved_servers:
            await interaction.followup.send("📋 No servers are currently approved for 24/7 mode.", ephemeral=True)
            return

        approved_list = []
        for guild_id in music_cog._247_approved_servers:
            guild = self.bot.get_guild(guild_id)
            guild_name = guild.name if guild else f"Unknown ({guild_id})"
            is_enabled = "✅" if music_cog.twenty_four_seven.get(guild_id, False) else "❌"
            member_count = guild.member_count if guild else "N/A"
            approved_list.append(f"{is_enabled} `{guild_name}` (`{guild_id}`) - {member_count} members")

        chunks = [approved_list[i:i+20] for i in range(0, len(approved_list), 20)]

        for i, chunk in enumerate(chunks):
            embed = build(title=f"📋 Approved 24/7 Servers ({i+1}/{len(chunks)})", description="\n".join(chunk), color=Config.COLOR_INFO, bot=self.bot)
            embed.set_footer(text=f"Total: {len(approved_list)} servers • ✅ = 24/7 Enabled, ❌ = 24/7 Disabled")
            if i == 0:
                await interaction.followup.send(embed=embed, ephemeral=True)
            else:
                await interaction.followup.send(embed=embed, ephemeral=True)

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            missing = ", ".join(p.replace("_", " ").title() for p in error.missing_permissions)
            log.warning(f"[Owner] {interaction.user} ({interaction.user.id}) missing permissions: {missing}")
            try:
                await interaction.response.send_message(f"❌ You are missing the required permissions: **{missing}**.", ephemeral=True)
            except discord.InteractionResponded:
                await interaction.followup.send(f"❌ You are missing the required permissions: **{missing}**.", ephemeral=True)
        elif isinstance(error, app_commands.CheckFailure):
            try:
                await interaction.response.send_message("❌ This command is only available to the bot owner.", ephemeral=True)
            except discord.InteractionResponded:
                await interaction.followup.send("❌ This command is only available to the bot owner.", ephemeral=True)
        else:
            log.error(f"Unhandled error in owner cog: {error}")
            try:
                await interaction.response.send_message(f"❌ An error occurred: {str(error)[:100]}", ephemeral=True)
            except discord.InteractionResponded:
                await interaction.followup.send(f"❌ An error occurred: {str(error)[:100]}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Owner(bot))