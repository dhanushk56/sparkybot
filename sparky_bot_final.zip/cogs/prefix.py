import discord
from discord.ext import commands
from discord import app_commands
from datetime import datetime, timezone
from config import Config
from utils.embed import build
from utils.theme import Theme
from utils.prefix_manager import get_prefixes, set_prefixes, add_prefix, remove_prefix

class Prefix(commands.Cog):

    def __init__(self, bot):
        self.bot = bot

    async def _check_permissions(self, interaction: discord.Interaction) -> bool:
        if not interaction.user.guild_permissions.manage_guild:
            await interaction.response.send_message(
                f"❌ You are missing the following permissions: **Manage Server**",
                ephemeral=True
            )
            return False
        return True

    prefix = app_commands.Group(name="prefix", description="Custom prefix management")

    @prefix.command(name="set", description="[ADMIN] Set the bot's prefix for this server")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    @app_commands.describe(prefix="The new prefix (e.g., '!', '$', '>')")
    async def prefix_set(self, interaction: discord.Interaction, prefix: str):

        if not await self._check_permissions(interaction):
            return

        await interaction.response.defer(ephemeral=True)

        if len(prefix) > 10:
            return await interaction.followup.send(
                "❌ Prefix cannot be longer than 10 characters.",
                ephemeral=True
            )

        if not prefix or prefix.isspace():
            return await interaction.followup.send(
                "❌ Prefix cannot be empty or just spaces.",
                ephemeral=True
            )

        set_prefixes(interaction.guild_id, [prefix])

        embed = build(title="✅ Prefix Updated", description=f"Bot prefix for this server is now: `{prefix}`", color=Config.COLOR_OK, bot=self.bot)
        embed.add_field(
            name="📝 How to use",
            value=f"Type `{prefix}help` or `{prefix}ping` to test it out!",
            inline=False
        )
        await interaction.followup.send(embed=embed, ephemeral=True)

    @prefix.command(name="add", description="[ADMIN] Add an additional prefix for this server")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    @app_commands.describe(prefix="The additional prefix to add")
    async def prefix_add(self, interaction: discord.Interaction, prefix: str):

        if not await self._check_permissions(interaction):
            return

        await interaction.response.defer(ephemeral=True)

        if len(prefix) > 10:
            return await interaction.followup.send(
                "❌ Prefix cannot be longer than 10 characters.",
                ephemeral=True
            )

        if not prefix or prefix.isspace():
            return await interaction.followup.send(
                "❌ Prefix cannot be empty or just spaces.",
                ephemeral=True
            )

        if add_prefix(interaction.guild_id, prefix):
            current_prefixes = get_prefixes(interaction.guild_id)
            await interaction.followup.send(
                f"✅ Added `{prefix}` as an additional prefix!\n"
                f"Current prefixes: {', '.join(f'`{p}`' for p in current_prefixes)}",
                ephemeral=True
            )
        else:
            await interaction.followup.send(
                f"❌ `{prefix}` is already a prefix for this server.",
                ephemeral=True
            )

    @prefix.command(name="remove", description="[ADMIN] Remove a prefix for this server")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    @app_commands.describe(prefix="The prefix to remove")
    async def prefix_remove(self, interaction: discord.Interaction, prefix: str):

        if not await self._check_permissions(interaction):
            return

        await interaction.response.defer(ephemeral=True)

        current_prefixes = get_prefixes(interaction.guild_id)

        if len(current_prefixes) <= 1:
            return await interaction.followup.send(
                "❌ You cannot remove the last prefix. Use `/prefix set` to change it.",
                ephemeral=True
            )

        if prefix == "//":
            return await interaction.followup.send(
                "❌ You cannot remove the default prefix.",
                ephemeral=True
            )

        if remove_prefix(interaction.guild_id, prefix):
            new_prefixes = get_prefixes(interaction.guild_id)
            await interaction.followup.send(
                f"✅ Removed `{prefix}` as a prefix for this server.\n"
                f"Current prefixes: {', '.join(f'`{p}`' for p in new_prefixes)}",
                ephemeral=True
            )
        else:
            await interaction.followup.send(
                f"❌ `{prefix}` is not a prefix for this server.",
                ephemeral=True
            )

    @prefix.command(name="list", description="List all prefixes for this server")
    async def prefix_list(self, interaction: discord.Interaction):

        if not interaction.user.guild_permissions.manage_guild:
            await interaction.response.send_message(
                f"❌ You are missing the following permissions: **Manage Server**",
                ephemeral=True
            )
            return

        await interaction.response.defer(ephemeral=True)

        prefixes = get_prefixes(interaction.guild_id)

        embed = build(title="📋 Server Prefixes", description=f"**{len(prefixes)}** prefix(es) configured for this server", color=Config.COLOR_INFO, bot=self.bot)
        embed.add_field(
            name="Current Prefixes",
            value="\n".join(f"`{p}`" for p in prefixes) or "`//` (default)",
            inline=False
        )
        embed.set_footer(text="Use /prefix set, add, or remove to manage prefixes")
        await interaction.followup.send(embed=embed, ephemeral=True)

    @prefix.command(name="reset", description="[ADMIN] Reset prefixes to default for this server")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def prefix_reset(self, interaction: discord.Interaction):

        if not await self._check_permissions(interaction):
            return

        await interaction.response.defer(ephemeral=True)

        set_prefixes(interaction.guild_id, [])

        embed = build(title="✅ Prefix Reset", description="Bot prefix for this server has been reset to: `//`", color=Config.COLOR_OK, bot=self.bot)
        embed.add_field(
            name="📝 Note",
            value="Users can now use `//` as the prefix.",
            inline=False
        )
        await interaction.followup.send(embed=embed, ephemeral=True)

    @commands.command(name="prefix")
    @commands.has_permissions(manage_guild=True)
    async def p_prefix(self, ctx, action: str = None, *, prefix: str = None):
        if not ctx.author.guild_permissions.manage_guild:
            await ctx.reply("❌ You are missing the following permissions: **Manage Server**")
            return

        if not action:

            prefixes = get_prefixes(ctx.guild.id)
            embed = build(title="📋 Server Prefixes", description=f"**{len(prefixes)}** prefix(es) configured", color=Config.COLOR_INFO, bot=self.bot)
            embed.add_field(
                name="Current Prefixes",
                value="\n".join(f"`{p}`" for p in prefixes) or "`//` (default)",
                inline=False
            )
            embed.set_footer(text="Use `//prefix set`, `//prefix add`, or `//prefix remove` to manage")
            return await ctx.reply(embed=embed)

        if action.lower() == "set":
            if not prefix:
                return await ctx.reply("❌ Please provide a prefix. Example: `//prefix set !`")
            if len(prefix) > 10:
                return await ctx.reply("❌ Prefix cannot be longer than 10 characters.")
            if not prefix or prefix.isspace():
                return await ctx.reply("❌ Prefix cannot be empty or just spaces.")

            set_prefixes(ctx.guild.id, [prefix])
            embed = build(title="✅ Prefix Updated", description=f"Bot prefix for this server is now: `{prefix}`", color=Config.COLOR_OK, bot=self.bot)
            embed.add_field(
                name="📝 How to use",
                value=f"Type `{prefix}help` or `{prefix}ping` to test it out!",
                inline=False
            )
            await ctx.reply(embed=embed)

        elif action.lower() == "add":
            if not prefix:
                return await ctx.reply("❌ Please provide a prefix. Example: `//prefix add $`")
            if len(prefix) > 10:
                return await ctx.reply("❌ Prefix cannot be longer than 10 characters.")
            if not prefix or prefix.isspace():
                return await ctx.reply("❌ Prefix cannot be empty or just spaces.")

            if add_prefix(ctx.guild.id, prefix):
                current_prefixes = get_prefixes(ctx.guild.id)
                await ctx.reply(
                    f"✅ Added `{prefix}` as an additional prefix!\n"
                    f"Current prefixes: {', '.join(f'`{p}`' for p in current_prefixes)}"
                )
            else:
                await ctx.reply(f"❌ `{prefix}` is already a prefix for this server.")

        elif action.lower() == "remove":
            if not prefix:
                return await ctx.reply("❌ Please provide a prefix. Example: `//prefix remove $`")

            current_prefixes = get_prefixes(ctx.guild.id)
            if len(current_prefixes) <= 1:
                return await ctx.reply("❌ You cannot remove the last prefix. Use `//prefix set` to change it.")

            if prefix == "//":
                return await ctx.reply("❌ You cannot remove the default prefix.")

            if remove_prefix(ctx.guild.id, prefix):
                new_prefixes = get_prefixes(ctx.guild.id)
                await ctx.reply(
                    f"✅ Removed `{prefix}` as a prefix for this server.\n"
                    f"Current prefixes: {', '.join(f'`{p}`' for p in new_prefixes)}"
                )
            else:
                await ctx.reply(f"❌ `{prefix}` is not a prefix for this server.")

        elif action.lower() == "list":
            prefixes = get_prefixes(ctx.guild.id)
            embed = build(title="📋 Server Prefixes", description=f"**{len(prefixes)}** prefix(es) configured", color=Config.COLOR_INFO, bot=self.bot)
            embed.add_field(
                name="Current Prefixes",
                value="\n".join(f"`{p}`" for p in prefixes) or "`//` (default)",
                inline=False
            )
            embed.set_footer(text="Use `//prefix set`, `//prefix add`, or `//prefix remove` to manage")
            await ctx.reply(embed=embed)

        elif action.lower() == "reset":
            set_prefixes(ctx.guild.id, [])
            embed = build(title="✅ Prefix Reset", description="Bot prefix for this server has been reset to: `//`", color=Config.COLOR_OK)
            embed.add_field(
                name="📝 Note",
                value="Users can now use `//` as the prefix.",
                inline=False
            )
            await ctx.reply(embed=embed)

        else:
            await ctx.reply(
                "❌ Unknown action. Available: `set`, `add`, `remove`, `list`, `reset`\n"
                "Example: `//prefix set !`"
            )

    @p_prefix.error
    async def p_prefix_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            await ctx.reply("❌ You are missing the following permissions: **Manage Server**")
        else:
            print(f"[Prefix] Error: {error}")
            await ctx.reply(f"❌ An error occurred: {error}")

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            missing = ", ".join(p.replace("_", " ").title() for p in error.missing_permissions)
            await interaction.response.send_message(
                f"❌ You are missing the following permissions: **{missing}**",
                ephemeral=True
            )
        else:
            print(f"[Prefix] Error: {error}")
            try:
                await interaction.response.send_message(f"❌ An error occurred: {error}", ephemeral=True)
            except discord.InteractionResponded:
                await interaction.followup.send(f"❌ An error occurred: {error}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Prefix(bot))
