import logging
import discord
from discord.ext import commands
from discord import app_commands
from config import Config
from utils.emojis import Emojis
from utils.theme import Theme
from utils.embed import build, error_embed
from utils.prefix_manager import get_prefixes

logger = logging.getLogger(__name__)

# Use only Unicode emojis for the dropdown menu (they always work)
# This is separate from the Emojis class which may contain custom IDs for other uses
UNICODE_EMOJIS = {
    "Owner": "👑",
    "Admin": "🛠️",
    "Prefix": "⌨️",
    "Help": "🧭",
    "Fun": "🎲",
    "Embed & Rules": "🖼️",
    "Utility": "⚙️",
    "Logging": "📜",
    "Music": "🎧",
    "Translation": "🌐",
    "Giveaway": "🎁",
    "Reaction Roles": "🎭",
    "Moderation": "🔨",
    "AutoMod": "🧹",
    "Anti-Nuke": "🧨",
    "Reports": "🚩",
    "Tickets": "🎟️",
    "Verification": "✅",
    "Welcome": "🚪",
    "JTC": "🔊",
    "YouTube": "📹",
    "Forum Lock": "🔒",
    "InviteTracking": "📨",
    "Leveling": "📈",
    "Applications": "📋",
    "Economy": "💰",
    "Counting": "🔢",
}

MODULE_INFO = {
    "Owner": ("Core control panel for the bot owner", UNICODE_EMOJIS["Owner"]),
    "Admin": ("Server configuration and module toggles", UNICODE_EMOJIS["Admin"]),
    "Prefix": ("Manage custom server prefixes", UNICODE_EMOJIS["Prefix"]),
    "Help": ("This menu", UNICODE_EMOJIS["Help"]),
    "Fun": ("8ball, coinflip, trivia, roast, ship and more", UNICODE_EMOJIS["Fun"]),
    "Embed & Rules": ("Rich embed builder and rules panels", UNICODE_EMOJIS["Embed & Rules"]),
    "Utility": ("Ping, userinfo, serverinfo, polls, reminders", UNICODE_EMOJIS["Utility"]),
    "Logging": ("Event logging for messages, members and roles", UNICODE_EMOJIS["Logging"]),
    "Music": ("Full music system with queue and 24/7 mode", UNICODE_EMOJIS["Music"]),
    "Translation": ("100+ languages with auto-translate", UNICODE_EMOJIS["Translation"]),
    "Giveaway": ("Create and manage giveaways", UNICODE_EMOJIS["Giveaway"]),
    "Reaction Roles": ("Assign roles through reactions", UNICODE_EMOJIS["Reaction Roles"]),
    "Moderation": ("Kick, ban, mute, warn, purge and lockdown", UNICODE_EMOJIS["Moderation"]),
    "AutoMod": ("Automatic spam, invite and word filtering", UNICODE_EMOJIS["AutoMod"]),
    "Anti-Nuke": ("Server protection against mass actions", UNICODE_EMOJIS["Anti-Nuke"]),
    "Reports": ("Member reports, suggestions and bug reports", UNICODE_EMOJIS["Reports"]),
    "Tickets": ("Support ticket system with transcripts", UNICODE_EMOJIS["Tickets"]),
    "Verification": ("Captcha verification for new members", UNICODE_EMOJIS["Verification"]),
    "Welcome": ("Welcome and goodbye messages", UNICODE_EMOJIS["Welcome"]),
    "JTC": ("Join-to-create voice channels", UNICODE_EMOJIS["JTC"]),
    "YouTube": ("YouTube upload notifications", UNICODE_EMOJIS["YouTube"]),
    "Forum Lock": ("Automatically lock forum posts", UNICODE_EMOJIS["Forum Lock"]),
    "InviteTracking": ("Invite tracking and leaderboards", UNICODE_EMOJIS["InviteTracking"]),
    "Leveling": ("XP, ranks and levelling rewards", UNICODE_EMOJIS["Leveling"]),
    "Applications": ("Custom application forms", UNICODE_EMOJIS["Applications"]),
    "Economy": ("Currency, jobs, shop and gambling", UNICODE_EMOJIS["Economy"]),
    "Counting": ("Counting channel with streaks", UNICODE_EMOJIS["Counting"]),
}

COG_TO_MODULE = {
    "Owner": "Owner", "Admin": "Admin", "Prefix": "Prefix", "Help": "Help",
    "Fun": "Fun", "Embed": "Embed & Rules", "Rules": "Embed & Rules",
    "Utility": "Utility", "Logging": "Logging", "Music": "Music",
    "Translation": "Translation", "Giveaway": "Giveaway", "ReactionRoles": "Reaction Roles",
    "Moderation": "Moderation", "AutoMod": "AutoMod", "AntiNuke": "Anti-Nuke",
    "Reports": "Reports", "Tickets": "Tickets", "Verification": "Verification",
    "Welcome": "Welcome", "JTC": "JTC", "YouTube": "YouTube", "ForumLock": "Forum Lock",
    "InviteTracking": "InviteTracking", "Leveling": "Leveling", "Applications": "Applications",
    "Economy": "Economy", "CountingListener": "Counting",
}

def module_name(cog_name: str) -> str:
    return COG_TO_MODULE.get(cog_name, cog_name)

def module_meta(name: str):
    return MODULE_INFO.get(name, ("", UNICODE_EMOJIS.get(name, "📌")))

class HelpView(discord.ui.View):
    PER_PAGE = 24

    def __init__(self, bot, author_id: int, prefix: str):
        super().__init__(timeout=150)
        self.bot = bot
        self.author_id = author_id
        self.prefix = prefix
        self.message = None
        self.selected = None
        self.page = 0
        self.modules = self._collect_modules()
        self.names = list(self.modules.keys())
        self.total_pages = max(1, -(-len(self.names) // self.PER_PAGE))
        self._build()

    def _collect_modules(self) -> list:
        found = {}
        for cog_name, cog in self.bot.cogs.items():
            name = module_name(cog_name)
            if name in ("Help",):
                continue
            cmds = [c for c in cog.walk_commands() if not c.hidden]
            if cmds:
                found.setdefault(name, []).extend(cmds)
        return dict(sorted(found.items()))

    def _select_options(self) -> list:
        options = [discord.SelectOption(label="Overview", value="__home__", emoji="📌")]
        start = self.page * self.PER_PAGE
        for name in self.names[start:start + self.PER_PAGE]:
            cmds = self.modules[name]
            desc, emoji = module_meta(name)
            # Ensure emoji is a string (never None)
            if emoji is None:
                emoji = "📌"
            options.append(discord.SelectOption(
                label=f"{name} ({len(cmds)})",
                value=name,
                emoji=emoji,
                description=desc[:95] if desc else None,
            ))
        return options

    def _build(self):
        self.clear_items()
        try:
            select = discord.ui.Select(
                placeholder="Browse a module...",
                options=self._select_options(),
                min_values=1, max_values=1, row=0,
            )
            select.callback = self._on_select
            self.add_item(select)
        except Exception as e:
            logger.error(f"Failed to build select menu: {e}", exc_info=True)
            # Fallback: add a simple button that opens the home embed
            fallback_btn = discord.ui.Button(label="Open Help", style=discord.ButtonStyle.primary, row=0)
            fallback_btn.callback = self._on_fallback
            self.add_item(fallback_btn)

        if self.total_pages > 1:
            prev_btn = discord.ui.Button(emoji="◀️", style=discord.ButtonStyle.secondary, row=1,
                                          disabled=self.page == 0)
            prev_btn.callback = self._on_prev
            next_btn = discord.ui.Button(emoji="▶️", style=discord.ButtonStyle.secondary, row=1,
                                          disabled=self.page >= self.total_pages - 1)
            next_btn.callback = self._on_next
            self.add_item(prev_btn)
            self.add_item(next_btn)

        self.add_item(self._link_button("Invite", "🔗",
            f"https://discord.com/oauth2/authorize?client_id={self.bot.user.id}&permissions=1099512676374&integration_type=0&scope=bot+applications.commands"))
        self.add_item(self._link_button("Support", "🌐", "https://discord.gg/sEJ6FwHGJw"))
        self.add_item(self._link_button("Vote", "⭐", "https://discord.com/application-directory"))

    async def _on_fallback(self, interaction: discord.Interaction):
        await interaction.response.send_message("Use `/help` to open the help menu.", ephemeral=True)

    async def _on_prev(self, interaction: discord.Interaction):
        self.page = max(0, self.page - 1)
        self._build()
        embed = self.home_embed() if self.selected is None else self.module_embed(self.selected)
        await interaction.response.edit_message(embed=embed, view=self)

    async def _on_next(self, interaction: discord.Interaction):
        self.page = min(self.total_pages - 1, self.page + 1)
        self._build()
        embed = self.home_embed() if self.selected is None else self.module_embed(self.selected)
        await interaction.response.edit_message(embed=embed, view=self)

    def _link_button(self, label, emoji, url):
        return discord.ui.Button(label=label, emoji=emoji, style=discord.ButtonStyle.link, url=url)

    def home_embed(self) -> discord.Embed:
        total = sum(len(v) for v in self.modules.values())
        lines = []
        for name, cmds in self.modules.items():
            desc, emoji = module_meta(name)
            lines.append(f"{emoji} **{name}** {Emojis.DOT} `{len(cmds)}`")
        e = build(
            title="Sparky",
            description=(
                f"{Emojis.BULLET} My prefix here is `{self.prefix}`\n"
                f"{Emojis.BULLET} Type `{self.prefix}help <module>` for a category\n"
                f"{Emojis.BULLET} Total commands: `{total}`\n\n"
                + "\n".join(lines)
            ),
            color=Theme.COLOR_PRIMARY,
            emoji=Emojis.STAR,
            bot=self.bot,
            note="Select a module below",
        )
        return e

    def module_embed(self, name: str) -> discord.Embed:
        cmds = self.modules.get(name, [])
        desc, emoji = module_meta(name)
        body = [f"*{desc}*", ""] if desc else []
        for cmd in sorted(cmds, key=lambda c: c.qualified_name):
            usage = self._usage(cmd)
            body.append(f"{Emojis.ARROW} `{self.prefix}{cmd.qualified_name}{usage}`")
        e = build(
            title=f"{name}",
            description="\n".join(body) if body else "*No commands in this module.*",
            color=Theme.COLOR_PRIMARY,
            emoji=emoji,
            bot=self.bot,
            note=f"{len(cmds)} commands",
        )
        return e

    def _usage(self, cmd) -> str:
        parts = []
        for pname, param in cmd.clean_params.items():
            if param.default is param.empty:
                parts.append(f" <{pname}>")
            else:
                parts.append(f" [{pname}]")
        return "".join(parts)

    async def _on_select(self, interaction: discord.Interaction):
        value = interaction.data["values"][0]
        self.selected = None if value == "__home__" else value
        embed = self.home_embed() if self.selected is None else self.module_embed(self.selected)
        await interaction.response.edit_message(embed=embed, view=self)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.author_id:
            await interaction.response.send_message(
                f"{Emojis.WRONG} This menu belongs to someone else.", ephemeral=True
            )
            return False
        return True

    async def on_timeout(self):
        for child in self.children:
            child.disabled = True
        if self.message:
            try:
                await self.message.edit(view=self)
            except discord.HTTPException:
                pass

class Help(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def _prefix_for(self, ctx_or_interaction) -> str:
        guild = getattr(ctx_or_interaction, "guild", None)
        if guild:
            prefixes = get_prefixes(guild.id)
            return prefixes[0] if prefixes else Config.PREFIX
        return Config.PREFIX

    @commands.command(name="help")
    async def help_prefix(self, ctx, *, command_name: str = None):
        if command_name:
            await self._command_help(ctx, command_name)
            return
        prefix = self._prefix_for(ctx)
        view = HelpView(self.bot, ctx.author.id, prefix)
        msg = await ctx.reply(embed=view.home_embed(), view=view)
        view.message = msg

    @app_commands.command(name="help", description="Open the Sparky help menu.")
    async def help_slash(self, interaction: discord.Interaction):
        prefix = self._prefix_for(interaction)
        view = HelpView(self.bot, interaction.user.id, prefix)
        await interaction.response.send_message(embed=view.home_embed(), view=view)
        view.message = await interaction.original_response()

    async def _command_help(self, ctx, command_name: str):
        try:
            cmd = self.bot.get_command(command_name)
            prefix = self._prefix_for(ctx)
            if not cmd:
                await ctx.reply(embed=error_embed(f"No command called `{command_name}` was found.", bot=self.bot))
                return

            usage_parts = []
            for pname, param in cmd.clean_params.items():
                usage_parts.append(f"<{pname}>" if param.default is param.empty else f"[{pname}]")
            usage = f"`{prefix}{cmd.qualified_name} {' '.join(usage_parts)}`".strip()

            e = build(
                title=cmd.qualified_name,
                description=cmd.help or "No description set.",
                color=Theme.COLOR_PRIMARY,
                emoji=Emojis.STAR,
                bot=self.bot,
            )
            e.add_field(name="Usage", value=usage, inline=False)
            if cmd.aliases:
                e.add_field(name="Aliases", value=", ".join(f"`{prefix}{a}`" for a in cmd.aliases), inline=False)
            await ctx.reply(embed=e)
        except Exception as e:
            logger.error(f"Error in command help for '{command_name}':", exc_info=True)
            await ctx.reply(embed=error_embed(f"An error occurred: {e}", bot=self.bot))

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        logger.error(f"Help cog error: {error}", exc_info=True)
        try:
            if interaction.response.is_done():
                await interaction.followup.send(f"❌ An error occurred: {error}", ephemeral=True)
            else:
                await interaction.response.send_message(f"❌ An error occurred: {error}", ephemeral=True)
        except:
            pass

async def setup(bot):
    await bot.add_cog(Help(bot))