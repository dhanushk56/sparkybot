import discord
from discord.ext import commands
from discord import app_commands
import asyncio
import re
from datetime import datetime, timezone, timedelta
from config import Config
from utils.embed import build
from utils.theme import Theme
from utils.data import load, save

def parse_duration_to_seconds(duration: str) -> int:
    duration = duration.strip().lower()
    if not duration:
        raise ValueError("Duration cannot be empty")
    units = {
        "w": 7 * 24 * 3600, "week": 7 * 24 * 3600, "weeks": 7 * 24 * 3600,
        "d": 24 * 3600, "day": 24 * 3600, "days": 24 * 3600,
        "h": 3600, "hour": 3600, "hours": 3600, "hr": 3600,
        "m": 60, "min": 60, "mins": 60, "minute": 60, "minutes": 60,
        "s": 1, "sec": 1, "secs": 1, "second": 1, "seconds": 1,
    }
    try:
        return int(duration)
    except ValueError:
        pass
    tokens = re.findall(r"([\d.]+)\s*([a-zA-Z]+)", duration)
    total_seconds = 0
    found_unit = False
    for number_str, unit_str in tokens:
        number = float(number_str)
        if number < 0:
            raise ValueError("Negative values are not allowed")
        unit_str = unit_str.strip().lower()
        if unit_str.endswith('s') and unit_str not in ('weeks', 'days', 'hours', 'minutes', 'seconds', 'mins', 'secs'):
            unit_str = unit_str[:-1]
        if unit_str in units:
            total_seconds += int(number * units[unit_str])
            found_unit = True
        else:
            raise ValueError(f"Unknown time unit: '{unit_str}'")
    if not found_unit:
        raise ValueError(f"Invalid duration format: '{duration}'")
    if total_seconds <= 0:
        raise ValueError("Duration must be greater than 0")
    return total_seconds

def format_duration(seconds: int) -> str:
    if seconds <= 0:
        return "0s"
    days = seconds // 86400
    seconds %= 86400
    hours = seconds // 3600
    seconds %= 3600
    minutes = seconds // 60
    seconds %= 60
    parts = []
    if days:
        parts.append(f"{days}d")
    if hours:
        parts.append(f"{hours}h")
    if minutes:
        parts.append(f"{minutes}m")
    if seconds:
        parts.append(f"{seconds}s")
    return " ".join(parts) if parts else "0s"

def mod_embed(title: str, description: str, color=Config.COLOR_MOD) -> discord.Embed:
    e = build(title=title, description=description, color=color)
    return e

class ForumLock(commands.Cog):
    slash = app_commands.Group(name="forumlock", description="Forum auto-lock commands")

    def __init__(self, bot):
        self.bot = bot
        self._lock_tasks = {}

    def _get_settings(self, guild_id: int) -> dict:
        data = load("guild_settings.json")
        return data.get(str(guild_id), {}).get("forum_auto_lock", {})

    def _save_settings(self, guild_id: int, settings: dict):
        data = load("guild_settings.json")
        data.setdefault(str(guild_id), {})["forum_auto_lock"] = settings
        save("guild_settings.json", data)

    def _get_guild_settings(self, guild_id: int) -> dict:
        data = load("guild_settings.json")
        return data.get(str(guild_id), {})

    def _save_guild_settings(self, guild_id: int, guild_data: dict):
        data = load("guild_settings.json")
        data[str(guild_id)] = guild_data
        save("guild_settings.json", data)

    # ========== SLASH COMMANDS ==========
    @slash.command(name="set", description="Automatically lock forum posts after a set time.")
    @app_commands.describe(forum_channel="The forum channel to monitor", duration="Duration before locking (e.g. 5m, 2h, 3d, 1w)", enabled="Enable or disable auto-lock for this channel")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def set_autolock(self, interaction: discord.Interaction, forum_channel: discord.ForumChannel, duration: str, enabled: bool = True):
        try:
            seconds = parse_duration_to_seconds(duration)
        except ValueError as e:
            return await interaction.response.send_message(embed=mod_embed("❌ Invalid Duration", str(e), Config.COLOR_ERR), ephemeral=True)
        if seconds < 60:
            return await interaction.response.send_message(embed=mod_embed("❌ Duration Too Short", "Duration must be at least 1 minute (60s).", Config.COLOR_ERR), ephemeral=True)
        settings = self._get_settings(interaction.guild.id)
        settings[str(forum_channel.id)] = {
            "enabled": enabled,
            "duration_seconds": seconds,
            "duration_readable": format_duration(seconds),
            "locked_count": 0
        }
        self._save_settings(interaction.guild.id, settings)
        status = "✅ Enabled" if enabled else "❌ Disabled"
        await interaction.response.send_message(embed=mod_embed(f"🔒 Forum Auto-Lock {status}", f"**Channel:** {forum_channel.mention}\n**Duration:** {format_duration(seconds)}\n**Status:** {'Active' if enabled else 'Inactive'}", Config.COLOR_OK if enabled else Config.COLOR_WARN), ephemeral=True)

    @slash.command(name="setlog", description="Set the log channel for forum auto-lock.")
    @app_commands.describe(channel="Channel to send forum lock logs to")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def set_log_channel(self, interaction: discord.Interaction, channel: discord.TextChannel):
        guild_data = self._get_guild_settings(interaction.guild.id)
        guild_data["forum_lock_log_channel"] = channel.id
        self._save_guild_settings(interaction.guild.id, guild_data)
        await interaction.response.send_message(embed=mod_embed("✅ Log Channel Set", f"Forum lock logs will be sent to {channel.mention}.", Config.COLOR_OK), ephemeral=True)

    @slash.command(name="remove", description="Remove auto-lock settings for a forum channel.")
    @app_commands.describe(forum_channel="The forum channel to remove auto-lock from")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def remove_autolock(self, interaction: discord.Interaction, forum_channel: discord.ForumChannel):
        settings = self._get_settings(interaction.guild.id)
        if str(forum_channel.id) not in settings:
            return await interaction.response.send_message(embed=mod_embed("ℹ️ No Settings Found", f"No auto-lock settings found for {forum_channel.mention}.", Config.COLOR_INFO), ephemeral=True)
        del settings[str(forum_channel.id)]
        self._save_settings(interaction.guild.id, settings)
        await interaction.response.send_message(embed=mod_embed("✅ Auto-Lock Removed", f"Auto-lock settings removed for {forum_channel.mention}.", Config.COLOR_OK), ephemeral=True)

    @slash.command(name="list", description="List all forum channels with auto-lock enabled.")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def list_autolock(self, interaction: discord.Interaction):
        settings = self._get_settings(interaction.guild.id)
        if not settings:
            return await interaction.response.send_message(embed=mod_embed("ℹ️ No Auto-Lock Settings", "No forum channels have auto-lock enabled.", Config.COLOR_INFO), ephemeral=True)
        lines = []
        for channel_id, config in settings.items():
            channel = interaction.guild.get_channel(int(channel_id))
            if channel:
                status = "✅ Active" if config.get("enabled", True) else "❌ Disabled"
                duration = config.get("duration_readable", f"{config.get('duration_seconds', 0)}s")
                locked = config.get("locked_count", 0)
                lines.append(f"• {channel.mention} • {status} • Duration: {duration} • {locked} posts locked")
            else:
                lines.append(f"• `{channel_id}` • ❌ Channel deleted")
        embed = mod_embed("🔒 Forum Auto-Lock Settings", "\n".join(lines) if lines else "No active settings.", Config.COLOR_INFO)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @slash.command(name="toggle", description="Enable or disable auto-lock for a forum channel.")
    @app_commands.describe(forum_channel="The forum channel to toggle", enabled="Enable or disable auto-lock")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def toggle_autolock(self, interaction: discord.Interaction, forum_channel: discord.ForumChannel, enabled: bool):
        settings = self._get_settings(interaction.guild.id)
        if str(forum_channel.id) not in settings:
            return await interaction.response.send_message(embed=mod_embed("ℹ️ No Settings Found", f"No auto-lock settings found for {forum_channel.mention}.", Config.COLOR_INFO), ephemeral=True)
        settings[str(forum_channel.id)]["enabled"] = enabled
        self._save_settings(interaction.guild.id, settings)
        status = "✅ Enabled" if enabled else "❌ Disabled"
        await interaction.response.send_message(embed=mod_embed(f"🔒 Forum Auto-Lock {status}", f"**Channel:** {forum_channel.mention}\n**Status:** {'Active' if enabled else 'Inactive'}", Config.COLOR_OK if enabled else Config.COLOR_WARN), ephemeral=True)

    @slash.command(name="update", description="Update the duration for an existing auto-lock setting.")
    @app_commands.describe(forum_channel="The forum channel to update", duration="New duration before locking (e.g. 5m, 2h, 3d, 1w)")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def update_autolock(self, interaction: discord.Interaction, forum_channel: discord.ForumChannel, duration: str):
        settings = self._get_settings(interaction.guild.id)
        if str(forum_channel.id) not in settings:
            return await interaction.response.send_message(embed=mod_embed("ℹ️ No Settings Found", f"No auto-lock settings found for {forum_channel.mention}.", Config.COLOR_INFO), ephemeral=True)
        try:
            seconds = parse_duration_to_seconds(duration)
        except ValueError as e:
            return await interaction.response.send_message(embed=mod_embed("❌ Invalid Duration", str(e), Config.COLOR_ERR), ephemeral=True)
        if seconds < 60:
            return await interaction.response.send_message(embed=mod_embed("❌ Duration Too Short", "Duration must be at least 1 minute (60s).", Config.COLOR_ERR), ephemeral=True)
        settings[str(forum_channel.id)]["duration_seconds"] = seconds
        settings[str(forum_channel.id)]["duration_readable"] = format_duration(seconds)
        self._save_settings(interaction.guild.id, settings)
        await interaction.response.send_message(embed=mod_embed("✅ Auto-Lock Updated", f"**Channel:** {forum_channel.mention}\n**New Duration:** {format_duration(seconds)}", Config.COLOR_OK), ephemeral=True)

    @commands.Cog.listener()
    async def on_thread_create(self, thread: discord.Thread):
        if not thread.parent or not isinstance(thread.parent, discord.ForumChannel):
            return
        settings = self._get_settings(thread.guild.id)
        channel_settings = settings.get(str(thread.parent.id))
        if not channel_settings or not channel_settings.get("enabled", True):
            return
        duration_seconds = channel_settings.get("duration_seconds", 3600)
        await self._send_log_embed(thread, duration_seconds)
        if thread.id in self._lock_tasks:
            self._lock_tasks[thread.id].cancel()
        task = asyncio.create_task(self._lock_post_after_delay(thread, duration_seconds))
        self._lock_tasks[thread.id] = task

    async def _send_log_embed(self, thread: discord.Thread, duration_seconds: int):
        guild_data = self._get_guild_settings(thread.guild.id)
        log_channel_id = guild_data.get("forum_lock_log_channel")
        if not log_channel_id:
            return
        log_channel = thread.guild.get_channel(int(log_channel_id))
        if not log_channel:
            return
        owner = thread.owner or thread.guild.get_member(thread.owner_id) if thread.owner_id else None
        lock_time = datetime.now(timezone.utc) + timedelta(seconds=duration_seconds)
        embed = build(title="🔒 Forum Post Created", description=f"A new forum post has been created that will be automatically locked.", color=Config.COLOR_INFO, bot=self.bot)
        embed.add_field(name="📝 Post", value=f"[{thread.name}]({thread.jump_url})", inline=False)
        embed.add_field(name="👤 Author", value=owner.mention if owner else "Unknown", inline=True)
        embed.add_field(name="📂 Channel", value=thread.parent.mention, inline=True)
        embed.add_field(name="⏰ Locking In", value=f"{format_duration(duration_seconds)} (at {discord.utils.format_dt(lock_time, 'F')})", inline=False)
        try:
            await log_channel.send(embed=embed)
        except Exception as e:
            print(f"[ForumLock] Failed to send log: {e}")

    async def _lock_post_after_delay(self, thread: discord.Thread, duration_seconds: int):
        try:
            await asyncio.sleep(duration_seconds)
            try:
                thread = await thread.guild.fetch_channel(thread.id)
            except (discord.NotFound, discord.Forbidden):
                if thread.id in self._lock_tasks:
                    del self._lock_tasks[thread.id]
                return
            if thread.locked or thread.archived:
                if thread.id in self._lock_tasks:
                    del self._lock_tasks[thread.id]
                return
            await thread.edit(locked=True, reason="Auto-lock: Post expired")
            settings = self._get_settings(thread.guild.id)
            channel_id_str = str(thread.parent.id)
            if channel_id_str in settings:
                settings[channel_id_str]["locked_count"] = settings[channel_id_str].get("locked_count", 0) + 1
                self._save_settings(thread.guild.id, settings)
            try:
                await thread.send(embed=mod_embed("🔒 Post Locked", f"This post has been automatically locked after {format_duration(duration_seconds)}.\nContact staff if you need to continue the discussion.", Config.COLOR_WARN))
            except Exception:
                pass
            await self._send_lock_log_embed(thread, duration_seconds)
            if thread.id in self._lock_tasks:
                del self._lock_tasks[thread.id]
        except asyncio.CancelledError:
            if thread.id in self._lock_tasks:
                del self._lock_tasks[thread.id]
            pass
        except Exception as e:
            print(f"[ForumLock] Failed to lock thread {thread.id}: {e}")
            if thread.id in self._lock_tasks:
                del self._lock_tasks[thread.id]

    async def _send_lock_log_embed(self, thread: discord.Thread, duration_seconds: int):
        guild_data = self._get_guild_settings(thread.guild.id)
        log_channel_id = guild_data.get("forum_lock_log_channel")
        if not log_channel_id:
            return
        log_channel = thread.guild.get_channel(int(log_channel_id))
        if not log_channel:
            return
        owner = thread.owner or thread.guild.get_member(thread.owner_id) if thread.owner_id else None
        embed = build(title="🔒 Forum Post Locked", description=f"A forum post has been automatically locked.", color=Config.COLOR_ERR, bot=self.bot)
        embed.add_field(name="📝 Post", value=f"[{thread.name}]({thread.jump_url})", inline=False)
        embed.add_field(name="👤 Author", value=owner.mention if owner else "Unknown", inline=True)
        embed.add_field(name="📂 Channel", value=thread.parent.mention, inline=True)
        embed.add_field(name="⏰ Locked After", value=format_duration(duration_seconds), inline=True)
        try:
            await log_channel.send(embed=embed)
        except Exception as e:
            print(f"[ForumLock] Failed to send lock log: {e}")

    # ========== PREFIX COMMANDS ==========
    @commands.command(name="forumlock")
    @commands.has_permissions(administrator=True)
    async def p_forumlock(self, ctx, action: str = None, *, args: str = None):
        if not action:
            return await ctx.reply("Usage: `//forumlock set|setlog|remove|list|toggle|update`")
        if action.lower() == "set":
            # Usage: //forumlock set #forum 1h [enable]
            parts = args.split() if args else []
            if len(parts) < 2:
                return await ctx.reply("Usage: `//forumlock set #forum <duration> [enable]`")
            forum_channel = discord.utils.get(ctx.guild.forums, mention=parts[0]) or discord.utils.get(ctx.guild.forums, name=parts[0])
            if not forum_channel:
                return await ctx.reply(f"❌ Forum channel `{parts[0]}` not found.")
            duration = parts[1]
            enabled = True
            if len(parts) > 2:
                enabled = parts[2].lower() in ("true", "yes", "1", "enable")
            await self.set_autolock.callback(self, await commands.Context.from_interaction(ctx), forum_channel, duration, enabled)
        elif action.lower() == "setlog":
            if not args:
                return await ctx.reply("Usage: `//forumlock setlog #channel`")
            channel = discord.utils.get(ctx.guild.text_channels, mention=args) or discord.utils.get(ctx.guild.text_channels, name=args)
            if not channel:
                return await ctx.reply(f"❌ Channel `{args}` not found.")
            await self.set_log_channel.callback(self, await commands.Context.from_interaction(ctx), channel)
        elif action.lower() == "remove":
            if not args:
                return await ctx.reply("Usage: `//forumlock remove #forum`")
            forum_channel = discord.utils.get(ctx.guild.forums, mention=args) or discord.utils.get(ctx.guild.forums, name=args)
            if not forum_channel:
                return await ctx.reply(f"❌ Forum channel `{args}` not found.")
            await self.remove_autolock.callback(self, await commands.Context.from_interaction(ctx), forum_channel)
        elif action.lower() == "list":
            await self.list_autolock.callback(self, await commands.Context.from_interaction(ctx))
        elif action.lower() == "toggle":
            parts = args.split() if args else []
            if len(parts) < 2:
                return await ctx.reply("Usage: `//forumlock toggle #forum <true/false>`")
            forum_channel = discord.utils.get(ctx.guild.forums, mention=parts[0]) or discord.utils.get(ctx.guild.forums, name=parts[0])
            if not forum_channel:
                return await ctx.reply(f"❌ Forum channel `{parts[0]}` not found.")
            enabled = parts[1].lower() in ("true", "yes", "1", "enable")
            await self.toggle_autolock.callback(self, await commands.Context.from_interaction(ctx), forum_channel, enabled)
        elif action.lower() == "update":
            parts = args.split() if args else []
            if len(parts) < 2:
                return await ctx.reply("Usage: `//forumlock update #forum <duration>`")
            forum_channel = discord.utils.get(ctx.guild.forums, mention=parts[0]) or discord.utils.get(ctx.guild.forums, name=parts[0])
            if not forum_channel:
                return await ctx.reply(f"❌ Forum channel `{parts[0]}` not found.")
            duration = parts[1]
            await self.update_autolock.callback(self, await commands.Context.from_interaction(ctx), forum_channel, duration)
        else:
            await ctx.reply(f"❌ Unknown action `{action}`. Available: set, setlog, remove, list, toggle, update")

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            missing = ", ".join(p.replace("_", " ").title() for p in error.missing_permissions)
            print(f"[ForumLock] {interaction.user} ({interaction.user.id}) missing permissions: {missing}")
            try:
                await interaction.response.send_message(f"❌ You are missing the required permissions: **{missing}**.", ephemeral=True)
            except discord.InteractionResponded:
                await interaction.followup.send(f"❌ You are missing the required permissions: **{missing}**.", ephemeral=True)

async def setup(bot):
    await bot.add_cog(ForumLock(bot))