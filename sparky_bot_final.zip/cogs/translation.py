import discord
from discord.ext import commands
from discord import app_commands
import asyncio
import re
import html
from datetime import datetime, timezone
from config import Config
from utils.embed import build
from utils.theme import Theme
from utils.data import load, save
from utils.prefix_manager import get_prefixes

try:
    from pygtrans import Translate
    HAS_PYGTRANS = True
    print("[Translation] pygtrans imported successfully")
except ImportError:
    HAS_PYGTRANS = False
    print("[Translation] pygtrans not installed. Translation features will be disabled. Install with: pip install pygtrans")

try:
    from indic_transliteration import sanscript
    from indic_transliteration.sanscript import transliterate as indic_transliterate
    HAS_TRANSLITERATION = True
    print("[Translation] indic-transliteration imported successfully")
except ImportError:
    HAS_TRANSLITERATION = False
    print("[Translation] indic-transliteration not installed. Transliteration features will be disabled. Install with: pip install indic-transliteration")

AUTO_TRANSLATE_FILE = "auto_translate.json"

def _get_auto_translate_config(guild_id: int) -> dict:
    data = load(AUTO_TRANSLATE_FILE)
    return data.get(str(guild_id), {
        "enabled": False,
        "default_language": "en",
        "ignored_channels": [],
        "ignored_roles": [],
        "ignored_users": []
    })

def _save_auto_translate_config(guild_id: int, config: dict):
    data = load(AUTO_TRANSLATE_FILE)
    data[str(guild_id)] = config
    save(AUTO_TRANSLATE_FILE, data)

LANGUAGES = {
    "af": "Afrikaans",
    "sq": "Albanian",
    "am": "Amharic",
    "ar": "Arabic",
    "hy": "Armenian",
    "az": "Azerbaijani",
    "eu": "Basque",
    "be": "Belarusian",
    "bn": "Bengali",
    "bs": "Bosnian",
    "bg": "Bulgarian",
    "ca": "Catalan",
    "ceb": "Cebuano",
    "ny": "Chichewa",
    "zh-cn": "Chinese (Simplified)",
    "zh-tw": "Chinese (Traditional)",
    "co": "Corsican",
    "hr": "Croatian",
    "cs": "Czech",
    "da": "Danish",
    "nl": "Dutch",
    "en": "English",
    "eo": "Esperanto",
    "et": "Estonian",
    "tl": "Filipino",
    "fi": "Finnish",
    "fr": "French",
    "fy": "Frisian",
    "gl": "Galician",
    "ka": "Georgian",
    "de": "German",
    "el": "Greek",
    "gu": "Gujarati",
    "ht": "Haitian Creole",
    "ha": "Hausa",
    "haw": "Hawaiian",
    "iw": "Hebrew",
    "hi": "Hindi",
    "hmn": "Hmong",
    "hu": "Hungarian",
    "is": "Icelandic",
    "ig": "Igbo",
    "id": "Indonesian",
    "ga": "Irish",
    "it": "Italian",
    "ja": "Japanese",
    "jw": "Javanese",
    "kn": "Kannada",
    "kk": "Kazakh",
    "km": "Khmer",
    "rw": "Kinyarwanda",
    "ko": "Korean",
    "ku": "Kurdish (Kurmanji)",
    "ky": "Kyrgyz",
    "lo": "Lao",
    "la": "Latin",
    "lv": "Latvian",
    "lt": "Lithuanian",
    "lb": "Luxembourgish",
    "mk": "Macedonian",
    "mg": "Malagasy",
    "ms": "Malay",
    "ml": "Malayalam",
    "mt": "Maltese",
    "mi": "Maori",
    "mr": "Marathi",
    "mn": "Mongolian",
    "my": "Myanmar (Burmese)",
    "ne": "Nepali",
    "no": "Norwegian",
    "or": "Odia (Oriya)",
    "ps": "Pashto",
    "fa": "Persian",
    "pl": "Polish",
    "pt": "Portuguese",
    "pa": "Punjabi",
    "ro": "Romanian",
    "ru": "Russian",
    "sm": "Samoan",
    "gd": "Scots Gaelic",
    "sr": "Serbian",
    "st": "Sesotho",
    "sn": "Shona",
    "sd": "Sindhi",
    "si": "Sinhala",
    "sk": "Slovak",
    "sl": "Slovenian",
    "so": "Somali",
    "es": "Spanish",
    "su": "Sundanese",
    "sw": "Swahili",
    "sv": "Swedish",
    "tg": "Tajik",
    "ta": "Tamil",
    "tt": "Tatar",
    "te": "Telugu",
    "th": "Thai",
    "tr": "Turkish",
    "tk": "Turkmen",
    "uk": "Ukrainian",
    "ur": "Urdu",
    "ug": "Uyghur",
    "uz": "Uzbek",
    "vi": "Vietnamese",
    "cy": "Welsh",
    "xh": "Xhosa",
    "yi": "Yiddish",
    "yo": "Yoruba",
    "zu": "Zulu"
}

LANGUAGE_NAME_TO_CODE = {v.lower(): k for k, v in LANGUAGES.items()}

TRANSLITERATION_SCRIPTS = {
    "dev": "Devanagari (Hindi, Marathi, Nepali)",
    "taml": "Tamil",
    "telu": "Telugu",
    "knda": "Kannada",
    "mlym": "Malayalam",
    "guru": "Gurmukhi (Punjabi)",
    "gujr": "Gujarati",
    "orya": "Odia",
    "beng": "Bengali",
    "sinh": "Sinhala"
}

def _clean_text(text: str) -> str:
    if not text:
        return text

    text = html.unescape(text)

    text = ' '.join(text.split())

    return text

def _get_translation_text(result):
    if result is None:
        return None

    translated_text = None

    if hasattr(result, 'translated_text'):
        translated_text = getattr(result, 'translated_text')

    if not translated_text:
        for attr in ['translatedText', 'text', 'result']:
            if hasattr(result, attr):
                translated_text = getattr(result, attr)
                break

    if not translated_text and isinstance(result, dict):
        for key in ['translatedText', 'translated_text', 'text']:
            if key in result and result[key]:
                translated_text = result[key]
                break

    if not translated_text and hasattr(result, '__dict__'):
        d = result.__dict__
        for key in ['translated_text', 'translatedText', 'text']:
            if key in d and d[key]:
                translated_text = d[key]
                break

    if translated_text and isinstance(translated_text, str):
        translated_text = _clean_text(translated_text)
        return translated_text

    if not translated_text:
        text = str(result)

        match = re.search(r"translatedText=['\"]([^'\"]*)['\"]", text)
        if match:
            translated_text = _clean_text(match.group(1))
            return translated_text

        if not text.startswith('TranslateResponse') and not text.startswith('<'):
            translated_text = _clean_text(text)
            return translated_text

    return translated_text

class Translation(commands.Cog):

    translate_group = app_commands.Group(name="translate", description="Translation commands")
    autotranslate_group = app_commands.Group(name="autotranslate", description="Auto-translate settings")
    transliterate_group = app_commands.Group(name="transliterate", description="Transliteration commands")

    def __init__(self, bot):
        self.bot = bot
        self.translator = None
        if HAS_PYGTRANS:
            try:
                self.translator = Translate()
                print("[Translation] pygtrans initialized successfully")
            except Exception as e:
                print(f"[Translation] Failed to initialize pygtrans: {e}")
                self.translator = None

    def cog_unload(self):
        pass

    def _get_translator(self):
        if not HAS_PYGTRANS:
            return None
        if self.translator is None:
            try:
                self.translator = Translate()
            except Exception:
                return None
        return self.translator

    def _get_language_code(self, lang_input: str) -> str | None:
        lang_input = lang_input.lower().strip()

        if lang_input in LANGUAGES:
            return lang_input

        if lang_input in LANGUAGE_NAME_TO_CODE:
            return LANGUAGE_NAME_TO_CODE[lang_input]

        for code, name in LANGUAGES.items():
            if lang_input in name.lower() or name.lower() in lang_input:
                return code

        return None

    def _format_translation(self, text: str, translated: str, source_lang: str, target_lang: str, source_detected: str = None) -> discord.Embed:

        text = _clean_text(text)
        translated = _clean_text(translated)

        source_name = LANGUAGES.get(source_lang, source_lang or "Unknown")
        target_name = LANGUAGES.get(target_lang, target_lang)

        embed = build(title="🌐 Translation", color=Config.COLOR_INFO, bot=self.bot)

        if len(text) > 1024:
            text = text[:1021] + "..."
        if len(translated) > 1024:
            translated = translated[:1021] + "..."

        embed.add_field(
            name=f"📝 Original ({source_name})",
            value=text or "*Empty text*",
            inline=False
        )
        embed.add_field(
            name=f"🔤 Translated ({target_name})",
            value=translated or "*Empty translation*",
            inline=False
        )

        if source_detected and source_detected != source_lang and source_detected != "auto":
            detected_name = LANGUAGES.get(source_detected, source_detected)
            embed.add_field(
                name="ℹ️ Detected Language",
                value=detected_name,
                inline=True
            )

        embed.set_footer(text="Using Google Translate")

        return embed

    def _should_auto_translate(self, message: discord.Message) -> bool:
        if not message.guild:
            return False

        config = _get_auto_translate_config(message.guild.id)

        if not config.get("enabled", False):
            return False

        if message.author.bot:
            return False

        if message.channel.id in config.get("ignored_channels", []):
            return False

        author_roles = [role.id for role in message.author.roles]
        if any(role_id in config.get("ignored_roles", []) for role_id in author_roles):
            return False

        if message.author.id in config.get("ignored_users", []):
            return False

        return True

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if not message.guild or message.author.bot:
            return

        if self._should_auto_translate(message) and message.content and HAS_PYGTRANS:
            translator = self._get_translator()
            if translator:
                try:
                    config = _get_auto_translate_config(message.guild.id)
                    default_lang = config.get("default_language", "en")

                    if default_lang not in LANGUAGES:
                        default_lang = "en"

                    if len(message.content.strip()) < 2:
                        return

                    try:
                        detect_result = translator.detect(message.content)
                        detected = None

                        if detect_result:
                            if hasattr(detect_result, 'language'):
                                detected = detect_result.language
                            elif hasattr(detect_result, 'detected_source_language'):
                                detected = detect_result.detected_source_language
                            elif isinstance(detect_result, dict) and 'language' in detect_result:
                                detected = detect_result['language']
                            elif isinstance(detect_result, list) and detect_result:
                                if hasattr(detect_result[0], 'language'):
                                    detected = detect_result[0].language
                                elif isinstance(detect_result[0], dict) and 'language' in detect_result[0]:
                                    detected = detect_result[0]['language']
                    except Exception as detect_error:
                        print(f"[Translation] Detect error: {detect_error}")
                        return

                    if not detected or detected == default_lang or detected not in LANGUAGES:
                        return

                    print(f"[Translation] Auto-translate: {detected} -> {default_lang} | {message.content[:50]}...")

                    try:
                        translate_result = translator.translate(message.content, target=default_lang)
                        translated = _get_translation_text(translate_result)
                    except Exception as translate_error:
                        print(f"[Translation] Translation error: {translate_error}")
                        return

                    if translated and translated != message.content:
                        embed = build(title="🌐 Auto-Translated", description=translated[:2000] if len(translated) > 2000 else translated, color=Config.COLOR_INFO, bot=self.bot)
                        embed.add_field(
                            name=f"📝 Original ({LANGUAGES.get(detected, detected)})",
                            value=message.content[:500] + ("..." if len(message.content) > 500 else ""),
                            inline=False
                        )
                        embed.add_field(
                            name="🔤 Translated to",
                            value=LANGUAGES.get(default_lang, default_lang),
                            inline=True
                        )
                        embed.set_footer(text="Auto-translate • Using Google Translate")

                        try:
                            await message.reply(embed=embed)
                        except Exception as reply_error:
                            print(f"[Translation] Reply error: {reply_error}")
                except Exception as e:
                    print(f"[Translation] Auto-translate error: {e}")

    @translate_group.command(name="text", description="Translate text to any language")
    @app_commands.describe(
        text="Text to translate",
        target="Target language (code or name, e.g. 'es' or 'spanish')",
        source="Source language (optional, auto-detect if not specified)"
    )
    async def translate_text(self, interaction: discord.Interaction, text: str, target: str, source: str = None):
        await interaction.response.defer()

        translator = self._get_translator()
        if not translator:
            return await interaction.followup.send(
                "❌ Translation service is unavailable. Please make sure pygtrans is installed.\n"
                "Install with: `pip install pygtrans`",
                ephemeral=True
            )

        target_code = self._get_language_code(target)
        if not target_code:
            return await interaction.followup.send(
                f"❌ Invalid target language: `{target}`.\n"
                f"Use a language code (e.g., `es`, `fr`) or name (e.g., `spanish`, `french`).",
                ephemeral=True
            )

        source_code = None
        if source:
            source_code = self._get_language_code(source)
            if not source_code:
                return await interaction.followup.send(
                    f"❌ Invalid source language: `{source}`.\n"
                    f"Use a language code (e.g., `en`, `fr`) or name (e.g., `english`, `french`).",
                    ephemeral=True
                )

        try:
            if source_code:
                result = translator.translate(text, source=source_code, target=target_code)
                detected = None
            else:
                result = translator.translate(text, target=target_code)
                detected = result.detected_source_language if hasattr(result, 'detected_source_language') else None

            translated = _get_translation_text(result)
            if not translated:
                translated = "⚠️ Translation failed – could not extract text."

            embed = self._format_translation(text, translated, source_code or detected or "auto", target_code, detected)
            await interaction.followup.send(embed=embed)

        except Exception as e:
            await interaction.followup.send(f"❌ Translation failed: {str(e)[:200]}", ephemeral=True)

    @translate_group.command(name="detect", description="Detect the language of text")
    @app_commands.describe(text="Text to detect language of")
    async def translate_detect(self, interaction: discord.Interaction, text: str):
        await interaction.response.defer()

        translator = self._get_translator()
        if not translator:
            return await interaction.followup.send(
                "❌ Translation service is unavailable. Please make sure pygtrans is installed.",
                ephemeral=True
            )

        try:
            detect_result = translator.detect(text)
            if isinstance(detect_result, list) and detect_result:
                detect_result = detect_result[0]
            detected = getattr(detect_result, 'language', None)

            if detected and detected in LANGUAGES:
                embed = build(title="🔍 Language Detection", color=Config.COLOR_INFO, bot=self.bot)
                embed.add_field(
                    name="📝 Text",
                    value=text[:1024] if len(text) <= 1024 else text[:1021] + "...",
                    inline=False
                )
                embed.add_field(
                    name="🌐 Detected Language",
                    value=f"{LANGUAGES.get(detected, detected)} (`{detected}`)",
                    inline=True
                )
                embed.set_footer(text="Using Google Translate")
                await interaction.followup.send(embed=embed)
            else:
                await interaction.followup.send("❌ Could not detect language. Please provide more text.")

        except Exception as e:
            await interaction.followup.send(f"❌ Detection failed: {str(e)[:200]}", ephemeral=True)

    @translate_group.command(name="list", description="List all supported languages")
    async def translate_list(self, interaction: discord.Interaction):
        await interaction.response.defer()

        embed = build(title="🌐 Supported Languages", description=f"**{len(LANGUAGES)}** languages supported", color=Config.COLOR_INFO, bot=self.bot)

        language_list = sorted(LANGUAGES.items(), key=lambda x: x[1])
        chunk_size = 25

        for i in range(0, len(language_list), chunk_size):
            chunk = language_list[i:i+chunk_size]
            value = "\n".join(f"`{code}` - {name}" for code, name in chunk)
            embed.add_field(
                name=f"Languages {i//chunk_size + 1}",
                value=value,
                inline=True
            )

        embed.set_footer(text="Use language codes or names in /translate text")
        await interaction.followup.send(embed=embed)

    @transliterate_group.command(name="text", description="Convert non-Latin text to English letters")
    @app_commands.describe(
        text="Text to transliterate",
        script="Script of the text (dev, taml, telu, etc.)"
    )
    async def transliterate_text(self, interaction: discord.Interaction, text: str, script: str = 'dev'):
        if not HAS_TRANSLITERATION:
            return await interaction.response.send_message(
                "❌ Transliteration is not available. Install with: `pip install indic-transliteration`",
                ephemeral=True
            )

        await interaction.response.defer()

        script = script.lower()
        if script not in TRANSLITERATION_SCRIPTS:
            available = ", ".join(f"`{s}`" for s in TRANSLITERATION_SCRIPTS.keys())
            return await interaction.followup.send(
                f"❌ Invalid script: `{script}`.\nAvailable scripts: {available}",
                ephemeral=True
            )

        try:

            clean_text = _clean_text(text)

            result = indic_transliterate(clean_text, script, sanscript.ITRANS)

            result = _clean_text(result)

            embed = build(title="🔤 Transliteration", color=Config.COLOR_INFO, bot=self.bot)
            embed.add_field(
                name=f"📝 Original ({TRANSLITERATION_SCRIPTS.get(script, script)})",
                value=clean_text[:1024] if len(clean_text) <= 1024 else clean_text[:1021] + "...",
                inline=False
            )
            embed.add_field(
                name="🔤 Transliterated (English)",
                value=result[:1024] if len(result) <= 1024 else result[:1021] + "...",
                inline=False
            )
            embed.set_footer(text="Indic Transliteration")

            await interaction.followup.send(embed=embed)

        except Exception as e:
            await interaction.followup.send(f"❌ Transliteration failed: {str(e)[:200]}", ephemeral=True)

    @transliterate_group.command(name="scripts", description="List all supported scripts for transliteration")
    async def transliterate_scripts(self, interaction: discord.Interaction):
        embed = build(title="📜 Supported Scripts for Transliteration", color=Config.COLOR_INFO, bot=self.bot)

        if not HAS_TRANSLITERATION:
            embed.description = "⚠️ Transliteration is not available. Install with: `pip install indic-transliteration`"
        else:
            script_list = []
            for code, name in TRANSLITERATION_SCRIPTS.items():
                script_list.append(f"`{code}` - {name}")

            embed.description = "Use `/transliterate text` with one of these script codes:\n\n" + "\n".join(script_list)
            embed.add_field(
                name="💡 Example",
                value="`/transliterate text मेरा नाम धनुष है script:dev` → `mera naam dhanush hai`",
                inline=False
            )

        embed.set_footer(text="Indic Transliteration • Converts non-Latin scripts to English letters")
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @commands.command(name="translate", aliases=["tr", "t"])
    async def p_translate(self, ctx, target: str, *, text: str = None):
        if not text:
            if ctx.message.reference:
                try:
                    ref_msg = await ctx.channel.fetch_message(ctx.message.reference.message_id)
                    text = ref_msg.content
                    if not text:
                        return await ctx.reply("❌ The referenced message has no text to translate.")
                except:
                    return await ctx.reply("❌ Could not fetch referenced message.")
            else:
                return await ctx.reply("❌ Please provide text to translate or reply to a message.")

        translator = self._get_translator()
        if not translator:
            return await ctx.reply("❌ Translation service is unavailable. Please make sure pygtrans is installed.")

        target_code = self._get_language_code(target)
        if not target_code:
            return await ctx.reply(f"❌ Invalid language: `{target}`. Use a language code or name.")

        try:
            result = translator.translate(text, target=target_code)
            translated = _get_translation_text(result)
            if not translated:
                translated = "⚠️ Translation failed – could not extract text."
            detected = result.detected_source_language if hasattr(result, 'detected_source_language') else None

            embed = self._format_translation(text, translated, detected or "auto", target_code, detected)
            await ctx.reply(embed=embed)

        except Exception as e:
            await ctx.reply(f"❌ Translation failed: {str(e)[:200]}")

    @commands.command(name="detect", aliases=["lang"])
    async def p_detect(self, ctx, *, text: str = None):
        if not text:
            if ctx.message.reference:
                try:
                    ref_msg = await ctx.channel.fetch_message(ctx.message.reference.message_id)
                    text = ref_msg.content
                    if not text:
                        return await ctx.reply("❌ The referenced message has no text to detect.")
                except:
                    return await ctx.reply("❌ Could not fetch referenced message.")
            else:
                return await ctx.reply("❌ Please provide text to detect or reply to a message.")

        translator = self._get_translator()
        if not translator:
            return await ctx.reply("❌ Translation service is unavailable.")

        try:
            detect_result = translator.detect(text)
            if isinstance(detect_result, list) and detect_result:
                detect_result = detect_result[0]
            detected = getattr(detect_result, 'language', None)

            if detected and detected in LANGUAGES:
                embed = build(title="🔍 Language Detection", color=Config.COLOR_INFO, bot=self.bot)
                embed.add_field(
                    name="📝 Text",
                    value=text[:1024] if len(text) <= 1024 else text[:1021] + "...",
                    inline=False
                )
                embed.add_field(
                    name="🌐 Detected Language",
                    value=f"{LANGUAGES.get(detected, detected)} (`{detected}`)",
                    inline=True
                )
                embed.set_footer(text="Using Google Translate")
                await ctx.reply(embed=embed)
            else:
                await ctx.reply("❌ Could not detect language. Please provide more text.")

        except Exception as e:
            await ctx.reply(f"❌ Detection failed: {str(e)[:200]}")

    @commands.command(name="languages", aliases=["langs"])
    async def p_languages(self, ctx):
        embed = build(title="🌐 Supported Languages", description=f"**{len(LANGUAGES)}** languages supported", color=Config.COLOR_INFO, bot=self.bot)

        language_list = sorted(LANGUAGES.items(), key=lambda x: x[1])
        chunk_size = 25

        for i in range(0, len(language_list), chunk_size):
            chunk = language_list[i:i+chunk_size]
            value = "\n".join(f"`{code}` - {name}" for code, name in chunk)
            embed.add_field(
                name=f"Languages {i//chunk_size + 1}",
                value=value,
                inline=True
            )

        embed.set_footer(text="Use language codes or names in /translate text")
        await ctx.reply(embed=embed)

    @commands.command(name="translateall", aliases=["tra", "trall"])
    async def p_translate_all(self, ctx, target: str, limit: int = 5):
        if limit < 1 or limit > 10:
            return await ctx.reply("❌ Limit must be between 1 and 10.")

        translator = self._get_translator()
        if not translator:
            return await ctx.reply("❌ Translation service is unavailable.")

        target_code = self._get_language_code(target)
        if not target_code:
            return await ctx.reply(f"❌ Invalid language: `{target}`.")

        messages = []
        async for msg in ctx.channel.history(limit=limit + 1):
            if msg.id != ctx.message.id and msg.content and not msg.author.bot:
                messages.append(msg)
                if len(messages) >= limit:
                    break

        if not messages:
            return await ctx.reply("❌ No messages found to translate.")

        await ctx.reply(f"🔄 Translating {len(messages)} messages to {LANGUAGES.get(target_code, target_code)}...")

        results = []
        for msg in messages:
            try:
                result = translator.translate(msg.content, target=target_code)
                translated = _get_translation_text(result)
                if not translated:
                    translated = "*Translation failed*"
                results.append({
                    "author": msg.author.display_name,
                    "original": msg.content[:200] + "..." if len(msg.content) > 200 else msg.content,
                    "translated": translated[:200] + "..." if len(translated) > 200 else translated,
                    "jump_url": msg.jump_url
                })
            except Exception:
                results.append({
                    "author": msg.author.display_name,
                    "original": msg.content[:200] + "..." if len(msg.content) > 200 else msg.content,
                    "translated": "*Translation failed*",
                    "jump_url": msg.jump_url
                })

        embed = build(title=f"📝 Translated Messages → {LANGUAGES.get(target_code, target_code)}", color=Config.COLOR_INFO, bot=self.bot)

        for i, result in enumerate(results, 1):
            embed.add_field(
                name=f"{i}. {result['author']}",
                value=f"**Original:** {result['original']}\n**Translated:** {result['translated']}\n[Jump to message]({result['jump_url']})",
                inline=False
            )

        embed.set_footer(text=f"Using Google Translate • {len(results)} messages")
        await ctx.reply(embed=embed)

    @commands.command(name="translatechannel", aliases=["trc", "tc"])
    @commands.has_permissions(manage_channels=True)
    async def p_translate_channel(self, ctx, target: str, limit: int = 10):
        await self.p_translate_all(ctx, target, min(limit, 25))

    @commands.command(name="transliterate", aliases=["tl"])
    async def p_transliterate(self, ctx, script: str = 'dev', *, text: str = None):
        if not HAS_TRANSLITERATION:
            return await ctx.reply("❌ Transliteration is not available. Install with: `pip install indic-transliteration`")

        if not text:
            if ctx.message.reference:
                try:
                    ref_msg = await ctx.channel.fetch_message(ctx.message.reference.message_id)
                    text = ref_msg.content
                    if not text:
                        return await ctx.reply("❌ The referenced message has no text to transliterate.")
                except:
                    return await ctx.reply("❌ Could not fetch referenced message.")
            else:
                return await ctx.reply("❌ Please provide text to transliterate or reply to a message.")

        script = script.lower()
        if script not in TRANSLITERATION_SCRIPTS:
            available = ", ".join(f"`{s}`" for s in TRANSLITERATION_SCRIPTS.keys())
            return await ctx.reply(f"❌ Invalid script: `{script}`.\nAvailable scripts: {available}")

        try:
            clean_text = _clean_text(text)
            result = indic_transliterate(clean_text, script, sanscript.ITRANS)
            result = _clean_text(result)

            embed = build(title="🔤 Transliteration", color=Config.COLOR_INFO, bot=self.bot)
            embed.add_field(
                name=f"📝 Original ({TRANSLITERATION_SCRIPTS.get(script, script)})",
                value=clean_text[:1024] if len(clean_text) <= 1024 else clean_text[:1021] + "...",
                inline=False
            )
            embed.add_field(
                name="🔤 Transliterated (English)",
                value=result[:1024] if len(result) <= 1024 else result[:1021] + "...",
                inline=False
            )
            embed.set_footer(text="Indic Transliteration")

            await ctx.reply(embed=embed)

        except Exception as e:
            await ctx.reply(f"❌ Transliteration failed: {str(e)[:200]}")

    @commands.command(name="tlscripts", aliases=["tlscript"])
    async def p_transliterate_scripts(self, ctx):
        embed = build(title="📜 Supported Scripts for Transliteration", color=Config.COLOR_INFO, bot=self.bot)

        if not HAS_TRANSLITERATION:
            embed.description = "⚠️ Transliteration is not available. Install with: `pip install indic-transliteration`"
        else:
            script_list = []
            for code, name in TRANSLITERATION_SCRIPTS.items():
                script_list.append(f"`{code}` - {name}")

            embed.description = "Use `//transliterate` with one of these script codes:\n\n" + "\n".join(script_list)
            embed.add_field(
                name="💡 Example",
                value="`//transliterate dev मेरा नाम धनुष है` → `mera naam dhanush hai`",
                inline=False
            )

        embed.set_footer(text="Indic Transliteration • Converts non-Latin scripts to English letters")
        await ctx.reply(embed=embed)

    @autotranslate_group.command(name="enable", description="Enable auto-translate for this server")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def autotranslate_enable(self, interaction: discord.Interaction):
        config = _get_auto_translate_config(interaction.guild.id)
        config["enabled"] = True
        _save_auto_translate_config(interaction.guild.id, config)

        embed = build(title="✅ Auto-Translate Enabled", description=f"Auto-translate is now **enabled** for this server.\n"
                       f"Default language: {LANGUAGES.get(config['default_language'], 'English')}\n\n"
                       f"Use `/autotranslate setlanguage` to change the default language.", color=Config.COLOR_OK, bot=self.bot)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @autotranslate_group.command(name="disable", description="Disable auto-translate for this server")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def autotranslate_disable(self, interaction: discord.Interaction):
        config = _get_auto_translate_config(interaction.guild.id)
        config["enabled"] = False
        _save_auto_translate_config(interaction.guild.id, config)

        embed = build(title="✅ Auto-Translate Disabled", description="Auto-translate is now **disabled** for this server.", color=Config.COLOR_OK, bot=self.bot)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @autotranslate_group.command(name="setlanguage", description="Set the server's default language for auto-translate")
    @app_commands.describe(language="Language code or name (e.g. 'es' or 'spanish')")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def autotranslate_setlanguage(self, interaction: discord.Interaction, language: str):
        lang_code = self._get_language_code(language)
        if not lang_code:
            return await interaction.response.send_message(
                f"❌ Invalid language: `{language}`. Use a language code or name.",
                ephemeral=True
            )

        config = _get_auto_translate_config(interaction.guild.id)
        config["default_language"] = lang_code
        _save_auto_translate_config(interaction.guild.id, config)

        embed = build(title="✅ Default Language Set", description=f"Default language set to: **{LANGUAGES.get(lang_code, lang_code)}**", color=Config.COLOR_OK, bot=self.bot)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @autotranslate_group.command(name="ignorechannel", description="Ignore a channel for auto-translate")
    @app_commands.describe(channel="Channel to ignore")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def autotranslate_ignorechannel(self, interaction: discord.Interaction, channel: discord.TextChannel):
        config = _get_auto_translate_config(interaction.guild.id)
        ignored = config.get("ignored_channels", [])

        if channel.id in ignored:
            return await interaction.response.send_message(f"{channel.mention} is already ignored.", ephemeral=True)

        ignored.append(channel.id)
        config["ignored_channels"] = ignored
        _save_auto_translate_config(interaction.guild.id, config)

        embed = build(title="✅ Channel Ignored", description=f"{channel.mention} will no longer be auto-translated.", color=Config.COLOR_OK, bot=self.bot)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @autotranslate_group.command(name="unignorechannel", description="Unignore a channel for auto-translate")
    @app_commands.describe(channel="Channel to unignore")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def autotranslate_unignorechannel(self, interaction: discord.Interaction, channel: discord.TextChannel):
        config = _get_auto_translate_config(interaction.guild.id)
        ignored = config.get("ignored_channels", [])

        if channel.id not in ignored:
            return await interaction.response.send_message(f"{channel.mention} is not ignored.", ephemeral=True)

        ignored.remove(channel.id)
        config["ignored_channels"] = ignored
        _save_auto_translate_config(interaction.guild.id, config)

        embed = build(title="✅ Channel Unignored", description=f"{channel.mention} will now be auto-translated.", color=Config.COLOR_OK, bot=self.bot)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @autotranslate_group.command(name="ignorerole", description="Ignore a role for auto-translate")
    @app_commands.describe(role="Role to ignore")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def autotranslate_ignorerole(self, interaction: discord.Interaction, role: discord.Role):
        config = _get_auto_translate_config(interaction.guild.id)
        ignored = config.get("ignored_roles", [])

        if role.id in ignored:
            return await interaction.response.send_message(f"{role.mention} is already ignored.", ephemeral=True)

        ignored.append(role.id)
        config["ignored_roles"] = ignored
        _save_auto_translate_config(interaction.guild.id, config)

        embed = build(title="✅ Role Ignored", description=f"Members with {role.mention} will no longer have their messages auto-translated.", color=Config.COLOR_OK, bot=self.bot)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @autotranslate_group.command(name="unignorerole", description="Unignore a role for auto-translate")
    @app_commands.describe(role="Role to unignore")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def autotranslate_unignorerole(self, interaction: discord.Interaction, role: discord.Role):
        config = _get_auto_translate_config(interaction.guild.id)
        ignored = config.get("ignored_roles", [])

        if role.id not in ignored:
            return await interaction.response.send_message(f"{role.mention} is not ignored.", ephemeral=True)

        ignored.remove(role.id)
        config["ignored_roles"] = ignored
        _save_auto_translate_config(interaction.guild.id, config)

        embed = build(title="✅ Role Unignored", description=f"Members with {role.mention} will now have their messages auto-translated.", color=Config.COLOR_OK, bot=self.bot)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @autotranslate_group.command(name="ignoreuser", description="Ignore a user for auto-translate")
    @app_commands.describe(user="User to ignore")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def autotranslate_ignoreuser(self, interaction: discord.Interaction, user: discord.User):
        config = _get_auto_translate_config(interaction.guild.id)
        ignored = config.get("ignored_users", [])

        if user.id in ignored:
            return await interaction.response.send_message(f"{user.mention} is already ignored.", ephemeral=True)

        ignored.append(user.id)
        config["ignored_users"] = ignored
        _save_auto_translate_config(interaction.guild.id, config)

        embed = build(title="✅ User Ignored", description=f"{user.mention} will no longer have their messages auto-translated.", color=Config.COLOR_OK, bot=self.bot)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @autotranslate_group.command(name="unignoreuser", description="Unignore a user for auto-translate")
    @app_commands.describe(user="User to unignore")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def autotranslate_unignoreuser(self, interaction: discord.Interaction, user: discord.User):
        config = _get_auto_translate_config(interaction.guild.id)
        ignored = config.get("ignored_users", [])

        if user.id not in ignored:
            return await interaction.response.send_message(f"{user.mention} is not ignored.", ephemeral=True)

        ignored.remove(user.id)
        config["ignored_users"] = ignored
        _save_auto_translate_config(interaction.guild.id, config)

        embed = build(title="✅ User Unignored", description=f"{user.mention} will now have their messages auto-translated.", color=Config.COLOR_OK, bot=self.bot)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @autotranslate_group.command(name="status", description="View auto-translate configuration")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def autotranslate_status(self, interaction: discord.Interaction):
        config = _get_auto_translate_config(interaction.guild.id)

        embed = build(title="🌐 Auto-Translate Configuration", color=Config.COLOR_INFO, bot=self.bot)

        embed.add_field(
            name="Status",
            value="✅ Enabled" if config.get("enabled", False) else "❌ Disabled",
            inline=True
        )
        embed.add_field(
            name="Default Language",
            value=LANGUAGES.get(config.get("default_language", "en"), "English"),
            inline=True
        )
        embed.add_field(
            name="Ignored Channels",
            value=f"{len(config.get('ignored_channels', []))} channel(s) ignored",
            inline=True
        )
        embed.add_field(
            name="Ignored Roles",
            value=f"{len(config.get('ignored_roles', []))} role(s) ignored",
            inline=True
        )
        embed.add_field(
            name="Ignored Users",
            value=f"{len(config.get('ignored_users', []))} user(s) ignored",
            inline=True
        )

        if config.get("ignored_channels", []):
            channels = []
            for ch_id in config["ignored_channels"][:5]:
                ch = interaction.guild.get_channel(ch_id)
                channels.append(ch.mention if ch else f"Deleted channel ({ch_id})")
            if len(config["ignored_channels"]) > 5:
                channels.append(f"... and {len(config['ignored_channels']) - 5} more")
            embed.add_field(
                name="Ignored Channels List",
                value="\n".join(channels) or "None",
                inline=False
            )

        embed.set_footer(text="Use /autotranslate commands to modify these settings")
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @commands.command(name="autotranslate", aliases=["at"])
    @commands.has_permissions(administrator=True)
    async def p_autotranslate(self, ctx, action: str = None, *, target: str = None):
        if not action:
            return await ctx.reply("Please specify an action. Use `//autotranslate help` for more info.")

        config = _get_auto_translate_config(ctx.guild.id)

        if action.lower() == "enable":
            config["enabled"] = True
            _save_auto_translate_config(ctx.guild.id, config)
            await ctx.reply("✅ Auto-translate **enabled**.")

        elif action.lower() == "disable":
            config["enabled"] = False
            _save_auto_translate_config(ctx.guild.id, config)
            await ctx.reply("✅ Auto-translate **disabled**.")

        elif action.lower() == "setlanguage":
            if not target:
                return await ctx.reply("❌ Please specify a language. Example: `//autotranslate setlanguage es`")
            lang_code = self._get_language_code(target)
            if not lang_code:
                return await ctx.reply(f"❌ Invalid language: `{target}`.")
            config["default_language"] = lang_code
            _save_auto_translate_config(ctx.guild.id, config)
            await ctx.reply(f"✅ Default language set to: **{LANGUAGES.get(lang_code, lang_code)}**")

        elif action.lower() == "status":
            embed = build(title="🌐 Auto-Translate Configuration", color=Config.COLOR_INFO, bot=self.bot)
            embed.add_field(
                name="Status",
                value="✅ Enabled" if config.get("enabled", False) else "❌ Disabled",
                inline=True
            )
            embed.add_field(
                name="Default Language",
                value=LANGUAGES.get(config.get("default_language", "en"), "English"),
                inline=True
            )
            embed.add_field(
                name="Ignored Channels",
                value=f"{len(config.get('ignored_channels', []))} channel(s)",
                inline=True
            )
            embed.add_field(
                name="Ignored Roles",
                value=f"{len(config.get('ignored_roles', []))} role(s)",
                inline=True
            )
            embed.add_field(
                name="Ignored Users",
                value=f"{len(config.get('ignored_users', []))} user(s)",
                inline=True
            )
            await ctx.reply(embed=embed)

        elif action.lower() == "ignorechannel":
            if not target:
                return await ctx.reply("❌ Please mention a channel. Example: `//autotranslate ignorechannel #general`")
            channel = await commands.TextChannelConverter().convert(ctx, target)
            ignored = config.get("ignored_channels", [])
            if channel.id in ignored:
                return await ctx.reply(f"{channel.mention} is already ignored.")
            ignored.append(channel.id)
            config["ignored_channels"] = ignored
            _save_auto_translate_config(ctx.guild.id, config)
            await ctx.reply(f"✅ {channel.mention} is now ignored for auto-translate.")

        elif action.lower() == "unignorechannel":
            if not target:
                return await ctx.reply("❌ Please mention a channel. Example: `//autotranslate unignorechannel #general`")
            channel = await commands.TextChannelConverter().convert(ctx, target)
            ignored = config.get("ignored_channels", [])
            if channel.id not in ignored:
                return await ctx.reply(f"{channel.mention} is not ignored.")
            ignored.remove(channel.id)
            config["ignored_channels"] = ignored
            _save_auto_translate_config(ctx.guild.id, config)
            await ctx.reply(f"✅ {channel.mention} is no longer ignored for auto-translate.")

        elif action.lower() == "ignorerole":
            if not target:
                return await ctx.reply("❌ Please mention a role. Example: `//autotranslate ignorerole @Moderator`")
            role = await commands.RoleConverter().convert(ctx, target)
            ignored = config.get("ignored_roles", [])
            if role.id in ignored:
                return await ctx.reply(f"{role.mention} is already ignored.")
            ignored.append(role.id)
            config["ignored_roles"] = ignored
            _save_auto_translate_config(ctx.guild.id, config)
            await ctx.reply(f"✅ {role.mention} is now ignored for auto-translate.")

        elif action.lower() == "unignorerole":
            if not target:
                return await ctx.reply("❌ Please mention a role. Example: `//autotranslate unignorerole @Moderator`")
            role = await commands.RoleConverter().convert(ctx, target)
            ignored = config.get("ignored_roles", [])
            if role.id not in ignored:
                return await ctx.reply(f"{role.mention} is not ignored.")
            ignored.remove(role.id)
            config["ignored_roles"] = ignored
            _save_auto_translate_config(ctx.guild.id, config)
            await ctx.reply(f"✅ {role.mention} is no longer ignored for auto-translate.")

        elif action.lower() == "ignoreuser":
            if not target:
                return await ctx.reply("❌ Please mention a user. Example: `//autotranslate ignoreuser @user`")
            user = await commands.UserConverter().convert(ctx, target)
            ignored = config.get("ignored_users", [])
            if user.id in ignored:
                return await ctx.reply(f"{user.mention} is already ignored.")
            ignored.append(user.id)
            config["ignored_users"] = ignored
            _save_auto_translate_config(ctx.guild.id, config)
            await ctx.reply(f"✅ {user.mention} is now ignored for auto-translate.")

        elif action.lower() == "unignoreuser":
            if not target:
                return await ctx.reply("❌ Please mention a user. Example: `//autotranslate unignoreuser @user`")
            user = await commands.UserConverter().convert(ctx, target)
            ignored = config.get("ignored_users", [])
            if user.id not in ignored:
                return await ctx.reply(f"{user.mention} is not ignored.")
            ignored.remove(user.id)
            config["ignored_users"] = ignored
            _save_auto_translate_config(ctx.guild.id, config)
            await ctx.reply(f"✅ {user.mention} is no longer ignored for auto-translate.")

        elif action.lower() == "help":
            help_text = """**Auto-Translate Commands:**

`//autotranslate enable` - Enable auto-translate
`//autotranslate disable` - Disable auto-translate
`//autotranslate setlanguage <language>` - Set default language
`//autotranslate status` - View configuration
`//autotranslate ignorechannel <#channel>` - Ignore a channel
`//autotranslate unignorechannel <#channel>` - Unignore a channel
`//autotranslate ignorerole <@role>` - Ignore a role
`//autotranslate unignorerole <@role>` - Unignore a role
`//autotranslate ignoreuser <@user>` - Ignore a user
`//autotranslate unignoreuser <@user>` - Unignore a user

**Slash commands:** `/autotranslate` group for all the above.

**Example:** `//autotranslate setlanguage es` - Sets default language to Spanish"""
            await ctx.reply(help_text)

        else:
            await ctx.reply(f"❌ Unknown action: `{action}`. Use `//autotranslate help` for available commands.")

    @commands.command(name="ats", aliases=["atstatus"])
    @commands.has_permissions(manage_guild=True)
    async def p_autotranslate_status_short(self, ctx):
        await self.p_autotranslate(ctx, "status")

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            missing = ", ".join(p.replace("_", " ").title() for p in error.missing_permissions)
            try:
                await interaction.response.send_message(
                    f"❌ You are missing the required permissions: **{missing}**.",
                    ephemeral=True,
                )
            except discord.InteractionResponded:
                await interaction.followup.send(
                    f"❌ You are missing the required permissions: **{missing}**.",
                    ephemeral=True,
                )
        else:
            print(f"[Translation] Error: {error}")
            try:
                if interaction.response.is_done():
                    await interaction.followup.send(f"❌ An error occurred: {error}", ephemeral=True)
                else:
                    await interaction.response.send_message(f"❌ An error occurred: {error}", ephemeral=True)
            except:
                pass

async def setup(bot):
    await bot.add_cog(Translation(bot))
