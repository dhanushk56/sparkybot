import discord
from discord import app_commands
from discord.ext import commands, tasks
import asyncio
import io
import re
import aiohttp
import time
from datetime import datetime, timezone, timedelta
from config import Config
from utils.embed import build
from utils.theme import Theme
from utils.data import load, save

TICKETS_FILE = "tickets.json"
REVIEWS_FILE = "reviews.json"

DEFAULT_CATEGORIES = {
    "general": {
        "label": "🆘 General Support",
        "description": "General inquiries, questions, and clarifications",
        "priority": 0,
        "enabled": True,
        "cooldown": 300,
        "auto_close_hours": 24,
        "questions": [],
        "staff_roles": [],
        "form_fields": []
    },
    "billing": {
        "label": "💰 Billing Support",
        "description": "Payment issues, invoices, and billing questions",
        "priority": 1,
        "enabled": True,
        "cooldown": 300,
        "auto_close_hours": 24,
        "questions": [],
        "staff_roles": [],
        "form_fields": []
    },
    "bug_report": {
        "label": "🐛 Report a Bug",
        "description": "Report bugs or glitches with details and steps",
        "priority": 2,
        "enabled": True,
        "cooldown": 600,
        "auto_close_hours": 48,
        "questions": [],
        "staff_roles": [],
        "form_fields": []
    },
    "partnership": {
        "label": "🤝 Partnership",
        "description": "Business inquiries, collaborations, and partnerships",
        "priority": 1,
        "enabled": True,
        "cooldown": 1800,
        "auto_close_hours": 72,
        "questions": [],
        "staff_roles": [],
        "form_fields": []
    },
    "other": {
        "label": "📌 Other",
        "description": "Anything that doesn't fit the other categories",
        "priority": 3,
        "enabled": True,
        "cooldown": 300,
        "auto_close_hours": 24,
        "questions": [],
        "staff_roles": [],
        "form_fields": []
    },
}

DEFAULT_CUSTOMIZATION = {
    "embed_title": "🎫 Support Tickets",
    "embed_description": "Welcome to the **Support System**! Please select a category below to create a ticket.",
    "embed_color": Config.COLOR_INFO,
    "embed_footer": "📝 Important Notes\n• Do not ping staff excessively\n• Be patient • staff will respond as soon as possible\n• Ticket abuse may result in restrictions\n• Provide clear information to help us assist you faster",
    "footer_text": "Sparky Bot • Ticket System",
    "panel_channel": None,
    "enable_ratings": True,
    "enable_history": True,
    "enable_auto_close": True,
    "default_auto_close_hours": 24,
    "staff_role_override": None,
    "reviews_channel": None,
    "show_available_categories": False,
    "important_notes_heading": "📝 Important Notes",
}

_submission_times = {}

_last_action = {}
_transcript_cache = {}

def _can_act(user_id: int, channel_id: int, action: str, cooldown: float = 2.0) -> bool:
    key = f"{user_id}_{channel_id}_{action}"
    now = datetime.now(timezone.utc).timestamp()
    if key in _last_action:
        if now - _last_action[key] < cooldown:
            return False
    _last_action[key] = now
    return True

def _is_staff(interaction_or_ctx, channel_id: int = None) -> bool:
    guild = interaction_or_ctx.guild
    user = interaction_or_ctx.author if hasattr(interaction_or_ctx, 'author') else interaction_or_ctx.user
    if not guild:
        return False
    if user.guild_permissions.manage_channels:
        return True
    settings = load("guild_settings.json").get(str(guild.id), {})
    global_roles = settings.get("ticket_staff_roles", [])
    user_roles = [role.id for role in user.roles]
    if any(role_id in user_roles for role_id in global_roles):
        return True
    if channel_id:
        td = _ticket_data(guild.id)
        info = td.get("open", {}).get(str(channel_id), {})
        cat = info.get("category", "general")
        type_roles = settings.get("ticket_type_roles", {}).get(cat, [])
        if any(role_id in user_roles for role_id in type_roles):
            return True
    return False

def _ticket_data(guild_id):
    data = load(TICKETS_FILE)
    return data.get(str(guild_id), {"counter": 0, "open": {}})

def _save_ticket(guild_id, td):
    data = load(TICKETS_FILE)
    data[str(guild_id)] = td
    save(TICKETS_FILE, data)

def _review_data(guild_id):
    data = load(REVIEWS_FILE)
    return data.get(str(guild_id), {"reviews": []})

def _save_review(guild_id, review_data):
    data = load(REVIEWS_FILE)
    if str(guild_id) not in data:
        data[str(guild_id)] = {"reviews": []}
    data[str(guild_id)]["reviews"].append(review_data)
    save(REVIEWS_FILE, data)

def _get_customization(guild_id: int) -> dict:
    settings = load("guild_settings.json")
    return settings.get(str(guild_id), {}).get("ticket_customization", DEFAULT_CUSTOMIZATION.copy())

def _save_customization(guild_id: int, custom_data: dict):
    settings = load("guild_settings.json")
    if str(guild_id) not in settings:
        settings[str(guild_id)] = {}
    settings[str(guild_id)]["ticket_customization"] = custom_data
    save("guild_settings.json", settings)

def _get_categories(guild_id: int) -> dict:
    settings = load("guild_settings.json")
    custom = settings.get(str(guild_id), {}).get("ticket_categories", {})
    if custom:
        return custom.copy()
    return DEFAULT_CATEGORIES.copy()

def _save_categories(guild_id: int, categories: dict):
    settings = load("guild_settings.json")
    if str(guild_id) not in settings:
        settings[str(guild_id)] = {}
    settings[str(guild_id)]["ticket_categories"] = categories
    save("guild_settings.json", settings)

FORM_FIELD_TYPES = [
    "text", "textarea", "dropdown", "number", "boolean"
]

class AddCategoryModal(discord.ui.Modal, title="Add Ticket Category"):
    category_key = discord.ui.TextInput(label="Category Key (internal ID)", placeholder="e.g. support, billing, report", max_length=30, required=True)
    category_label = discord.ui.TextInput(label="Category Label (shown to users)", placeholder="e.g. 🆘 Support", max_length=100, required=True)
    category_description = discord.ui.TextInput(label="Category Description", style=discord.TextStyle.paragraph, placeholder="Describe what this category is for...", max_length=500, required=False)

    def __init__(self, guild_id: int):
        super().__init__()
        self.guild_id = guild_id

    async def on_submit(self, interaction: discord.Interaction):
        try:
            key = self.category_key.value.strip().lower().replace(" ", "_")
            if not key:
                return await interaction.response.send_message("❌ Category key cannot be empty.", ephemeral=True)

            categories = _get_categories(self.guild_id)
            if key in categories:
                return await interaction.response.send_message(f"❌ Category `{key}` already exists.", ephemeral=True)

            categories[key] = {
                "label": self.category_label.value.strip(),
                "description": self.category_description.value.strip() or " ",
                "priority": len(categories),
                "enabled": True,
                "cooldown": 300,
                "auto_close_hours": 24,
                "questions": [],
                "staff_roles": [],
                "form_fields": []
            }
            _save_categories(self.guild_id, categories)

            embed = build(title="✅ Category Added", description=f"Category `{key}` added successfully!\nUse `/tkt fields add category:{key}` to add form fields.", color=Config.COLOR_OK, bot=self.bot)
            await interaction.response.send_message(embed=embed, ephemeral=True)
        except Exception as e:
            print(f"[Tickets] Error in AddCategoryModal: {e}")
            await interaction.response.send_message(f"❌ An error occurred: {str(e)[:100]}", ephemeral=True)

class RemoveCategorySelect(discord.ui.Select):
    def __init__(self, guild_id: int, categories: dict):
        self.guild_id = guild_id
        options = []
        for key, cat in categories.items():
            options.append(
                discord.SelectOption(
                    label=cat["label"][:100],
                    value=key,
                    description=f"Key: {key}"
                )
            )
        super().__init__(placeholder="Select a category to remove...", options=options[:25])

    async def callback(self, interaction: discord.Interaction):
        try:
            key = self.values[0]
            categories = _get_categories(self.guild_id)
            if key in categories:
                del categories[key]
                _save_categories(self.guild_id, categories)
                await interaction.response.send_message(f"✅ Category `{key}` removed successfully!", ephemeral=True)
            else:
                await interaction.response.send_message(f"❌ Failed to remove category `{key}`.", ephemeral=True)
            self.view.stop()
        except Exception as e:
            print(f"[Tickets] Error in RemoveCategorySelect: {e}")
            await interaction.response.send_message(f"❌ An error occurred: {str(e)[:100]}", ephemeral=True)

class RemoveCategoryView(discord.ui.View):
    def __init__(self, guild_id: int, categories: dict):
        super().__init__(timeout=60)
        self.add_item(RemoveCategorySelect(guild_id, categories))

class ResetCategoriesView(discord.ui.View):
    def __init__(self, guild_id: int):
        super().__init__(timeout=60)
        self.guild_id = guild_id

    @discord.ui.button(label="✅ Yes, Reset to Defaults", style=discord.ButtonStyle.danger)
    async def confirm_reset(self, interaction: discord.Interaction, button: discord.ui.Button):
        try:
            if not interaction.user.guild_permissions.administrator:
                return await interaction.response.send_message("❌ You need Administrator permission.", ephemeral=True)
            _save_categories(self.guild_id, DEFAULT_CATEGORIES.copy())
            await interaction.response.send_message("✅ Categories reset to defaults!", ephemeral=True)
            self.stop()
        except Exception as e:
            print(f"[Tickets] Error in ResetCategoriesView: {e}")
            await interaction.response.send_message(f"❌ An error occurred: {str(e)[:100]}", ephemeral=True)

    @discord.ui.button(label="❌ Cancel", style=discord.ButtonStyle.secondary)
    async def cancel_reset(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("Reset cancelled.", ephemeral=True)
        self.stop()

class SetEmbedTextView(discord.ui.View):
    def __init__(self, guild_id: int):
        super().__init__(timeout=60)
        self.guild_id = guild_id

    @discord.ui.button(label="✏️ Set Embed Text", style=discord.ButtonStyle.primary, emoji="📝")
    async def set_embed_text(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message("❌ You need Administrator permission.", ephemeral=True)
        await interaction.response.send_modal(SetEmbedTextModal(self.guild_id))

    @discord.ui.button(label="🗑️ Clear Embed Text", style=discord.ButtonStyle.danger, emoji="🗑️")
    async def clear_embed_text(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message("❌ You need Administrator permission.", ephemeral=True)
        settings = load("guild_settings.json")
        gd = settings.get(str(self.guild_id), {})
        if "ticket_customization" in gd:
            gd["ticket_customization"].pop("ticket_embed_text", None)
        save("guild_settings.json", settings)
        await interaction.response.send_message("✅ Ticket embed text cleared!", ephemeral=True)

class SetEmbedTextModal(discord.ui.Modal, title="Set Ticket Embed Text"):
    embed_text = discord.ui.TextInput(
        label="Embed Text",
        style=discord.TextStyle.paragraph,
        required=False,
        max_length=4000,
        placeholder="Welcome {opener}! Staff will assist you shortly.\n{open_tickets} ticket(s) currently open."
    )

    def __init__(self, guild_id: int):
        super().__init__()
        self.guild_id = guild_id
        custom = _get_customization(guild_id)
        current = custom.get("ticket_embed_text", "")
        self.embed_text.default = current

    async def on_submit(self, interaction: discord.Interaction):
        try:
            custom = _get_customization(self.guild_id)
            if self.embed_text.value.strip():
                custom["ticket_embed_text"] = self.embed_text.value.strip()
            else:
                custom.pop("ticket_embed_text", None)
            _save_customization(self.guild_id, custom)
            await interaction.response.send_message("✅ Ticket embed text updated!", ephemeral=True)
        except Exception as e:
            print(f"[Tickets] Error in SetEmbedTextModal: {e}")
            await interaction.response.send_message(f"❌ An error occurred: {str(e)[:100]}", ephemeral=True)

class TicketPanelView(discord.ui.View):
    def __init__(self, categories: dict):
        super().__init__(timeout=None)

class AddFormFieldModal(discord.ui.Modal, title="Add Form Field"):
    field_type = discord.ui.TextInput(
        label="Field Type",
        placeholder="text, textarea, dropdown, number, boolean",
        max_length=20,
        required=True
    )
    label = discord.ui.TextInput(
        label="Field Label",
        placeholder="What is your question?",
        max_length=100,
        required=True
    )
    required = discord.ui.TextInput(
        label="Required? (yes/no)",
        placeholder="yes",
        max_length=3,
        required=True,
        default="yes"
    )
    options = discord.ui.TextInput(
        label="Options (comma separated, for dropdown)",
        placeholder="Option A, Option B, Option C",
        max_length=500,
        required=False
    )
    placeholder = discord.ui.TextInput(
        label="Placeholder (optional)",
        placeholder="Enter your answer...",
        max_length=100,
        required=False
    )

    def __init__(self, guild_id: int, category_key: str):
        super().__init__()
        self.guild_id = guild_id
        self.category_key = category_key

    async def on_submit(self, interaction: discord.Interaction):
        ftype = self.field_type.value.strip().lower()
        if ftype not in FORM_FIELD_TYPES:
            return await interaction.response.send_message(
                f"❌ Invalid type. Valid: {', '.join(FORM_FIELD_TYPES)}",
                ephemeral=True
            )

        categories = _get_categories(self.guild_id)
        if self.category_key not in categories:
            return await interaction.response.send_message(
                "❌ Category not found.",
                ephemeral=True
            )

        options = []
        if self.options.value.strip():
            options = [o.strip() for o in self.options.value.split(",") if o.strip()]

        if ftype == "dropdown" and len(options) < 2:
            return await interaction.response.send_message(
                "❌ Dropdown needs at least 2 options.",
                ephemeral=True
            )

        required = self.required.value.strip().lower() not in ("no", "n", "false")

        field = {
            "type": ftype,
            "label": self.label.value.strip(),
            "required": required,
            "options": options,
            "placeholder": self.placeholder.value.strip() or None
        }

        categories[self.category_key].setdefault("form_fields", []).append(field)
        _save_categories(self.guild_id, categories)

        embed = build(title="✅ Form Field Added", description=f"Added field to **{categories[self.category_key]['label']}**", color=Config.COLOR_OK, bot=self.bot)
        await interaction.response.send_message(embed=embed, ephemeral=True)

class RemoveFormFieldSelect(discord.ui.Select):
    def __init__(self, guild_id: int, category_key: str, fields: list):
        self.guild_id = guild_id
        self.category_key = category_key
        options = []
        for i, field in enumerate(fields):
            label = field["label"][:50]
            options.append(
                discord.SelectOption(
                    label=label,
                    value=str(i),
                    description=f"{field['type']} - {'Required' if field.get('required', True) else 'Optional'}"
                )
            )
        super().__init__(placeholder="Select a field to remove...", options=options[:25])

    async def callback(self, interaction: discord.Interaction):
        idx = int(self.values[0])
        categories = _get_categories(self.guild_id)
        if self.category_key not in categories:
            return await interaction.response.send_message("❌ Category not found.", ephemeral=True)

        fields = categories[self.category_key].get("form_fields", [])
        if idx >= len(fields):
            return await interaction.response.send_message("❌ Field not found.", ephemeral=True)

        removed = fields.pop(idx)
        categories[self.category_key]["form_fields"] = fields
        _save_categories(self.guild_id, categories)

        embed = build(title="✅ Field Removed", description=f"Removed: **{removed['label']}**", color=Config.COLOR_OK, bot=self.bot)
        await interaction.response.send_message(embed=embed, ephemeral=True)
        self.view.stop()

class RemoveFormFieldView(discord.ui.View):
    def __init__(self, guild_id: int, category_key: str, fields: list):
        super().__init__(timeout=60)
        self.add_item(RemoveFormFieldSelect(guild_id, category_key, fields))

class TicketFormModal(discord.ui.Modal, title="Create Ticket"):
    def __init__(self, fields: list, category_key: str, category_label: str, opener_id: int, guild_id: int):
        super().__init__(title=f"New Ticket: {category_label[:30]}")
        self.fields = fields
        self.category_key = category_key
        self.category_label = category_label
        self.opener_id = opener_id
        self.guild_id = guild_id
        self.answers = {}
        self.field_items = []

        for i, field in enumerate(fields[:5]):
            ftype = field.get("type", "text")
            label = field["label"][:45]
            placeholder = field.get("placeholder", "")
            required = field.get("required", True)

            if ftype == "text":
                item = discord.ui.TextInput(
                    label=label,
                    placeholder=placeholder or "Short answer...",
                    required=required,
                    max_length=200,
                    style=discord.TextStyle.short
                )
            elif ftype == "textarea":
                item = discord.ui.TextInput(
                    label=label,
                    placeholder=placeholder or "Detailed answer...",
                    required=required,
                    max_length=4000,
                    style=discord.TextStyle.paragraph
                )
            elif ftype == "number":
                item = discord.ui.TextInput(
                    label=label,
                    placeholder=placeholder or "Enter a number...",
                    required=required,
                    max_length=20,
                    style=discord.TextStyle.short
                )
            elif ftype == "boolean":
                item = discord.ui.TextInput(
                    label=label,
                    placeholder="yes or no",
                    required=required,
                    max_length=3,
                    style=discord.TextStyle.short
                )
            elif ftype == "dropdown":
                options = field.get("options", [])
                item = discord.ui.TextInput(
                    label=label,
                    placeholder=f"Options: {', '.join(options[:5])}",
                    required=required,
                    max_length=500,
                    style=discord.TextStyle.short
                )
            else:
                item = discord.ui.TextInput(
                    label=label,
                    placeholder=placeholder or "Answer...",
                    required=required,
                    max_length=200,
                    style=discord.TextStyle.short
                )

            setattr(self, f"field_{i}", item)
            self.field_items.append(item)
            self.add_item(item)

        self.field_labels = [field["label"] for field in fields[:5]]

    async def on_submit(self, interaction: discord.Interaction):
        for i, item in enumerate(self.field_items):
            self.answers[self.field_labels[i]] = item.value

        self.interaction = interaction
        await interaction.response.defer(ephemeral=True)
        self.stop()

class CustomTicketPanelView(discord.ui.View):
    def __init__(self, categories: dict, guild_id: int):
        super().__init__(timeout=None)
        self.guild_id = guild_id
        self.add_item(TicketCategorySelect(categories, guild_id))

class TicketCategorySelect(discord.ui.Select):
    def __init__(self, categories: dict, guild_id: int):
        self.categories = categories
        self.guild_id = guild_id
        options = []
        for key, cat in categories.items():
            if not cat.get("enabled", True):
                continue
            q_count = len(cat.get("form_fields", [])) + len(cat.get("questions", []))
            desc = cat.get("description", "")[:50] or " "
            if q_count:
                desc += f" ({q_count} fields)"
            options.append(
                discord.SelectOption(
                    label=cat["label"][:100],
                    value=key,
                    description=desc[:100] or " ",
                )
            )
        super().__init__(
            placeholder="Select a ticket category...",
            min_values=1,
            max_values=1,
            options=options[:25],
            custom_id="ticket_category_select"
        )

    async def callback(self, interaction: discord.Interaction):
        try:
            category_key = self.values[0]
            categories = _get_categories(self.guild_id)

            if category_key not in categories:
                await interaction.response.send_message("❌ This category no longer exists.", ephemeral=True)
                return

            category_label = categories[category_key]["label"]
            form_fields = categories[category_key].get("form_fields", [])
            questions = categories[category_key].get("questions", [])

            all_fields = form_fields + questions

            td = _ticket_data(self.guild_id)
            for ch_id, info in td.get("open", {}).items():
                if info.get("opener") == interaction.user.id and interaction.guild.get_channel(int(ch_id)):
                    await interaction.response.send_message(
                        f"You already have an open ticket: <#{ch_id}>",
                        ephemeral=True
                    )
                    return

            if all_fields:
                modal = TicketFormModal(all_fields, category_key, category_label, interaction.user.id, self.guild_id)
                await interaction.response.send_modal(modal)

                await modal.wait()

                if hasattr(modal, 'answers') and modal.answers:
                    answers = modal.answers
                    result = await _create_ticket_channel(
                        interaction.guild,
                        interaction.user,
                        category_key,
                        category_label,
                        answers
                    )
                    number, channel = result
                    if number is None:
                        await interaction.followup.send(
                            f"You already have an open ticket: {channel.mention}",
                            ephemeral=True
                        )
                        return

                    settings = load("guild_settings.json").get(str(interaction.guild.id), {})
                    custom_embed_text = settings.get("ticket_customization", {}).get("ticket_embed_text")
                    await interaction.followup.send(
                        f"✅ Ticket created: {channel.mention}",
                        ephemeral=True
                    )
                    await _send_ticket_embed(
                        channel,
                        interaction.user,
                        number,
                        category_label,
                        custom_embed_text,
                        answers
                    )
                else:
                    await interaction.followup.send(
                        "❌ Ticket creation cancelled.",
                        ephemeral=True
                    )
            else:
                result = await _create_ticket_channel(
                    interaction.guild,
                    interaction.user,
                    category_key,
                    category_label,
                    None
                )
                number, channel = result
                if number is None:
                    await interaction.response.send_message(
                        f"You already have an open ticket: {channel.mention}",
                        ephemeral=True
                    )
                    return

                settings = load("guild_settings.json").get(str(interaction.guild.id), {})
                custom_embed_text = settings.get("ticket_customization", {}).get("ticket_embed_text")
                await interaction.response.send_message(
                    f"✅ Ticket created: {channel.mention}",
                    ephemeral=True
                )
                await _send_ticket_embed(
                    channel,
                    interaction.user,
                    number,
                    category_label,
                    custom_embed_text
                )

        except Exception as e:
            print(f"[Tickets] Error in TicketCategorySelect: {e}")
            await interaction.response.send_message(
                f"❌ An error occurred: {str(e)[:100]}",
                ephemeral=True
            )

class TicketControlView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self._update_buttons()

    def _update_buttons(self, claimed: bool = False, claimed_by: int = None):
        self.clear_items()
        self.add_item(self.close_btn)
        self.add_item(self.claim_btn)
        self.add_item(self.unclaim_btn)
        self.add_item(self.transcript_btn)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        td = _ticket_data(interaction.guild.id)
        info = td.get("open", {}).get(str(interaction.channel.id))
        if not info:
            await interaction.response.send_message("This channel is not an active ticket.", ephemeral=True)
            return False
        button_id = interaction.data.get("custom_id")
        if not _is_staff(interaction, interaction.channel.id):
            await interaction.response.send_message("❌ Only staff can use ticket buttons.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="🔒 Close", style=discord.ButtonStyle.danger, custom_id="ticket_close_btn")
    async def close_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not _is_staff(interaction, interaction.channel.id):
            return await interaction.response.send_message("❌ Only staff can close tickets.", ephemeral=True)

        if not _can_act(interaction.user.id, interaction.channel.id, "close", 3.0):
            await interaction.response.send_message("⏳ Please wait a moment before using this button again.", ephemeral=True)
            return
        await interaction.response.send_modal(CloseModal(interaction.channel, interaction.user))

    @discord.ui.button(label="✅ Claim", style=discord.ButtonStyle.primary, custom_id="ticket_claim_btn")
    async def claim_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not _can_act(interaction.user.id, interaction.channel.id, "claim", 2.0):
            await interaction.response.send_message("⏳ Please wait a moment before using this button again.", ephemeral=True)
            return
        td = _ticket_data(interaction.guild.id)
        channel_id = str(interaction.channel.id)
        info = td.get("open", {}).get(channel_id, {})
        if info.get("claimed_by"):
            return await interaction.response.send_message("This ticket is already claimed.", ephemeral=True)
        opener = interaction.guild.get_member(info["opener"])
        info["claimed_by"] = interaction.user.id
        td["open"][channel_id] = info
        _save_ticket(interaction.guild.id, td)
        await _update_channel_topic(interaction.channel, interaction.user)
        claim_message = f"✅ {interaction.user.mention} has claimed this ticket! {opener.mention if opener else ''}"
        await interaction.channel.send(claim_message)
        await interaction.response.send_message("✅ You claimed this ticket!", ephemeral=True)

    @discord.ui.button(label="🔓 Unclaim", style=discord.ButtonStyle.secondary, custom_id="ticket_unclaim_btn")
    async def unclaim_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not _can_act(interaction.user.id, interaction.channel.id, "unclaim", 2.0):
            await interaction.response.send_message("⏳ Please wait a moment before using this command again.", ephemeral=True)
            return
        td = _ticket_data(interaction.guild.id)
        channel_id = str(interaction.channel.id)
        info = td.get("open", {}).get(channel_id, {})
        if not info.get("claimed_by"):
            return await interaction.response.send_message("This ticket is not claimed.", ephemeral=True)
        if info["claimed_by"] != interaction.user.id:
            claimer = interaction.guild.get_member(info["claimed_by"])
            return await interaction.response.send_message(f"Only {claimer.mention if claimer else 'the claimant'} can unclaim this ticket.", ephemeral=True)
        opener = interaction.guild.get_member(info["opener"])
        info["claimed_by"] = None
        td["open"][channel_id] = info
        _save_ticket(interaction.guild.id, td)
        await _update_channel_topic(interaction.channel, None)
        unclaim_message = f"🔓 {interaction.user.mention} has unclaimed this ticket! {opener.mention if opener else ''}"
        await interaction.channel.send(unclaim_message)
        await interaction.response.send_message("🔓 You unclaimed this ticket!", ephemeral=True)

    @discord.ui.button(label="📄 Transcript", style=discord.ButtonStyle.secondary, custom_id="ticket_transcript_btn")
    async def transcript_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not _is_staff(interaction, interaction.channel.id):
            return await interaction.response.send_message("❌ Only staff can generate transcripts.", ephemeral=True)
        if not _can_act(interaction.user.id, interaction.channel.id, "transcript", 10.0):
            await interaction.response.send_message("⏳ Please wait a moment before generating another transcript.", ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        transcript = await _generate_transcript(interaction.channel)
        if not transcript:
            return await interaction.followup.send("❌ Failed to generate transcript.", ephemeral=True)
        if transcript.get("url"):
            await interaction.followup.send(f"📄 Transcript for {interaction.channel.mention}\n[Click here to view]({transcript['url']})", ephemeral=True)
        elif transcript.get("file"):
            await interaction.followup.send(f"📄 Transcript for {interaction.channel.mention}", file=transcript["file"], ephemeral=True)
        else:
            await interaction.followup.send("❌ Failed to generate transcript.", ephemeral=True)

class RatingSelect(discord.ui.Select):
    def __init__(self, guild_id: int, channel_id: int, opener_id: int, ticket_number: int, category: str):
        self.guild_id = guild_id
        self.channel_id = channel_id
        self.opener_id = opener_id
        self.ticket_number = ticket_number
        self.category = category
        options = []
        for i in range(1, 6):
            stars = "⭐" * i
            label = f"{stars} {i}/5"
            options.append(discord.SelectOption(label=label, value=str(i), description=f"Rate {i} stars"))
        super().__init__(placeholder="Select your rating...", options=options, min_values=1, max_values=1)

    async def callback(self, interaction: discord.Interaction):
        rating = int(self.values[0])
        original_message = interaction.message
        modal = ReviewModal(
            self.guild_id,
            self.channel_id,
            self.opener_id,
            self.ticket_number,
            self.category,
            rating,
            original_message
        )
        await interaction.response.send_modal(modal)

class RatingView(discord.ui.View):
    def __init__(self, guild_id: int, channel_id: int, opener_id: int, ticket_number: int, category: str):
        super().__init__(timeout=300)
        self.add_item(RatingSelect(guild_id, channel_id, opener_id, ticket_number, category))

class ReviewModal(discord.ui.Modal, title="📝 Leave a Review"):
    review_text = discord.ui.TextInput(
        label="Your Review (Optional)",
        style=discord.TextStyle.paragraph,
        required=False,
        max_length=2000,
        placeholder="Share your experience with our support team... (optional)"
    )

    def __init__(self, guild_id: int, channel_id: int, opener_id: int, ticket_number: int, category: str, rating: int, original_message: discord.Message):
        super().__init__()
        self.guild_id = guild_id
        self.channel_id = channel_id
        self.opener_id = opener_id
        self.ticket_number = ticket_number
        self.category = category
        self.rating = rating
        self.original_message = original_message

    async def on_submit(self, interaction: discord.Interaction):
        try:

            td = _ticket_data(self.guild_id)
            info = td.get("open", {}).get(str(self.channel_id), {})
            if info:
                info["rating"] = self.rating
                if self.review_text.value:
                    info["review"] = self.review_text.value
                td["open"][str(self.channel_id)] = info
                _save_ticket(self.guild_id, td)

            review_data = {
                "user_id": self.opener_id,
                "user_name": str(interaction.user),
                "rating": self.rating,
                "review": self.review_text.value or None,
                "category": self.category,
                "ticket_number": self.ticket_number,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "guild_id": self.guild_id,
                "channel_id": self.channel_id,
            }
            _save_review(self.guild_id, review_data)

            custom = _get_customization(self.guild_id)
            reviews_channel_id = custom.get("reviews_channel")
            if reviews_channel_id:
                bot = interaction.client
                guild = bot.get_guild(self.guild_id)
                if guild:
                    channel = guild.get_channel(reviews_channel_id)
                    if channel:
                        embed = await self._build_review_embed(interaction)
                        await channel.send(embed=embed)

            if self.original_message and self.original_message.embeds:
                original_embed = self.original_message.embeds[0]
                new_embed = discord.Embed.from_dict(original_embed.to_dict())
                new_embed.color = Config.COLOR_OK
                new_embed.add_field(
                    name="⭐ Rating",
                    value=f"{'⭐' * self.rating} ({self.rating}/5)\n**Review:** {self.review_text.value or 'No review provided'}",
                    inline=False
                )
                await self.original_message.edit(embed=new_embed, view=None)
            else:
                updated_embed = build(title="✅ Rating Submitted", description=f"Thank you! You rated this experience **{self.rating} ⭐**.\n\n**Your Review:** {self.review_text.value or 'No review provided'}", color=Config.COLOR_OK, bot=self.bot)
                await self.original_message.edit(embed=updated_embed, view=None)

            await interaction.response.send_message(
                f"✅ Thank you for your rating! You rated this experience **{self.rating} ⭐**.",
                ephemeral=True
            )

        except Exception as e:
            print(f"[Tickets] Error saving review: {e}")
            await interaction.response.send_message(
                f"❌ An error occurred: {str(e)[:100]}",
                ephemeral=True
            )

    async def _build_review_embed(self, interaction: discord.Interaction) -> discord.Embed:
        guild = interaction.client.get_guild(self.guild_id)
        if not guild:
            guild = interaction.guild
        guild_name = guild.name if guild else "Unknown Server"

        td = _ticket_data(self.guild_id)
        info = td.get("open", {}).get(str(self.channel_id), {})

        participants = info.get("participants", {})
        total_messages = sum(participants.values())

        sorted_participants = sorted(participants.items(), key=lambda x: x[1], reverse=True)
        participant_lines = []
        for uid, count in sorted_participants:
            member = guild.get_member(int(uid)) if guild else None
            name = member.mention if member else f"Unknown ({uid})"
            participant_lines.append(f"{name} • {count} messages")

        if not participant_lines:
            participant_lines = ["No participant data available"]

        stars = "⭐" * self.rating + "☆" * (5 - self.rating)
        embed = build(title="🎫 Ticket Closed", description=(
                f"Your ticket has been closed in **{guild_name}**\n"
                f"You rated this ticket: **{stars} ({self.rating}/5)**\n"
                f"Your Review: {self.review_text.value or 'No review provided'}"
            ), color=0x5865F2, bot=self.bot)

        close_reason = info.get("close_reason", "No reason provided.")
        closed_by_id = info.get("closed_by")
        closed_by = f"<@{closed_by_id}>" if closed_by_id else "Unknown"
        claimed_by = info.get("claimed_by")
        claimed_by_str = f"<@{claimed_by}>" if claimed_by else "Not claimed"

        embed.add_field(
            name="Ticket Details",
            value=(
                f"**Category:** {info.get('category_label', self.category)}\n"
                f"**Close Reason:** {close_reason}\n"
                f"**Closed by:** {closed_by}\n"
                f"**Claimed by:** {claimed_by_str}\n"
                f"**Total Messages:** {total_messages}"
            ),
            inline=False
        )

        embed.add_field(
            name="Participants",
            value="\n".join(participant_lines),
            inline=False
        )

        transcript_url = info.get("transcript_url") or "https://lunarwolf71020"
        embed.add_field(name="Transcript", value=f"[Click here]({transcript_url})", inline=False)

        embed.set_footer(text=f"Ticket #{self.ticket_number:04d}")

        return embed

class AutoCloseView(discord.ui.View):
    def __init__(self, channel: discord.TextChannel, hours: float, opener_id: int):
        super().__init__(timeout=None)
        self.channel = channel
        self.opener_id = opener_id
        self.hours = hours
        self.cancelled = False

    @discord.ui.button(label="❌ Cancel Auto-Close", style=discord.ButtonStyle.secondary)
    async def cancel_auto_close(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.opener_id and not _is_staff(interaction, self.channel.id):
            return await interaction.response.send_message("❌ Only the ticket opener or staff can cancel auto-close.", ephemeral=True)

        self.cancelled = True
        td = _ticket_data(interaction.guild.id)
        info = td.get("open", {}).get(str(self.channel.id), {})
        if info:
            info.pop("autoclose_at", None)
            info.pop("autoclose_reason", None)
            td["open"][str(self.channel.id)] = info
            _save_ticket(interaction.guild.id, td)

        embed = build(title="🔄 Auto-Close Cancelled", description="The auto-close timer has been cancelled.", color=Config.COLOR_OK, bot=self.bot)
        await interaction.response.send_message(embed=embed)
        self.stop()

def _parse_time(time_str: str) -> tuple[int, int] | None:
    time_str = time_str.strip()
    m = re.match(r'^(\d{1,2}):(\d{2})\s*(AM|PM)$', time_str, re.IGNORECASE)
    if m:
        h, mi, ampm = int(m.group(1)), int(m.group(2)), m.group(3).upper()
        if ampm == "PM" and h != 12: h += 12
        if ampm == "AM" and h == 12: h = 0
        if 0 <= h <= 23 and 0 <= mi <= 59: return h, mi
    m = re.match(r'^(\d{1,2}):(\d{2})$', time_str)
    if m:
        h, mi = int(m.group(1)), int(m.group(2))
        if 0 <= h <= 23 and 0 <= mi <= 59: return h, mi
    return None

def _is_within_support_hours(start_str: str, end_str: str) -> bool:
    start = _parse_time(start_str)
    end = _parse_time(end_str)
    if not start or not end: return False
    now = datetime.now(timezone.utc)
    now_mins = now.hour * 60 + now.minute
    start_mins = start[0] * 60 + start[1]
    end_mins = end[0] * 60 + end[1]
    if start_mins <= end_mins:
        return start_mins <= now_mins < end_mins
    else:
        return now_mins >= start_mins or now_mins < end_mins

def _real_open_count(guild, td) -> int:
    return sum(1 for ch_id in td.get("open", {}) if guild.get_channel(int(ch_id)))

async def _update_channel_topic(channel: discord.TextChannel, claimed_by: discord.Member = None):
    if not channel:
        return
    try:
        if claimed_by:
            await channel.edit(topic=f"Claimed by {claimed_by.display_name}")
        else:
            await channel.edit(topic="Unclaimed Ticket")
    except Exception:
        pass

async def _generate_transcript(channel):
    if not channel:
        return None
    cache_key = str(channel.id)
    now = datetime.now(timezone.utc).timestamp()
    if cache_key in _transcript_cache:
        cached, timestamp = _transcript_cache[cache_key]
        if now - timestamp < 300:
            return cached
    api_key = getattr(Config, "COOKIE_API_KEY", None)
    result = None
    if api_key and "YOUR_" not in api_key:
        try:
            url = f"https://api.cookie-api.com/api/transcript?channel_id={channel.id}"
            headers = {"Authorization": api_key, "Content-Type": "application/json"}
            payload = {"bot_token": Config.TOKEN}
            async with aiohttp.ClientSession() as session:
                async with session.post(url, headers=headers, json=payload, timeout=30) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        if data.get("success") and data.get("url"):
                            result = {"url": data.get("url"), "type": "cookie"}
        except Exception as e:
            print(f"[Tickets] Cookie API error: {e}")
    if not result:
        lines = []
        count = 0
        try:
            async for msg in channel.history(limit=500, oldest_first=True):
                count += 1
                ts = msg.created_at.strftime("%Y-%m-%d %H:%M:%S")
                text = msg.content or ""
                for a in msg.attachments: text += f" [Attachment: {a.url}]"
                lines.append(f"[{ts}] {msg.author.display_name}: {text}")
            if count >= 500:
                lines.append(f"\n... and possibly more messages (limited to 500 for performance)")
            file = discord.File(io.BytesIO("\n".join(lines).encode()), filename=f"transcript-{channel.name}.txt")
            result = {"file": file, "type": "file"}
        except Exception as e:
            print(f"[Tickets] Failed to generate transcript: {e}")
            return None
    _transcript_cache[cache_key] = (result, now)
    return result

async def _send_transcript_to_opener(opener: discord.Member, transcript: dict, cat: str, number: int, closer: discord.Member = None, reason: str = None):
    if not opener:
        return

    try:
        if not opener.guild:
            print(f"[Tickets] Opener has no guild")
            return

        td = _ticket_data(opener.guild.id)
        info = None
        for ch_id, ticket_info in td.get("open", {}).items():
            if ticket_info.get("opener") == opener.id:
                info = ticket_info
                break

        participants = info.get("participants", {}) if info else {}
        sorted_participants = sorted(participants.items(), key=lambda x: x[1], reverse=True)
        participant_lines = []
        for uid, count in sorted_participants:
            member = opener.guild.get_member(int(uid))
            name = member.mention if member else f"Unknown ({uid})"
            participant_lines.append(f"{name} • {count} messages")

        total_messages = sum(participants.values()) if participants else 0
        claimed_by = info.get("claimed_by") if info else None
        claimed_by_str = f"<@{claimed_by}>" if claimed_by else "Not claimed"
        close_reason = reason or info.get("close_reason", "No reason provided.") if info else "No reason provided."
        closed_by = closer.mention if closer else "Unknown"
        category = info.get("category_label", cat) if info else cat

        embed = build(title=f"🎫 Ticket #{number:04d} Closed", description=f"Your ticket has been closed in **{opener.guild.name}**", color=0x5865F2)

        embed.add_field(
            name="Ticket Details",
            value=(
                f"**Category:** {category}\n"
                f"**Close Reason:** {close_reason}\n"
                f"**Closed by:** {closed_by}\n"
                f"**Claimed by:** {claimed_by_str}\n"
                f"**Total Messages:** {total_messages}"
            ),
            inline=False
        )

        embed.add_field(
            name="Participants",
            value="\n".join(participant_lines) or "No participants",
            inline=False
        )

        if transcript and transcript.get("url"):
            embed.add_field(
                name="Transcript",
                value=f"[Click here to view transcript]({transcript['url']})",
                inline=False
            )
        elif transcript and transcript.get("file"):
            embed.add_field(
                name="Transcript",
                value="Transcript file is attached below.",
                inline=False
            )

        embed.set_footer(text=f"Ticket #{number:04d}")

        view = RatingView(opener.guild.id, None, opener.id, number, category)
        file = transcript.get("file") if transcript and transcript.get("file") else None

        if file:
            await opener.send(embed=embed, file=file, view=view)
        else:
            await opener.send(embed=embed, view=view)

        print(f"[Tickets] Sent transcript with rating to {opener.name} for ticket #{number}")

    except discord.Forbidden:
        print(f"[Tickets] Could not DM transcript to {opener.name} (DMs closed)")
    except Exception as e:
        print(f"[Tickets] Failed to send transcript DM: {e}")

async def _send_transcript_to_logs(log_ch: discord.TextChannel, transcript: dict, opener: discord.Member, cat: str, number: int, closer: discord.Member, reason: str = None):
    if not log_ch or not transcript:
        return
    try:
        e = build(title=f"Ticket #{number:04d} Closed", color=Config.COLOR_ERR)
        e.add_field(name="Opener", value=opener.mention if opener else "Unknown", inline=True)
        e.add_field(name="Category", value=cat, inline=True)
        e.add_field(name="Closed by", value=closer.mention, inline=True)
        if reason:
            e.add_field(name="Reason", value=reason, inline=False)

        if transcript.get("url"):
            e.add_field(name="Transcript", value=f"[📄 View Transcript]({transcript['url']})", inline=False)
            await log_ch.send(embed=e)
        elif transcript.get("file"):
            await log_ch.send(embed=e, file=transcript["file"])
    except Exception as e:
        print(f"[Tickets] Failed to send transcript to logs: {e}")

async def _do_close(guild, channel, closer, reason: str = None):
    if not channel or not guild:
        print("[Tickets] _do_close called with None guild or channel")
        return

    try:
        guild_id = guild.id
    except AttributeError:
        print("[Tickets] Invalid guild object in _do_close")
        return

    td = _ticket_data(guild_id)
    info = td.get("open", {}).get(str(channel.id))
    if not info:
        print(f"[Tickets] No ticket info found for channel {channel.id}")
        return

    try:
        settings = load("guild_settings.json").get(str(guild_id), {})
        log_ch_id = settings.get("ticket_log_channel")
        log_ch = guild.get_channel(log_ch_id) if log_ch_id else None

        opener = guild.get_member(info["opener"])
        cat = info.get("category_label", "Unknown")
        number = info.get("number", "?")

        if opener:
            try:
                await channel.set_permissions(
                    opener,
                    send_messages=False,
                    reason="Ticket closing in 5 seconds"
                )
                print(f"[Tickets] Locked channel for {opener.name}")
            except Exception as e:
                print(f"[Tickets] Failed to lock channel for opener: {e}")

        countdown_embed = build(title="⏳ Closing Ticket...", description="This ticket will be closed in **5** seconds...", color=Config.COLOR_WARN)
        countdown_embed.set_footer(text=f"Ticket #{number:04d}")
        countdown_msg = await channel.send(embed=countdown_embed)

        for i in range(4, 0, -1):
            await asyncio.sleep(1)
            countdown_embed.description = f"This ticket will be closed in **{i}** second{'s' if i != 1 else ''}..."
            await countdown_msg.edit(embed=countdown_embed)

        await asyncio.sleep(1)

        final_embed = build(title="🔒 Ticket Closed", description=f"This ticket has been closed by {closer.mention if closer else 'staff'}.", color=Config.COLOR_ERR)
        if reason:
            final_embed.add_field(name="Reason", value=reason, inline=False)
        final_embed.set_footer(text=f"Ticket #{number:04d}")
        await channel.send(embed=final_embed)

        transcript = await _generate_transcript(channel)

        if log_ch and transcript:
            await _send_transcript_to_logs(log_ch, transcript, opener, cat, number, closer, reason)

        if opener and transcript:
            await _send_transcript_to_opener(opener, transcript, cat, number, closer, reason)

        td["open"].pop(str(channel.id), None)
        _save_ticket(guild_id, td)

        try:
            await asyncio.sleep(1)
            if channel:
                try:
                    await channel.delete(reason=f"Ticket closed by {closer}")
                    print(f"[Tickets] Deleted channel {channel.name} ({channel.id})")
                except discord.NotFound:
                    print(f"[Tickets] Channel {channel.id} was already deleted - skipping")
                except discord.Forbidden:
                    print(f"[Tickets] Missing permissions to delete channel {channel.id}")
                except Exception as e:
                    print(f"[Tickets] Failed to delete channel {channel.id}: {e}")
        except Exception as e:
            print(f"[Tickets] Unexpected error while deleting channel: {e}")

    except Exception as e:
        print(f"[Tickets] Error in _do_close: {e}")
        import traceback
        traceback.print_exc()

async def _create_ticket_channel(guild, author, category_key, category_label, answers: dict = None):
    td, settings = _ticket_data(guild.id), load("guild_settings.json").get(str(guild.id), {})
    for ch_id, info in td.get("open", {}).items():
        if info.get("opener") == author.id and guild.get_channel(int(ch_id)):
            return None, guild.get_channel(int(ch_id))

    cat_name = settings.get("ticket_category", "Tickets")
    category = discord.utils.get(guild.categories, name=cat_name) or await guild.create_category(cat_name)
    td["counter"] = td.get("counter", 0) + 1
    number, slug = td["counter"], category_key[:6]
    overwrites = {
        guild.default_role: discord.PermissionOverwrite(read_messages=False),
        author: discord.PermissionOverwrite(read_messages=True, send_messages=True, attach_files=True),
        guild.me: discord.PermissionOverwrite(read_messages=True, send_messages=True, manage_channels=True),
    }
    type_roles = settings.get("ticket_type_roles", {}).get(category_key, [])
    global_roles = settings.get("ticket_staff_roles", [])
    all_roles = type_roles + global_roles
    for role_id in all_roles:
        if role := guild.get_role(int(role_id)):
            overwrites[role] = discord.PermissionOverwrite(read_messages=True, send_messages=True, manage_messages=True)
    channel = await category.create_text_channel(f"{slug}-{number:04d}", overwrites=overwrites)
    td.setdefault("open", {})[str(channel.id)] = {
        "opener": author.id,
        "number": number,
        "category": category_key,
        "category_label": category_label,
        "opened_at": datetime.now(timezone.utc).isoformat(),
        "claimed_by": None,
        "autoclose_at": None,
        "answers": answers or {},
        "rating": None,
        "participants": {str(author.id): 1},
        "close_reason": None,
        "closed_by": None,
        "transcript_url": None,
    }
    _save_ticket(guild.id, td)
    return number, channel

async def _send_ticket_embed(channel, opener, number, category_label, custom_embed_text: str = None, answers: dict = None):
    if not channel:
        return
    td = _ticket_data(channel.guild.id)

    description = custom_embed_text or f"Welcome {opener.mention}! Staff will assist you shortly.\n**{_real_open_count(channel.guild, td)}** ticket(s) currently open."

    if answers:
        answer_text = "\n\n**📋 Form Answers:**\n"
        for key, value in answers.items():
            answer_text += f"• **{key}:** {value}\n"
        description += answer_text

    main_embed = build(title=f"🎫 Ticket #{number:04d} • {category_label}", description=description, color=Config.COLOR_INFO)

    custom = _get_customization(channel.guild.id)
    if custom.get("show_available_categories", False):
        categories = _get_categories(channel.guild.id)
        cat_list = ""
        for key, cat in categories.items():
            if not cat.get("enabled", True):
                continue
            q_count = len(cat.get("form_fields", [])) + len(cat.get("questions", []))
            cat_list += f"**{cat['label']}** • {cat.get('description', '')}"
            if q_count:
                cat_list += f" ({q_count} fields)"
            cat_list += "\n"
        main_embed.add_field(name="📂 Available Categories", value=cat_list or "No categories available", inline=False)

    notes_heading = custom.get("important_notes_heading", "📝 Important Notes")
    main_embed.add_field(name=notes_heading, value=custom.get("embed_footer", DEFAULT_CUSTOMIZATION["embed_footer"]), inline=False)

    footer_text = custom.get("footer_text", "Sparky Bot • Ticket System")
    main_embed.set_footer(text=footer_text)

    info = td.get("open", {}).get(str(channel.id), {})
    claimed = bool(info.get("claimed_by"))
    view = TicketControlView()
    view._update_buttons(claimed)
    await channel.send(embed=main_embed, view=view)

    settings = load("guild_settings.json").get(str(channel.guild.id), {})
    cat = td.get("open", {}).get(str(channel.id), {}).get("category", "general")
    type_roles = settings.get("ticket_type_roles", {}).get(cat, [])
    global_roles = settings.get("ticket_staff_roles", [])
    ping_ids = type_roles if type_roles else global_roles
    valid_ping_ids = [rid for rid in ping_ids if channel.guild.get_role(int(rid))]
    ping_message = f"{opener.mention} has opened a new **{category_label}** ticket!"
    if valid_ping_ids:
        ping_message = f"{' '.join(f'<@&{rid}>' for rid in valid_ping_ids)} • {opener.mention} has opened a new **{category_label}** ticket!"
    await channel.send(ping_message, allowed_mentions=discord.AllowedMentions(roles=True, users=True))
    await _send_support_timing_embed(channel)

async def _send_support_timing_embed(channel: discord.TextChannel):
    if not channel:
        return
    settings = load("guild_settings.json").get(str(channel.guild.id), {})
    start, end = settings.get("support_start"), settings.get("support_end")
    if not start or not end: return
    if _is_within_support_hours(start, end):
        e = build(title="🟢 We are currently working and will get to you soon", description="Please refrain from pinging staff multiple times.", color=Config.COLOR_OK)
    else:
        e = discord.Embed(title="🔴 Sorry, we aren't working right now", description=f"Staff support timings are from **{start}** to **{end}** (UTC).", color=Config.COLOR_ERR)
    await channel.send(embed=e)

async def _send_autoclose_embed(channel: discord.TextChannel, hours: float, reason: str = None):
    if not channel:
        return
    close_time = datetime.now(timezone.utc) + timedelta(hours=hours)

    td = _ticket_data(channel.guild.id)
    info = td.get("open", {}).get(str(channel.id), {})
    opener_id = info.get("opener") if info else None

    embed = build(title="⏰ Auto-Close Timer Set", description=f"This ticket will automatically close in **{hours}** hours.", color=Config.COLOR_WARN)
    if reason:
        embed.add_field(name="Reason", value=reason, inline=False)
    embed.add_field(
        name="📌 How to Cancel",
        value="The auto-close timer can be cancelled by the opener or staff using the button below.",
        inline=False
    )
    embed.set_footer(text=f"Auto-close scheduled for {discord.utils.format_dt(close_time, 'F')}")

    try:
        view = AutoCloseView(channel, hours, opener_id) if opener_id else None
        msg = await channel.send(embed=embed, view=view)
        try:
            await msg.pin(reason="Auto-close timer notification")
        except Exception:
            pass
    except Exception as e:
        print(f"[Tickets] Failed to send auto-close embed: {e}")

async def _send_autoclose_cancelled_embed(channel: discord.TextChannel, opener: discord.Member):
    if not channel:
        return
    embed = build(title="🔄 Auto-Close Cancelled", description=f"{opener.mention} has responded in this ticket.\n\nThe auto-close timer has been **cancelled** and the ticket will remain open.", color=Config.COLOR_OK)
    embed.set_footer(text="Auto-close cancelled")

    try:
        msg = await channel.send(embed=embed)
        try:
            await msg.pin(reason="Auto-close cancellation notification")
        except Exception:
            pass
    except Exception as e:
        print(f"[Tickets] Failed to send auto-close cancelled embed: {e}")

class CloseModal(discord.ui.Modal, title="Close Ticket"):
    reason = discord.ui.TextInput(
        label="Reason for closing (optional)",
        style=discord.TextStyle.paragraph,
        required=False,
        max_length=500,
        placeholder="Leave blank for no reason"
    )
    def __init__(self, channel, closer):
        super().__init__()
        self.channel, self.closer = channel, closer

    async def on_submit(self, interaction):
        await interaction.response.defer()
        await _do_close(interaction.guild, self.channel, self.closer, self.reason.value or None)

class CloseRequestOpenerView(discord.ui.View):
    def __init__(self, channel, opener_id):
        super().__init__(timeout=None)
        self.channel, self.opener_id = channel, opener_id
        self.closed = False

    async def interaction_check(self, interaction):
        if interaction.user.id != self.opener_id:
            await interaction.response.send_message("Only the ticket opener can respond.", ephemeral=True)
            return False
        if self.closed:
            await interaction.response.send_message("This request has already been handled.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="Yes, close it", style=discord.ButtonStyle.danger)
    async def yes(self, interaction, button):
        self.closed = True
        await interaction.response.defer()
        await _do_close(interaction.guild, self.channel, interaction.user)
        self.stop()

    @discord.ui.button(label="No, keep it open", style=discord.ButtonStyle.secondary)
    async def no(self, interaction, button):
        self.closed = True
        await interaction.response.send_message("Ticket kept open.", ephemeral=True)
        self.stop()

class TicketHistoryView(discord.ui.View):
    def __init__(self, user_id: int, tickets: list, page: int = 0):
        super().__init__(timeout=120)
        self.user_id = user_id
        self.tickets = tickets
        self.page = page
        self.items_per_page = 5
        self.total_pages = max(1, (len(tickets) + self.items_per_page - 1) // self.items_per_page)
        self._update_buttons()

    def _update_buttons(self):
        self.clear_items()
        self.add_item(self.prev_btn)
        self.add_item(self.page_counter)
        self.add_item(self.next_btn)
        self.add_item(self.close_btn)

        self.prev_btn.disabled = self.page == 0
        self.next_btn.disabled = self.page >= self.total_pages - 1

    def _get_page_items(self):
        start = self.page * self.items_per_page
        end = start + self.items_per_page
        return self.tickets[start:end]

    def _build_embed(self) -> discord.Embed:
        page_items = self._get_page_items()

        embed = build(title="📋 Your Ticket History", description=f"Page {self.page + 1}/{self.total_pages}", color=Config.COLOR_INFO, bot=self.bot)

        if not page_items:
            embed.description = "No tickets found."
            return embed

        for ticket in page_items:
            status = "🔒 Closed" if ticket.get("closed") else "🟢 Open"
            rating = f"⭐ {ticket.get('rating', 'N/A')}" if ticket.get('rating') else "No rating"
            embed.add_field(
                name=f"#{ticket.get('number', '??')} - {ticket.get('category_label', 'Unknown')}",
                value=f"Status: {status}\nRating: {rating}\nOpened: {ticket.get('opened_at', 'Unknown')[:10]}",
                inline=True
            )

        embed.set_footer(text=f"Total: {len(self.tickets)} tickets")
        return embed

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("❌ This isn't your ticket history.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="◀️", style=discord.ButtonStyle.secondary)
    async def prev_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.page > 0:
            self.page -= 1
        self._update_buttons()
        await interaction.response.edit_message(embed=self._build_embed(), view=self)

    @discord.ui.button(label=f"📄", style=discord.ButtonStyle.primary, disabled=True)
    async def page_counter(self, interaction: discord.Interaction, button: discord.ui.Button):
        pass

    @discord.ui.button(label="▶️", style=discord.ButtonStyle.secondary)
    async def next_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.page < self.total_pages - 1:
            self.page += 1
        self._update_buttons()
        await interaction.response.edit_message(embed=self._build_embed(), view=self)

    @discord.ui.button(label="✖ Close", style=discord.ButtonStyle.danger)
    async def close_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(
            embed=build(title="📋 Ticket History Closed", color=Config.COLOR_ERR, bot=self.bot),
            view=None
        )
        self.stop()

    async def on_timeout(self):
        try:
            await self.message.edit(
                embed=build(title="⏰ History Timed Out", color=Config.COLOR_ERR, bot=self.bot),
                view=None
            )
        except Exception:
            pass

class ReviewsView(discord.ui.View):
    def __init__(self, reviews: list, page: int = 0):
        super().__init__(timeout=120)
        self.reviews = reviews
        self.page = page
        self.items_per_page = 5
        self.total_pages = max(1, (len(reviews) + self.items_per_page - 1) // self.items_per_page)
        self._update_buttons()

    def _update_buttons(self):
        self.clear_items()
        self.add_item(self.prev_btn)
        self.add_item(self.page_counter)
        self.add_item(self.next_btn)
        self.add_item(self.close_btn)

        self.prev_btn.disabled = self.page == 0
        self.next_btn.disabled = self.page >= self.total_pages - 1

    def _get_page_items(self):
        start = self.page * self.items_per_page
        end = start + self.items_per_page
        return self.reviews[start:end]

    def _build_embed(self) -> discord.Embed:
        page_items = self._get_page_items()

        total_reviews = len(self.reviews)
        avg_rating = sum(r.get('rating', 0) for r in self.reviews) / total_reviews if total_reviews > 0 else 0

        embed = build(title="⭐ Ticket Reviews", description=f"Page {self.page + 1}/{self.total_pages}\nAverage Rating: {avg_rating:.1f} ⭐ ({total_reviews} reviews)", color=Config.COLOR_INFO, bot=self.bot)

        if not page_items:
            embed.description = "No reviews found."
            return embed

        for review in page_items:
            stars = "⭐" * review.get('rating', 0)
            review_text = review.get('review', 'No review provided')
            embed.add_field(
                name=f"#{review.get('ticket_number', '??')} - {review.get('category', 'Unknown')}",
                value=f"{stars} {review.get('rating', 0)}/5\n👤 <@{review.get('user_id')}>\n👨‍💼 Staff: <@{review.get('staff_id')}>" if review.get('staff_id') else f"{stars} {review.get('rating', 0)}/5\n👤 <@{review.get('user_id')}>\n📅 {review.get('timestamp', '')[:10]}\n📝 {review_text[:100]}{'...' if len(review_text) > 100 else ''}",
                inline=False
            )

        embed.set_footer(text=f"Total: {total_reviews} reviews • Average: {avg_rating:.1f}⭐")
        return embed

    @discord.ui.button(label="◀️", style=discord.ButtonStyle.secondary)
    async def prev_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.page > 0:
            self.page -= 1
        self._update_buttons()
        await interaction.response.edit_message(embed=self._build_embed(), view=self)

    @discord.ui.button(label=f"📄", style=discord.ButtonStyle.primary, disabled=True)
    async def page_counter(self, interaction: discord.Interaction, button: discord.ui.Button):
        pass

    @discord.ui.button(label="▶️", style=discord.ButtonStyle.secondary)
    async def next_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.page < self.total_pages - 1:
            self.page += 1
        self._update_buttons()
        await interaction.response.edit_message(embed=self._build_embed(), view=self)

    @discord.ui.button(label="✖ Close", style=discord.ButtonStyle.danger)
    async def close_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(
            embed=build(title="📋 Reviews Closed", color=Config.COLOR_ERR, bot=self.bot),
            view=None
        )
        self.stop()

    async def on_timeout(self):
        try:
            await self.message.edit(
                embed=build(title="⏰ Reviews Timed Out", color=Config.COLOR_ERR, bot=self.bot),
                view=None
            )
        except Exception:
            pass

class CustomizationView(discord.ui.View):
    def __init__(self, guild_id: int):
        super().__init__(timeout=120)
        self.guild_id = guild_id

    @discord.ui.button(label="📝 Title", style=discord.ButtonStyle.secondary, row=0)
    async def set_title(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(SetEmbedTitleModal(self.guild_id))

    @discord.ui.button(label="📄 Description", style=discord.ButtonStyle.secondary, row=0)
    async def set_description(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(SetEmbedDescriptionModal(self.guild_id))

    @discord.ui.button(label="📌 Footer Notes", style=discord.ButtonStyle.secondary, row=0)
    async def set_footer_notes(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(SetEmbedFooterModal(self.guild_id))

    @discord.ui.button(label="🔽 Footer Text", style=discord.ButtonStyle.secondary, row=0)
    async def set_footer_text(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(SetFooterTextModal(self.guild_id))

    @discord.ui.button(label="🎨 Color", style=discord.ButtonStyle.secondary, row=1)
    async def set_color(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(SetColorModal(self.guild_id))

    @discord.ui.button(label="📂 Toggle Categories", style=discord.ButtonStyle.secondary, emoji="📂", row=1)
    async def toggle_categories(self, interaction: discord.Interaction, button: discord.ui.Button):
        custom = _get_customization(self.guild_id)
        custom["show_available_categories"] = not custom.get("show_available_categories", False)
        _save_customization(self.guild_id, custom)
        status = "shown" if custom["show_available_categories"] else "hidden"
        await interaction.response.send_message(f"✅ Available categories section is now **{status}**.", ephemeral=True)

    @discord.ui.button(label="✏️ Notes Heading", style=discord.ButtonStyle.secondary, emoji="✏️", row=1)
    async def set_notes_heading(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(SetImportantNotesHeadingModal(self.guild_id))

    @discord.ui.button(label="🔧 Settings", style=discord.ButtonStyle.primary, row=2)
    async def settings(self, interaction: discord.Interaction, button: discord.ui.Button):
        custom = _get_customization(self.guild_id)
        embed = build(title="⚙️ Ticket System Settings", color=Config.COLOR_INFO, bot=self.bot)
        embed.add_field(
            name="📊 Ratings",
            value="✅ Enabled" if custom.get("enable_ratings", True) else "❌ Disabled",
            inline=True
        )
        embed.add_field(
            name="📋 History",
            value="✅ Enabled" if custom.get("enable_history", True) else "❌ Disabled",
            inline=True
        )
        embed.add_field(
            name="⏰ Auto-Close",
            value="✅ Enabled" if custom.get("enable_auto_close", True) else "❌ Disabled",
            inline=True
        )
        embed.add_field(
            name="⏱️ Default Auto-Close Hours",
            value=f"{custom.get('default_auto_close_hours', 24)} hours",
            inline=True
        )
        embed.add_field(
            name="📌 Reviews Channel",
            value=f"<#{custom.get('reviews_channel')}>" if custom.get('reviews_channel') else "❌ Not set",
            inline=True
        )
        embed.add_field(
            name="📂 Show Available Categories",
            value="✅ Yes" if custom.get("show_available_categories", False) else "❌ No",
            inline=True
        )
        embed.add_field(
            name="✏️ Notes Heading",
            value=custom.get("important_notes_heading", "📝 Important Notes"),
            inline=True
        )
        view = SettingsView(self.guild_id)
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

class SettingsView(discord.ui.View):
    def __init__(self, guild_id: int):
        super().__init__(timeout=120)
        self.guild_id = guild_id

    @discord.ui.button(label="🔘 Toggle Ratings", style=discord.ButtonStyle.primary, row=0)
    async def toggle_ratings(self, interaction: discord.Interaction, button: discord.ui.Button):
        custom = _get_customization(self.guild_id)
        custom["enable_ratings"] = not custom.get("enable_ratings", True)
        _save_customization(self.guild_id, custom)
        await interaction.response.send_message(
            f"✅ Ratings {'enabled' if custom['enable_ratings'] else 'disabled'}.",
            ephemeral=True
        )

    @discord.ui.button(label="🔘 Toggle History", style=discord.ButtonStyle.primary, row=0)
    async def toggle_history(self, interaction: discord.Interaction, button: discord.ui.Button):
        custom = _get_customization(self.guild_id)
        custom["enable_history"] = not custom.get("enable_history", True)
        _save_customization(self.guild_id, custom)
        await interaction.response.send_message(
            f"✅ History {'enabled' if custom['enable_history'] else 'disabled'}.",
            ephemeral=True
        )

    @discord.ui.button(label="🔘 Toggle Auto-Close", style=discord.ButtonStyle.primary, row=0)
    async def toggle_autoclose(self, interaction: discord.Interaction, button: discord.ui.Button):
        custom = _get_customization(self.guild_id)
        custom["enable_auto_close"] = not custom.get("enable_auto_close", True)
        _save_customization(self.guild_id, custom)
        await interaction.response.send_message(
            f"✅ Auto-close {'enabled' if custom['enable_auto_close'] else 'disabled'}.",
            ephemeral=True
        )

    @discord.ui.button(label="📌 Set Reviews Channel", style=discord.ButtonStyle.primary, row=1)
    async def set_reviews_channel(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(
            "Please type the channel ID or mention the channel for reviews.",
            ephemeral=True
        )

        def check(m):
            return m.author.id == interaction.user.id and m.channel.id == interaction.channel.id

        try:
            msg = await interaction.client.wait_for("message", timeout=60, check=check)
            channel_id = re.search(r'\d+', msg.content)
            if not channel_id:
                return await interaction.followup.send("❌ Invalid channel ID.", ephemeral=True)

            channel = interaction.guild.get_channel(int(channel_id.group()))
            if not channel:
                return await interaction.followup.send("❌ Channel not found.", ephemeral=True)

            custom = _get_customization(self.guild_id)
            custom["reviews_channel"] = channel.id
            _save_customization(self.guild_id, custom)

            await interaction.followup.send(f"✅ Reviews channel set to {channel.mention}.", ephemeral=True)
        except TimeoutError:
            await interaction.followup.send("⏰ Timed out. No channel set.", ephemeral=True)

    @discord.ui.button(label="📂 Toggle Categories", style=discord.ButtonStyle.secondary, emoji="📂", row=1)
    async def toggle_categories_settings(self, interaction: discord.Interaction, button: discord.ui.Button):
        custom = _get_customization(self.guild_id)
        custom["show_available_categories"] = not custom.get("show_available_categories", False)
        _save_customization(self.guild_id, custom)
        status = "shown" if custom["show_available_categories"] else "hidden"
        await interaction.response.send_message(f"✅ Available categories section is now **{status}**.", ephemeral=True)

class SetImportantNotesHeadingModal(discord.ui.Modal, title="Set Important Notes Heading"):
    def __init__(self, guild_id: int):
        super().__init__()
        self.guild_id = guild_id
        custom = _get_customization(guild_id)
        default_value = custom.get("important_notes_heading", "📝 Important Notes")
        self.add_item(
            discord.ui.TextInput(
                label="Heading for Important Notes",
                placeholder="📝 Important Notes",
                max_length=50,
                required=True,
                default=default_value
            )
        )

    async def on_submit(self, interaction: discord.Interaction):
        heading = self.children[0].value.strip()
        custom = _get_customization(self.guild_id)
        custom["important_notes_heading"] = heading
        _save_customization(self.guild_id, custom)
        embed = build(title="✅ Notes Heading Updated", description=f"New heading: **{heading}**", color=Config.COLOR_OK, bot=self.bot)
        await interaction.response.send_message(embed=embed, ephemeral=True)

class SetEmbedTitleModal(discord.ui.Modal, title="Set Ticket Panel Title"):
    def __init__(self, guild_id: int):
        super().__init__()
        self.guild_id = guild_id
        custom = _get_customization(guild_id)
        default_value = custom.get("embed_title", "🎫 Support Tickets")
        self.add_item(
            discord.ui.TextInput(
                label="Embed Title",
                placeholder="🎫 Support Tickets",
                max_length=256,
                required=True,
                default=default_value
            )
        )

    async def on_submit(self, interaction: discord.Interaction):
        title_input = self.children[0]
        custom = _get_customization(self.guild_id)
        custom["embed_title"] = title_input.value
        _save_customization(self.guild_id, custom)
        embed = build(title="✅ Title Updated", description=f"New title: **{title_input.value}**", color=Config.COLOR_OK, bot=self.bot)
        await interaction.response.send_message(embed=embed, ephemeral=True)

class SetEmbedDescriptionModal(discord.ui.Modal, title="Set Panel Description"):
    def __init__(self, guild_id: int):
        super().__init__()
        self.guild_id = guild_id
        custom = _get_customization(guild_id)
        default_value = custom.get("embed_description", "Welcome to the **Support System**! Please select a category below to create a ticket.")
        self.add_item(
            discord.ui.TextInput(
                label="Embed Description",
                style=discord.TextStyle.paragraph,
                placeholder="Welcome to the **Support System**!...",
                max_length=2000,
                required=True,
                default=default_value
            )
        )

    async def on_submit(self, interaction: discord.Interaction):
        desc_input = self.children[0]
        custom = _get_customization(self.guild_id)
        custom["embed_description"] = desc_input.value
        _save_customization(self.guild_id, custom)
        embed = build(title="✅ Description Updated", description="The panel description has been updated.", color=Config.COLOR_OK, bot=self.bot)
        await interaction.response.send_message(embed=embed, ephemeral=True)

class SetEmbedFooterModal(discord.ui.Modal, title="Set Panel Footer Notes"):
    def __init__(self, guild_id: int):
        super().__init__()
        self.guild_id = guild_id
        custom = _get_customization(guild_id)
        default_value = custom.get("embed_footer", DEFAULT_CUSTOMIZATION["embed_footer"])
        self.add_item(
            discord.ui.TextInput(
                label="Footer Notes",
                style=discord.TextStyle.paragraph,
                placeholder="📝 Important Notes\n• Do not ping staff excessively\n• Be patient...",
                max_length=2000,
                required=True,
                default=default_value
            )
        )

    async def on_submit(self, interaction: discord.Interaction):
        footer_input = self.children[0]
        custom = _get_customization(self.guild_id)
        custom["embed_footer"] = footer_input.value
        _save_customization(self.guild_id, custom)
        embed = build(title="✅ Footer Notes Updated", description="The panel footer notes have been updated.", color=Config.COLOR_OK, bot=self.bot)
        await interaction.response.send_message(embed=embed, ephemeral=True)

class SetFooterTextModal(discord.ui.Modal, title="Set Embed Footer Text"):
    def __init__(self, guild_id: int):
        super().__init__()
        self.guild_id = guild_id
        custom = _get_customization(guild_id)
        default_value = custom.get("footer_text", "Sparky Bot • Ticket System")
        self.add_item(
            discord.ui.TextInput(
                label="Footer Text",
                placeholder="Sparky Bot • Ticket System",
                max_length=100,
                required=False,
                default=default_value
            )
        )

    async def on_submit(self, interaction: discord.Interaction):
        footer_text_input = self.children[0]
        custom = _get_customization(self.guild_id)
        custom["footer_text"] = footer_text_input.value or None
        _save_customization(self.guild_id, custom)
        embed = build(title="✅ Footer Text Updated", color=Config.COLOR_OK, bot=self.bot)
        await interaction.response.send_message(embed=embed, ephemeral=True)

class SetColorModal(discord.ui.Modal, title="Set Embed Color"):
    def __init__(self, guild_id: int):
        super().__init__()
        self.guild_id = guild_id
        custom = _get_customization(guild_id)
        current_color = custom.get("embed_color", Config.COLOR_INFO)
        if isinstance(current_color, int):
            default_value = f"#{hex(current_color)[2:].zfill(6)}"
        else:
            default_value = "#5865F2"
        self.add_item(
            discord.ui.TextInput(
                label="Color (Hex Code)",
                placeholder="#5865F2 or 5865F2",
                max_length=7,
                required=True,
                default=default_value
            )
        )

    async def on_submit(self, interaction: discord.Interaction):
        color_input = self.children[0]
        color_str = color_input.value.strip()
        if not color_str.startswith("#"):
            color_str = f"#{color_str}"
        try:
            color_int = int(color_str[1:], 16)
            if color_int < 0 or color_int > 0xFFFFFF:
                raise ValueError
            custom = _get_customization(self.guild_id)
            custom["embed_color"] = color_int
            _save_customization(self.guild_id, custom)
            embed = build(title="✅ Color Updated", description=f"New color: {color_str}", color=color_int, bot=self.bot)
            await interaction.response.send_message(embed=embed, ephemeral=True)
        except ValueError:
            await interaction.response.send_message(
                "❌ Invalid color format. Use hex like `#5865F2` or `#5865F2`.",
                ephemeral=True
            )

# ========== MAIN COG ==========
class Tickets(commands.Cog):

    def __init__(self, bot):
        self.bot = bot
        categories = {}
        bot.add_view(TicketPanelView(categories))
        bot.add_view(TicketControlView())
        self.autoclose_loop.start()

    def cog_unload(self):
        self.autoclose_loop.cancel()

    @tasks.loop(minutes=10)
    async def autoclose_loop(self):
        now = datetime.now(timezone.utc)
        data = load(TICKETS_FILE)
        for guild_id_str, td in data.items():
            guild = self.bot.get_guild(int(guild_id_str))
            if not guild:
                continue
            for ch_id_str, info in list(td.get("open", {}).items()):
                autoclose_at_str = info.get("autoclose_at")
                if autoclose_at_str:
                    autoclose_at = datetime.fromisoformat(autoclose_at_str)
                    if now >= autoclose_at:
                        channel = guild.get_channel(int(ch_id_str))
                        if channel:
                            reason = info.get("autoclose_reason", "Autoclosed due to timeout.")
                            await _do_close(guild, channel, guild.me, reason)
                        else:
                            td["open"].pop(ch_id_str, None)
                            _save_ticket(guild.id, td)
                        await asyncio.sleep(1)

    @autoclose_loop.before_loop
    async def before_autoclose_loop(self):
        await self.bot.wait_until_ready()

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild:
            return

        td = _ticket_data(message.guild.id)
        info = td.get("open", {}).get(str(message.channel.id))
        if not info:
            return

        participants = info.setdefault("participants", {})
        uid = str(message.author.id)
        participants[uid] = participants.get(uid, 0) + 1
        _save_ticket(message.guild.id, td)

        if message.author.id == info.get("opener") and info.get("autoclose_at"):
            info.pop("autoclose_at", None)
            info.pop("autoclose_reason", None)
            td["open"][str(message.channel.id)] = info
            _save_ticket(message.guild.id, td)
            await _send_autoclose_cancelled_embed(message.channel, message.author)

    # ===================== SLASH COMMANDS =====================
    ticket = app_commands.Group(name="tkt", description="Ticket system commands")
    fields = app_commands.Group(name="fields", description="Form field management", parent=ticket)
    customize = app_commands.Group(name="customize", description="Ticket customization commands", parent=ticket)
    staff = app_commands.Group(name="staff", description="Staff management commands", parent=ticket)
    manage = app_commands.Group(name="manage", description="Ticket management commands", parent=ticket)

    # ---------- Existing prefix commands (flat) ----------
    @commands.command(name="tkt")
    @commands.has_permissions(administrator=True)
    async def prefix_ticketsetup(self, ctx, channel: discord.TextChannel = None):
        ch = channel or ctx.channel
        categories = _get_categories(ctx.guild.id)
        custom = _get_customization(ctx.guild.id)

        embed = build(title=custom.get("embed_title", DEFAULT_CUSTOMIZATION["embed_title"]), description=custom.get("embed_description", DEFAULT_CUSTOMIZATION["embed_description"]), color=custom.get("embed_color", Config.COLOR_INFO), bot=self.bot)

        if custom.get("show_available_categories", False):
            cat_list = ""
            for key, cat in categories.items():
                if not cat.get("enabled", True):
                    continue
                q_count = len(cat.get("form_fields", [])) + len(cat.get("questions", []))
                cat_list += f"**{cat['label']}** • {cat.get('description', '')}"
                if q_count:
                    cat_list += f" ({q_count} fields)"
                cat_list += "\n"
            embed.add_field(name="📂 Available Categories", value=cat_list or "No categories available", inline=False)

        notes_heading = custom.get("important_notes_heading", "📝 Important Notes")
        embed.add_field(name=notes_heading, value=custom.get("embed_footer", DEFAULT_CUSTOMIZATION["embed_footer"]), inline=False)

        footer_text = custom.get("footer_text", "Sparky Bot • Ticket System")
        embed.set_footer(text=footer_text)

        view = CustomTicketPanelView(categories, ctx.guild.id)
        self.bot.add_view(view)
        await ch.send(embed=embed, view=view)
        await ctx.reply(f"✅ Custom ticket panel sent to {ch.mention}.")

    @commands.command(name="tktstaff")
    @commands.has_permissions(administrator=True)
    async def prefix_ticketstaffrole(self, ctx, role: discord.Role):
        data = load("guild_settings.json")
        gd = data.setdefault(str(ctx.guild.id), {})
        roles = gd.setdefault("ticket_staff_roles", [])
        if role.id in roles:
            roles.remove(role.id)
            msg = f"✅ Removed {role.mention} from ticket staff."
        else:
            roles.append(role.id)
            msg = f"✅ Added {role.mention} as ticket staff."
        save("guild_settings.json", data)
        await ctx.reply(msg)

    @commands.command(name="tktlog")
    @commands.has_permissions(administrator=True)
    async def prefix_ticketlogchannel(self, ctx, channel: discord.TextChannel):
        if not isinstance(channel, discord.TextChannel):
            return await ctx.reply("❌ Please select a **text channel**.")

        test_embed = build(title="✅ Ticket Log Channel Set", description="Test message", color=Config.COLOR_OK, bot=self.bot)
        try:
            await channel.send(embed=test_embed)
        except discord.Forbidden:
            return await ctx.reply(f"⚠️ I couldn't send a test message to {channel.mention}. Check permissions.")
        except Exception as e:
            return await ctx.reply(f"⚠️ Failed to send test: {str(e)[:100]}")

        data = load("guild_settings.json")
        data.setdefault(str(ctx.guild.id), {})["ticket_log_channel"] = channel.id
        save("guild_settings.json", data)
        await ctx.reply(f"✅ Ticket logs → {channel.mention}.")

    @commands.command(name="tktcat")
    @commands.has_permissions(administrator=True)
    async def prefix_ticketsetcategory(self, ctx, category_name: str):
        data = load("guild_settings.json")
        data.setdefault(str(ctx.guild.id), {})["ticket_category"] = category_name
        save("guild_settings.json", data)
        await ctx.reply(f"✅ Ticket category set to **{category_name}**.")

    @commands.command(name="tkttime")
    @commands.has_permissions(administrator=True)
    async def prefix_ticketsupporttimes(self, ctx, start: str, end: str):
        if not _parse_time(start) or not _parse_time(end):
            return await ctx.reply("❌ Invalid time format. Use HH:MM or H:MM AM/PM.")
        data = load("guild_settings.json")
        gd = data.setdefault(str(ctx.guild.id), {})
        gd["support_start"] = start
        gd["support_end"] = end
        save("guild_settings.json", data)
        await ctx.reply(f"✅ Support times set to **{start}** → **{end}** (UTC).")

    @commands.command(name="tktrmtime")
    @commands.has_permissions(administrator=True)
    async def prefix_ticketremovesupporttimes(self, ctx):
        data = load("guild_settings.json")
        gd = data.get(str(ctx.guild.id), {})
        gd.pop("support_start", None)
        gd.pop("support_end", None)
        save("guild_settings.json", data)
        await ctx.reply("✅ Support timings removed.")

    @commands.command(name="tkttype")
    @commands.has_permissions(administrator=True)
    async def prefix_tickettyperole(self, ctx, ticket_type: str, role: discord.Role):
        categories = _get_categories(ctx.guild.id)
        if ticket_type not in categories:
            return await ctx.reply(f"❌ Ticket type `{ticket_type}` not found.")
        data = load("guild_settings.json")
        gd = data.setdefault(str(ctx.guild.id), {})
        type_roles = gd.setdefault("ticket_type_roles", {})
        roles = type_roles.setdefault(ticket_type, [])
        if role.id in roles:
            roles.remove(role.id)
            msg = f"✅ Removed {role.mention} from **{categories[ticket_type]['label']}** staff."
        else:
            roles.append(role.id)
            msg = f"✅ Added {role.mention} to **{categories[ticket_type]['label']}** staff."
        save("guild_settings.json", data)
        await ctx.reply(msg)

    @commands.command(name="tktinfo")
    @commands.has_permissions(manage_channels=True)
    async def prefix_tickettypeinfo(self, ctx):
        settings = load("guild_settings.json").get(str(ctx.guild.id), {})
        type_roles = settings.get("ticket_type_roles", {})
        global_roles = settings.get("ticket_staff_roles", [])
        guild = ctx.guild
        valid_global = [r for r in global_roles if guild.get_role(int(r))]
        global_mentions = " ".join(f"<@&{r}>" for r in valid_global) or "None"
        e = build(title="📋 Ticket Staff Role Configuration", color=Config.COLOR_INFO, bot=self.bot)
        e.add_field(name="🌍 Global Staff", value=global_mentions, inline=False)
        categories = _get_categories(ctx.guild.id)
        has_type_roles = False
        for key, info in categories.items():
            roles = type_roles.get(key, [])
            valid = [r for r in roles if guild.get_role(int(r))]
            if valid:
                has_type_roles = True
                mentions = " ".join(f"<@&{r}>" for r in valid)
                e.add_field(name=info["label"], value=mentions, inline=True)
        if not has_type_roles:
            e.add_field(name="ℹ️ Type-Specific Roles", value="No type-specific roles configured.", inline=False)
        e.set_footer(text="Global staff can access all tickets.")
        await ctx.reply(embed=e)

    @commands.command(name="tktcats")
    @commands.has_permissions(manage_channels=True)
    async def prefix_ticketlistcategories(self, ctx):
        categories = _get_categories(ctx.guild.id)
        settings = load("guild_settings.json").get(str(ctx.guild.id), {})
        custom_keys = settings.get("ticket_categories", {}).keys()
        e = build(title="📋 Ticket Categories", color=Config.COLOR_INFO, bot=self.bot)
        for key, cat in categories.items():
            is_custom = "✅" if key in custom_keys else "❌"
            q_count = len(cat.get("form_fields", [])) + len(cat.get("questions", []))
            status = "🔴 Disabled" if not cat.get("enabled", True) else "🟢 Enabled"
            e.add_field(
                name=f"{cat['label']} {is_custom}",
                value=f"Key: `{key}`\n{cat.get('description', 'No description')}\nFields: {q_count}\nStatus: {status}",
                inline=False
            )
        e.set_footer(text="✅ = Custom | ❌ = Default")
        await ctx.reply(embed=e)

    @commands.command(name="tktaddcat")
    @commands.has_permissions(administrator=True)
    async def prefix_ticketaddcategory(self, ctx):
        await ctx.reply("Please use the slash command: `/tkt manage add`")

    @commands.command(name="tktrmcat")
    @commands.has_permissions(administrator=True)
    async def prefix_ticketremovecategory(self, ctx):
        categories = _get_categories(ctx.guild.id)
        if not categories:
            return await ctx.reply("ℹ️ No categories to remove.")
        view = RemoveCategoryView(ctx.guild.id, categories)
        await ctx.reply("Select a category to remove:", view=view)

    @commands.command(name="tktrstcat")
    @commands.has_permissions(administrator=True)
    async def prefix_ticketresetcategories(self, ctx):
        view = ResetCategoriesView(ctx.guild.id)
        await ctx.reply("⚠️ **Reset all categories to defaults?**", view=view)

    @commands.command(name="tktembed")
    @commands.has_permissions(administrator=True)
    async def prefix_ticketembedtext(self, ctx):
        view = SetEmbedTextView(ctx.guild.id)
        await ctx.reply("Click below to set custom embed text for new tickets.", view=view)

    @commands.command(name="tkthistory")
    async def prefix_history(self, ctx):
        custom = _get_customization(ctx.guild.id)
        if not custom.get("enable_history", True):
            return await ctx.reply("❌ Ticket history is disabled.")
        td = _ticket_data(ctx.guild.id)
        tickets = []
        for ch_id, info in td.get("open", {}).items():
            if info.get("opener") == ctx.author.id:
                info["closed"] = False
                tickets.append(info)
        if not tickets:
            return await ctx.reply("📋 You have no open tickets.")
        view = TicketHistoryView(ctx.author.id, tickets)
        embed = view._build_embed()
        await ctx.reply(embed=embed, view=view)
        view.message = await ctx.original_response()

    @commands.command(name="tktreviews")
    @commands.has_permissions(manage_channels=True)
    async def prefix_reviews(self, ctx):
        reviews_data = _review_data(ctx.guild.id)
        reviews = reviews_data.get("reviews", [])
        if not reviews:
            return await ctx.reply("📋 No reviews yet.")
        view = ReviewsView(reviews)
        embed = view._build_embed()
        await ctx.reply(embed=embed, view=view)
        view.message = await ctx.original_response()

    # ---------- New flat prefix commands for all slash actions ----------
    @commands.command(name="tktclose")
    @commands.has_permissions(manage_channels=True)
    async def prefix_ticket_close(self, ctx, *, reason: str = None):
        td = _ticket_data(ctx.guild.id)
        channel_id = str(ctx.channel.id)
        if channel_id not in td.get("open", {}):
            return await ctx.reply("❌ Not a ticket channel.")
        if not _is_staff(ctx, ctx.channel.id):
            return await ctx.reply("❌ Only staff can close tickets.")
        if not _can_act(ctx.author.id, ctx.channel.id, "close", 3.0):
            return await ctx.reply("⏳ Please wait a moment.")
        await _do_close(ctx.guild, ctx.channel, ctx.author, reason)
        await ctx.reply("✅ Ticket closed.")

    @commands.command(name="tktclosereq")
    @commands.has_permissions(manage_channels=True)
    async def prefix_ticket_closereq(self, ctx):
        td = _ticket_data(ctx.guild.id)
        if str(ctx.channel.id) not in td.get("open", {}):
            return await ctx.reply("❌ Not a ticket channel.")
        info = td["open"][str(ctx.channel.id)]
        opener = ctx.guild.get_member(info["opener"])
        if not opener:
            return await ctx.reply("❌ Could not find ticket opener.")
        view = CloseRequestOpenerView(ctx.channel, info["opener"])
        await ctx.reply(f"{opener.mention} • {ctx.author.mention} is requesting to close this ticket.", view=view)

    @commands.command(name="tktadduser")
    @commands.has_permissions(manage_channels=True)
    async def prefix_ticket_adduser(self, ctx, member: discord.Member):
        td = _ticket_data(ctx.guild.id)
        if str(ctx.channel.id) not in td.get("open", {}):
            return await ctx.reply("❌ Not a ticket channel.")
        await ctx.channel.set_permissions(member, read_messages=True, send_messages=True)
        await ctx.reply(f"✅ Added {member.mention}.")

    @commands.command(name="tktremoveuser")
    @commands.has_permissions(manage_channels=True)
    async def prefix_ticket_removeuser(self, ctx, member: discord.Member):
        td = _ticket_data(ctx.guild.id)
        if str(ctx.channel.id) not in td.get("open", {}):
            return await ctx.reply("❌ Not a ticket channel.")
        await ctx.channel.set_permissions(member, overwrite=None)
        await ctx.reply(f"✅ Removed {member.mention}.")

    @commands.command(name="tktopen")
    @commands.has_permissions(manage_channels=True)
    async def prefix_ticket_open(self, ctx, user: discord.Member, category: str):
        categories = _get_categories(ctx.guild.id)
        if category not in categories:
            return await ctx.reply(f"❌ Invalid category.")
        category_label = categories[category]["label"]
        result = await _create_ticket_channel(ctx.guild, user, category, category_label)
        number, channel = result
        if number is None:
            return await ctx.reply(f"❌ User already has an open ticket: {channel.mention}")
        settings = load("guild_settings.json").get(str(ctx.guild.id), {})
        custom_embed_text = settings.get("ticket_customization", {}).get("ticket_embed_text")
        await ctx.reply(f"✅ Opened ticket {channel.mention} for {user.mention}.")
        await _send_ticket_embed(channel, user, number, category_label, custom_embed_text)

    @commands.command(name="tktautoclose")
    @commands.has_permissions(manage_channels=True)
    async def prefix_ticket_autoclose(self, ctx, hours: float, *, reason: str = None):
        custom = _get_customization(ctx.guild.id)
        if not custom.get("enable_auto_close", True):
            return await ctx.reply("❌ Auto-close disabled.")
        td = _ticket_data(ctx.guild.id)
        info = td.get("open", {}).get(str(ctx.channel.id))
        if not info:
            return await ctx.reply("❌ Not an active ticket.")
        close_time = datetime.now(timezone.utc) + timedelta(hours=hours)
        info["autoclose_at"] = close_time.isoformat()
        if reason:
            info["autoclose_reason"] = reason
        td["open"][str(ctx.channel.id)] = info
        _save_ticket(ctx.guild.id, td)
        await _send_autoclose_embed(ctx.channel, hours, reason)
        await ctx.reply(f"✅ Auto-close set for **{hours}** hours.")

    @commands.command(name="tktremoveautoclose")
    @commands.has_permissions(manage_channels=True)
    async def prefix_ticket_removeautoclose(self, ctx):
        td = _ticket_data(ctx.guild.id)
        info = td.get("open", {}).get(str(ctx.channel.id))
        if not info:
            return await ctx.reply("❌ Not an active ticket.")
        if not info.get("autoclose_at"):
            return await ctx.reply("ℹ️ No auto-close timer set.")
        info.pop("autoclose_at", None)
        info.pop("autoclose_reason", None)
        td["open"][str(ctx.channel.id)] = info
        _save_ticket(ctx.guild.id, td)
        await ctx.reply("✅ Auto-close removed.")

    @commands.command(name="tkttranscript")
    @commands.has_permissions(manage_channels=True)
    async def prefix_ticket_transcript(self, ctx):
        td = _ticket_data(ctx.guild.id)
        if str(ctx.channel.id) not in td.get("open", {}):
            return await ctx.reply("❌ Not a ticket channel.")
        if not _is_staff(ctx, ctx.channel.id):
            return await ctx.reply("❌ Only staff can generate transcripts.")
        if not _can_act(ctx.author.id, ctx.channel.id, "transcript", 10.0):
            return await ctx.reply("⏳ Please wait.")
        transcript = await _generate_transcript(ctx.channel)
        if not transcript:
            return await ctx.reply("❌ Failed to generate transcript.")
        if transcript.get("url"):
            await ctx.reply(f"📄 Transcript for {ctx.channel.mention}\n[Click here]({transcript['url']})")
        elif transcript.get("file"):
            await ctx.reply(f"📄 Transcript for {ctx.channel.mention}", file=transcript["file"])
        else:
            await ctx.reply("❌ Failed to generate transcript.")

    @commands.command(name="tktfieldsadd")
    @commands.has_permissions(administrator=True)
    async def prefix_ticket_addfield(self, ctx, category: str):
        await ctx.reply("Please use `/tkt fields add` (modal cannot be opened via prefix).")

    @commands.command(name="tktfieldsremove")
    @commands.has_permissions(administrator=True)
    async def prefix_ticket_removefield(self, ctx, category: str):
        categories = _get_categories(ctx.guild.id)
        if category not in categories:
            return await ctx.reply(f"❌ Category `{category}` not found.")
        fields = categories[category].get("form_fields", [])
        if not fields:
            return await ctx.reply(f"ℹ️ No form fields.")
        view = RemoveFormFieldView(ctx.guild.id, category, fields)
        embed = build(title=f"Remove Field from {categories[category]['label']}", description="Select a field to remove:", color=Config.COLOR_INFO, bot=self.bot)
        await ctx.reply(embed=embed, view=view)

    @commands.command(name="tktcustomize")
    @commands.has_permissions(administrator=True)
    async def prefix_ticket_customize(self, ctx):
        embed = build(title="🎨 Ticket Customization", description="Select an option:", color=Config.COLOR_INFO, bot=self.bot)
        view = CustomizationView(ctx.guild.id)
        await ctx.reply(embed=embed, view=view)

    @commands.command(name="tktstafftype")
    @commands.has_permissions(administrator=True)
    async def prefix_ticket_typerole(self, ctx, ticket_type: str, role: discord.Role):
        await self.prefix_tickettyperole(ctx, ticket_type, role)

    @commands.command(name="tktstaffglobal")
    @commands.has_permissions(administrator=True)
    async def prefix_ticket_staffrole(self, ctx, role: discord.Role):
        await self.prefix_ticketstaffrole(ctx, role)

    @commands.command(name="tktstaffinfo")
    @commands.has_permissions(manage_channels=True)
    async def prefix_ticket_info(self, ctx):
        await self.prefix_tickettypeinfo(ctx)

    @commands.command(name="tktmanagesetup")
    @commands.has_permissions(administrator=True)
    async def prefix_ticket_setup(self, ctx, channel: discord.TextChannel = None):
        await self.prefix_ticketsetup(ctx, channel)

    @commands.command(name="tktmanageadd")
    @commands.has_permissions(administrator=True)
    async def prefix_ticket_addcategory(self, ctx):
        await ctx.reply("Use `/tkt manage add` to add a category.")

    @commands.command(name="tktmanageremove")
    @commands.has_permissions(administrator=True)
    async def prefix_ticket_removecategory(self, ctx):
        await self.prefix_ticketremovecategory(ctx)

    @commands.command(name="tktmanagereset")
    @commands.has_permissions(administrator=True)
    async def prefix_ticket_resetcategories(self, ctx):
        await self.prefix_ticketresetcategories(ctx)

    @commands.command(name="tktmanagecat")
    @commands.has_permissions(administrator=True)
    async def prefix_ticket_setcategory(self, ctx, category_name: str):
        await self.prefix_ticketsetcategory(ctx, category_name)

    @commands.command(name="tktmanagelistcats")
    @commands.has_permissions(manage_channels=True)
    async def prefix_ticket_listcats(self, ctx):
        await self.prefix_ticketlistcategories(ctx)

    @commands.command(name="tktmanagetime")
    @commands.has_permissions(administrator=True)
    async def prefix_ticket_supporttimes(self, ctx, start: str, end: str):
        await self.prefix_ticketsupporttimes(ctx, start, end)

    @commands.command(name="tktmanageremovetime")
    @commands.has_permissions(administrator=True)
    async def prefix_ticket_removesupporttimes(self, ctx):
        await self.prefix_ticketremovesupporttimes(ctx)

    @commands.command(name="tktmanageembed")
    @commands.has_permissions(administrator=True)
    async def prefix_ticket_setembedtext(self, ctx):
        await self.prefix_ticketembedtext(ctx)

    @commands.command(name="tktmanageclean")
    @commands.has_permissions(manage_channels=True)
    async def prefix_ticket_cleanup(self, ctx):
        td = _ticket_data(ctx.guild.id)
        stale = [ch_id for ch_id in td.get("open", {}) if not ctx.guild.get_channel(int(ch_id))]
        if not stale:
            return await ctx.reply("✅ Memory is clean.")
        for ch_id in stale:
            td["open"].pop(ch_id, None)
        _save_ticket(ctx.guild.id, td)
        await ctx.reply(f"✅ Removed **{len(stale)}** stale records.")

    @commands.command(name="tktmanagecount")
    @commands.has_permissions(manage_channels=True)
    async def prefix_ticket_opentickets(self, ctx):
        td = _ticket_data(ctx.guild.id)
        real_count = _real_open_count(ctx.guild, td)
        await ctx.reply(f"**{real_count}** ticket(s) open.")

    @commands.command(name="tktmanagelist")
    @commands.has_permissions(manage_channels=True)
    async def prefix_ticket_list(self, ctx):
        td = _ticket_data(ctx.guild.id)
        open_tickets = td.get("open", {})
        if not open_tickets:
            return await ctx.reply("✅ No open tickets.")
        lines = []
        for ch_id, info in open_tickets.items():
            ch = ctx.guild.get_channel(int(ch_id))
            opener = ctx.guild.get_member(info["opener"])
            cat = info.get("category_label", "Unknown")
            if ch:
                claimed = "✅ " if info.get("claimed_by") else ""
                autoclose = "⏰ " if info.get("autoclose_at") else ""
                rating = f"⭐ {info.get('rating')}" if info.get('rating') else ""
                lines.append(f"• {claimed}{autoclose}{ch.mention} • {opener.mention if opener else 'Unknown'} • {cat} {rating}")
        embed = build(title=f"📋 Open Tickets • {len(lines)}", description="\n".join(lines), color=Config.COLOR_INFO, bot=self.bot)
        await ctx.reply(embed=embed)

    @commands.command(name="tktmanagehistory")
    async def prefix_ticket_history(self, ctx):
        await self.prefix_history(ctx)

    @commands.command(name="tktmanagereviews")
    @commands.has_permissions(manage_channels=True)
    async def prefix_ticket_reviews(self, ctx):
        await self.prefix_reviews(ctx)

    # ---------- Slash commands (existing) ----------
    @manage.command(name="setup", description="Post a fully customizable ticket panel.")
    @app_commands.describe(channel="Channel to send the panel to")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def ticket_setup_slash(self, interaction: discord.Interaction, channel: discord.TextChannel = None):
        ch = channel or interaction.channel
        categories = _get_categories(interaction.guild.id)
        custom = _get_customization(interaction.guild.id)
        embed = build(title=custom.get("embed_title", DEFAULT_CUSTOMIZATION["embed_title"]), description=custom.get("embed_description", DEFAULT_CUSTOMIZATION["embed_description"]), color=custom.get("embed_color", Config.COLOR_INFO), bot=self.bot)
        if custom.get("show_available_categories", False):
            cat_list = ""
            for key, cat in categories.items():
                if not cat.get("enabled", True):
                    continue
                q_count = len(cat.get("form_fields", [])) + len(cat.get("questions", []))
                cat_list += f"**{cat['label']}** • {cat.get('description', '')}"
                if q_count:
                    cat_list += f" ({q_count} fields)"
                cat_list += "\n"
            embed.add_field(name="📂 Available Categories", value=cat_list or "No categories available", inline=False)
        notes_heading = custom.get("important_notes_heading", "📝 Important Notes")
        embed.add_field(name=notes_heading, value=custom.get("embed_footer", DEFAULT_CUSTOMIZATION["embed_footer"]), inline=False)
        footer_text = custom.get("footer_text", "Sparky Bot • Ticket System")
        embed.set_footer(text=footer_text)
        view = CustomTicketPanelView(categories, interaction.guild.id)
        self.bot.add_view(view)
        await ch.send(embed=embed, view=view)
        await interaction.response.send_message(f"✅ Custom ticket panel sent to {ch.mention}.", ephemeral=True)

    @manage.command(name="add", description="Add a new ticket category.")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def ticket_addcategory_slash(self, interaction: discord.Interaction):
        await interaction.response.send_modal(AddCategoryModal(interaction.guild.id))

    @manage.command(name="remove", description="Remove a ticket category.")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def ticket_removecategory_slash(self, interaction: discord.Interaction):
        categories = _get_categories(interaction.guild.id)
        if not categories:
            return await interaction.response.send_message("ℹ️ No categories to remove.", ephemeral=True)
        view = RemoveCategoryView(interaction.guild.id, categories)
        await interaction.response.send_message("Select a category to remove:", view=view, ephemeral=True)

    @manage.command(name="reset", description="Reset all categories to defaults.")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def ticket_resetcategories_slash(self, interaction: discord.Interaction):
        view = ResetCategoriesView(interaction.guild.id)
        await interaction.response.send_message("⚠️ **Reset all categories to defaults?**", view=view, ephemeral=True)

    @manage.command(name="cat", description="Set the category name for ticket channels.")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def ticket_setcategory_slash(self, interaction: discord.Interaction, category_name: str):
        data = load("guild_settings.json")
        data.setdefault(str(interaction.guild.id), {})["ticket_category"] = category_name
        save("guild_settings.json", data)
        await interaction.response.send_message(f"✅ Ticket category set to **{category_name}**.", ephemeral=True)

    @manage.command(name="listcats", description="List all ticket categories.")
    @app_commands.default_permissions(manage_channels=True)
    @app_commands.checks.has_permissions(manage_channels=True)
    async def ticket_listcats_slash(self, interaction: discord.Interaction):
        await self.prefix_ticketlistcategories(await commands.Context.from_interaction(interaction))

    @manage.command(name="time", description="Set staff support hours.")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def ticket_supporttimes_slash(self, interaction: discord.Interaction, start: str, end: str):
        if not _parse_time(start) or not _parse_time(end):
            return await interaction.response.send_message("❌ Invalid time format.", ephemeral=True)
        data = load("guild_settings.json")
        gd = data.setdefault(str(interaction.guild.id), {})
        gd["support_start"] = start
        gd["support_end"] = end
        save("guild_settings.json", data)
        embed = build(title="✅ Support Times Set", description=f"Support hours: **{start}** → **{end}** (UTC).", color=Config.COLOR_OK, bot=self.bot)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @manage.command(name="rmtime", description="Remove support timings.")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def ticket_removesupporttimes_slash(self, interaction: discord.Interaction):
        data = load("guild_settings.json")
        gd = data.get(str(interaction.guild.id), {})
        gd.pop("support_start", None)
        gd.pop("support_end", None)
        save("guild_settings.json", data)
        embed = build(title="✅ Support Timings Removed", color=Config.COLOR_OK, bot=self.bot)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @manage.command(name="setlog", description="[ADMIN] Set the ticket log channel.")
    @app_commands.describe(channel="Text channel for ticket logs")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def ticket_setlog_slash(self, interaction: discord.Interaction, channel: discord.TextChannel):
        if not isinstance(channel, discord.TextChannel):
            return await interaction.response.send_message("❌ Please select a text channel.", ephemeral=True)
        test_embed = build(title="✅ Ticket Log Channel Set", description="Test message", color=Config.COLOR_OK, bot=self.bot)
        try:
            await channel.send(embed=test_embed)
        except discord.Forbidden:
            return await interaction.response.send_message(f"⚠️ I can't send messages to {channel.mention}.", ephemeral=True)
        except Exception as e:
            return await interaction.response.send_message(f"⚠️ Failed to send test: {str(e)[:100]}", ephemeral=True)
        data = load("guild_settings.json")
        data.setdefault(str(interaction.guild.id), {})["ticket_log_channel"] = channel.id
        save("guild_settings.json", data)
        await interaction.response.send_message(f"✅ Ticket logs → {channel.mention}.", ephemeral=True)

    @manage.command(name="embed", description="Set custom text for the ticket embed.")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def ticket_setembedtext_slash(self, interaction: discord.Interaction):
        view = SetEmbedTextView(interaction.guild.id)
        await interaction.response.send_message("Click below to set custom embed text.", view=view, ephemeral=True)

    @manage.command(name="clean", description="Remove stale ticket records.")
    @app_commands.default_permissions(manage_channels=True)
    @app_commands.checks.has_permissions(manage_channels=True)
    async def ticket_cleanup_slash(self, interaction: discord.Interaction):
        td = _ticket_data(interaction.guild.id)
        stale = [ch_id for ch_id in td.get("open", {}) if not interaction.guild.get_channel(int(ch_id))]
        if not stale:
            return await interaction.response.send_message("✅ Memory is clean.", ephemeral=True)
        for ch_id in stale:
            td["open"].pop(ch_id, None)
        _save_ticket(interaction.guild.id, td)
        await interaction.response.send_message(f"✅ Removed **{len(stale)}** stale records.", ephemeral=True)

    @manage.command(name="count", description="Show open ticket count.")
    @app_commands.default_permissions(manage_channels=True)
    @app_commands.checks.has_permissions(manage_channels=True)
    async def ticket_opentickets_slash(self, interaction: discord.Interaction):
        td = _ticket_data(interaction.guild.id)
        real_count = _real_open_count(interaction.guild, td)
        await interaction.response.send_message(f"**{real_count}** ticket(s) open.", ephemeral=True)

    @manage.command(name="list", description="List all open tickets.")
    @app_commands.default_permissions(manage_channels=True)
    @app_commands.checks.has_permissions(manage_channels=True)
    async def ticket_list_slash(self, interaction: discord.Interaction):
        td = _ticket_data(interaction.guild.id)
        open_tickets = td.get("open", {})
        if not open_tickets:
            return await interaction.response.send_message("✅ No open tickets.", ephemeral=True)
        lines = []
        for ch_id, info in open_tickets.items():
            ch = interaction.guild.get_channel(int(ch_id))
            opener = interaction.guild.get_member(info["opener"])
            cat = info.get("category_label", "Unknown")
            if ch:
                claimed = "✅ " if info.get("claimed_by") else ""
                autoclose = "⏰ " if info.get("autoclose_at") else ""
                rating = f"⭐ {info.get('rating')}" if info.get('rating') else ""
                lines.append(f"• {claimed}{autoclose}{ch.mention} • {opener.mention if opener else 'Unknown'} • {cat} {rating}")
        embed = build(title=f"📋 Open Tickets • {len(lines)}", description="\n".join(lines), color=Config.COLOR_INFO, bot=self.bot)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @manage.command(name="history", description="View your ticket history.")
    async def ticket_history_slash(self, interaction: discord.Interaction):
        await self.prefix_history(await commands.Context.from_interaction(interaction))

    @manage.command(name="reviews", description="View all ticket reviews.")
    @app_commands.default_permissions(manage_channels=True)
    @app_commands.checks.has_permissions(manage_channels=True)
    async def ticket_reviews_slash(self, interaction: discord.Interaction):
        await self.prefix_reviews(await commands.Context.from_interaction(interaction))

    @fields.command(name="add", description="Add a form field to a category.")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def ticket_addfield_slash(self, interaction: discord.Interaction, category: str):
        categories = _get_categories(interaction.guild.id)
        if category not in categories:
            return await interaction.response.send_message(f"❌ Category `{category}` not found.", ephemeral=True)
        fields = categories[category].get("form_fields", [])
        if len(fields) >= 5:
            return await interaction.response.send_message("❌ Max 5 fields.", ephemeral=True)
        modal = AddFormFieldModal(interaction.guild.id, category)
        await interaction.response.send_modal(modal)

    @fields.command(name="remove", description="Remove a form field from a category.")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def ticket_removefield_slash(self, interaction: discord.Interaction, category: str):
        categories = _get_categories(interaction.guild.id)
        if category not in categories:
            return await interaction.response.send_message(f"❌ Category `{category}` not found.", ephemeral=True)
        fields = categories[category].get("form_fields", [])
        if not fields:
            return await interaction.response.send_message(f"ℹ️ No fields.", ephemeral=True)
        view = RemoveFormFieldView(interaction.guild.id, category, fields)
        embed = build(title=f"Remove Field from {categories[category]['label']}", description="Select a field:", color=Config.COLOR_INFO, bot=self.bot)
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

    @staff.command(name="type", description="Add/remove staff role for a ticket type.")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def ticket_typerole_slash(self, interaction: discord.Interaction, ticket_type: str, role: discord.Role):
        await self.prefix_tickettyperole(await commands.Context.from_interaction(interaction), ticket_type, role)

    @staff.command(name="global", description="Add/remove global staff role.")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def ticket_staffrole_slash(self, interaction: discord.Interaction, role: discord.Role):
        await self.prefix_ticketstaffrole(await commands.Context.from_interaction(interaction), role)

    @staff.command(name="info", description="View staff role config.")
    @app_commands.default_permissions(manage_channels=True)
    @app_commands.checks.has_permissions(manage_channels=True)
    async def ticket_info_slash(self, interaction: discord.Interaction):
        await self.prefix_tickettypeinfo(await commands.Context.from_interaction(interaction))

    @customize.command(name="menu", description="Customize ticket panel appearance.")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def ticket_customize_slash(self, interaction: discord.Interaction):
        embed = build(title="🎨 Ticket Customization", description="Select an option:", color=Config.COLOR_INFO, bot=self.bot)
        view = CustomizationView(interaction.guild.id)
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

    @ticket.command(name="close", description="Close the current ticket.")
    async def ticket_close_slash(self, interaction: discord.Interaction, reason: str = None):
        await self.prefix_ticket_close(await commands.Context.from_interaction(interaction), reason)

    @ticket.command(name="closereq", description="Request opener to close ticket.")
    async def ticket_closereq_slash(self, interaction: discord.Interaction):
        await self.prefix_ticket_closereq(await commands.Context.from_interaction(interaction))

    @ticket.command(name="adduser", description="Add a member to this ticket.")
    @app_commands.default_permissions(manage_channels=True)
    @app_commands.checks.has_permissions(manage_channels=True)
    async def ticket_adduser_slash(self, interaction: discord.Interaction, member: discord.Member):
        await self.prefix_ticket_adduser(await commands.Context.from_interaction(interaction), member)

    @ticket.command(name="removeuser", description="Remove a member from this ticket.")
    @app_commands.default_permissions(manage_channels=True)
    @app_commands.checks.has_permissions(manage_channels=True)
    async def ticket_removeuser_slash(self, interaction: discord.Interaction, member: discord.Member):
        await self.prefix_ticket_removeuser(await commands.Context.from_interaction(interaction), member)

    @ticket.command(name="open", description="Manually open a ticket for a user.")
    @app_commands.default_permissions(manage_channels=True)
    @app_commands.checks.has_permissions(manage_channels=True)
    async def ticket_open_slash(self, interaction: discord.Interaction, user: discord.Member, category: str):
        await self.prefix_ticket_open(await commands.Context.from_interaction(interaction), user, category)

    @ticket.command(name="autoclose", description="Set auto-close timer.")
    async def ticket_autoclose_slash(self, interaction: discord.Interaction, hours: float, reason: str = None):
        await self.prefix_ticket_autoclose(await commands.Context.from_interaction(interaction), hours, reason)

    @ticket.command(name="rmautoclose", description="Remove auto-close timer.")
    async def ticket_removeautoclose_slash(self, interaction: discord.Interaction):
        await self.prefix_ticket_removeautoclose(await commands.Context.from_interaction(interaction))

    @ticket.command(name="transcript", description="Generate transcript.")
    async def ticket_transcript_slash(self, interaction: discord.Interaction):
        await self.prefix_ticket_transcript(await commands.Context.from_interaction(interaction))

    # ---------- Error handler ----------
    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            missing = ", ".join(p.replace("_", " ").title() for p in error.missing_permissions)
            print(f"[Tickets] {interaction.user} missing: {missing}")
            try:
                await interaction.response.send_message(f"❌ Missing: **{missing}**.", ephemeral=True)
            except discord.InteractionResponded:
                await interaction.followup.send(f"❌ Missing: **{missing}**.", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Tickets(bot))