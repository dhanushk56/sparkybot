import discord
from discord.ext import commands
from discord import app_commands
import asyncio
import re
from datetime import datetime, timezone
from config import Config
from utils.data import load, save
from utils.prefix_manager import get_prefixes
from utils.emojis import Emojis
from utils.theme import Theme
from utils.embed import build, error_embed

AFK_FILE = "afk.json"

NUMBER_EMOJIS = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"]


class PollView(discord.ui.View):

    def __init__(self, options: list, author_id: int):
        super().__init__(timeout=3600)
        self.options = options
        self.author_id = author_id
        self.votes = {opt: set() for opt in options}
        self.message = None
        self.question = None
        for i, opt in enumerate(options):
            button = discord.ui.Button(
                label=opt[:75], emoji=NUMBER_EMOJIS[i], style=discord.ButtonStyle.secondary,
                row=i // 5,
            )
            button.callback = self._make_callback(opt)
            self.add_item(button)

        close_btn = discord.ui.Button(label="Close", emoji=Emojis.WRONG, style=discord.ButtonStyle.danger,
                                       row=(len(options) - 1) // 5 + 1)
        close_btn.callback = self._on_close
        self.add_item(close_btn)

    def _make_callback(self, option: str):
        async def callback(interaction: discord.Interaction):
            for voters in self.votes.values():
                voters.discard(interaction.user.id)
            self.votes[option].add(interaction.user.id)
            await interaction.response.edit_message(embed=self.render(self.question, interaction.user, interaction.client))
        return callback

    async def _on_close(self, interaction: discord.Interaction):
        if interaction.user.id != self.author_id:
            await interaction.response.send_message(f"{Emojis.WRONG} Only the poll creator can close this.", ephemeral=True)
            return
        for child in self.children:
            child.disabled = True
        await interaction.response.edit_message(embed=self.render(self.question, interaction.user, interaction.client, closed=True), view=self)
        self.stop()

    def render(self, question: str, author, bot, closed: bool = False) -> discord.Embed:
        self.question = question
        total = sum(len(v) for v in self.votes.values())
        lines = []
        for i, opt in enumerate(self.options):
            count = len(self.votes[opt])
            pct = (count / total * 100) if total else 0
            bar_len = int(pct / 100 * 16)
            bar = "█" * bar_len + "░" * (16 - bar_len)
            lines.append(f"{NUMBER_EMOJIS[i]} **{opt}**\n`{bar}` {count} vote{'s' if count != 1 else ''} ({pct:.0f}%)")

        e = build(
            title=question,
            description="\n\n".join(lines),
            color=Theme.COLOR_ERROR if closed else Theme.COLOR_PRIMARY,
            emoji=Emojis.WRONG if closed else "📊",
            bot=bot,
            note=f"{'Closed' if closed else 'Open'} {Emojis.DOT} {total} total votes {Emojis.DOT} started by {author.display_name}",
        )
        return e

    async def on_timeout(self):
        for child in self.children:
            child.disabled = True
        if self.message:
            try:
                await self.message.edit(view=self)
            except discord.HTTPException:
                pass

def _get_afk(guild_id: int) -> dict:
    return load(AFK_FILE).get(str(guild_id), {})

def _save_afk(guild_id: int, afk: dict):
    data = load(AFK_FILE)
    data[str(guild_id)] = afk
    save(AFK_FILE, data)

class Utility(commands.Cog):

    slash = app_commands.Group(name="utility", description="General utility commands")

    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="ping")
    async def ping(self, ctx):
        start = discord.utils.utcnow()
        msg = await ctx.reply("Pinging...")
        end = discord.utils.utcnow()
        rtt = (end - start).total_seconds() * 1000
        ws = round(ctx.bot.latency * 1000)

        shard_id = ctx.bot.shard_id if ctx.bot.shard_id is not None else 0
        shard_count = ctx.bot.shard_count if ctx.bot.shard_count is not None else 1

        e = build(title="Pong!", color=Config.COLOR_INFO, bot=self.bot)
        e.add_field(name="WebSocket", value=f"`{ws}ms`")
        e.add_field(name="Round-Trip", value=f"`{rtt:.0f}ms`")
        e.add_field(name="🔀 Shard", value=f"`{shard_id+1}/{shard_count}`")
        e.set_footer(text=f"Server: {ctx.guild.name} • Shard {shard_id+1}/{shard_count}")

        await msg.edit(content=None, embed=e)

    @slash.command(name="ping", description="Check the bot latency.")
    async def ping_slash(self, interaction: discord.Interaction):
        ctx = await commands.Context.from_interaction(interaction)
        await self.ping.callback(self, ctx)

    @commands.command(name="userinfo", aliases=["ui", "whois"])
    async def userinfo(self, ctx, member: discord.Member = None):
        m = member or ctx.author
        roles = [r.mention for r in m.roles if r != ctx.guild.default_role]
        joined = discord.utils.format_dt(m.joined_at, "R") if m.joined_at else "Unknown"
        e = build(title=str(m), color=m.color or Config.COLOR_INFO, bot=self.bot)
        e.set_thumbnail(url=m.display_avatar.url)
        e.add_field(name="ID", value=str(m.id))
        e.add_field(name="Bot", value="Yes" if m.bot else "No")
        e.add_field(name="Joined", value=joined)
        e.add_field(name="Registered", value=discord.utils.format_dt(m.created_at, "R"))
        e.add_field(name="Status", value=str(m.status).title())
        e.add_field(name="Top Role", value=m.top_role.mention)
        if roles:
            e.add_field(
                name=f"Roles ({len(roles)})",
                value=" ".join(roles[:15]) + ("..." if len(roles) > 15 else ""),
                inline=False,
            )
        await ctx.reply(embed=e)

    @slash.command(name="userinfo", description="View detailed info about a member.")
    @app_commands.describe(member="Member to look up (leave empty for yourself)")
    async def userinfo_slash(self, interaction: discord.Interaction, member: discord.Member = None):
        ctx = await commands.Context.from_interaction(interaction)
        await self.userinfo.callback(self, ctx, member)

    @commands.command(name="serverinfo", aliases=["si", "guildinfo"])
    async def serverinfo(self, ctx):
        g = ctx.guild
        bots = sum(m.bot for m in g.members)
        online = sum(m.status != discord.Status.offline and not m.bot for m in g.members)
        e = build(title=g.name, color=Config.COLOR_INFO, bot=self.bot)
        if g.icon:
            e.set_thumbnail(url=g.icon.url)
        e.add_field(name="Owner", value=g.owner.mention if g.owner else "Unknown")
        e.add_field(name="ID", value=str(g.id))
        e.add_field(name="Created", value=discord.utils.format_dt(g.created_at, "R"))
        e.add_field(name="Members", value=f"{g.member_count:,} ({bots} bots)")
        e.add_field(name="Online", value=f"{online:,}")
        e.add_field(name="Channels", value=f"{len(g.text_channels)} text | {len(g.voice_channels)} voice")
        e.add_field(name="Roles", value=str(len(g.roles)))
        e.add_field(name="Emojis", value=str(len(g.emojis)))
        e.add_field(name="Boosts", value=f"Level {g.premium_tier} ({g.premium_subscription_count} boosts)")
        await ctx.reply(embed=e)

    @slash.command(name="serverinfo", description="View information about this server.")
    async def serverinfo_slash(self, interaction: discord.Interaction):
        ctx = await commands.Context.from_interaction(interaction)
        await self.serverinfo.callback(self, ctx)

    @commands.command(name="avatar", aliases=["av", "pfp"])
    async def avatar(self, ctx, member: discord.Member = None):
        m = member or ctx.author
        e = build(title=f"{m.display_name}'s Avatar", color=Config.COLOR_INFO, bot=self.bot)
        e.set_image(url=m.display_avatar.url)
        e.description = f"[PNG]({m.display_avatar.with_format('png').url}) | [JPG]({m.display_avatar.with_format('jpg').url}) | [WEBP]({m.display_avatar.with_format('webp').url})"
        await ctx.reply(embed=e)

    @slash.command(name="avatar", description="Show a member's avatar.")
    @app_commands.describe(member="Member to show avatar for")
    async def avatar_slash(self, interaction: discord.Interaction, member: discord.Member = None):
        ctx = await commands.Context.from_interaction(interaction)
        await self.avatar.callback(self, ctx, member)

    @commands.command(name="banner")
    async def banner(self, ctx, member: discord.Member = None):
        m = member or ctx.author
        user = await self.bot.fetch_user(m.id)
        if not user.banner:
            return await ctx.reply(f"**{m}** has no banner.")
        e = build(title=f"{m.display_name}'s Banner", color=Config.COLOR_INFO, bot=self.bot)
        e.set_image(url=user.banner.url)
        await ctx.reply(embed=e)

    @slash.command(name="banner", description="Show a member's banner.")
    @app_commands.describe(member="Member to show banner for")
    async def banner_slash(self, interaction: discord.Interaction, member: discord.Member = None):
        ctx = await commands.Context.from_interaction(interaction)
        await self.banner.callback(self, ctx, member)

    @commands.command(name="roleinfo")
    async def roleinfo(self, ctx, role: discord.Role):
        perms = [p.replace("_", " ").title() for p, v in role.permissions if v]
        e = build(title=f"Role: {role.name}", color=role.color or Config.COLOR_INFO, bot=self.bot)
        e.add_field(name="ID", value=str(role.id))
        e.add_field(name="Color", value=str(role.color))
        e.add_field(name="Mentionable", value="Yes" if role.mentionable else "No")
        e.add_field(name="Hoisted", value="Yes" if role.hoist else "No")
        e.add_field(name="Members", value=str(len(role.members)))
        e.add_field(name="Created", value=discord.utils.format_dt(role.created_at, "R"))
        if perms:
            e.add_field(name="Key Permissions", value=", ".join(perms[:10]), inline=False)
        await ctx.reply(embed=e)

    @slash.command(name="roleinfo", description="Show info about a role.")
    @app_commands.describe(role="Role to look up")
    async def roleinfo_slash(self, interaction: discord.Interaction, role: discord.Role):
        ctx = await commands.Context.from_interaction(interaction)
        await self.roleinfo.callback(self, ctx, role)

    @commands.command(name="channelinfo", aliases=["ci"])
    async def channelinfo(self, ctx, channel: discord.TextChannel = None):
        ch = channel or ctx.channel
        e = build(title=f"#{ch.name}", color=Config.COLOR_INFO, bot=self.bot)
        e.add_field(name="ID", value=str(ch.id))
        e.add_field(name="Type", value=str(ch.type).replace("_", " ").title())
        e.add_field(name="Category", value=ch.category.name if ch.category else "None")
        e.add_field(name="NSFW", value="Yes" if ch.is_nsfw() else "No")
        e.add_field(name="Created", value=discord.utils.format_dt(ch.created_at, "R"))
        if isinstance(ch, discord.TextChannel):
            e.add_field(name="Slowmode", value=f"{ch.slowmode_delay}s" if ch.slowmode_delay else "Off")
            e.add_field(name="Topic", value=ch.topic or "None", inline=False)
        await ctx.reply(embed=e)

    @slash.command(name="channelinfo", description="Show info about a channel.")
    @app_commands.describe(channel="Channel to look up (defaults to current)")
    async def channelinfo_slash(self, interaction: discord.Interaction, channel: discord.TextChannel = None):
        ctx = await commands.Context.from_interaction(interaction)
        await self.channelinfo.callback(self, ctx, channel)

    @commands.command(name="invite")
    async def invite(self, ctx):
        perms = discord.Permissions(
            kick_members=True, ban_members=True, manage_channels=True,
            manage_guild=True, add_reactions=True, view_channel=True,
            send_messages=True, manage_messages=True, embed_links=True,
            attach_files=True, read_message_history=True, mention_everyone=False,
            connect=True, speak=True, move_members=True, manage_roles=True,
            moderate_members=True,
        )
        url = discord.utils.oauth_url(self.bot.user.id, permissions=perms)
        e = build(title="Invite Me!", description=f"[Click here to invite {self.bot.user.name}]({url})", color=Config.COLOR_INFO, bot=self.bot)
        await ctx.reply(embed=e)

    @slash.command(name="invite", description="Get the bot invite link.")
    async def invite_slash(self, interaction: discord.Interaction):
        ctx = await commands.Context.from_interaction(interaction)
        await self.invite.callback(self, ctx)

    @commands.command(name="poll")
    async def poll(self, ctx, question: str, *options: str):
        if len(options) < 2:
            return await ctx.reply(embed=error_embed("Provide at least 2 options.", bot=self.bot))
        if len(options) > 10:
            return await ctx.reply(embed=error_embed("A poll can have at most 10 options.", bot=self.bot))

        view = PollView(list(options), ctx.author.id)
        embed = view.render(question, ctx.author, self.bot)
        msg = await ctx.reply(embed=embed, view=view)
        view.message = msg

    @slash.command(name="poll", description="Create a poll with up to 10 options.")
    @app_commands.describe(question="Poll question", options="Options separated by commas")
    async def poll_slash(self, interaction: discord.Interaction, question: str, options: str):
        ctx = await commands.Context.from_interaction(interaction)
        opts = [o.strip() for o in options.split(",") if o.strip()]
        await self.poll.callback(self, ctx, question, *opts)

    @commands.command(name="remind", aliases=["remindme"])
    async def remind(self, ctx, time: str, *, reminder: str):
        units = {"s": 1, "m": 60, "h": 3600, "d": 86400}
        unit = time[-1].lower()
        if unit not in units or not time[:-1].isdigit():
            return await ctx.reply("Invalid time format. Use `10s`, `5m`, `2h`, `1d`.")
        seconds = int(time[:-1]) * units[unit]
        if seconds > 2592000:
            return await ctx.reply("Maximum reminder time is 30 days.")
        author = ctx.author
        channel = ctx.channel
        await ctx.reply(f"I'll remind you in **{time}**: *{reminder}*")
        await asyncio.sleep(seconds)
        try:
            await channel.send(f"{author.mention} Reminder: **{reminder}**")
        except Exception:
            try:
                await author.send(f"Reminder: **{reminder}**")
            except Exception:
                pass

    @slash.command(name="remind", description="Set a reminder.")
    @app_commands.describe(time="Duration e.g. 10m, 2h, 1d", reminder="What to remind you about")
    async def remind_slash(self, interaction: discord.Interaction, time: str, reminder: str):
        ctx = await commands.Context.from_interaction(interaction)
        await self.remind.callback(self, ctx, time, reminder=reminder)

    @commands.command(name="afk")
    async def afk(self, ctx, *, reason: str = "AFK"):
        afk = _get_afk(ctx.guild.id)
        afk[str(ctx.author.id)] = {"reason": reason, "time": discord.utils.utcnow().isoformat()}
        _save_afk(ctx.guild.id, afk)
        await ctx.reply(f"You are now AFK: *{reason}*")

    @slash.command(name="afk", description="Set yourself as AFK with an optional reason.")
    @app_commands.describe(reason="Why you're going AFK")
    async def afk_slash(self, interaction: discord.Interaction, reason: str = "AFK"):
        ctx = await commands.Context.from_interaction(interaction)
        await self.afk.callback(self, ctx, reason=reason)

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild:
            return

        from utils.data import load as _load
        counting_data = _load("counting.json").get(str(message.guild.id), {})
        if counting_data.get("channel") and message.channel.id == counting_data["channel"]:
            return

        afk = _get_afk(message.guild.id)

        if str(message.author.id) in afk:
            del afk[str(message.author.id)]
            _save_afk(message.guild.id, afk)
            try:
                await message.reply("Welcome back! Your AFK status has been removed.", delete_after=5)
            except Exception:
                pass

        for m in message.mentions:
            if str(m.id) in afk:
                info = afk[str(m.id)]
                try:
                    afk_time = discord.utils.format_dt(datetime.fromisoformat(info["time"]), "R")
                    await message.reply(
                        f"**{m.display_name}** is AFK {afk_time}: *{info['reason']}*",
                        delete_after=10,
                    )
                except Exception:
                    pass

    @commands.command(name="timestamp")
    async def timestamp(self, ctx, date: str):
        try:
            dt = datetime.strptime(date, "%Y-%m-%d").replace(tzinfo=timezone.utc)
            ts = int(dt.timestamp())
            e = build(title="Timestamp", color=Config.COLOR_INFO, bot=self.bot)
            e.add_field(name="Input", value=date)
            e.add_field(name="Unix", value=f"`{ts}`")
            e.add_field(name="Short Date", value=discord.utils.format_dt(dt, "d"))
            e.add_field(name="Long Date+Time", value=discord.utils.format_dt(dt, "f"))
            e.add_field(name="Relative", value=discord.utils.format_dt(dt, "R"))
            await ctx.reply(embed=e)
        except ValueError:
            await ctx.reply("Invalid date format. Use `YYYY-MM-DD`.")

    @slash.command(name="timestamp", description="Get Unix timestamp for a date.")
    @app_commands.describe(date="Date in YYYY-MM-DD format")
    async def timestamp_slash(self, interaction: discord.Interaction, date: str):
        ctx = await commands.Context.from_interaction(interaction)
        await self.timestamp.callback(self, ctx, date)

    @commands.command(name="emojis")
    async def emojis(self, ctx):
        if not ctx.guild.emojis:
            return await ctx.reply("This server has no custom emojis.")
        pages = [ctx.guild.emojis[i:i+40] for i in range(0, len(ctx.guild.emojis), 40)]
        for page in pages[:2]:
            await ctx.reply(" ".join(str(e) for e in page))

    @slash.command(name="emojis", description="List all custom server emojis.")
    async def emojis_slash(self, interaction: discord.Interaction):
        ctx = await commands.Context.from_interaction(interaction)
        await self.emojis.callback(self, ctx)

    @commands.command(name="membercount")
    async def membercount(self, ctx):
        g = ctx.guild
        bots = sum(m.bot for m in g.members)
        humans = g.member_count - bots
        online = sum(m.status != discord.Status.offline and not m.bot for m in g.members)
        e = build(title=f"{g.name} Member Count", color=Config.COLOR_INFO, bot=self.bot)
        e.add_field(name="Humans", value=f"**{humans:,}**")
        e.add_field(name="Bots", value=f"**{bots:,}**")
        e.add_field(name="Online", value=f"**{online:,}**")
        e.add_field(name="Total", value=f"**{g.member_count:,}**", inline=False)
        if g.icon:
            e.set_thumbnail(url=g.icon.url)
        await ctx.reply(embed=e)

    @slash.command(name="membercount", description="Show the server member count breakdown.")
    async def membercount_slash(self, interaction: discord.Interaction):
        ctx = await commands.Context.from_interaction(interaction)
        await self.membercount.callback(self, ctx)

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            missing = ", ".join(p.replace("_", " ").title() for p in error.missing_permissions)
            try:
                await interaction.response.send_message(
                    f"❌ You are missing the following permissions: **{missing}**.",
                    ephemeral=True,
                )
            except discord.InteractionResponded:
                await interaction.followup.send(
                    f"❌ You are missing the following permissions: **{missing}**.",
                    ephemeral=True,
                )
        else:
            print(f"[Utility] Error: {error}")
            try:
                if interaction.response.is_done():
                    await interaction.followup.send(f"❌ An error occurred: {error}", ephemeral=True)
                else:
                    await interaction.response.send_message(f"❌ An error occurred: {error}", ephemeral=True)
            except:
                pass

async def setup(bot):
    await bot.add_cog(Utility(bot))
