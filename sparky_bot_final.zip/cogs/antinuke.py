import discord
from discord.ext import commands
from discord import app_commands
import asyncio
import json
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from config import Config
from utils.embed import build
from utils.theme import Theme
from utils.data import load, save

import logging
log = logging.getLogger("OmniBot")

ANTINUKE_FILE = "antinuke.json"

EVENT_CATEGORIES = {
    "critical": {
        "label": "🔴 Critical",
        "description": "Server-destroying events (ban, kick, prune, bot_add)",
        "default_threshold": 1,
        "enabled_by_default": True
    },
    "high": {
        "label": "🟠 High",
        "description": "High-risk events (role_dangerous, guild_update, webhook_create)",
        "default_threshold": 2,
        "enabled_by_default": True
    },
    "medium": {
        "label": "🟡 Medium",
        "description": "Moderate-risk events (channel_create, role_create, member_update)",
        "default_threshold": 3,
        "enabled_by_default": True
    },
    "low": {
        "label": "🟢 Low",
        "description": "Low-risk events (emoji_update, sticker_update)",
        "default_threshold": 5,
        "enabled_by_default": False
    }
}

EVENT_CONFIG = {
    "ban": {"category": "critical", "default_threshold": 1, "enabled_by_default": True},
    "kick": {"category": "critical", "default_threshold": 1, "enabled_by_default": True},
    "prune": {"category": "critical", "default_threshold": 1, "enabled_by_default": True},
    "bot_add": {"category": "critical", "default_threshold": 1, "enabled_by_default": True},
    "role_dangerous_perms": {"category": "high", "default_threshold": 2, "enabled_by_default": True},
    "guild_update": {"category": "high", "default_threshold": 2, "enabled_by_default": True},
    "webhook_create": {"category": "high", "default_threshold": 2, "enabled_by_default": True},
    "integration_add": {"category": "high", "default_threshold": 2, "enabled_by_default": True},
    "channel_create": {"category": "medium", "default_threshold": 3, "enabled_by_default": True},
    "channel_delete": {"category": "medium", "default_threshold": 3, "enabled_by_default": True},
    "channel_update": {"category": "medium", "default_threshold": 3, "enabled_by_default": True},
    "role_create": {"category": "medium", "default_threshold": 3, "enabled_by_default": True},
    "role_delete": {"category": "medium", "default_threshold": 3, "enabled_by_default": True},
    "role_update": {"category": "medium", "default_threshold": 3, "enabled_by_default": True},
    "webhook_update": {"category": "medium", "default_threshold": 3, "enabled_by_default": True},
    "webhook_delete": {"category": "medium", "default_threshold": 3, "enabled_by_default": True},
    "member_update": {"category": "medium", "default_threshold": 3, "enabled_by_default": True},
    "mention_everyone": {"category": "medium", "default_threshold": 3, "enabled_by_default": True},
    "member_dangerous_perms": {"category": "low", "default_threshold": 5, "enabled_by_default": False},
    "sticker_update": {"category": "low", "default_threshold": 5, "enabled_by_default": False},
    "emoji_update": {"category": "low", "default_threshold": 5, "enabled_by_default": False},
}

ALL_EVENTS = list(EVENT_CONFIG.keys())
EVENT_CATEGORY_NAMES = list(EVENT_CATEGORIES.keys())

def _antinuke_data(guild_id: int) -> dict:
    raw = load(ANTINUKE_FILE).get(str(guild_id), {})
    if isinstance(raw.get("whitelist"), list):
        raw["whitelist"] = {}
    defaults = {
        "enabled": False,
        "whitelist": {},
        "global_whitelist": [],
        "global_whitelist_roles": [],
        "role_whitelist": {},
        "owner_id": None,
        "forbidden_channels": [],
        "forbidden_categories": [],
        "punishment": "timeout",
        "duration": 60,
        "log_channel": None,
        "event_config": EVENT_CONFIG.copy(),
        "user_violations": {},
    }
    for key, default in defaults.items():
        if key not in raw:
            raw[key] = default
        elif key == "event_config" and isinstance(raw[key], dict):
            for event, config in EVENT_CONFIG.items():
                if event not in raw[key]:
                    raw[key][event] = config
                else:
                    for cfg_key, cfg_val in config.items():
                        if cfg_key not in raw[key][event]:
                            raw[key][event][cfg_key] = cfg_val
    if "thresholds" in raw:
        for event, threshold in raw["thresholds"].items():
            if event in raw["event_config"]:
                raw["event_config"][event]["custom_threshold"] = threshold
    return raw

def _save_antinuke(guild_id: int, data: dict):
    full = load(ANTINUKE_FILE)
    full[str(guild_id)] = data
    save(ANTINUKE_FILE, full)

def _is_whitelisted(guild_id: int, member: discord.Member = None, user_id: int = None, event: str = None) -> bool:
    data = _antinuke_data(guild_id)
    if member:
        if member.guild_permissions.administrator or member.guild_permissions.manage_guild:
            return True
        if member.id == member.guild.owner_id:
            return True
    if user_id and data.get("owner_id") == user_id:
        return True
    if user_id and user_id in data.get("global_whitelist", []):
        return True
    if user_id and event:
        per_event = data.get("whitelist", {})
        allowed_events = per_event.get(str(user_id), [])
        if event in allowed_events:
            return True
    if member:
        user_role_ids = [role.id for role in member.roles]
        global_roles = data.get("global_whitelist_roles", [])
        if any(role_id in global_roles for role_id in user_role_ids):
            return True
        if event:
            role_whitelist = data.get("role_whitelist", {})
            for role_id in user_role_ids:
                if str(role_id) in role_whitelist:
                    allowed_events = role_whitelist[str(role_id)]
                    if event in allowed_events:
                        return True
    return False

def _get_event_threshold(data: dict, event: str) -> int:
    config = data.get("event_config", {}).get(event, {})
    if "custom_threshold" in config:
        return config["custom_threshold"]
    return config.get("default_threshold", 3)

def _is_event_enabled(data: dict, event: str) -> bool:
    config = data.get("event_config", {}).get(event, {})
    return config.get("enabled", True)

PUNISHMENT_TYPES = {
    "warn": "Warn",
    "timeout": "Timeout",
    "strip_roles": "Strip Roles",
    "kick": "Kick",
    "softban": "Softban",
    "ban": "Ban",
}

PUNISHMENT_CHOICES = [
    app_commands.Choice(name="Warn", value="warn"),
    app_commands.Choice(name="Timeout", value="timeout"),
    app_commands.Choice(name="Strip Roles", value="strip_roles"),
    app_commands.Choice(name="Kick", value="kick"),
    app_commands.Choice(name="Softban", value="softban"),
    app_commands.Choice(name="Ban", value="ban"),
]

async def _apply_punishment(guild: discord.Guild, member: discord.Member, reason: str, data: dict):
    user_id = member.id
    violations = data.setdefault("user_violations", {})
    user_violations = violations.get(str(user_id), [])
    now = datetime.now(timezone.utc)
    recent_violations = [
        v for v in user_violations
        if (now - datetime.fromisoformat(v["time"])).total_seconds() < 86400
    ]
    violation_count = len(recent_violations) + 1
    punishment = data.get("punishment", "timeout")
    duration = data.get("duration", 60)
    action = None
    action_desc = None
    duration_minutes = 0

    if punishment == "warn":
        action = "Warn"
        action_desc = f"Warning issued"
        duration_minutes = 0
    elif punishment == "strip_roles":
        if violation_count == 1:
            action = "Strip Roles"
            action_desc = "All roles removed (except @everyone)"
            duration_minutes = 0
        elif violation_count == 2:
            action = "Kick"
            action_desc = "Kicked from server"
            duration_minutes = 0
        elif violation_count >= 3:
            action = "Ban"
            action_desc = "Banned from server"
            duration_minutes = 0
        else:
            action = "Strip Roles"
            action_desc = "All roles removed (except @everyone)"
            duration_minutes = 0
    elif punishment == "softban":
        if violation_count == 1:
            action = "Softban"
            action_desc = "Kicked and banned (messages deleted), then unbanned"
            duration_minutes = 0
        elif violation_count == 2:
            action = "Kick"
            action_desc = "Kicked from server"
            duration_minutes = 0
        elif violation_count >= 3:
            action = "Ban"
            action_desc = "Banned from server"
            duration_minutes = 0
        else:
            action = "Softban"
            action_desc = "Kicked and banned (messages deleted), then unbanned"
            duration_minutes = 0
    elif punishment == "ban":
        action = "Ban"
        action_desc = "Banned from server"
        duration_minutes = 0
    elif punishment == "kick":
        if violation_count == 1:
            action = "Kick"
            action_desc = "Kicked from server"
            duration_minutes = 0
        elif violation_count >= 2:
            action = "Ban"
            action_desc = "Banned from server"
            duration_minutes = 0
        else:
            action = "Kick"
            action_desc = "Kicked from server"
            duration_minutes = 0
    else:
        if violation_count == 1:
            action = "Timeout"
            duration_minutes = min(duration, 60)
            action_desc = f"Timeout for {duration_minutes} minutes"
        elif violation_count == 2:
            action = "Kick"
            duration_minutes = 0
            action_desc = "Kicked from server"
        elif violation_count >= 3:
            action = "Ban"
            duration_minutes = 0
            action_desc = "Banned from server"
        else:
            action = "Timeout"
            duration_minutes = min(duration, 60)
            action_desc = f"Timeout for {duration_minutes} minutes"

    violations[str(user_id)] = recent_violations + [{
        "time": now.isoformat(),
        "reason": reason,
        "action": action,
        "count": violation_count
    }]
    data["user_violations"] = violations
    _save_antinuke(guild.id, data)

    color = Config.COLOR_ERR if action in ["Ban", "Kick", "Softban"] else Config.COLOR_WARN
    embed = _mod_embed(
        f"🛡️ Anti-Nuke: {action}",
        f"**User:** {member.mention}\n"
        f"**Reason:** {reason}\n"
        f"**Action:** {action_desc}\n"
        f"**Violation Count:** {violation_count}",
        color
    )
    await _log_action(guild, data, embed)

    try:
        if action == "Ban":
            await member.ban(reason=f"Anti-nuke: {reason} ({violation_count} violations)")
        elif action == "Kick":
            await member.kick(reason=f"Anti-nuke: {reason} ({violation_count} violations)")
        elif action == "Softban":
            await member.ban(reason=f"Anti-nuke softban: {reason} ({violation_count} violations)", delete_message_days=1)
            await guild.unban(member.user, reason="Anti-nuke softban completed")
        elif action == "Strip Roles":
            roles_to_remove = [r for r in member.roles if r != guild.default_role]
            if roles_to_remove:
                await member.remove_roles(*roles_to_remove, reason=f"Anti-nuke: {reason}")
        elif action == "Warn":
            pass
        else:
            until = discord.utils.utcnow() + timedelta(minutes=duration_minutes)
            await member.timeout(until, reason=f"Anti-nuke: {reason} ({violation_count} violations)")
    except discord.Forbidden:
        log.error(f"Missing permissions to apply {action} to {member}")
        if action not in ["Warn"]:
            try:
                await _log_action(guild, data, _mod_embed(
                    "⚠️ Punishment Failed - Fallback: Warn",
                    f"**User:** {member.mention}\n**Original Action:** {action}\n**Reason:** Missing permissions",
                    Config.COLOR_WARN
                ))
            except:
                pass
    except Exception as e:
        log.error(f"Failed to apply punishment to {member}: {e}")

def _mod_embed(title: str, description: str, color=Config.COLOR_ERR) -> discord.Embed:
    return build(title=title, description=description, color=color)

async def _log_action(guild: discord.Guild, data: dict, embed: discord.Embed):
    log_ch_id = data.get("log_channel")
    if log_ch_id:
        ch = guild.get_channel(int(log_ch_id))
        if ch:
            try:
                await ch.send(embed=embed)
            except Exception:
                pass

class AntiNuke(commands.Cog):
    antinuke = app_commands.Group(name="antinuke", description="Anti-nuke protection commands")

    def __init__(self, bot):
        self.bot = bot
        self.cooldowns: dict[str, list[datetime]] = {}

    def _check_threshold(self, guild_id: int, user_id: int, event: str) -> bool:
        data = _antinuke_data(guild_id)
        if not data.get("enabled"):
            return False
        if not _is_event_enabled(data, event):
            return False
        guild = self.bot.get_guild(guild_id)
        member = guild.get_member(user_id) if guild else None
        if _is_whitelisted(guild_id, member=member, user_id=user_id, event=event):
            return False
        threshold = _get_event_threshold(data, event)
        now = datetime.now(timezone.utc)
        key = f"{guild_id}_{user_id}_{event}"
        times = self.cooldowns.get(key, [])
        times = [t for t in times if (now - t).total_seconds() < 60]
        times.append(now)
        self.cooldowns[key] = times
        if len(times) >= threshold:
            self.cooldowns[key] = []
            return True
        return False

    async def _handle_violation(self, guild: discord.Guild, user_id: int, event: str, reason: str):
        data = _antinuke_data(guild.id)
        member = guild.get_member(user_id)
        if not member:
            return
        if _is_whitelisted(guild.id, member=member, user_id=user_id, event=event):
            return
        await _apply_punishment(guild, member, reason, data)

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild:
            return
        if message.author.id == message.guild.owner_id:
            return
        data = _antinuke_data(message.guild.id)
        if not data.get("enabled"):
            return
        if message.channel.id in data.get("forbidden_channels", []):
            if _is_whitelisted(message.guild.id, member=message.author):
                return
            if message.channel.category_id in data.get("forbidden_categories", []):
                return
            await self._handle_violation(
                message.guild,
                message.author.id,
                "forbidden_channel",
                f"Sending message in forbidden channel {message.channel.mention}"
            )
            try:
                await message.delete()
            except Exception:
                pass
            return
        if message.mention_everyone:
            if self._check_threshold(message.guild.id, message.author.id, "mention_everyone"):
                await self._handle_violation(
                    message.guild,
                    message.author.id,
                    "mention_everyone",
                    "@everyone mention detected"
                )

    @commands.Cog.listener()
    async def on_member_ban(self, guild: discord.Guild, user: discord.User):
        await asyncio.sleep(0.5)
        try:
            async for entry in guild.audit_logs(limit=1, action=discord.AuditLogAction.ban):
                if entry.user and entry.user.id != self.bot.user.id:
                    if self._check_threshold(guild.id, entry.user.id, "ban"):
                        await self._handle_violation(guild, entry.user.id, "ban", "Mass banning detected")
                break
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        await asyncio.sleep(0.5)
        try:
            async for entry in member.guild.audit_logs(limit=1, action=discord.AuditLogAction.kick):
                if entry.user and entry.target and entry.target.id == member.id:
                    if entry.user.id != self.bot.user.id:
                        if self._check_threshold(member.guild.id, entry.user.id, "kick"):
                            await self._handle_violation(member.guild, entry.user.id, "kick", "Mass kicking detected")
                    break
        except Exception:
            pass
        try:
            async for entry in member.guild.audit_logs(limit=1, action=discord.AuditLogAction.member_prune):
                if entry.user and entry.user.id != self.bot.user.id:
                    if self._check_threshold(member.guild.id, entry.user.id, "prune"):
                        await self._handle_violation(member.guild, entry.user.id, "prune", "Mass prune detected")
                break
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        if not member.bot:
            return
        await asyncio.sleep(0.5)
        try:
            async for entry in member.guild.audit_logs(limit=1, action=discord.AuditLogAction.bot_add):
                if entry.user and entry.user.id != self.bot.user.id:
                    if self._check_threshold(member.guild.id, entry.user.id, "bot_add"):
                        try:
                            await member.ban(reason="Anti-nuke: Unauthorized bot added")
                        except Exception:
                            pass
                        await self._handle_violation(member.guild, entry.user.id, "bot_add", "Unauthorized bot added")
                break
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_guild_update(self, before: discord.Guild, after: discord.Guild):
        await asyncio.sleep(0.5)
        try:
            async for entry in after.audit_logs(limit=1, action=discord.AuditLogAction.guild_update):
                if entry.user and entry.user.id != self.bot.user.id:
                    if self._check_threshold(after.id, entry.user.id, "guild_update"):
                        try:
                            if before.name != after.name:
                                await after.edit(name=before.name)
                            if before.icon and before.icon != after.icon:
                                await after.edit(icon=await before.icon.read())
                        except Exception:
                            pass
                        await self._handle_violation(after, entry.user.id, "guild_update", "Server settings changed")
                break
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel: discord.abc.GuildChannel):
        await asyncio.sleep(0.5)
        try:
            async for entry in channel.guild.audit_logs(limit=1, action=discord.AuditLogAction.channel_create):
                if entry.user and entry.user.id != self.bot.user.id:
                    if self._check_threshold(channel.guild.id, entry.user.id, "channel_create"):
                        try:
                            await channel.delete()
                        except Exception:
                            pass
                        await self._handle_violation(channel.guild, entry.user.id, "channel_create", "Unauthorized channel created")
                break
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel: discord.abc.GuildChannel):
        await asyncio.sleep(0.5)
        try:
            async for entry in channel.guild.audit_logs(limit=1, action=discord.AuditLogAction.channel_delete):
                if entry.user and entry.user.id != self.bot.user.id:
                    if self._check_threshold(channel.guild.id, entry.user.id, "channel_delete"):
                        await self._handle_violation(channel.guild, entry.user.id, "channel_delete", "Channel deleted")
                break
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_guild_channel_update(self, before: discord.abc.GuildChannel, after: discord.abc.GuildChannel):
        await asyncio.sleep(0.5)
        try:
            async for entry in after.guild.audit_logs(limit=1, action=discord.AuditLogAction.channel_update):
                if entry.user and entry.user.id != self.bot.user.id:
                    if self._check_threshold(after.guild.id, entry.user.id, "channel_update"):
                        await self._handle_violation(after.guild, entry.user.id, "channel_update", "Channel settings modified")
                break
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_guild_role_create(self, role: discord.Role):
        await asyncio.sleep(0.5)
        try:
            async for entry in role.guild.audit_logs(limit=1, action=discord.AuditLogAction.role_create):
                if entry.user and entry.user.id != self.bot.user.id:
                    if self._check_threshold(role.guild.id, entry.user.id, "role_create"):
                        try:
                            await role.delete()
                        except Exception:
                            pass
                        await self._handle_violation(role.guild, entry.user.id, "role_create", "Unauthorized role created")
                break
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role: discord.Role):
        await asyncio.sleep(0.5)
        try:
            async for entry in role.guild.audit_logs(limit=1, action=discord.AuditLogAction.role_delete):
                if entry.user and entry.user.id != self.bot.user.id:
                    if self._check_threshold(role.guild.id, entry.user.id, "role_delete"):
                        await self._handle_violation(role.guild, entry.user.id, "role_delete", "Role deleted")
                break
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_guild_role_update(self, before: discord.Role, after: discord.Role):
        await asyncio.sleep(0.5)
        try:
            async for entry in after.guild.audit_logs(limit=1, action=discord.AuditLogAction.role_update):
                if entry.user and entry.user.id != self.bot.user.id:
                    new_perms = set([p for p, v in after.permissions if v])
                    for perm in [
                        "administrator", "ban_members", "kick_members", "manage_guild",
                        "manage_channels", "manage_roles", "manage_webhooks", "manage_emojis",
                        "manage_nicknames", "moderate_members", "mention_everyone"
                    ]:
                        if perm in new_perms and perm not in set([p for p, v in before.permissions if v]):
                            if self._check_threshold(after.guild.id, entry.user.id, "role_dangerous_perms"):
                                try:
                                    await after.edit(permissions=before.permissions)
                                except Exception:
                                    pass
                                await self._handle_violation(
                                    after.guild, entry.user.id, "role_dangerous_perms",
                                    f"Dangerous permission added: {perm}"
                                )
                                return
                    if self._check_threshold(after.guild.id, entry.user.id, "role_update"):
                        await self._handle_violation(after.guild, entry.user.id, "role_update", "Role modified")
                break
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_webhooks_update(self, channel: discord.abc.GuildChannel):
        await asyncio.sleep(0.5)
        try:
            async for entry in channel.guild.audit_logs(limit=1, action=discord.AuditLogAction.webhook_create):
                if entry.user and entry.user.id != self.bot.user.id:
                    if self._check_threshold(channel.guild.id, entry.user.id, "webhook_create"):
                        webhooks = await channel.webhooks()
                        for wh in webhooks:
                            try:
                                await wh.delete()
                            except Exception:
                                pass
                        await self._handle_violation(channel.guild, entry.user.id, "webhook_create", "Unauthorized webhook created")
                break
        except Exception:
            pass
        try:
            async for entry in channel.guild.audit_logs(limit=1, action=discord.AuditLogAction.webhook_update):
                if entry.user and entry.user.id != self.bot.user.id:
                    if self._check_threshold(channel.guild.id, entry.user.id, "webhook_update"):
                        await self._handle_violation(channel.guild, entry.user.id, "webhook_update", "Webhook modified")
                break
        except Exception:
            pass
        try:
            async for entry in channel.guild.audit_logs(limit=1, action=discord.AuditLogAction.webhook_delete):
                if entry.user and entry.user.id != self.bot.user.id:
                    if self._check_threshold(channel.guild.id, entry.user.id, "webhook_delete"):
                        await self._handle_violation(channel.guild, entry.user.id, "webhook_delete", "Webhook deleted")
                break
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_member_update(self, before: discord.Member, after: discord.Member):
        await asyncio.sleep(0.5)
        try:
            async for entry in after.guild.audit_logs(limit=1, action=discord.AuditLogAction.member_update):
                if entry.user and entry.user.id != self.bot.user.id:
                    new_roles = set(after.roles) - set(before.roles)
                    for role in new_roles:
                        if any(getattr(role.permissions, p, False) for p in [
                            "administrator", "ban_members", "kick_members", "manage_guild",
                            "manage_channels", "manage_roles", "manage_webhooks"
                        ]):
                            if self._check_threshold(after.guild.id, entry.user.id, "member_dangerous_perms"):
                                try:
                                    await after.remove_roles(role)
                                except Exception:
                                    pass
                                await self._handle_violation(
                                    after.guild, entry.user.id, "member_dangerous_perms",
                                    f"Dangerous role given to {after.display_name}: {role.name}"
                                )
                                return
                    if self._check_threshold(after.guild.id, entry.user.id, "member_update"):
                        await self._handle_violation(after.guild, entry.user.id, "member_update", f"Member updated: {after.display_name}")
                break
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_guild_integrations_update(self, guild: discord.Guild):
        await asyncio.sleep(0.5)
        try:
            async for entry in guild.audit_logs(limit=1, action=discord.AuditLogAction.integration_create):
                if entry.user and entry.user.id != self.bot.user.id:
                    if self._check_threshold(guild.id, entry.user.id, "integration_add"):
                        await self._handle_violation(guild, entry.user.id, "integration_add", "Unauthorized integration added")
                break
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_guild_stickers_update(self, guild: discord.Guild, before, after):
        if not _is_event_enabled(_antinuke_data(guild.id), "sticker_update"):
            return
        await asyncio.sleep(0.5)
        try:
            async for entry in guild.audit_logs(limit=1, action=discord.AuditLogAction.sticker_create):
                if entry.user and entry.user.id != self.bot.user.id:
                    if self._check_threshold(guild.id, entry.user.id, "sticker_update"):
                        await self._handle_violation(guild, entry.user.id, "sticker_update", "Sticker modified")
                break
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_guild_emojis_update(self, guild: discord.Guild, before, after):
        if not _is_event_enabled(_antinuke_data(guild.id), "emoji_update"):
            return
        await asyncio.sleep(0.5)
        try:
            async for entry in guild.audit_logs(limit=1, action=discord.AuditLogAction.emoji_create):
                if entry.user and entry.user.id != self.bot.user.id:
                    if self._check_threshold(guild.id, entry.user.id, "emoji_update"):
                        await self._handle_violation(guild, entry.user.id, "emoji_update", "Emoji modified")
                break
        except Exception:
            pass

    # ========== SLASH COMMANDS ==========
    @antinuke.command(name="enable", description="Enable anti-nuke protection.")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def enable(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        data = _antinuke_data(interaction.guild.id)
        data["enabled"] = True
        data["owner_id"] = interaction.guild.owner_id
        _save_antinuke(interaction.guild.id, data)
        await interaction.followup.send("🛡️ Anti-nuke **enabled**.", ephemeral=True)

    @antinuke.command(name="disable", description="Disable anti-nuke protection.")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def disable(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        data = _antinuke_data(interaction.guild.id)
        data["enabled"] = False
        _save_antinuke(interaction.guild.id, data)
        await interaction.followup.send("🛡️ Anti-nuke **disabled**.", ephemeral=True)

    @antinuke.command(name="status", description="View current anti-nuke settings.")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def status(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        data = _antinuke_data(interaction.guild.id)
        lines = [
            f"**Enabled:** {data.get('enabled', False)}",
            f"**Default Punishment:** {data.get('punishment', 'timeout')}",
            f"**Default Duration:** {data.get('duration', 60)} minutes",
            "",
            "**Event Status:**",
        ]
        for category in EVENT_CATEGORY_NAMES:
            cat_info = EVENT_CATEGORIES[category]
            events = [e for e, c in EVENT_CONFIG.items() if c["category"] == category]
            enabled = sum(1 for e in events if _is_event_enabled(data, e))
            lines.append(f"{cat_info['label']}: {enabled}/{len(events)} enabled")
        lines.append("")
        lines.append(f"**Whitelisted Users:** {len(data.get('global_whitelist', []))}")
        lines.append(f"**Whitelisted Roles:** {len(data.get('global_whitelist_roles', []))}")
        lines.append(f"**Forbidden Channels:** {len(data.get('forbidden_channels', []))}")
        lines.append(f"**Forbidden Categories:** {len(data.get('forbidden_categories', []))}")
        embed = build(title="🛡️ Anti-Nuke Status", description="\n".join(lines), color=Config.COLOR_INFO, bot=self.bot)
        await interaction.followup.send(embed=embed, ephemeral=True)

    @antinuke.command(name="punishment", description="Set default punishment type and duration.")
    @app_commands.describe(action="Default punishment type", duration="Duration in minutes for timeout (0 for default)")
    @app_commands.choices(action=PUNISHMENT_CHOICES)
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def punishment(self, interaction: discord.Interaction, action: str, duration: int = 60):
        await interaction.response.defer(ephemeral=True)
        if action not in PUNISHMENT_TYPES:
            return await interaction.followup.send(f"❌ Invalid punishment type.", ephemeral=True)
        data = _antinuke_data(interaction.guild.id)
        data["punishment"] = action
        data["duration"] = duration if duration > 0 else 60
        _save_antinuke(interaction.guild.id, data)
        punishment_name = PUNISHMENT_TYPES.get(action, action)
        await interaction.followup.send(f"Default punishment: **{punishment_name}** ({duration if duration > 0 else 60} min)", ephemeral=True)

    @antinuke.command(name="setlog", description="Set anti-nuke log channel.")
    @app_commands.describe(channel="Log channel")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def setlog(self, interaction: discord.Interaction, channel: discord.TextChannel):
        data = _antinuke_data(interaction.guild.id)
        data["log_channel"] = channel.id
        _save_antinuke(interaction.guild.id, data)
        await interaction.response.send_message(f"Logs → {channel.mention}.", ephemeral=True)

    @antinuke.command(name="punishmentinfo", description="View detailed punishment escalation info.")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def punishment_info(self, interaction: discord.Interaction):
        data = _antinuke_data(interaction.guild.id)
        punishment = data.get("punishment", "timeout")
        punishment_name = PUNISHMENT_TYPES.get(punishment, punishment)
        duration = data.get("duration", 60)
        escalation_map = {
            "warn": [
                "1st offense: ⚠️ **Warn**",
                "2nd offense: ⚠️ **Warn**",
                "3rd+ offense: ⚠️ **Warn**",
            ],
            "strip_roles": [
                "1st offense: 🗑️ **Strip Roles** (all roles removed)",
                "2nd offense: 👢 **Kick**",
                "3rd+ offense: 🔨 **Ban**",
            ],
            "softban": [
                "1st offense: 🔄 **Softban** (ban + unban, messages deleted)",
                "2nd offense: 👢 **Kick**",
                "3rd+ offense: 🔨 **Ban**",
            ],
            "kick": [
                "1st offense: 👢 **Kick**",
                "2nd+ offense: 🔨 **Ban**",
            ],
            "ban": [
                "All offenses: 🔨 **Ban**",
            ],
            "timeout": [
                f"1st offense: ⏰ **Timeout** ({min(duration, 60)} minutes)",
                "2nd offense: 👢 **Kick**",
                "3rd+ offense: 🔨 **Ban**",
            ],
        }
        escalation = escalation_map.get(punishment, escalation_map["timeout"])
        embed = build(title=f"📋 Punishment Escalation: {punishment_name}", description="\n".join(escalation), color=Config.COLOR_INFO, bot=self.bot)
        embed.set_footer(text="Violations are tracked per user over a 24-hour period")
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @antinuke.command(name="eventconfig", description="Configure a specific event.")
    @app_commands.describe(event="Event to configure", enabled="Enable or disable this event", threshold="Number of events in 60 seconds to trigger (1-50)")
    @app_commands.choices(event=[app_commands.Choice(name=e.replace("_", " ").title(), value=e) for e in ALL_EVENTS])
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def eventconfig(self, interaction: discord.Interaction, event: str, enabled: bool = None, threshold: int = None):
        await interaction.response.defer(ephemeral=True)
        if event not in ALL_EVENTS:
            return await interaction.followup.send(f"❌ Invalid event. Choose from: {', '.join(ALL_EVENTS)}", ephemeral=True)
        data = _antinuke_data(interaction.guild.id)
        config = data.setdefault("event_config", {}).setdefault(event, EVENT_CONFIG[event].copy())
        if enabled is not None:
            config["enabled"] = enabled
        if threshold is not None:
            if threshold < 1 or threshold > 50:
                return await interaction.followup.send("❌ Threshold must be between 1 and 50.", ephemeral=True)
            config["custom_threshold"] = threshold
        data["event_config"][event] = config
        _save_antinuke(interaction.guild.id, data)
        status = "enabled" if config.get("enabled", True) else "disabled"
        thresh = config.get("custom_threshold", config.get("default_threshold", 3))
        await interaction.followup.send(f"**{event.replace('_', ' ').title()}** → {status} (threshold: {thresh})", ephemeral=True)

    @antinuke.command(name="eventlist", description="List all events and their status.")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def eventlist(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        data = _antinuke_data(interaction.guild.id)
        embed = build(title="📋 Anti-Nuke Events", color=Config.COLOR_INFO, bot=self.bot)
        for category in EVENT_CATEGORY_NAMES:
            cat_info = EVENT_CATEGORIES[category]
            events = [e for e, c in EVENT_CONFIG.items() if c["category"] == category]
            lines = []
            for event in events:
                config = data.get("event_config", {}).get(event, EVENT_CONFIG[event])
                status = "✅" if config.get("enabled", True) else "❌"
                thresh = config.get("custom_threshold", config.get("default_threshold", 3))
                lines.append(f"{status} `{event}` (threshold: {thresh})")
            embed.add_field(name=f"{cat_info['label']} {cat_info['description']}", value="\n".join(lines) if lines else "No events", inline=False)
        await interaction.followup.send(embed=embed, ephemeral=True)

    @antinuke.command(name="whitelist", description="Add or remove a user from the whitelist.")
    @app_commands.describe(user="User to whitelist or remove", action="Add or remove")
    @app_commands.choices(action=[app_commands.Choice(name="Add", value="add"), app_commands.Choice(name="Remove", value="remove")])
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def whitelist(self, interaction: discord.Interaction, user: discord.User, action: str):
        data = _antinuke_data(interaction.guild.id)
        if action == "remove":
            global_wl = data.setdefault("global_whitelist", [])
            per_event = data.setdefault("whitelist", {})
            removed = False
            if user.id in global_wl:
                global_wl.remove(user.id)
                removed = True
            if str(user.id) in per_event:
                del per_event[str(user.id)]
                removed = True
            if not removed:
                return await interaction.response.send_message(f"{user.mention} is not whitelisted.", ephemeral=True)
            _save_antinuke(interaction.guild.id, data)
            return await interaction.response.send_message(f"✅ {user.mention} removed from all whitelists.", ephemeral=True)
        await interaction.response.send_message(f"Select the events to whitelist **{user.mention}** for.\nYou can pick multiple. Choose **🌐 Global Whitelist** to exempt them from everything.", view=WhitelistEventView(user), ephemeral=True)

    @antinuke.command(name="whitelistinfo", description="View whitelist status for a user.")
    @app_commands.describe(user="User to check")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def whitelistinfo(self, interaction: discord.Interaction, user: discord.User):
        await interaction.response.defer(ephemeral=True)
        data = _antinuke_data(interaction.guild.id)
        global_wl = data.get("global_whitelist", [])
        per_event = data.get("whitelist", {})
        lines = [f"**{user.mention}**"]
        if user.id == interaction.guild.owner_id:
            lines.append("• Server Owner • fully whitelisted")
        elif user.id in global_wl:
            lines.append("• Global whitelist • all events")
        elif str(user.id) in per_event:
            events = per_event[str(user.id)]
            lines.append(f"• Per-event whitelist: **{', '.join(events)}**")
        else:
            lines.append("• Not whitelisted")
        await interaction.followup.send("\n".join(lines), ephemeral=True)

    @antinuke.command(name="whitelistrole", description="Add or remove a role from the whitelist.")
    @app_commands.describe(role="The role to whitelist or remove", action="Add or remove the role from whitelist")
    @app_commands.choices(action=[app_commands.Choice(name="Add", value="add"), app_commands.Choice(name="Remove", value="remove")])
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def whitelistrole(self, interaction: discord.Interaction, role: discord.Role, action: str):
        data = _antinuke_data(interaction.guild.id)
        if action == "remove":
            global_roles = data.setdefault("global_whitelist_roles", [])
            per_event = data.setdefault("role_whitelist", {})
            removed = False
            if role.id in global_roles:
                global_roles.remove(role.id)
                removed = True
            if str(role.id) in per_event:
                del per_event[str(role.id)]
                removed = True
            if not removed:
                return await interaction.response.send_message(f"{role.mention} is not whitelisted.", ephemeral=True)
            _save_antinuke(interaction.guild.id, data)
            return await interaction.response.send_message(f"✅ {role.mention} removed from all whitelists.", ephemeral=True)
        await interaction.response.send_message(f"Select the events to whitelist **{role.mention}** for.\nYou can pick multiple. Choose **🌐 Global Role Whitelist** to exempt them from everything.", view=WhitelistRoleView(role), ephemeral=True)

    @antinuke.command(name="whitelistroleinfo", description="View whitelist status for a role.")
    @app_commands.describe(role="Role to check")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def whitelistroleinfo(self, interaction: discord.Interaction, role: discord.Role):
        await interaction.response.defer(ephemeral=True)
        data = _antinuke_data(interaction.guild.id)
        global_roles = data.get("global_whitelist_roles", [])
        per_event = data.get("role_whitelist", {})
        lines = [f"**{role.mention}**"]
        if role.id in global_roles:
            lines.append("• Global whitelist • all events")
        elif str(role.id) in per_event:
            events = per_event[str(role.id)]
            lines.append(f"• Per-event whitelist: **{', '.join(events)}**")
        else:
            lines.append("• Not whitelisted")
        await interaction.followup.send("\n".join(lines), ephemeral=True)

    @antinuke.command(name="whitelistroles", description="List all whitelisted roles.")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def whitelistroles(self, interaction: discord.Interaction):
        data = _antinuke_data(interaction.guild.id)
        global_roles = data.get("global_whitelist_roles", [])
        per_event = data.get("role_whitelist", {})
        all_whitelisted_roles = set(global_roles)
        for role_id in per_event.keys():
            all_whitelisted_roles.add(int(role_id))
        if not all_whitelisted_roles:
            await interaction.response.send_message("ℹ️ No roles are whitelisted from antinuke.", ephemeral=True)
            return
        role_mentions = []
        for role_id in all_whitelisted_roles:
            role = interaction.guild.get_role(int(role_id))
            if role:
                if role_id in global_roles:
                    role_mentions.append(f"🌐 {role.mention} (Global)")
                else:
                    events = per_event.get(str(role_id), [])
                    event_list = ", ".join(e.replace("_", " ").title() for e in events)
                    role_mentions.append(f"📋 {role.mention} ({event_list})")
            else:
                role_mentions.append(f"Deleted Role (`{role_id}`)")
        embed = build(title="🛡️ Whitelisted Roles", description="\n".join(role_mentions), color=Config.COLOR_INFO, bot=self.bot)
        embed.set_footer(text=f"{len(role_mentions)} role(s) whitelisted")
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @antinuke.command(name="forbidchannel", description="Add/remove a forbidden channel.")
    @app_commands.describe(channel="Channel", action="Add or remove")
    @app_commands.choices(action=[app_commands.Choice(name="Add", value="add"), app_commands.Choice(name="Remove", value="remove")])
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def forbidchannel(self, interaction: discord.Interaction, channel: discord.TextChannel, action: str):
        data = _antinuke_data(interaction.guild.id)
        forbidden = data.setdefault("forbidden_channels", [])
        if action == "add":
            if channel.id in forbidden:
                return await interaction.response.send_message(f"{channel.mention} already forbidden.", ephemeral=True)
            forbidden.append(channel.id)
            _save_antinuke(interaction.guild.id, data)
            await interaction.response.send_message(f"🚫 {channel.mention} forbidden.", ephemeral=True)
        else:
            if channel.id not in forbidden:
                return await interaction.response.send_message(f"{channel.mention} not forbidden.", ephemeral=True)
            forbidden.remove(channel.id)
            _save_antinuke(interaction.guild.id, data)
            await interaction.response.send_message(f"✅ {channel.mention} no longer forbidden.", ephemeral=True)

    @antinuke.command(name="forbidcategory", description="Add/remove a forbidden category.")
    @app_commands.describe(category="Category", action="Add or remove")
    @app_commands.choices(action=[app_commands.Choice(name="Add", value="add"), app_commands.Choice(name="Remove", value="remove")])
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def forbidcategory(self, interaction: discord.Interaction, category: discord.CategoryChannel, action: str):
        data = _antinuke_data(interaction.guild.id)
        forbidden = data.setdefault("forbidden_categories", [])
        if action == "add":
            if category.id in forbidden:
                return await interaction.response.send_message(f"{category.name} already forbidden.", ephemeral=True)
            forbidden.append(category.id)
            _save_antinuke(interaction.guild.id, data)
            await interaction.response.send_message(f"🚫 Category **{category.name}** forbidden.", ephemeral=True)
        else:
            if category.id not in forbidden:
                return await interaction.response.send_message(f"{category.name} not forbidden.", ephemeral=True)
            forbidden.remove(category.id)
            _save_antinuke(interaction.guild.id, data)
            await interaction.response.send_message(f"✅ Category **{category.name}** no longer forbidden.", ephemeral=True)

    @antinuke.command(name="violations", description="View violations for a user.")
    @app_commands.describe(user="User to check")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def violations(self, interaction: discord.Interaction, user: discord.Member):
        await interaction.response.defer(ephemeral=True)
        data = _antinuke_data(interaction.guild.id)
        user_violations = data.get("user_violations", {}).get(str(user.id), [])
        if not user_violations:
            return await interaction.followup.send(f"✅ {user.mention} has no violations.", ephemeral=True)
        recent = user_violations[-10:]
        lines = []
        for v in reversed(recent):
            time = datetime.fromisoformat(v["time"]).strftime("%Y-%m-%d %H:%M")
            lines.append(f"• {time} • **{v['action']}** • {v['reason'][:50]}")
        embed = build(title=f"🚨 Violations for {user.display_name}", description="\n".join(lines), color=Config.COLOR_WARN, bot=self.bot)
        embed.set_footer(text=f"{len(user_violations)} total violations")
        await interaction.followup.send(embed=embed, ephemeral=True)

    @antinuke.command(name="clearviolations", description="Clear violations for a user.")
    @app_commands.describe(user="User to clear violations for")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def clearviolations(self, interaction: discord.Interaction, user: discord.Member):
        data = _antinuke_data(interaction.guild.id)
        violations = data.get("user_violations", {})
        if str(user.id) in violations:
            del violations[str(user.id)]
            data["user_violations"] = violations
            _save_antinuke(interaction.guild.id, data)
            await interaction.response.send_message(f"✅ Cleared violations for {user.mention}.", ephemeral=True)
        else:
            await interaction.response.send_message(f"ℹ️ {user.mention} has no violations.", ephemeral=True)

    # ========== PREFIX COMMANDS ==========
    @commands.command(name="antinuke")
    @commands.has_permissions(administrator=True)
    async def p_antinuke(self, ctx, action: str = None):
        if not action:
            return await ctx.reply("Usage: `//antinuke enable|disable|status|punishment|setlog|...`")
        # Route to appropriate subcommand
        if action.lower() == "enable":
            await self.enable.callback(self, await commands.Context.from_interaction(ctx))
        elif action.lower() == "disable":
            await self.disable.callback(self, await commands.Context.from_interaction(ctx))
        elif action.lower() == "status":
            await self.status.callback(self, await commands.Context.from_interaction(ctx))
        elif action.lower() == "punishmentinfo":
            await self.punishment_info.callback(self, await commands.Context.from_interaction(ctx))
        elif action.lower() == "eventlist":
            await self.eventlist.callback(self, await commands.Context.from_interaction(ctx))
        elif action.lower() == "whitelistroles":
            await self.whitelistroles.callback(self, await commands.Context.from_interaction(ctx))
        else:
            await ctx.reply(f"❌ Unknown action `{action}`. Available: enable, disable, status, punishmentinfo, eventlist, whitelistroles")

    @commands.command(name="antinuke_punishment")
    @commands.has_permissions(administrator=True)
    async def p_punishment(self, ctx, action: str, duration: int = 60):
        if action not in PUNISHMENT_TYPES:
            return await ctx.reply(f"❌ Invalid punishment. Choose from: {', '.join(PUNISHMENT_TYPES.keys())}")
        data = _antinuke_data(ctx.guild.id)
        data["punishment"] = action
        data["duration"] = duration if duration > 0 else 60
        _save_antinuke(ctx.guild.id, data)
        punishment_name = PUNISHMENT_TYPES.get(action, action)
        await ctx.reply(f"Default punishment: **{punishment_name}** ({duration if duration > 0 else 60} min)")

    @commands.command(name="antinuke_setlog")
    @commands.has_permissions(administrator=True)
    async def p_setlog(self, ctx, channel: discord.TextChannel):
        data = _antinuke_data(ctx.guild.id)
        data["log_channel"] = channel.id
        _save_antinuke(ctx.guild.id, data)
        await ctx.reply(f"Logs → {channel.mention}.")

    @commands.command(name="antinuke_eventconfig")
    @commands.has_permissions(administrator=True)
    async def p_eventconfig(self, ctx, event: str, enabled: bool = None, threshold: int = None):
        if event not in ALL_EVENTS:
            return await ctx.reply(f"❌ Invalid event. Available: {', '.join(ALL_EVENTS)}")
        data = _antinuke_data(ctx.guild.id)
        config = data.setdefault("event_config", {}).setdefault(event, EVENT_CONFIG[event].copy())
        if enabled is not None:
            config["enabled"] = enabled
        if threshold is not None:
            if threshold < 1 or threshold > 50:
                return await ctx.reply("❌ Threshold must be between 1 and 50.")
            config["custom_threshold"] = threshold
        data["event_config"][event] = config
        _save_antinuke(ctx.guild.id, data)
        status = "enabled" if config.get("enabled", True) else "disabled"
        thresh = config.get("custom_threshold", config.get("default_threshold", 3))
        await ctx.reply(f"**{event.replace('_', ' ').title()}** → {status} (threshold: {thresh})")

    @commands.command(name="antinuke_whitelist")
    @commands.has_permissions(administrator=True)
    async def p_whitelist(self, ctx, user: discord.User, action: str):
        data = _antinuke_data(ctx.guild.id)
        if action.lower() == "remove":
            global_wl = data.setdefault("global_whitelist", [])
            per_event = data.setdefault("whitelist", {})
            removed = False
            if user.id in global_wl:
                global_wl.remove(user.id)
                removed = True
            if str(user.id) in per_event:
                del per_event[str(user.id)]
                removed = True
            if not removed:
                return await ctx.reply(f"{user.mention} is not whitelisted.")
            _save_antinuke(ctx.guild.id, data)
            return await ctx.reply(f"✅ {user.mention} removed from all whitelists.")
        elif action.lower() == "add":
            await ctx.reply(f"Please use the slash command `/antinuke whitelist` to select events via dropdown.")
        else:
            await ctx.reply("Usage: `//antinuke_whitelist @user add|remove`")

    @commands.command(name="antinuke_whitelistrole")
    @commands.has_permissions(administrator=True)
    async def p_whitelistrole(self, ctx, role: discord.Role, action: str):
        data = _antinuke_data(ctx.guild.id)
        if action.lower() == "remove":
            global_roles = data.setdefault("global_whitelist_roles", [])
            per_event = data.setdefault("role_whitelist", {})
            removed = False
            if role.id in global_roles:
                global_roles.remove(role.id)
                removed = True
            if str(role.id) in per_event:
                del per_event[str(role.id)]
                removed = True
            if not removed:
                return await ctx.reply(f"{role.mention} is not whitelisted.")
            _save_antinuke(ctx.guild.id, data)
            return await ctx.reply(f"✅ {role.mention} removed from all whitelists.")
        elif action.lower() == "add":
            await ctx.reply(f"Please use the slash command `/antinuke whitelistrole` to select events via dropdown.")
        else:
            await ctx.reply("Usage: `//antinuke_whitelistrole @role add|remove`")

    @commands.command(name="antinuke_forbidchannel")
    @commands.has_permissions(administrator=True)
    async def p_forbidchannel(self, ctx, channel: discord.TextChannel, action: str):
        data = _antinuke_data(ctx.guild.id)
        forbidden = data.setdefault("forbidden_channels", [])
        if action.lower() == "add":
            if channel.id in forbidden:
                return await ctx.reply(f"{channel.mention} already forbidden.")
            forbidden.append(channel.id)
            _save_antinuke(ctx.guild.id, data)
            await ctx.reply(f"🚫 {channel.mention} forbidden.")
        elif action.lower() == "remove":
            if channel.id not in forbidden:
                return await ctx.reply(f"{channel.mention} not forbidden.")
            forbidden.remove(channel.id)
            _save_antinuke(ctx.guild.id, data)
            await ctx.reply(f"✅ {channel.mention} no longer forbidden.")
        else:
            await ctx.reply("Usage: `//antinuke_forbidchannel #channel add|remove`")

    @commands.command(name="antinuke_forbidcategory")
    @commands.has_permissions(administrator=True)
    async def p_forbidcategory(self, ctx, category: discord.CategoryChannel, action: str):
        data = _antinuke_data(ctx.guild.id)
        forbidden = data.setdefault("forbidden_categories", [])
        if action.lower() == "add":
            if category.id in forbidden:
                return await ctx.reply(f"{category.name} already forbidden.")
            forbidden.append(category.id)
            _save_antinuke(ctx.guild.id, data)
            await ctx.reply(f"🚫 Category **{category.name}** forbidden.")
        elif action.lower() == "remove":
            if category.id not in forbidden:
                return await ctx.reply(f"{category.name} not forbidden.")
            forbidden.remove(category.id)
            _save_antinuke(ctx.guild.id, data)
            await ctx.reply(f"✅ Category **{category.name}** no longer forbidden.")
        else:
            await ctx.reply("Usage: `//antinuke_forbidcategory #category add|remove`")

    @commands.command(name="antinuke_violations")
    @commands.has_permissions(manage_guild=True)
    async def p_violations(self, ctx, user: discord.Member):
        data = _antinuke_data(ctx.guild.id)
        user_violations = data.get("user_violations", {}).get(str(user.id), [])
        if not user_violations:
            return await ctx.reply(f"✅ {user.mention} has no violations.")
        recent = user_violations[-10:]
        lines = []
        for v in reversed(recent):
            time = datetime.fromisoformat(v["time"]).strftime("%Y-%m-%d %H:%M")
            lines.append(f"• {time} • **{v['action']}** • {v['reason'][:50]}")
        embed = build(title=f"🚨 Violations for {user.display_name}", description="\n".join(lines), color=Config.COLOR_WARN, bot=self.bot)
        embed.set_footer(text=f"{len(user_violations)} total violations")
        await ctx.reply(embed=embed)

    @commands.command(name="antinuke_clearviolations")
    @commands.has_permissions(administrator=True)
    async def p_clearviolations(self, ctx, user: discord.Member):
        data = _antinuke_data(ctx.guild.id)
        violations = data.get("user_violations", {})
        if str(user.id) in violations:
            del violations[str(user.id)]
            data["user_violations"] = violations
            _save_antinuke(ctx.guild.id, data)
            await ctx.reply(f"✅ Cleared violations for {user.mention}.")
        else:
            await ctx.reply(f"ℹ️ {user.mention} has no violations.")

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            missing = ", ".join(p.replace("_", " ").title() for p in error.missing_permissions)
            log.warning(f"[Antinuke] {interaction.user} ({interaction.user.id}) missing permissions: {missing}")
            try:
                await interaction.response.send_message(f"❌ You are missing the required permissions: **{missing}**.", ephemeral=True)
            except discord.InteractionResponded:
                await interaction.followup.send(f"❌ You are missing the required permissions: **{missing}**.", ephemeral=True)

class WhitelistEventSelect(discord.ui.Select):
    def __init__(self, target_user: discord.User):
        self.target_user = target_user
        options = []
        for event in ALL_EVENTS:
            label = event.replace("_", " ").title()
            options.append(discord.SelectOption(label=label, value=event))
        options.append(discord.SelectOption(label="🌐 Global Whitelist", value="__global__", description="Allow everything for this user", emoji="🌐"))
        super().__init__(placeholder=f"Select events to whitelist {target_user.display_name} for…", options=options, min_values=1, max_values=len(options), custom_id="antinuke_whitelist_select")

    async def callback(self, interaction: discord.Interaction):
        guild_id = interaction.guild.id
        data = _antinuke_data(guild_id)
        if "__global__" in self.values:
            global_wl = data.setdefault("global_whitelist", [])
            if self.target_user.id in global_wl:
                return await interaction.response.send_message(f"{self.target_user.mention} is already globally whitelisted.", ephemeral=True)
            global_wl.append(self.target_user.id)
            _save_antinuke(guild_id, data)
            return await interaction.response.send_message(f"✅ {self.target_user.mention} **globally whitelisted** (all events).", ephemeral=True)
        selected_events = [v for v in self.values if v != "__global__"]
        per_event = data.setdefault("whitelist", {})
        per_event[str(self.target_user.id)] = selected_events
        _save_antinuke(guild_id, data)
        event_list = ", ".join(e.replace("_", " ").title() for e in selected_events)
        await interaction.response.send_message(f"✅ {self.target_user.mention} whitelisted for:\n**{event_list}**", ephemeral=True)

class WhitelistEventView(discord.ui.View):
    def __init__(self, user: discord.User):
        super().__init__(timeout=120)
        self.add_item(WhitelistEventSelect(user))

class WhitelistRoleSelect(discord.ui.Select):
    def __init__(self, target_role: discord.Role):
        self.target_role = target_role
        options = []
        for event in ALL_EVENTS:
            label = event.replace("_", " ").title()
            options.append(discord.SelectOption(label=label, value=event))
        options.append(discord.SelectOption(label="🌐 Global Role Whitelist", value="__global__", description="Allow this role for all events", emoji="🌐"))
        super().__init__(placeholder=f"Select events to whitelist {target_role.name} for…", options=options, min_values=1, max_values=len(options), custom_id="antinuke_role_whitelist_select")

    async def callback(self, interaction: discord.Interaction):
        guild_id = interaction.guild.id
        data = _antinuke_data(guild_id)
        if "__global__" in self.values:
            global_roles = data.setdefault("global_whitelist_roles", [])
            if self.target_role.id in global_roles:
                return await interaction.response.send_message(f"{self.target_role.mention} is already globally whitelisted.", ephemeral=True)
            global_roles.append(self.target_role.id)
            _save_antinuke(guild_id, data)
            return await interaction.response.send_message(f"✅ {self.target_role.mention} **globally whitelisted** (all events).", ephemeral=True)
        selected_events = [v for v in self.values if v != "__global__"]
        per_event = data.setdefault("role_whitelist", {})
        per_event[str(self.target_role.id)] = selected_events
        _save_antinuke(guild_id, data)
        event_list = ", ".join(e.replace("_", " ").title() for e in selected_events)
        await interaction.response.send_message(f"✅ {self.target_role.mention} whitelisted for:\n**{event_list}**", ephemeral=True)

class WhitelistRoleView(discord.ui.View):
    def __init__(self, role: discord.Role):
        super().__init__(timeout=120)
        self.add_item(WhitelistRoleSelect(role))

async def setup(bot):
    await bot.add_cog(AntiNuke(bot))