import discord
from discord.ext import commands
from discord import app_commands
import json
import os
import asyncio
from datetime import datetime, timezone
from config import Config
from utils.embed import build
from utils.theme import Theme
from utils.data import load, save

REPORTS_FILE = "reports.json"

class ResolveReasonModal(discord.ui.Modal, title="Resolve Report"):
    reason = discord.ui.TextInput(
        label="Reason (Optional)",
        style=discord.TextStyle.paragraph,
        placeholder="Why is this report being resolved?",
        required=False,
        max_length=500,
    )

    def __init__(self, report_id: int):
        super().__init__()
        self.report_id = report_id

class DismissReasonModal(discord.ui.Modal, title="Dismiss Report"):
    reason = discord.ui.TextInput(
        label="Reason (Optional)",
        style=discord.TextStyle.paragraph,
        placeholder="Why is this report being dismissed?",
        required=False,
        max_length=500,
    )

    def __init__(self, report_id: int):
        super().__init__()
        self.report_id = report_id

class ApproveSuggestionModal(discord.ui.Modal, title="Approve Suggestion"):
    reason = discord.ui.TextInput(
        label="Reason (Optional)",
        style=discord.TextStyle.paragraph,
        placeholder="Why is this suggestion being approved?",
        required=False,
        max_length=500,
    )

    def __init__(self, suggestion_id: int):
        super().__init__()
        self.suggestion_id = suggestion_id

class DenySuggestionModal(discord.ui.Modal, title="Deny Suggestion"):
    reason = discord.ui.TextInput(
        label="Reason",
        style=discord.TextStyle.paragraph,
        placeholder="Why is this suggestion being denied?",
        required=True,
        max_length=500,
    )

    def __init__(self, suggestion_id: int):
        super().__init__()
        self.suggestion_id = suggestion_id

class BugFixedModal(discord.ui.Modal, title="Mark Bug as Fixed"):
    reason = discord.ui.TextInput(
        label="Notes (Optional)",
        style=discord.TextStyle.paragraph,
        placeholder="Any additional notes about the fix?",
        required=False,
        max_length=500,
    )

    def __init__(self, bug_id: int):
        super().__init__()
        self.bug_id = bug_id

class BugInvalidModal(discord.ui.Modal, title="Mark Bug as Invalid"):
    reason = discord.ui.TextInput(
        label="Reason",
        style=discord.TextStyle.paragraph,
        placeholder="Why is this bug invalid?",
        required=True,
        max_length=500,
    )

    def __init__(self, bug_id: int):
        super().__init__()
        self.bug_id = bug_id

class ReportModal(discord.ui.Modal, title="📋 Report a Member"):
    reported_user = discord.ui.TextInput(
        label="Reported Username",
        placeholder="Enter the Discord username of the person you're reporting",
        required=True,
        max_length=100,
    )
    reason = discord.ui.TextInput(
        label="Reason for Report",
        style=discord.TextStyle.paragraph,
        placeholder="Describe what happened in detail...",
        required=True,
        max_length=1000,
    )
    proof = discord.ui.TextInput(
        label="Proof Link",
        placeholder="Paste a screenshot or media link here",
        required=False,
        max_length=500,
    )

    def __init__(self, guild: discord.Guild):
        super().__init__()
        self.guild = guild

    async def on_submit(self, interaction: discord.Interaction):
        settings = load("guild_settings.json").get(str(self.guild.id), {})
        ch_id = settings.get("report_channel")
        if not ch_id:
            return await interaction.response.send_message("❌ Report channel not configured.", ephemeral=True)
        ch = self.guild.get_channel(int(ch_id))
        if not ch:
            return await interaction.response.send_message("❌ Report channel not found.", ephemeral=True)

        if not ch.permissions_for(self.guild.me).send_messages:
            return await interaction.response.send_message("❌ I don't have permission to send messages in the report channel.", ephemeral=True)

        data = load(REPORTS_FILE)
        gdata = data.setdefault(str(self.guild.id), {"reports": {}, "counter": 0, "suggestions": {}, "sug_counter": 0, "bugs": {}, "bug_counter": 0})
        gdata["counter"] = gdata.get("counter", 0) + 1
        report_id = gdata["counter"]

        report = {
            "id": report_id,
            "reported": self.reported_user.value,
            "reporter_id": interaction.user.id,
            "reason": self.reason.value,
            "proof": self.proof.value or "No proof provided",
            "status": "pending",
            "time": datetime.now(timezone.utc).isoformat(),
            "resolved_by": None,
            "resolved_reason": None,
            "dismissed_by": None,
            "dismissed_reason": None,
        }
        gdata.setdefault("reports", {})[str(report_id)] = report
        save(REPORTS_FILE, data)

        embed = self._build_embed(report, "pending")
        view = ReportActionView(report_id, interaction.user.id)
        await ch.send(embed=embed, view=view)
        await interaction.response.send_message(f"✅ Report #{report_id:04d} submitted!", ephemeral=True)

    def _build_embed(self, report: dict, status: str) -> discord.Embed:
        if status == "pending":
            color = Config.COLOR_INFO
            status_text = "⏳ Pending Review"
        elif status == "resolved":
            color = Config.COLOR_OK
            status_text = f"✅ Resolved by <@{report.get('resolved_by')}>"
            if report.get('resolved_reason'):
                status_text += f"\n📝 Reason: {report['resolved_reason']}"
        else:
            color = Config.COLOR_ERR
            status_text = f"❌ Dismissed by <@{report.get('dismissed_by')}>"
            if report.get('dismissed_reason'):
                status_text += f"\n📝 Reason: {report['dismissed_reason']}"

        embed = build(title=f"🚨 Report #{report['id']:04d}", color=color, bot=self.bot)
        embed.add_field(name="Reported User", value=report['reported'], inline=True)
        embed.add_field(name="Reporter", value=f"<@{report['reporter_id']}>", inline=True)
        embed.add_field(name="Status", value=status_text, inline=False)
        embed.add_field(name="Reason", value=report['reason'], inline=False)
        embed.add_field(name="Proof", value=report['proof'] or "None provided", inline=False)
        embed.set_footer(text=f"Report ID: {report['id']:04d}")
        return embed

class ReportActionView(discord.ui.View):
    def __init__(self, report_id: int, reporter_id: int):
        super().__init__(timeout=None)
        self.report_id = report_id
        self.reporter_id = reporter_id
        self.action_taken = False

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if not interaction.user.guild_permissions.manage_messages:
            await interaction.response.send_message("❌ You need **Manage Messages** permission.", ephemeral=True)
            return False
        if self.action_taken:
            await interaction.response.send_message("❌ This report has already been handled.", ephemeral=True)
            return False
        return True

    def _disable_buttons(self):
        for item in self.children:
            item.disabled = True
        self.action_taken = True

    async def _update_embed(self, interaction: discord.Interaction, report: dict, status: str):

        from cogs.reports import ReportModal
        embed = ReportModal._build_embed(self, report, status)
        await interaction.message.edit(embed=embed, view=self)

    @discord.ui.button(label="✅ Resolve", style=discord.ButtonStyle.success, custom_id="report_resolve")
    async def resolve(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = ResolveReasonModal(self.report_id)
        await interaction.response.send_modal(modal)
        await modal.wait()

        data = load(REPORTS_FILE)
        gdata = data.get(str(interaction.guild.id), {})
        report = gdata.get("reports", {}).get(str(self.report_id))

        if not report:
            await interaction.followup.send(f"❌ Report #{self.report_id:04d} not found.", ephemeral=True)
            return

        report["status"] = "resolved"
        report["resolved_by"] = interaction.user.id
        report["resolved_reason"] = modal.reason.value or None
        save(REPORTS_FILE, data)

        self._disable_buttons()
        await self._update_embed(interaction, report, "resolved")

        await interaction.followup.send(f"✅ Report #{self.report_id:04d} marked as **resolved**.", ephemeral=True)

        await self._dm_reporter(interaction, report, "resolved", modal.reason.value)
        self.stop()

    @discord.ui.button(label="❌ Dismiss", style=discord.ButtonStyle.danger, custom_id="report_dismiss")
    async def dismiss(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = DismissReasonModal(self.report_id)
        await interaction.response.send_modal(modal)
        await modal.wait()

        data = load(REPORTS_FILE)
        gdata = data.get(str(interaction.guild.id), {})
        report = gdata.get("reports", {}).get(str(self.report_id))

        if not report:
            await interaction.followup.send(f"❌ Report #{self.report_id:04d} not found.", ephemeral=True)
            return

        report["status"] = "dismissed"
        report["dismissed_by"] = interaction.user.id
        report["dismissed_reason"] = modal.reason.value or None
        save(REPORTS_FILE, data)

        self._disable_buttons()
        await self._update_embed(interaction, report, "dismissed")

        await interaction.followup.send(f"❌ Report #{self.report_id:04d} **dismissed**.", ephemeral=True)

        await self._dm_reporter(interaction, report, "dismissed", modal.reason.value)
        self.stop()

    async def _dm_reporter(self, interaction: discord.Interaction, report: dict, action: str, reason: str):
        try:
            reporter = await interaction.client.fetch_user(self.reporter_id)
            if reporter:
                embed = build(title=f"📋 Report #{report['id']:04d} Update", color=Config.COLOR_OK if action == "resolved" else Config.COLOR_ERR, bot=self.bot)
                embed.add_field(name="Status", value="✅ Resolved" if action == "resolved" else "❌ Dismissed", inline=True)
                embed.add_field(name="Reported User", value=report['reported'], inline=True)
                if reason:
                    embed.add_field(name="Reason", value=reason, inline=False)
                embed.set_footer(text=f"Action taken by {interaction.user}")
                await reporter.send(embed=embed)
        except discord.Forbidden:
            print(f"[Reports] Could not DM user {self.reporter_id} (DMs closed)")
        except Exception as e:
            print(f"[Reports] Failed to DM reporter: {e}")

class ReportPanelView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="📋 Fill Out Report Form", style=discord.ButtonStyle.danger, custom_id="report_open_modal")
    async def open_form(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(ReportModal(interaction.guild))

class SuggestionModal(discord.ui.Modal, title="💡 Submit a Suggestion"):
    suggestion_title = discord.ui.TextInput(
        label="Suggestion Title",
        placeholder="Brief title for your suggestion",
        required=True,
        max_length=100,
    )
    description = discord.ui.TextInput(
        label="Description",
        style=discord.TextStyle.paragraph,
        placeholder="Describe your idea in detail...",
        required=True,
        max_length=1000,
    )

    def __init__(self, guild: discord.Guild):
        super().__init__()
        self.guild = guild

    async def on_submit(self, interaction: discord.Interaction):
        settings = load("guild_settings.json").get(str(self.guild.id), {})
        ch_id = settings.get("suggestion_channel")
        if not ch_id:
            return await interaction.response.send_message("❌ Suggestion channel not configured.", ephemeral=True)
        ch = self.guild.get_channel(int(ch_id))
        if not ch:
            return await interaction.response.send_message("❌ Suggestion channel not found.", ephemeral=True)

        if not ch.permissions_for(self.guild.me).send_messages:
            return await interaction.response.send_message("❌ I don't have permission to send messages in the suggestion channel.", ephemeral=True)

        data = load(REPORTS_FILE)
        gdata = data.setdefault(str(self.guild.id), {"reports": {}, "counter": 0, "suggestions": {}, "sug_counter": 0, "bugs": {}, "bug_counter": 0})
        gdata["sug_counter"] = gdata.get("sug_counter", 0) + 1
        sug_id = gdata["sug_counter"]

        suggestion = {
            "id": sug_id,
            "title": self.suggestion_title.value,
            "desc": self.description.value,
            "author_id": interaction.user.id,
            "status": "pending",
            "time": datetime.now(timezone.utc).isoformat(),
            "approved_by": None,
            "approved_reason": None,
            "denied_by": None,
            "denied_reason": None,
        }
        gdata.setdefault("suggestions", {})[str(sug_id)] = suggestion
        save(REPORTS_FILE, data)

        embed = self._build_embed(suggestion, "pending")
        view = SuggestionActionView(sug_id, interaction.user.id)
        msg = await ch.send(embed=embed, view=view)
        await msg.add_reaction("👍")
        await msg.add_reaction("👎")
        await interaction.response.send_message(f"✅ Suggestion #{sug_id:04d} submitted!", ephemeral=True)

    def _build_embed(self, suggestion: dict, status: str) -> discord.Embed:
        if status == "pending":
            color = Config.COLOR_INFO
            status_text = "⏳ Pending Review"
        elif status == "approved":
            color = Config.COLOR_OK
            status_text = f"✅ Approved by <@{suggestion.get('approved_by')}>"
            if suggestion.get('approved_reason'):
                status_text += f"\n📝 Reason: {suggestion['approved_reason']}"
        else:
            color = Config.COLOR_ERR
            status_text = f"❌ Denied by <@{suggestion.get('denied_by')}>"
            if suggestion.get('denied_reason'):
                status_text += f"\n📝 Reason: {suggestion['denied_reason']}"

        embed = build(title=f"💡 Suggestion #{suggestion['id']:04d} • {suggestion['title']}", description=suggestion['desc'], color=color, bot=self.bot)
        embed.set_author(name=f"Submitted by <@{suggestion['author_id']}>")
        embed.add_field(name="Status", value=status_text, inline=False)
        embed.set_footer(text=f"Suggestion #{suggestion['id']:04d}")
        return embed

class SuggestionActionView(discord.ui.View):
    def __init__(self, sug_id: int, author_id: int):
        super().__init__(timeout=None)
        self.sug_id = sug_id
        self.author_id = author_id
        self.action_taken = False

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if not interaction.user.guild_permissions.manage_guild:
            await interaction.response.send_message("❌ You need **Manage Server** permission.", ephemeral=True)
            return False
        if self.action_taken:
            await interaction.response.send_message("❌ This suggestion has already been handled.", ephemeral=True)
            return False
        return True

    def _disable_buttons(self):
        for item in self.children:
            item.disabled = True
        self.action_taken = True

    async def _update_embed(self, interaction: discord.Interaction, suggestion: dict, status: str):
        from cogs.reports import SuggestionModal
        embed = SuggestionModal._build_embed(self, suggestion, status)
        await interaction.message.edit(embed=embed, view=self)

    @discord.ui.button(label="✅ Approve", style=discord.ButtonStyle.success, custom_id="sug_approve")
    async def approve(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = ApproveSuggestionModal(self.sug_id)
        await interaction.response.send_modal(modal)
        await modal.wait()

        data = load(REPORTS_FILE)
        sug = data.get(str(interaction.guild.id), {}).get("suggestions", {}).get(str(self.sug_id))

        if not sug:
            await interaction.followup.send(f"❌ Suggestion #{self.sug_id:04d} not found.", ephemeral=True)
            return

        sug["status"] = "approved"
        sug["approved_by"] = interaction.user.id
        sug["approved_reason"] = modal.reason.value or None
        save(REPORTS_FILE, data)

        self._disable_buttons()
        await self._update_embed(interaction, sug, "approved")
        await interaction.followup.send(f"✅ Suggestion #{self.sug_id:04d} **approved**.", ephemeral=True)

        await self._dm_author(interaction, sug, "approved", modal.reason.value)
        self.stop()

    @discord.ui.button(label="❌ Deny", style=discord.ButtonStyle.danger, custom_id="sug_deny")
    async def deny(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = DenySuggestionModal(self.sug_id)
        await interaction.response.send_modal(modal)
        await modal.wait()

        data = load(REPORTS_FILE)
        sug = data.get(str(interaction.guild.id), {}).get("suggestions", {}).get(str(self.sug_id))

        if not sug:
            await interaction.followup.send(f"❌ Suggestion #{self.sug_id:04d} not found.", ephemeral=True)
            return

        sug["status"] = "denied"
        sug["denied_by"] = interaction.user.id
        sug["denied_reason"] = modal.reason.value or None
        save(REPORTS_FILE, data)

        self._disable_buttons()
        await self._update_embed(interaction, sug, "denied")
        await interaction.followup.send(f"❌ Suggestion #{self.sug_id:04d} **denied**.", ephemeral=True)

        await self._dm_author(interaction, sug, "denied", modal.reason.value)
        self.stop()

    async def _dm_author(self, interaction: discord.Interaction, sug: dict, action: str, reason: str):
        try:
            author = await interaction.client.fetch_user(self.author_id)
            if author:
                embed = build(title=f"💡 Suggestion #{sug['id']:04d} Update", color=Config.COLOR_OK if action == "approved" else Config.COLOR_ERR, bot=self.bot)
                embed.add_field(name="Title", value=sug['title'], inline=True)
                embed.add_field(name="Status", value="✅ Approved" if action == "approved" else "❌ Denied", inline=True)
                if reason:
                    embed.add_field(name="Reason", value=reason, inline=False)
                embed.set_footer(text=f"Action taken by {interaction.user}")
                await author.send(embed=embed)
        except discord.Forbidden:
            print(f"[Reports] Could not DM user {self.author_id} (DMs closed)")
        except Exception as e:
            print(f"[Reports] Failed to DM author: {e}")

class SuggestionPanelView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="💡 Submit a Suggestion", style=discord.ButtonStyle.primary, custom_id="sug_open_modal")
    async def open_form(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(SuggestionModal(interaction.guild))

class BugReportModal(discord.ui.Modal, title="🐛 Bug Report"):
    bug_title = discord.ui.TextInput(
        label="Bug Title",
        placeholder="Brief description of the bug",
        required=True,
        max_length=100,
    )
    steps = discord.ui.TextInput(
        label="Steps to Reproduce",
        style=discord.TextStyle.paragraph,
        placeholder="1. Do this\n2. Then this\n3. Bug appears",
        required=True,
        max_length=800,
    )
    expected = discord.ui.TextInput(
        label="Expected vs Actual Behavior",
        style=discord.TextStyle.paragraph,
        placeholder="Expected: ...\nActual: ...",
        required=True,
        max_length=500,
    )

    def __init__(self, guild: discord.Guild):
        super().__init__()
        self.guild = guild

    async def on_submit(self, interaction: discord.Interaction):
        settings = load("guild_settings.json").get(str(self.guild.id), {})
        ch_id = settings.get("bug_report_channel")
        if not ch_id:
            return await interaction.response.send_message("❌ Bug report channel not configured.", ephemeral=True)
        ch = self.guild.get_channel(int(ch_id))
        if not ch:
            return await interaction.response.send_message("❌ Bug report channel not found.", ephemeral=True)

        if not ch.permissions_for(self.guild.me).send_messages:
            return await interaction.response.send_message("❌ I don't have permission to send messages in the bug report channel.", ephemeral=True)

        data = load(REPORTS_FILE)
        gdata = data.setdefault(str(self.guild.id), {"reports": {}, "counter": 0, "suggestions": {}, "sug_counter": 0, "bugs": {}, "bug_counter": 0})
        gdata["bug_counter"] = gdata.get("bug_counter", 0) + 1
        bug_id = gdata["bug_counter"]

        bug = {
            "id": bug_id,
            "title": self.bug_title.value,
            "steps": self.steps.value,
            "expected": self.expected.value,
            "author_id": interaction.user.id,
            "status": "pending",
            "time": datetime.now(timezone.utc).isoformat(),
            "fixed_by": None,
            "fixed_reason": None,
            "invalid_by": None,
            "invalid_reason": None,
        }
        gdata.setdefault("bugs", {})[str(bug_id)] = bug
        save(REPORTS_FILE, data)

        embed = self._build_embed(bug, "pending")
        view = BugReportActionView(bug_id, interaction.user.id)
        await ch.send(embed=embed, view=view)
        await interaction.response.send_message(f"✅ Bug report #{bug_id:04d} submitted!", ephemeral=True)

    def _build_embed(self, bug: dict, status: str) -> discord.Embed:
        if status == "pending":
            color = Config.COLOR_INFO
            status_text = "⏳ Pending Review"
        elif status == "fixed":
            color = Config.COLOR_OK
            status_text = f"🔧 Fixed by <@{bug.get('fixed_by')}>"
            if bug.get('fixed_reason'):
                status_text += f"\n📝 Notes: {bug['fixed_reason']}"
        else:
            color = Config.COLOR_ERR
            status_text = f"❌ Invalid by <@{bug.get('invalid_by')}>"
            if bug.get('invalid_reason'):
                status_text += f"\n📝 Reason: {bug['invalid_reason']}"

        embed = build(title=f"🐛 Bug Report #{bug['id']:04d} • {bug['title']}", color=color, bot=self.bot)
        embed.set_author(name=f"Reported by <@{bug['author_id']}>")
        embed.add_field(name="Status", value=status_text, inline=False)
        embed.add_field(name="Steps to Reproduce", value=bug['steps'], inline=False)
        embed.add_field(name="Expected vs Actual", value=bug['expected'], inline=False)
        embed.set_footer(text=f"Bug #{bug['id']:04d}")
        return embed

class BugReportActionView(discord.ui.View):
    def __init__(self, bug_id: int, author_id: int):
        super().__init__(timeout=None)
        self.bug_id = bug_id
        self.author_id = author_id
        self.action_taken = False

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if not interaction.user.guild_permissions.manage_messages:
            await interaction.response.send_message("❌ You need **Manage Messages** permission.", ephemeral=True)
            return False
        if self.action_taken:
            await interaction.response.send_message("❌ This bug report has already been handled.", ephemeral=True)
            return False
        return True

    def _disable_buttons(self):
        for item in self.children:
            item.disabled = True
        self.action_taken = True

    async def _update_embed(self, interaction: discord.Interaction, bug: dict, status: str):
        from cogs.reports import BugReportModal
        embed = BugReportModal._build_embed(self, bug, status)
        await interaction.message.edit(embed=embed, view=self)

    @discord.ui.button(label="🔧 Fixed", style=discord.ButtonStyle.success, custom_id="bug_fixed")
    async def fixed(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = BugFixedModal(self.bug_id)
        await interaction.response.send_modal(modal)
        await modal.wait()

        data = load(REPORTS_FILE)
        bug = data.get(str(interaction.guild.id), {}).get("bugs", {}).get(str(self.bug_id))

        if not bug:
            await interaction.followup.send(f"❌ Bug report #{self.bug_id:04d} not found.", ephemeral=True)
            return

        bug["status"] = "fixed"
        bug["fixed_by"] = interaction.user.id
        bug["fixed_reason"] = modal.reason.value or None
        save(REPORTS_FILE, data)

        self._disable_buttons()
        await self._update_embed(interaction, bug, "fixed")
        await interaction.followup.send(f"🔧 Bug #{self.bug_id:04d} marked as **fixed**.", ephemeral=True)

        await self._dm_author(interaction, bug, "fixed", modal.reason.value)
        self.stop()

    @discord.ui.button(label="❌ Invalid", style=discord.ButtonStyle.danger, custom_id="bug_invalid")
    async def invalid(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = BugInvalidModal(self.bug_id)
        await interaction.response.send_modal(modal)
        await modal.wait()

        data = load(REPORTS_FILE)
        bug = data.get(str(interaction.guild.id), {}).get("bugs", {}).get(str(self.bug_id))

        if not bug:
            await interaction.followup.send(f"❌ Bug report #{self.bug_id:04d} not found.", ephemeral=True)
            return

        bug["status"] = "invalid"
        bug["invalid_by"] = interaction.user.id
        bug["invalid_reason"] = modal.reason.value or None
        save(REPORTS_FILE, data)

        self._disable_buttons()
        await self._update_embed(interaction, bug, "invalid")
        await interaction.followup.send(f"❌ Bug #{self.bug_id:04d} marked as **invalid**.", ephemeral=True)

        await self._dm_author(interaction, bug, "invalid", modal.reason.value)
        self.stop()

    async def _dm_author(self, interaction: discord.Interaction, bug: dict, action: str, reason: str):
        try:
            author = await interaction.client.fetch_user(self.author_id)
            if author:
                embed = build(title=f"🐛 Bug Report #{bug['id']:04d} Update", color=Config.COLOR_OK if action == "fixed" else Config.COLOR_ERR, bot=self.bot)
                embed.add_field(name="Title", value=bug['title'], inline=True)
                embed.add_field(name="Status", value="✅ Fixed" if action == "fixed" else "❌ Invalid", inline=True)
                if reason:
                    embed.add_field(name="Reason", value=reason, inline=False)
                embed.set_footer(text=f"Action taken by {interaction.user}")
                await author.send(embed=embed)
        except discord.Forbidden:
            print(f"[Reports] Could not DM user {self.author_id} (DMs closed)")
        except Exception as e:
            print(f"[Reports] Failed to DM author: {e}")

class BugReportPanelView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="🐛 Report a Bug", style=discord.ButtonStyle.secondary, custom_id="bug_open_modal")
    async def open_form(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(BugReportModal(interaction.guild))

class Reports(commands.Cog):

    slash = app_commands.Group(name="rp", description="Report, suggestion, and bug report system")

    def __init__(self, bot):
        self.bot = bot
        bot.add_view(ReportPanelView())
        bot.add_view(SuggestionPanelView())
        bot.add_view(BugReportPanelView())
        bot.add_view(ReportActionView(0, 0))
        bot.add_view(SuggestionActionView(0, 0))
        bot.add_view(BugReportActionView(0, 0))

    @commands.command(name="rp")
    async def report(self, ctx):
        settings = load("guild_settings.json").get(str(ctx.guild.id), {})
        if not settings.get("report_channel"):
            return await ctx.reply("❌ No report channel set. Ask an admin to use `//rp set`.")
        e = build(title="🚨 Report a Member", description=(
                "**Before submitting a report, you need proof.**\n\n"
                "**How to get proof:**\n"
                "1. Take a screenshot of the evidence\n"
                "2. Upload it to any Discord channel\n"
                "3. Right-click the image → **Copy Link**\n"
                "4. Click the button below and paste the link in the Proof field\n\n"
                "⚠️ **Reports without valid proof will be dismissed.**"
            ), color=Config.COLOR_ERR, bot=self.bot)
        await ctx.reply(embed=e, view=ReportPanelView())

    @slash.command(name="report", description="Report a member to staff.")
    async def report_slash(self, interaction: discord.Interaction):
        settings = load("guild_settings.json").get(str(interaction.guild.id), {})
        if not settings.get("report_channel"):
            return await interaction.response.send_message("❌ No report channel set. Ask an admin to use `/rp set`.", ephemeral=True)
        await interaction.response.send_modal(ReportModal(interaction.guild))

    @commands.command(name="rpset")
    @commands.has_permissions(administrator=True)
    async def rpset(self, ctx, channel: discord.TextChannel):
        data = load("guild_settings.json")
        data.setdefault(str(ctx.guild.id), {})["report_channel"] = channel.id
        save("guild_settings.json", data)
        await ctx.reply(f"✅ Reports will be sent to {channel.mention}.")

    @slash.command(name="set", description="Set the channel for member reports.")
    @app_commands.describe(channel="Channel for reports")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def rpset_slash(self, interaction: discord.Interaction, channel: discord.TextChannel):
        ctx = await commands.Context.from_interaction(interaction)
        await self.rpset.callback(self, ctx, channel)

    @commands.command(name="rplist")
    @commands.has_permissions(manage_messages=True)
    async def rplist(self, ctx, status: str = "pending"):
        data = load(REPORTS_FILE).get(str(ctx.guild.id), {})
        reps = data.get("reports", {})

        filtered = [r for r in reps.values() if r.get("status") == status]

        if not filtered:
            return await ctx.reply(f"✅ No {status} reports!")

        filtered.sort(key=lambda x: x['id'], reverse=True)

        lines = []
        for r in filtered[:25]:
            status_emoji = "⏳" if r['status'] == "pending" else "✅" if r['status'] == "resolved" else "❌"
            lines.append(f"{status_emoji} `#{r['id']:04d}` • **{r['reported']}** by <@{r['reporter_id']}>")

        e = build(title=f"📋 Reports ({status.title()})", description="\n".join(lines) or "No reports found.", color=Config.COLOR_ERR if status == "pending" else Config.COLOR_INFO, bot=self.bot)
        if len(filtered) > 25:
            e.set_footer(text=f"Showing 25 of {len(filtered)} reports")
        await ctx.reply(embed=e)

    @slash.command(name="list", description="View reports by status.")
    @app_commands.describe(status="Filter by status: pending, resolved, dismissed")
    @app_commands.choices(status=[
        app_commands.Choice(name="Pending", value="pending"),
        app_commands.Choice(name="Resolved", value="resolved"),
        app_commands.Choice(name="Dismissed", value="dismissed"),
    ])
    @app_commands.default_permissions(manage_messages=True)
    @app_commands.checks.has_permissions(manage_messages=True)
    async def rplist_slash(self, interaction: discord.Interaction, status: str = "pending"):
        ctx = await commands.Context.from_interaction(interaction)
        await self.rplist.callback(self, ctx, status)

    @commands.command(name="sug")
    async def suggestion(self, ctx):
        settings = load("guild_settings.json").get(str(ctx.guild.id), {})
        if not settings.get("suggestion_channel"):
            return await ctx.reply("❌ No suggestion channel set. Ask an admin to use `//sugset`.")
        e = build(title="💡 Submit a Suggestion", description=(
                "Have an idea to improve the server? We'd love to hear it!\n\n"
                "Click the button below to fill out the suggestion form.\n"
                "Once submitted, the community can vote on your idea with 👍 and 👎."
            ), color=Config.COLOR_INFO, bot=self.bot)
        await ctx.reply(embed=e, view=SuggestionPanelView())

    @slash.command(name="suggest", description="Submit a suggestion for the server.")
    async def suggest_slash(self, interaction: discord.Interaction):
        settings = load("guild_settings.json").get(str(interaction.guild.id), {})
        if not settings.get("suggestion_channel"):
            return await interaction.response.send_message("❌ No suggestion channel set. Ask an admin to use `/rp setsug`.", ephemeral=True)
        await interaction.response.send_modal(SuggestionModal(interaction.guild))

    @commands.command(name="sugset")
    @commands.has_permissions(administrator=True)
    async def sugset(self, ctx, channel: discord.TextChannel):
        data = load("guild_settings.json")
        data.setdefault(str(ctx.guild.id), {})["suggestion_channel"] = channel.id
        save("guild_settings.json", data)
        await ctx.reply(f"✅ Suggestions will be sent to {channel.mention}.")

    @slash.command(name="setsug", description="Set the suggestions channel.")
    @app_commands.describe(channel="Channel for suggestions")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def sugset_slash(self, interaction: discord.Interaction, channel: discord.TextChannel):
        ctx = await commands.Context.from_interaction(interaction)
        await self.sugset.callback(self, ctx, channel)

    @commands.command(name="suglist")
    @commands.has_permissions(manage_guild=True)
    async def suglist(self, ctx, status: str = "pending"):
        data = load(REPORTS_FILE).get(str(ctx.guild.id), {})
        sugs = data.get("suggestions", {})

        filtered = [s for s in sugs.values() if s.get("status") == status]

        if not filtered:
            return await ctx.reply(f"✅ No {status} suggestions!")

        filtered.sort(key=lambda x: x['id'], reverse=True)

        lines = []
        for s in filtered[:25]:
            status_emoji = "⏳" if s['status'] == "pending" else "✅" if s['status'] == "approved" else "❌"
            lines.append(f"{status_emoji} `#{s['id']:04d}` • **{s['title']}** by <@{s['author_id']}>")

        e = build(title=f"💡 Suggestions ({status.title()})", description="\n".join(lines) or "No suggestions found.", color=Config.COLOR_INFO, bot=self.bot)
        if len(filtered) > 25:
            e.set_footer(text=f"Showing 25 of {len(filtered)} suggestions")
        await ctx.reply(embed=e)

    @slash.command(name="listsug", description="View suggestions by status.")
    @app_commands.describe(status="Filter by status: pending, approved, denied")
    @app_commands.choices(status=[
        app_commands.Choice(name="Pending", value="pending"),
        app_commands.Choice(name="Approved", value="approved"),
        app_commands.Choice(name="Denied", value="denied"),
    ])
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def suglist_slash(self, interaction: discord.Interaction, status: str = "pending"):
        ctx = await commands.Context.from_interaction(interaction)
        await self.suglist.callback(self, ctx, status)

    @commands.command(name="bug")
    async def bugreport(self, ctx):
        settings = load("guild_settings.json").get(str(ctx.guild.id), {})
        if not settings.get("bug_report_channel"):
            return await ctx.reply("❌ No bug report channel set. Ask an admin to use `//bugset`.")
        e = build(title="🐛 Report a Bug", description=(
                "Found a bug in the bot? Let us know!\n\n"
                "Click the button below to fill out the bug report form.\n"
                "Please be as detailed as possible so we can reproduce and fix it."
            ), color=Config.COLOR_WARN, bot=self.bot)
        await ctx.reply(embed=e, view=BugReportPanelView())

    @slash.command(name="bug", description="Report a bug in the bot.")
    async def bugreport_slash(self, interaction: discord.Interaction):
        settings = load("guild_settings.json").get(str(interaction.guild.id), {})
        if not settings.get("bug_report_channel"):
            return await interaction.response.send_message("❌ No bug report channel set. Ask an admin to use `/rp setbug`.", ephemeral=True)
        await interaction.response.send_modal(BugReportModal(interaction.guild))

    @commands.command(name="bugset")
    @commands.has_permissions(administrator=True)
    async def bugset(self, ctx, channel: discord.TextChannel):
        data = load("guild_settings.json")
        data.setdefault(str(ctx.guild.id), {})["bug_report_channel"] = channel.id
        save("guild_settings.json", data)
        await ctx.reply(f"✅ Bug reports will be sent to {channel.mention}.")

    @slash.command(name="setbug", description="Set the bug report channel.")
    @app_commands.describe(channel="Channel for bug reports")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def bugset_slash(self, interaction: discord.Interaction, channel: discord.TextChannel):
        ctx = await commands.Context.from_interaction(interaction)
        await self.bugset.callback(self, ctx, channel)

    @commands.command(name="buglist")
    @commands.has_permissions(manage_messages=True)
    async def buglist(self, ctx, status: str = "pending"):
        data = load(REPORTS_FILE).get(str(ctx.guild.id), {})
        bugs = data.get("bugs", {})

        filtered = [b for b in bugs.values() if b.get("status") == status]

        if not filtered:
            return await ctx.reply(f"✅ No {status} bug reports!")

        filtered.sort(key=lambda x: x['id'], reverse=True)

        lines = []
        for b in filtered[:25]:
            status_emoji = "⏳" if b['status'] == "pending" else "🔧" if b['status'] == "fixed" else "❌"
            lines.append(f"{status_emoji} `#{b['id']:04d}` • **{b['title']}** by <@{b['author_id']}>")

        e = build(title=f"🐛 Bug Reports ({status.title()})", description="\n".join(lines) or "No bug reports found.", color=Config.COLOR_WARN, bot=self.bot)
        if len(filtered) > 25:
            e.set_footer(text=f"Showing 25 of {len(filtered)} bug reports")
        await ctx.reply(embed=e)

    @slash.command(name="listbug", description="View bug reports by status.")
    @app_commands.describe(status="Filter by status: pending, fixed, invalid")
    @app_commands.choices(status=[
        app_commands.Choice(name="Pending", value="pending"),
        app_commands.Choice(name="Fixed", value="fixed"),
        app_commands.Choice(name="Invalid", value="invalid"),
    ])
    @app_commands.default_permissions(manage_messages=True)
    @app_commands.checks.has_permissions(manage_messages=True)
    async def buglist_slash(self, interaction: discord.Interaction, status: str = "pending"):
        ctx = await commands.Context.from_interaction(interaction)
        await self.buglist.callback(self, ctx, status)

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            missing = ", ".join(p.replace("_", " ").title() for p in error.missing_permissions)
            print(f"[Reports] {interaction.user} ({interaction.user.id}) missing permissions: {missing}")
            try:
                await interaction.response.send_message(
                    f"❌ You are missing the required permissions: **{missing}**.",
                    ephemeral=True,
                )
            except discord.InteractionResponded:
                await interaction.followup.send(
                    f"❌ You are missing the required permissions: **{missing}**.",
                    ephemeral=True,
                )

async def setup(bot):
    await bot.add_cog(Reports(bot))
