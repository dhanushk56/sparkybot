import discord
from discord.ext import commands, tasks
from discord import app_commands
import random
import asyncio
from datetime import datetime, timezone, timedelta
from config import Config
from utils.embed import build
from utils.theme import Theme
from utils.emojis import Emojis
from utils.data import load, save
import string

ECO_FILE = "economy.json"
SHOP_CONFIG_FILE = "shop_config.json"

SHOP_ITEMS = {

    "vip_role":           {"name": "⭐ VIP Role",           "price": 5000,  "desc": "Get the VIP role", "category": "roles"},
    "premium_role":       {"name": "💎 Premium Member",     "price": 10000, "desc": "Premium member role", "category": "roles"},
    "booster_role":       {"name": "🚀 Booster",            "price": 7500,  "desc": "Server booster role", "category": "roles"},
    "legend_role":        {"name": "👑 Legend",             "price": 25000, "desc": "Legendary member role", "category": "roles"},
    "elite_role":         {"name": "⚡ Elite Member",       "price": 15000, "desc": "Elite member role", "category": "roles"},
    "supporter_role":     {"name": "🤝 Supporter",          "price": 3000,  "desc": "Server supporter role", "category": "roles"},
    "veteran_role":       {"name": "🎖️ Veteran",           "price": 20000, "desc": "Veteran member role", "category": "roles"},
    "champion_role":      {"name": "🏆 Champion",           "price": 30000, "desc": "Champion role", "category": "roles"},
    "hero_role":          {"name": "🦸 Hero",               "price": 40000, "desc": "Hero role", "category": "roles"},
    "god_role":           {"name": "⛰️ God",                "price": 100000, "desc": "God role", "category": "roles"},
    "color_red":          {"name": "🔴 Red Role",           "price": 2000,  "desc": "Red colored role", "category": "roles"},
    "color_blue":         {"name": "🔵 Blue Role",          "price": 2000,  "desc": "Blue colored role", "category": "roles"},
    "color_green":        {"name": "🟢 Green Role",         "price": 2000,  "desc": "Green colored role", "category": "roles"},
    "color_yellow":       {"name": "🟡 Yellow Role",        "price": 2000,  "desc": "Yellow colored role", "category": "roles"},
    "color_purple":       {"name": "🟣 Purple Role",        "price": 2000,  "desc": "Purple colored role", "category": "roles"},
    "color_orange":       {"name": "🟠 Orange Role",        "price": 2000,  "desc": "Orange colored role", "category": "roles"},
    "color_pink":         {"name": "🌸 Pink Role",          "price": 2000,  "desc": "Pink colored role", "category": "roles"},
    "color_cyan":         {"name": "🩵 Cyan Role",          "price": 2000,  "desc": "Cyan colored role", "category": "roles"},
    "color_brown":        {"name": "🟤 Brown Role",         "price": 2000,  "desc": "Brown colored role", "category": "roles"},
    "color_white":        {"name": "⚪ White Role",         "price": 2000,  "desc": "White colored role", "category": "roles"},
    "color_black":        {"name": "⬛ Black Role",         "price": 2000,  "desc": "Black colored role", "category": "roles"},
    "color_gold":         {"name": "🌟 Gold Role",          "price": 5000,  "desc": "Gold colored role", "category": "roles"},
    "color_silver":       {"name": "🔘 Silver Role",        "price": 4000,  "desc": "Silver colored role", "category": "roles"},
    "color_bronze":       {"name": "🥉 Bronze Role",        "price": 3000,  "desc": "Bronze colored role", "category": "roles"},

    "trophy":             {"name": "🏆 Trophy",             "price": 500,   "desc": "A shiny trophy collectible", "category": "collectibles"},
    "diamond":            {"name": "💎 Diamond",            "price": 10000, "desc": "Ultra rare gem collectible", "category": "collectibles"},
    "gold_coin":          {"name": "🪙 Gold Coin",          "price": 1000,  "desc": "A rare gold coin", "category": "collectibles"},
    "silver_coin":        {"name": "🥈 Silver Coin",        "price": 500,   "desc": "A shiny silver coin", "category": "collectibles"},
    "bronze_coin":        {"name": "🥉 Bronze Coin",        "price": 250,   "desc": "A bronze coin", "category": "collectibles"},
    "crystal":            {"name": "💠 Crystal",            "price": 2000,  "desc": "A beautiful crystal", "category": "collectibles"},
    "ruby":               {"name": "🔴 Ruby",               "price": 5000,  "desc": "A precious ruby", "category": "collectibles"},
    "sapphire":           {"name": "🔵 Sapphire",           "price": 5000,  "desc": "A precious sapphire", "category": "collectibles"},
    "emerald":            {"name": "🟢 Emerald",            "price": 5000,  "desc": "A precious emerald", "category": "collectibles"},
    "amethyst":           {"name": "🟣 Amethyst",           "price": 4000,  "desc": "A precious amethyst", "category": "collectibles"},
    "pearl":              {"name": "⚪ Pearl",              "price": 3000,  "desc": "A rare pearl", "category": "collectibles"},
    "opal":               {"name": "🟠 Opal",               "price": 3500,  "desc": "A rare opal", "category": "collectibles"},
    "jade":               {"name": "🟩 Jade",               "price": 4000,  "desc": "A precious jade", "category": "collectibles"},
    "topaz":              {"name": "🟨 Topaz",              "price": 3000,  "desc": "A precious topaz", "category": "collectibles"},
    "garnet":             {"name": "❤️ Garnet",             "price": 2500,  "desc": "A precious garnet", "category": "collectibles"},
    "moonstone":          {"name": "🌙 Moonstone",          "price": 4500,  "desc": "A mystical moonstone", "category": "collectibles"},
    "sunstone":           {"name": "☀️ Sunstone",           "price": 4500,  "desc": "A radiant sunstone", "category": "collectibles"},
    "star_sapphire":      {"name": "⭐ Star Sapphire",      "price": 8000,  "desc": "A rare star sapphire", "category": "collectibles"},
    "tigers_eye":         {"name": "🐯 Tiger's Eye",        "price": 2000,  "desc": "A protective tiger's eye", "category": "collectibles"},
    "malachite":          {"name": "🟢 Malachite",          "price": 1500,  "desc": "A beautiful malachite", "category": "collectibles"},
    "lapis_lazuli":       {"name": "🔷 Lapis Lazuli",       "price": 2000,  "desc": "A rich lapis lazuli", "category": "collectibles"},
    "turquoise":          {"name": "🔷 Turquoise",          "price": 2500,  "desc": "A vibrant turquoise", "category": "collectibles"},
    "obsidian":           {"name": "⬛ Obsidian",           "price": 1000,  "desc": "A volcanic obsidian", "category": "collectibles"},
    "moon_rock":          {"name": "🌑 Moon Rock",          "price": 5000,  "desc": "A rock from the moon", "category": "collectibles"},
    "meteorite":          {"name": "☄️ Meteorite",          "price": 8000,  "desc": "A meteorite fragment", "category": "collectibles"},

    "lucky_charm":        {"name": "🍀 Lucky Charm",        "price": 750,   "desc": "+10% gamble win chance", "category": "powerups"},
    "xp_boost":           {"name": "⚡ XP Boost",           "price": 2000,  "desc": "1.5x XP for 24 hours", "category": "powerups"},
    "coin_multiplier":    {"name": "💰 Coin Multiplier",    "price": 3000,  "desc": "2x coins from work for 24h", "category": "powerups"},
    "double_daily":       {"name": "📅 Double Daily",       "price": 1500,  "desc": "2x daily reward tomorrow", "category": "powerups"},
    "bank_protection":    {"name": "🛡️ Bank Protection",   "price": 1000,  "desc": "Protect bank from robbery", "category": "powerups"},
    "stealth_mode":       {"name": "👤 Stealth Mode",       "price": 500,   "desc": "Hide your balance from others", "category": "powerups"},
    "instant_work":       {"name": "⚡ Instant Work",       "price": 2000,  "desc": "Skip work cooldown once", "category": "powerups"},
    "lucky_dice":         {"name": "🎲 Lucky Dice",         "price": 1000,  "desc": "Better gambling odds", "category": "powerups"},
    "golden_ticket":      {"name": "🎟️ Golden Ticket",     "price": 5000,  "desc": "Enter special giveaways", "category": "powerups"},
    "bank_interest":      {"name": "🏦 Bank Interest",     "price": 5000,  "desc": "+5% bank interest per day", "category": "powerups"},
    "investor_badge":     {"name": "📈 Investor Badge",     "price": 10000, "desc": "Show you're an investor", "category": "powerups"},
    "tycoon_badge":       {"name": "💼 Tycoon Badge",       "price": 25000, "desc": "Tycoon status", "category": "powerups"},
    "millionaire_badge":  {"name": "💰 Millionaire Badge",  "price": 100000, "desc": "Millionaire status", "category": "powerups"},

    "nickname":           {"name": "✏️ Custom Nickname",    "price": 1000,  "desc": "Change your nickname", "category": "customization"},
    "color_role":         {"name": "🎨 Color Role",         "price": 2000,  "desc": "Custom color role", "category": "customization"},
    "custom_embed":       {"name": "🖼️ Custom Embed",      "price": 5000,  "desc": "Custom embed color", "category": "customization"},
    "profile_border":     {"name": "🖼️ Profile Border",    "price": 3000,  "desc": "Custom profile border", "category": "customization"},
    "animated_avatar":    {"name": "🎞️ Animated Avatar",   "price": 8000,  "desc": "Animated avatar frame", "category": "customization"},
    "custom_banner":      {"name": "🎨 Custom Banner",      "price": 5000,  "desc": "Custom profile banner", "category": "customization"},
    "glowing_name":       {"name": "✨ Glowing Name",       "price": 3000,  "desc": "Glowing name effect", "category": "customization"},
    "rainbow_name":       {"name": "🌈 Rainbow Name",       "price": 5000,  "desc": "Rainbow name effect", "category": "customization"},
    "sparkle_effect":     {"name": "✨ Sparkle Effect",     "price": 2000,  "desc": "Sparkle avatar effect", "category": "customization"},
    "fire_effect":        {"name": "🔥 Fire Effect",        "price": 3000,  "desc": "Fire avatar effect", "category": "customization"},
    "ice_effect":         {"name": "❄️ Ice Effect",         "price": 3000,  "desc": "Ice avatar effect", "category": "customization"},
    "lightning_effect":   {"name": "⚡ Lightning Effect",   "price": 4000,  "desc": "Lightning avatar effect", "category": "customization"},
    "crown_effect":       {"name": "👑 Crown Effect",       "price": 5000,  "desc": "Crown avatar effect", "category": "customization"},
    "heart_effect":       {"name": "❤️ Heart Effect",       "price": 2000,  "desc": "Heart avatar effect", "category": "customization"},
    "star_effect":        {"name": "⭐ Star Effect",        "price": 2500,  "desc": "Star avatar effect", "category": "customization"},
    "moon_effect":        {"name": "🌙 Moon Effect",        "price": 2500,  "desc": "Moon avatar effect", "category": "customization"},
    "sun_effect":         {"name": "☀️ Sun Effect",         "price": 2500,  "desc": "Sun avatar effect", "category": "customization"},
    "galaxy_effect":      {"name": "🌌 Galaxy Effect",      "price": 6000,  "desc": "Galaxy avatar effect", "category": "customization"},

    "lottery_ticket":     {"name": "🎟️ Lottery Ticket",    "price": 100,   "desc": "Enter the daily lottery", "category": "special"},
    "mystery_box":        {"name": "📦 Mystery Box",        "price": 500,   "desc": "Random mystery item", "category": "special"},
    "golden_apple":       {"name": "🍎 Golden Apple",       "price": 1000,  "desc": "A magical golden apple", "category": "special"},
    "dragon_egg":         {"name": "🥚 Dragon Egg",         "price": 5000,  "desc": "A rare dragon egg", "category": "special"},
    "phoenix_feather":    {"name": "🪶 Phoenix Feather",    "price": 3000,  "desc": "A phoenix feather", "category": "special"},
    "unicorn_horn":       {"name": "🦄 Unicorn Horn",       "price": 4000,  "desc": "A unicorn horn", "category": "special"},
    "mermaid_tear":       {"name": "🧜 Mermaid Tear",       "price": 2000,  "desc": "A mermaid tear", "category": "special"},
    "fairy_dust":         {"name": "🧚 Fairy Dust",         "price": 1500,  "desc": "Magical fairy dust", "category": "special"},
    "wizard_staff":       {"name": "🪄 Wizard Staff",       "price": 3000,  "desc": "A wizard's staff", "category": "special"},
    "enchanted_book":     {"name": "📖 Enchanted Book",     "price": 2000,  "desc": "An enchanted book", "category": "special"},
    "potion_of_wealth":   {"name": "🧪 Potion of Wealth",   "price": 2500,  "desc": "Temporary wealth boost", "category": "special"},
    "potion_of_luck":     {"name": "🧪 Potion of Luck",     "price": 1500,  "desc": "Temporary luck boost", "category": "special"},
    "potion_of_strength": {"name": "🧪 Potion of Strength", "price": 2000,  "desc": "Temporary strength boost", "category": "special"},
    "potion_of_speed":    {"name": "🧪 Potion of Speed",    "price": 2000,  "desc": "Temporary speed boost", "category": "special"},
    "potion_of_healing":  {"name": "🧪 Potion of Healing",  "price": 1000,  "desc": "Restore health", "category": "special"},
    "potion_of_mana":     {"name": "🧪 Potion of Mana",     "price": 1000,  "desc": "Restore mana", "category": "special"},
    "potion_of_stealth":  {"name": "🧪 Potion of Stealth",  "price": 1500,  "desc": "Temporary invisibility", "category": "special"},
    "potion_of_fire":     {"name": "🧪 Potion of Fire",     "price": 800,   "desc": "Fire resistance", "category": "special"},
    "potion_of_ice":      {"name": "🧪 Potion of Ice",      "price": 800,   "desc": "Ice resistance", "category": "special"},
    "potion_of_lightning":{"name": "🧪 Potion of Lightning", "price": 1000,  "desc": "Lightning resistance", "category": "special"},
    "potion_of_poison":   {"name": "🧪 Potion of Poison",   "price": 500,   "desc": "Poison resistance", "category": "special"},
    "potion_of_undead":   {"name": "🧪 Potion of Undead",   "price": 3000,  "desc": "Undead transformation", "category": "special"},

    "pet_cat":            {"name": "🐱 Cat",                "price": 1000,  "desc": "A cute pet cat", "category": "pets"},
    "pet_dog":            {"name": "🐶 Dog",                "price": 1000,  "desc": "A loyal pet dog", "category": "pets"},
    "pet_dragon":         {"name": "🐉 Dragon",             "price": 5000,  "desc": "A majestic dragon", "category": "pets"},
    "pet_phoenix":        {"name": "🦅 Phoenix",            "price": 4000,  "desc": "A mythical phoenix", "category": "pets"},
    "pet_unicorn":        {"name": "🦄 Unicorn",            "price": 4000,  "desc": "A magical unicorn", "category": "pets"},
    "pet_wolf":           {"name": "🐺 Wolf",               "price": 2000,  "desc": "A fierce wolf", "category": "pets"},
    "pet_fox":            {"name": "🦊 Fox",                "price": 1500,  "desc": "A clever fox", "category": "pets"},
    "pet_panda":          {"name": "🐼 Panda",              "price": 2000,  "desc": "A cute panda", "category": "pets"},
    "pet_penguin":        {"name": "🐧 Penguin",            "price": 1500,  "desc": "A cute penguin", "category": "pets"},
    "pet_owl":            {"name": "🦉 Owl",                "price": 1500,  "desc": "A wise owl", "category": "pets"},
    "pet_raven":          {"name": "🐦 Raven",              "price": 1200,  "desc": "A mysterious raven", "category": "pets"},
    "pet_snake":          {"name": "🐍 Snake",              "price": 1000,  "desc": "A slithery snake", "category": "pets"},
    "pet_turtle":         {"name": "🐢 Turtle",             "price": 800,   "desc": "A wise turtle", "category": "pets"},
    "pet_rabbit":         {"name": "🐰 Rabbit",             "price": 800,   "desc": "A cute rabbit", "category": "pets"},
    "pet_hamster":        {"name": "🐹 Hamster",            "price": 500,   "desc": "A tiny hamster", "category": "pets"},
    "pet_parrot":         {"name": "🦜 Parrot",             "price": 1200,  "desc": "A colorful parrot", "category": "pets"},
    "pet_shark":          {"name": "🦈 Shark",              "price": 3000,  "desc": "A terrifying shark", "category": "pets"},
    "pet_whale":          {"name": "🐋 Whale",              "price": 3000,  "desc": "A majestic whale", "category": "pets"},
    "pet_dolphin":        {"name": "🐬 Dolphin",            "price": 2500,  "desc": "A friendly dolphin", "category": "pets"},
    "pet_tiger":          {"name": "🐯 Tiger",              "price": 3000,  "desc": "A powerful tiger", "category": "pets"},
    "pet_lion":           {"name": "🦁 Lion",               "price": 3000,  "desc": "A majestic lion", "category": "pets"},
    "pet_elephant":       {"name": "🐘 Elephant",           "price": 2500,  "desc": "A gentle giant", "category": "pets"},
    "pet_giraffe":        {"name": "🦒 Giraffe",            "price": 2000,  "desc": "A tall giraffe", "category": "pets"},
    "pet_monkey":         {"name": "🐒 Monkey",             "price": 1500,  "desc": "A mischievous monkey", "category": "pets"},
}

JOBS = [

    {"name": "Software Engineer", "emoji": "💻", "min_pay": 150, "max_pay": 350},
    {"name": "Web Developer", "emoji": "🌐", "min_pay": 120, "max_pay": 300},
    {"name": "Data Scientist", "emoji": "📊", "min_pay": 180, "max_pay": 400},
    {"name": "AI Engineer", "emoji": "🤖", "min_pay": 200, "max_pay": 450},
    {"name": "Cybersecurity Analyst", "emoji": "🔒", "min_pay": 160, "max_pay": 380},
    {"name": "Game Developer", "emoji": "🎮", "min_pay": 140, "max_pay": 350},
    {"name": "DevOps Engineer", "emoji": "⚙️", "min_pay": 170, "max_pay": 380},
    {"name": "Cloud Architect", "emoji": "☁️", "min_pay": 190, "max_pay": 420},
    {"name": "Database Administrator", "emoji": "🗄️", "min_pay": 130, "max_pay": 320},
    {"name": "Network Administrator", "emoji": "🌐", "min_pay": 120, "max_pay": 300},
    {"name": "Systems Analyst", "emoji": "💻", "min_pay": 140, "max_pay": 340},
    {"name": "IT Support Specialist", "emoji": "🛠️", "min_pay": 100, "max_pay": 250},

    {"name": "Graphic Designer", "emoji": "🎨", "min_pay": 130, "max_pay": 320},
    {"name": "UX/UI Designer", "emoji": "🖌️", "min_pay": 140, "max_pay": 340},
    {"name": "Video Editor", "emoji": "🎬", "min_pay": 120, "max_pay": 300},
    {"name": "Animator", "emoji": "🎞️", "min_pay": 150, "max_pay": 350},
    {"name": "3D Modeler", "emoji": "🎨", "min_pay": 160, "max_pay": 360},
    {"name": "Photographer", "emoji": "📸", "min_pay": 110, "max_pay": 280},
    {"name": "Illustrator", "emoji": "✏️", "min_pay": 120, "max_pay": 300},
    {"name": "Motion Graphics Designer", "emoji": "🎞️", "min_pay": 150, "max_pay": 360},
    {"name": "Content Creator", "emoji": "📱", "min_pay": 100, "max_pay": 280},
    {"name": "Social Media Manager", "emoji": "📱", "min_pay": 110, "max_pay": 280},
    {"name": "Copywriter", "emoji": "✍️", "min_pay": 100, "max_pay": 260},
    {"name": "Technical Writer", "emoji": "📝", "min_pay": 120, "max_pay": 300},

    {"name": "Doctor", "emoji": "🩺", "min_pay": 250, "max_pay": 500},
    {"name": "Nurse", "emoji": "👩‍⚕️", "min_pay": 180, "max_pay": 380},
    {"name": "Surgeon", "emoji": "🔬", "min_pay": 300, "max_pay": 600},
    {"name": "Pharmacist", "emoji": "💊", "min_pay": 160, "max_pay": 360},
    {"name": "Dentist", "emoji": "🦷", "min_pay": 200, "max_pay": 450},
    {"name": "Veterinarian", "emoji": "🐾", "min_pay": 150, "max_pay": 350},
    {"name": "Paramedic", "emoji": "🚑", "min_pay": 140, "max_pay": 320},
    {"name": "Medical Researcher", "emoji": "🔬", "min_pay": 180, "max_pay": 400},

    {"name": "CEO", "emoji": "💼", "min_pay": 400, "max_pay": 800},
    {"name": "Entrepreneur", "emoji": "🚀", "min_pay": 200, "max_pay": 500},
    {"name": "Manager", "emoji": "📋", "min_pay": 180, "max_pay": 400},
    {"name": "Accountant", "emoji": "🧮", "min_pay": 140, "max_pay": 340},
    {"name": "Financial Analyst", "emoji": "📈", "min_pay": 160, "max_pay": 380},
    {"name": "Marketing Manager", "emoji": "📣", "min_pay": 150, "max_pay": 360},
    {"name": "Sales Representative", "emoji": "📞", "min_pay": 120, "max_pay": 320},
    {"name": "Human Resources", "emoji": "👥", "min_pay": 130, "max_pay": 320},
    {"name": "Recruiter", "emoji": "🔍", "min_pay": 120, "max_pay": 300},
    {"name": "Project Manager", "emoji": "📊", "min_pay": 170, "max_pay": 390},

    {"name": "Electrician", "emoji": "⚡", "min_pay": 140, "max_pay": 340},
    {"name": "Plumber", "emoji": "🔧", "min_pay": 130, "max_pay": 320},
    {"name": "Carpenter", "emoji": "🪚", "min_pay": 120, "max_pay": 300},
    {"name": "Mechanic", "emoji": "🔩", "min_pay": 120, "max_pay": 300},
    {"name": "Welder", "emoji": "⚡", "min_pay": 130, "max_pay": 320},
    {"name": "Construction Worker", "emoji": "🏗️", "min_pay": 110, "max_pay": 280},
    {"name": "Painter", "emoji": "🎨", "min_pay": 100, "max_pay": 260},
    {"name": "Landscaper", "emoji": "🌿", "min_pay": 100, "max_pay": 260},
    {"name": "Chef", "emoji": "👨‍🍳", "min_pay": 130, "max_pay": 320},
    {"name": "Baker", "emoji": "🧁", "min_pay": 110, "max_pay": 280},
    {"name": "Barista", "emoji": "☕", "min_pay": 90, "max_pay": 240},

    {"name": "Musician", "emoji": "🎵", "min_pay": 120, "max_pay": 300},
    {"name": "Singer", "emoji": "🎤", "min_pay": 130, "max_pay": 320},
    {"name": "Actor", "emoji": "🎭", "min_pay": 140, "max_pay": 340},
    {"name": "Dancer", "emoji": "💃", "min_pay": 110, "max_pay": 280},
    {"name": "Director", "emoji": "🎬", "min_pay": 180, "max_pay": 400},
    {"name": "Screenwriter", "emoji": "📝", "min_pay": 130, "max_pay": 320},
    {"name": "Voice Actor", "emoji": "🎙️", "min_pay": 120, "max_pay": 300},
    {"name": "Composer", "emoji": "🎼", "min_pay": 140, "max_pay": 340},

    {"name": "Teacher", "emoji": "👨‍🏫", "min_pay": 130, "max_pay": 320},
    {"name": "Professor", "emoji": "👨‍🎓", "min_pay": 180, "max_pay": 420},
    {"name": "Tutor", "emoji": "📚", "min_pay": 90, "max_pay": 240},
    {"name": "Librarian", "emoji": "📚", "min_pay": 110, "max_pay": 280},
]

BANK_NAMES = [
    "Sparky Bank", "Galactic Union", "Golden Treasury", "Emerald Federal",
    "Digital Vault", "Oceanic Reserve", "Crystal Trust", "Phoenix Financial",
    "Apex Banking", "Stellar Savings", "Iron Bank", "First Republic",
    "Merchant's Guild", "Royal Bank", "Highland Credit", "Valley National",
    "Bridgewater Bank", "Sovereign Savings", "Liberty Federal", "Pioneer Trust"
]

def _get_global_user(user_id: int) -> dict:
    data = load(ECO_FILE)
    user_data = data.get("global", {}).get(str(user_id), {
        "wallet": Config.STARTING_BALANCE,
        "bank": 0,
        "last_daily": None,
        "last_work": None,
        "job": None,
        "job_cooldown": None,
        "inventory": [],
        "boosts": {
            "xp": None,
            "coins": None,
            "gamble": None,
        },
        "premium_items": [],
        "total_earned": 0,
        "total_work_count": 0,
        "bargains_used": 0,
        "last_bargain_reset": None,
        "bank_account": None,
        "bank_name": None,
        "created_at": None,

        "loan": None,
        "loan_cooldown_until": None,
        "transactions": [],
    })

    if "loan" not in user_data:
        user_data["loan"] = None
    if "loan_cooldown_until" not in user_data:
        user_data["loan_cooldown_until"] = None
    if "transactions" not in user_data:
        user_data["transactions"] = []
    if "bargains_used" not in user_data:
        user_data["bargains_used"] = 0
    if "last_bargain_reset" not in user_data:
        user_data["last_bargain_reset"] = None
    if "bank_account" not in user_data or user_data["bank_account"] is None:
        user_data["bank_account"] = ''.join(random.choices(string.digits, k=10))
    if "bank_name" not in user_data or user_data["bank_name"] is None:
        user_data["bank_name"] = random.choice(BANK_NAMES)
    if "created_at" not in user_data or user_data["created_at"] is None:
        user_data["created_at"] = datetime.now(timezone.utc).isoformat()
    save(ECO_FILE, data)
    return user_data

def _save_global_user(user_id: int, user_data: dict):
    data = load(ECO_FILE)
    data.setdefault("global", {})[str(user_id)] = user_data
    save(ECO_FILE, data)

def eco_embed(title: str, desc: str, color=Config.COLOR_GOLD) -> discord.Embed:
    return build(title=title, description=desc, color=color, emoji=Emojis.DOLLAR)

def format_money(amount: int) -> str:
    if amount >= 1_000_000:
        return f"${amount/1_000_000:.1f}M"
    elif amount >= 1_000:
        return f"${amount/1_000:.1f}k"
    else:
        return f"${amount}"

def parse_amount(amount_str: str) -> int:
    amount_str = amount_str.lower().strip()
    multipliers = {
        'k': 1_000,
        'm': 1_000_000,
        'b': 1_000_000_000,
        't': 1_000_000_000_000
    }
    if amount_str[-1] in multipliers:
        try:
            num = float(amount_str[:-1])
            return int(num * multipliers[amount_str[-1]])
        except ValueError:
            raise ValueError("Invalid number format")
    else:
        try:
            return int(amount_str)
        except ValueError:
            raise ValueError("Invalid amount")

def add_transaction(user_id: int, t_type: str, amount: int, description: str):
    user_data = _get_global_user(user_id)
    user_data["transactions"].append({
        "type": t_type,
        "amount": amount,
        "description": description,
        "timestamp": datetime.now(timezone.utc).isoformat()
    })

    if len(user_data["transactions"]) > 100:
        user_data["transactions"] = user_data["transactions"][-100:]
    _save_global_user(user_id, user_data)

ITEM_EFFECTS = {
    "golden_apple":   {"type": "coins", "value": 2000},
    "mystery_box":    {"type": "coins", "value": random.randint(100, 500)},
    "lottery_ticket": {"type": "coins", "value": 1500},
    "dragon_egg":     {"type": "coins", "value": 5000},
    "phoenix_feather":{"type": "coins", "value": 3000},
    "unicorn_horn":   {"type": "coins", "value": 4000},
    "mermaid_tear":   {"type": "coins", "value": 2000},
    "fairy_dust":     {"type": "coins", "value": 1500},
    "wizard_staff":   {"type": "coins", "value": 3000},
    "enchanted_book": {"type": "coins", "value": 2000},
    "vip_role":       {"type": "role", "role_key": "vip_role_id"},
    "premium_role":   {"type": "role", "role_key": "premium_role_id"},
    "booster_role":   {"type": "role", "role_key": "booster_role_id"},
    "legend_role":    {"type": "role", "role_key": "legend_role_id"},
    "elite_role":     {"type": "role", "role_key": "elite_role_id"},
    "supporter_role": {"type": "role", "role_key": "supporter_role_id"},
    "veteran_role":   {"type": "role", "role_key": "veteran_role_id"},
    "champion_role":  {"type": "role", "role_key": "champion_role_id"},
    "hero_role":      {"type": "role", "role_key": "hero_role_id"},
    "god_role":       {"type": "role", "role_key": "god_role_id"},
    "color_red":      {"type": "role", "role_key": "color_red_id"},
    "color_blue":     {"type": "role", "role_key": "color_blue_id"},
    "color_green":    {"type": "role", "role_key": "color_green_id"},
    "color_yellow":   {"type": "role", "role_key": "color_yellow_id"},
    "color_purple":   {"type": "role", "role_key": "color_purple_id"},
    "color_orange":   {"type": "role", "role_key": "color_orange_id"},
    "color_pink":     {"type": "role", "role_key": "color_pink_id"},
    "color_cyan":     {"type": "role", "role_key": "color_cyan_id"},
    "color_brown":    {"type": "role", "role_key": "color_brown_id"},
    "color_white":    {"type": "role", "role_key": "color_white_id"},
    "color_black":    {"type": "role", "role_key": "color_black_id"},
    "color_gold":     {"type": "role", "role_key": "color_gold_id"},
    "color_silver":   {"type": "role", "role_key": "color_silver_id"},
    "color_bronze":   {"type": "role", "role_key": "color_bronze_id"},
}

def _get_guild_role_config(guild_id: int) -> dict:
    config = load(SHOP_CONFIG_FILE)
    guild_str = str(guild_id)
    if guild_str not in config:
        config[guild_str] = {}
    return config[guild_str]

def _save_guild_role_config(guild_id: int, config_data: dict):
    config = load(SHOP_CONFIG_FILE)
    config[str(guild_id)] = config_data
    save(SHOP_CONFIG_FILE, config)

class ShopPaginationView(discord.ui.View):
    def __init__(self, items: list, items_per_page: int = 10, author_id: int = None):
        super().__init__(timeout=120)
        self.items = items
        self.items_per_page = items_per_page
        self.current_page = 0
        self.total_pages = max(1, (len(items) + items_per_page - 1) // items_per_page)
        self.author_id = author_id
        self.message = None
        self._update_buttons()

    def _update_buttons(self):
        self.clear_items()
        self.add_item(self.prev_btn)
        self.add_item(self.page_counter)
        self.add_item(self.next_btn)
        self.add_item(self.close_btn)
        self.prev_btn.disabled = self.current_page == 0
        self.next_btn.disabled = self.current_page >= self.total_pages - 1

    def _get_page_items(self) -> list:
        start = self.current_page * self.items_per_page
        end = start + self.items_per_page
        return self.items[start:end]

    def _build_embed(self) -> discord.Embed:
        page_items = self._get_page_items()
        embed = build(title="🛒 Item Shop", description=f"**Page {self.current_page + 1}/{self.total_pages}**\nBuy items with `$buy <item_key>`\n", color=Config.COLOR_GOLD, bot=self.bot)
        if not page_items:
            embed.description += "\n*No items on this page.*"
            return embed
        for key, item in page_items:
            embed.add_field(
                name=f"{item['name']} • `${item['price']:,}`",
                value=f"{item['desc']}\nKey: `{key}`",
                inline=False
            )
        embed.set_footer(text=f"Total: {len(self.items)} items • Use buttons to navigate")
        return embed

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if self.author_id and interaction.user.id != self.author_id:
            await interaction.response.send_message("❌ Only the person who opened the shop can navigate it.", ephemeral=True)
            return False
        return True

    @discord.ui.button(emoji="◀️", style=discord.ButtonStyle.secondary)
    async def prev_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.current_page > 0:
            self.current_page -= 1
        self._update_buttons()
        await interaction.response.edit_message(embed=self._build_embed(), view=self)

    @discord.ui.button(label="📄", style=discord.ButtonStyle.primary, disabled=True)
    async def page_counter(self, interaction: discord.Interaction, button: discord.ui.Button):
        pass

    @discord.ui.button(emoji="▶️", style=discord.ButtonStyle.secondary)
    async def next_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.current_page < self.total_pages - 1:
            self.current_page += 1
        self._update_buttons()
        await interaction.response.edit_message(embed=self._build_embed(), view=self)

    @discord.ui.button(label="✖ Close", style=discord.ButtonStyle.danger)
    async def close_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(
            embed=build(title="🛒 Shop Closed", description="The shop has been closed.", color=Config.COLOR_ERR, bot=self.bot),
            view=None
        )
        self.stop()

    async def on_timeout(self):
        if self.message:
            try:
                await self.message.edit(
                    embed=build(title="🛒 Shop Timed Out", description="The shop has been closed due to inactivity.", color=Config.COLOR_ERR, bot=self.bot),
                    view=None
                )
            except:
                pass

class JobSelect(discord.ui.Select):
    def __init__(self, jobs: list, user_id: int):
        self.jobs = jobs
        self.user_id = user_id
        options = []
        for job in jobs[:25]:
            options.append(
                discord.SelectOption(
                    label=job["name"],
                    description=f"${job['min_pay']} - ${job['max_pay']} per work",
                    emoji=job["emoji"]
                )
            )
        super().__init__(placeholder="🔍 Select your dream job...", options=options, min_values=1, max_values=1)

    async def callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.user_id:
            return await interaction.response.send_message("❌ This isn't for you.", ephemeral=True)
        selected = self.values[0]
        job = None
        for j in self.jobs:
            if j["name"] == selected:
                job = j
                break
        if not job:
            return await interaction.response.send_message("❌ Job not found.", ephemeral=True)
        user_data = _get_global_user(interaction.user.id)
        user_data["job"] = job
        _save_global_user(interaction.user.id, user_data)
        embed = build(title="✅ Job Selected!", description=f"You are now a **{job['emoji']} {job['name']}**!\n\n"
                       f"**Pay Range:** ${job['min_pay']:,} - ${job['max_pay']:,}\n"
                       f"**Next Step:** Use `$work` to start earning!", color=Config.COLOR_OK, bot=self.bot)
        await interaction.response.edit_message(embed=embed, view=None)

class JobView(discord.ui.View):
    def __init__(self, jobs: list, user_id: int):
        super().__init__(timeout=120)
        self.add_item(JobSelect(jobs, user_id))

class BargainModal(discord.ui.Modal, title="💰 Bargain"):
    offer = discord.ui.TextInput(
        label="Your Offer (price you want to pay)",
        placeholder="Enter a number between 80% and 90% of original price",
        required=True,
        min_length=1,
        max_length=10
    )

    def __init__(self, item_key: str, original_price: int, user_id: int, cog):
        super().__init__()
        self.item_key = item_key
        self.original_price = original_price
        self.user_id = user_id
        self.cog = cog

    async def on_submit(self, interaction: discord.Interaction):
        user_data = _get_global_user(self.user_id)
        now = datetime.now(timezone.utc)
        last_reset = user_data.get("last_bargain_reset")
        if last_reset:
            last = datetime.fromisoformat(last_reset)
            if now - last >= timedelta(hours=24):
                user_data["bargains_used"] = 0
                user_data["last_bargain_reset"] = now.isoformat()
        if user_data.get("bargains_used", 0) >= 3:
            await interaction.response.send_message("❌ You have used all 3 bargains for today.", ephemeral=True)
            return
        try:
            offer = int(self.offer.value)
        except ValueError:
            await interaction.response.send_message("❌ Please enter a valid number.", ephemeral=True)
            return
        if offer <= 0:
            await interaction.response.send_message("❌ Offer must be positive.", ephemeral=True)
            return
        min_price = int(self.original_price * 0.8)
        max_price = int(self.original_price * 0.9)
        if min_price == max_price:
            min_price -= 1
        if min_price <= offer <= max_price:
            final_price = offer
            discount = True
        else:
            final_price = self.original_price + 5
            discount = False
        if user_data["wallet"] < final_price:
            await interaction.response.send_message(f"❌ Insufficient funds. You need **${final_price:,}**.", ephemeral=True)
            return
        user_data["wallet"] -= final_price
        user_data["inventory"].append(self.item_key)
        user_data["bargains_used"] = user_data.get("bargains_used", 0) + 1
        user_data["last_bargain_reset"] = now.isoformat()
        _save_global_user(self.user_id, user_data)
        shop_item = SHOP_ITEMS[self.item_key]
        if discount:
            embed = build(title="✅ Bargain Successful!", description=f"You bought **{shop_item['name']}** for **${final_price:,}** (was ${self.original_price:,})!", color=Config.COLOR_OK, bot=self.bot)
        else:
            embed = discord.Embed(
                title="⚠️ Bargain Failed",
                description=f"Your offer was outside the acceptable range (${min_price:,} - ${max_price:,}). You paid full price **${self.original_price:,}** plus a $5 fine, total **${final_price:,}**.",
                color=Config.COLOR_WARN
            )
        embed.add_field(name="Remaining Bargains Today", value=f"{3 - user_data['bargains_used']}", inline=True)
        await interaction.response.send_message(embed=embed, ephemeral=False)

    async def on_error(self, interaction: discord.Interaction, error: Exception):
        await interaction.response.send_message("❌ Something went wrong with your bargain.", ephemeral=True)

class BuyConfirmView(discord.ui.View):
    def __init__(self, item_key: str, price: int, user_id: int, cog):
        super().__init__(timeout=120)
        self.item_key = item_key
        self.price = price
        self.user_id = user_id
        self.cog = cog

    @discord.ui.button(label="✅ Confirm", style=discord.ButtonStyle.success)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("❌ This is not your transaction.", ephemeral=True)
            return
        user_data = _get_global_user(self.user_id)
        if user_data["wallet"] < self.price:
            await interaction.response.send_message(f"❌ Insufficient funds. You need **${self.price:,}**.", ephemeral=True)
            return
        user_data["wallet"] -= self.price
        user_data["inventory"].append(self.item_key)
        _save_global_user(self.user_id, user_data)
        shop_item = SHOP_ITEMS[self.item_key]
        embed = build(title="✅ Purchase Complete!", description=f"You bought **{shop_item['name']}** for **${self.price:,}**.", color=Config.COLOR_OK, bot=self.bot)
        await interaction.response.edit_message(embed=embed, view=None)
        self.stop()

    @discord.ui.button(label="🤝 Bargain", style=discord.ButtonStyle.secondary)
    async def bargain(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("❌ This is not your transaction.", ephemeral=True)
            return
        user_data = _get_global_user(self.user_id)
        now = datetime.now(timezone.utc)
        last_reset = user_data.get("last_bargain_reset")
        if last_reset:
            last = datetime.fromisoformat(last_reset)
            if now - last >= timedelta(hours=24):
                user_data["bargains_used"] = 0
                user_data["last_bargain_reset"] = now.isoformat()
                _save_global_user(self.user_id, user_data)
        if user_data.get("bargains_used", 0) >= 3:
            await interaction.response.send_message("❌ You have used all 3 bargains for today.", ephemeral=True)
            return
        modal = BargainModal(self.item_key, self.price, self.user_id, self.cog)
        await interaction.response.send_modal(modal)

    @discord.ui.button(label="❌ Cancel", style=discord.ButtonStyle.danger)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("❌ This is not your transaction.", ephemeral=True)
            return
        embed = build(title="🛑 Purchase Cancelled", description="You cancelled the transaction.", color=Config.COLOR_ERR, bot=self.bot)
        await interaction.response.edit_message(embed=embed, view=None)
        self.stop()

class SellConfirmView(discord.ui.View):
    def __init__(self, item_key: str, quantity: int, price_per: int, user_id: int):
        super().__init__(timeout=120)
        self.item_key = item_key
        self.quantity = quantity
        self.price_per = price_per
        self.user_id = user_id

    @discord.ui.button(label="✅ Sell", style=discord.ButtonStyle.success)
    async def sell_confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("❌ This is not your transaction.", ephemeral=True)
            return
        user_data = _get_global_user(self.user_id)
        inv = user_data.get("inventory", [])
        count = inv.count(self.item_key)
        if count < self.quantity:
            await interaction.response.send_message("❌ You don't have that many items.", ephemeral=True)
            return
        removed = 0
        while removed < self.quantity:
            inv.remove(self.item_key)
            removed += 1
        user_data["inventory"] = inv
        total = self.price_per * self.quantity
        user_data["wallet"] += total
        _save_global_user(self.user_id, user_data)
        shop_item = SHOP_ITEMS[self.item_key]
        embed = build(title="💰 Sold!", description=f"Sold **{self.quantity}x {shop_item['name']}** for **${total:,}** (${self.price_per:,} each).", color=Config.COLOR_OK, bot=self.bot)
        await interaction.response.edit_message(embed=embed, view=None)
        self.stop()

    @discord.ui.button(label="❌ Cancel", style=discord.ButtonStyle.danger)
    async def sell_cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("❌ This is not your transaction.", ephemeral=True)
            return
        embed = build(title="🛑 Sale Cancelled", description="You cancelled the sale.", color=Config.COLOR_ERR, bot=self.bot)
        await interaction.response.edit_message(embed=embed, view=None)
        self.stop()

class LoanAmountSelect(discord.ui.Select):
    def __init__(self, user_id: int):
        self.user_id = user_id
        options = [
            discord.SelectOption(label="$500", value="500", emoji="💵"),
            discord.SelectOption(label="$1,000", value="1000", emoji="💵"),
            discord.SelectOption(label="$5,000", value="5000", emoji="💵"),
            discord.SelectOption(label="$10,000", value="10000", emoji="💵"),
            discord.SelectOption(label="$50,000", value="50000", emoji="💵"),
        ]
        super().__init__(placeholder="💳 Select loan amount...", options=options, min_values=1, max_values=1)

    async def callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.user_id:
            return await interaction.response.send_message("❌ This is not for you.", ephemeral=True)
        amount = int(self.values[0])
        view = LoanPlanView(amount, self.user_id)
        embed = view._build_embed()
        await interaction.response.edit_message(embed=embed, view=view)

class LoanAmountView(discord.ui.View):
    def __init__(self, user_id: int):
        super().__init__(timeout=120)
        self.add_item(LoanAmountSelect(user_id))

class LoanPlanView(discord.ui.View):
    def __init__(self, amount: int, user_id: int):
        super().__init__(timeout=120)
        self.amount = amount
        self.user_id = user_id
        self.plans = [
            {"rate": 0.05, "tenure": 7},
            {"rate": 0.10, "tenure": 14},
            {"rate": 0.15, "tenure": 30},
            {"rate": 0.20, "tenure": 60},
        ]
        self._add_buttons()

    def _add_buttons(self):
        for i, plan in enumerate(self.plans, 1):
            total_repay = int(self.amount * (1 + plan["rate"]))
            daily = int(total_repay / plan["tenure"])
            label = f"Option {i}: {plan['rate']*100:.0f}% in {plan['tenure']} days"
            button = discord.ui.Button(label=label, style=discord.ButtonStyle.secondary, custom_id=f"plan_{i-1}")
            button.callback = self.make_callback(i-1)
            self.add_item(button)

    def make_callback(self, index):
        async def callback(interaction: discord.Interaction):
            if interaction.user.id != self.user_id:
                return await interaction.response.send_message("❌ This is not for you.", ephemeral=True)
            plan = self.plans[index]
            total_repay = int(self.amount * (1 + plan["rate"]))
            daily = int(total_repay / plan["tenure"])
            user_data = _get_global_user(self.user_id)
            if user_data.get("loan") is not None:
                return await interaction.response.send_message("❌ You already have an active loan.", ephemeral=True)
            cooldown = user_data.get("loan_cooldown_until")
            if cooldown:
                cooldown_dt = datetime.fromisoformat(cooldown)
                if datetime.now(timezone.utc) < cooldown_dt:
                    remaining = cooldown_dt - datetime.now(timezone.utc)
                    days = remaining.days
                    hours, rem = divmod(remaining.seconds, 3600)
                    return await interaction.response.send_message(f"❌ You are on cooldown. Please wait **{days}d {hours}h** before taking another loan.", ephemeral=True)
            now = datetime.now(timezone.utc)
            loan = {
                "principal": self.amount,
                "interest_rate": plan["rate"],
                "tenure_days": plan["tenure"],
                "total_repay": total_repay,
                "daily_installment": daily,
                "remaining_balance": total_repay,
                "installments_paid": 0,
                "next_due": now.isoformat(),
                "start_date": now.isoformat(),
                "completed": False
            }
            user_data["loan"] = loan
            user_data["wallet"] += self.amount
            _save_global_user(self.user_id, user_data)
            add_transaction(self.user_id, "loan_taken", self.amount, f"Loan of ${self.amount} taken with {plan['rate']*100:.0f}% interest over {plan['tenure']} days.")
            embed = discord.Embed(
                title="✅ Loan Approved!",
                description=f"You received **${self.amount:,}** in your wallet.\n"
                            f"**Repayment Plan:** {plan['rate']*100:.0f}% interest, {plan['tenure']} days\n"
                            f"**Total to repay:** ${total_repay:,}\n"
                            f"**Daily installment:** ${daily:,}\n"
                            f"First deduction will occur in ~24 hours.",
                color=Config.COLOR_OK
            )
            await interaction.response.edit_message(embed=embed, view=None)
            self.stop()
        return callback

    def _build_embed(self) -> discord.Embed:
        embed = build(title="💳 Choose Repayment Plan", description=f"Amount: **${self.amount:,}**\nSelect one of the 4 options below:", color=Config.COLOR_GOLD, bot=self.bot)
        for i, plan in enumerate(self.plans, 1):
            total_repay = int(self.amount * (1 + plan["rate"]))
            daily = int(total_repay / plan["tenure"])
            embed.add_field(
                name=f"Option {i}",
                value=f"Interest: {plan['rate']*100:.0f}%\nTenure: {plan['tenure']} days\nTotal: ${total_repay:,}\nDaily: ${daily:,}",
                inline=True
            )
        return embed

class Economy(commands.Cog):

    eco = app_commands.Group(name="eco", description="Economy commands")

    def __init__(self, bot):
        self.bot = bot

        self.admin_group = app_commands.Group(name="admin", description="Admin/Owner economy commands")
        self.eco.add_command(self.admin_group)

        self.admin_group.add_command(
            app_commands.Command(
                name="addmoney",
                description="[OWNER] Add money to a user's wallet with k/m/b/t support.",
                callback=self.addmoney_slash_callback,
            )
        )
        self.admin_group.add_command(
            app_commands.Command(
                name="setrolerole",
                description="[ADMIN] Set the role granted by any role item",
                callback=self.set_role_item_slash,
            )
        )
        self.admin_group.add_command(
            app_commands.Command(
                name="removeroleitem",
                description="[ADMIN] Remove/disable a role item from the shop",
                callback=self.remove_role_item_slash,
            )
        )
        self.admin_group.add_command(
            app_commands.Command(
                name="roleitemsconfig",
                description="[ADMIN] View all role item configurations",
                callback=self.role_items_config_slash,
            )
        )
        self.admin_group.add_command(
            app_commands.Command(
                name="removeroleitemsall",
                description="[ADMIN] Remove ALL role item configurations",
                callback=self.remove_all_role_items_slash,
            )
        )

        self.loan_checker.start()

    def cog_unload(self):
        self.loan_checker.cancel()

    @tasks.loop(hours=1)
    async def loan_checker(self):
        data = load(ECO_FILE)
        global_data = data.get("global", {})
        now = datetime.now(timezone.utc)
        updated = False
        for user_id_str, user_data in global_data.items():
            loan = user_data.get("loan")
            if loan and not loan.get("completed", False):
                next_due = datetime.fromisoformat(loan["next_due"])
                if now >= next_due:
                    daily = loan["daily_installment"]
                    remaining = loan["remaining_balance"]
                    wallet = user_data["wallet"]
                    bank = user_data["bank"]
                    total_funds = wallet + bank
                    if total_funds >= daily:
                        if wallet >= daily:
                            user_data["wallet"] -= daily
                        else:
                            needed = daily - wallet
                            user_data["wallet"] = 0
                            user_data["bank"] -= needed
                    else:
                        user_data["wallet"] -= daily
                    loan["remaining_balance"] = remaining - daily
                    loan["installments_paid"] = loan.get("installments_paid", 0) + 1
                    loan["next_due"] = (now + timedelta(days=1)).isoformat()
                    add_transaction(int(user_id_str), "loan_payment", daily, f"Daily loan installment (${daily})")
                    if loan["remaining_balance"] <= 0:
                        loan["completed"] = True
                        user_data["loan"] = None
                        user_data["loan_cooldown_until"] = (now + timedelta(days=7)).isoformat()
                        add_transaction(int(user_id_str), "loan_completed", 0, f"Loan fully repaid. Cooldown until {user_data['loan_cooldown_until']}")
                    updated = True
        if updated:
            save(ECO_FILE, data)

    @loan_checker.before_loop
    async def before_loan_checker(self):
        await self.bot.wait_until_ready()

    @commands.command(name="eco", aliases=["bal"])
    async def balance(self, ctx, member: discord.Member = None):
        m = member or ctx.author
        u = _get_global_user(m.id)
        wallet = u["wallet"]

        embed = build(title=f"💰 {m.display_name}'s Wallet Balance", color=Config.COLOR_GOLD, bot=self.bot)
        embed.set_thumbnail(url=m.display_avatar.url)

        big = format_money(wallet)
        exact = f"${wallet:,}"
        embed.description = f"**{big}**\n*Exact: {exact}*"

        if u.get("job"):
            job = u["job"]
            embed.add_field(name="💼 Job", value=f"{job['emoji']} {job['name']}", inline=True)
        if u.get("total_work_count", 0) > 0:
            embed.add_field(name="🔨 Times Worked", value=f"{u['total_work_count']:,}", inline=True)

        embed.add_field(name="🏦 Bank Balance", value=f"${u['bank']:,} (use `$bank` for details)", inline=False)

        if u.get("loan") and not u["loan"].get("completed", False):
            loan = u["loan"]
            embed.add_field(
                name="💳 Active Loan",
                value=f"Remaining: ${loan['remaining_balance']:,}\nDaily installment: ${loan['daily_installment']:,}\nNext due: <t:{int(datetime.fromisoformat(loan['next_due']).timestamp())}:R>",
                inline=False
            )
        elif u.get("loan_cooldown_until"):
            cooldown = datetime.fromisoformat(u["loan_cooldown_until"])
            if datetime.now(timezone.utc) < cooldown:
                embed.add_field(
                    name="⏳ Loan Cooldown",
                    value=f"Next loan available: <t:{int(cooldown.timestamp())}:R>",
                    inline=False
                )

        embed.set_footer(text=f"Bargains remaining today: {3 - u.get('bargains_used', 0)}")
        await ctx.reply(embed=embed)

    @eco.command(name="bal", description="Check your or another member's wallet balance.")
    @app_commands.describe(member="Member to check (leave empty for yourself)")
    async def balance_slash(self, interaction: discord.Interaction, member: discord.Member = None):
        ctx = await commands.Context.from_interaction(interaction)
        await self.balance.callback(self, ctx, member)

    @commands.command(name="bank")
    async def bank(self, ctx):
        u = _get_global_user(ctx.author.id)
        embed = build(title=f"🏦 {ctx.author.display_name}'s Bank Account", color=Config.COLOR_INFO, bot=self.bot)
        embed.set_thumbnail(url=ctx.author.display_avatar.url)
        embed.add_field(name="🏛️ Bank Name", value=u['bank_name'], inline=True)
        embed.add_field(name="🔢 Account Number", value=f"`{u['bank_account']}`", inline=True)

        bank_big = format_money(u['bank'])
        bank_exact = f"${u['bank']:,}"
        embed.add_field(name="💰 Bank Balance", value=f"**{bank_big}**\n*Exact: {bank_exact}*", inline=False)

        embed.add_field(name="👛 Wallet Balance", value=f"${u['wallet']:,}", inline=True)
        embed.add_field(name="📅 Account Created", value=f"<t:{int(datetime.fromisoformat(u['created_at']).timestamp())}:D>", inline=True)
        embed.add_field(name="💵 Total Wealth", value=f"${u['wallet'] + u['bank']:,}", inline=True)

        embed.set_footer(text="Use `$dep` and `$with` to manage your bank.")
        await ctx.reply(embed=embed)

    @eco.command(name="bank", description="Show your bank account details and balance.")
    async def bank_slash(self, interaction: discord.Interaction):
        ctx = await commands.Context.from_interaction(interaction)
        await self.bank.callback(self, ctx)

    @commands.command(name="daily")
    async def daily(self, ctx):
        u = _get_global_user(ctx.author.id)
        now = datetime.now(timezone.utc)
        if u["last_daily"]:
            last = datetime.fromisoformat(u["last_daily"])
            diff = now - last
            if diff < timedelta(hours=24):
                remaining = timedelta(hours=24) - diff
                h, m_ = divmod(int(remaining.total_seconds()), 3600)
                m_, s = divmod(m_, 60)
                return await ctx.reply(f"⏰ Daily already claimed! Come back in **{h}h {m_}m {s}s**.")
        u["wallet"] += Config.DAILY_AMOUNT
        u["last_daily"] = now.isoformat()
        u["total_earned"] = u.get("total_earned", 0) + Config.DAILY_AMOUNT
        _save_global_user(ctx.author.id, u)
        add_transaction(ctx.author.id, "daily", Config.DAILY_AMOUNT, "Daily reward")
        await ctx.reply(embed=eco_embed("📅 Daily Claimed!", f"You received **${Config.DAILY_AMOUNT:,}**!\nNew wallet balance: **${u['wallet']:,}**"))

    @eco.command(name="daily", description="Claim your daily reward.")
    async def daily_slash(self, interaction: discord.Interaction):
        ctx = await commands.Context.from_interaction(interaction)
        await self.daily.callback(self, ctx)

    @commands.command(name="work")
    async def work(self, ctx):
        u = _get_global_user(ctx.author.id)
        if not u.get("job"):
            return await ctx.reply("❌ You don't have a job! Use `$job` to choose one.")
        now = datetime.now(timezone.utc)
        if u.get("job_cooldown"):
            last = datetime.fromisoformat(u["job_cooldown"])
            diff = now - last
            if diff < timedelta(hours=2):
                remaining = timedelta(hours=2) - diff
                h, m_ = divmod(int(remaining.total_seconds()), 3600)
                m_, s = divmod(m_, 60)
                return await ctx.reply(f"⏰ You're tired! Take a break for **{h}h {m_}m {s}s**.")
        job = u["job"]
        amount = random.randint(job["min_pay"], job["max_pay"])
        bonus_events = [
            {"msg": "🎉 You got a promotion! +$50", "bonus": 50, "chance": 0.05},
            {"msg": "⭐ You worked overtime! +$75", "bonus": 75, "chance": 0.03},
            {"msg": "🏆 Employee of the month! +$100", "bonus": 100, "chance": 0.02},
            {"msg": "🤝 You helped a coworker! +$25", "bonus": 25, "chance": 0.08},
            {"msg": "💡 Great idea! +$80", "bonus": 80, "chance": 0.04},
            {"msg": "📈 Company did well! +$200", "bonus": 200, "chance": 0.01},
        ]
        bonus_msg = ""
        for event in bonus_events:
            if random.random() < event["chance"]:
                amount += event["bonus"]
                bonus_msg = f"\n{event['msg']}"
                break
        u["wallet"] += amount
        u["total_earned"] = u.get("total_earned", 0) + amount
        u["total_work_count"] = u.get("total_work_count", 0) + 1
        u["job_cooldown"] = now.isoformat()
        _save_global_user(ctx.author.id, u)
        add_transaction(ctx.author.id, "work", amount, f"Worked as {job['emoji']} {job['name']}")
        job_name = f"{job['emoji']} {job['name']}"
        await ctx.reply(embed=eco_embed(
            "💼 Work Completed!",
            f"You worked as a **{job_name}** and earned **${amount:,}**!{bonus_msg}\n\n"
            f"💰 New wallet balance: **${u['wallet']:,}**\n"
            f"🔨 Times worked: **{u['total_work_count']}**",
            Config.COLOR_OK
        ))

    @eco.command(name="work", description="Work your job to earn money (2h cooldown).")
    async def work_slash(self, interaction: discord.Interaction):
        ctx = await commands.Context.from_interaction(interaction)
        await self.work.callback(self, ctx)

    @commands.command(name="job")
    async def job(self, ctx):
        u = _get_global_user(ctx.author.id)
        if u.get("job"):
            job = u["job"]
            embed = build(title=f"💼 Your Job", description=f"You are a **{job['emoji']} {job['name']}**!\n\n"
                           f"**Pay Range:** ${job['min_pay']:,} - ${job['max_pay']:,}\n"
                           f"**Times Worked:** {u.get('total_work_count', 0)}\n"
                           f"**Total Earned:** ${u.get('total_earned', 0):,}\n\n"
                           f"Use `$work` to earn money!", color=Config.COLOR_INFO, bot=self.bot)
            embed.add_field(
                name="🔄 Change Job",
                value="Use `$resign` to resign from your current job, then use `$job` again to choose a new one.",
                inline=False
            )
            await ctx.reply(embed=embed)
        else:
            embed = build(title="💼 Choose Your Job", description="Select a job from the dropdown below to start earning money!", color=Config.COLOR_INFO, bot=self.bot)
            view = JobView(JOBS, ctx.author.id)
            await ctx.reply(embed=embed, view=view)

    @eco.command(name="job", description="Choose or view your current job.")
    async def job_slash(self, interaction: discord.Interaction):
        u = _get_global_user(interaction.user.id)
        if u.get("job"):
            job = u["job"]
            embed = build(title=f"💼 Your Job", description=f"You are a **{job['emoji']} {job['name']}**!\n\n"
                           f"**Pay Range:** ${job['min_pay']:,} - ${job['max_pay']:,}\n"
                           f"**Times Worked:** {u.get('total_work_count', 0)}\n"
                           f"**Total Earned:** ${u.get('total_earned', 0):,}\n\n"
                           f"Use `$work` to earn money!", color=Config.COLOR_INFO, bot=self.bot)
            embed.add_field(
                name="🔄 Change Job",
                value="Use `$resign` to resign from your current job, then use `$job` again to choose a new one.",
                inline=False
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
        else:
            embed = build(title="💼 Choose Your Job", description="Select a job from the dropdown below to start earning money!", color=Config.COLOR_INFO, bot=self.bot)
            view = JobView(JOBS, interaction.user.id)
            await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

    @commands.command(name="resign")
    async def resign(self, ctx):
        u = _get_global_user(ctx.author.id)
        if not u.get("job"):
            return await ctx.reply("❌ You don't have a job to resign from!")
        job_name = u["job"]["name"]
        job_emoji = u["job"]["emoji"]
        u["job"] = None
        u["job_cooldown"] = None
        _save_global_user(ctx.author.id, u)
        embed = build(title="✅ Resigned Successfully!", description=f"You have resigned from your position as **{job_emoji} {job_name}**.\n\n"
                       f"Use `$job` to choose a new job!", color=Config.COLOR_INFO, bot=self.bot)
        await ctx.reply(embed=embed)

    @eco.command(name="resign", description="Resign from your current job to choose a new one.")
    async def resign_slash(self, interaction: discord.Interaction):
        ctx = await commands.Context.from_interaction(interaction)
        await self.resign.callback(self, ctx)

    @commands.command(name="pay")
    async def pay(self, ctx, member: discord.Member, amount: int):
        if member == ctx.author:
            return await ctx.reply("❌ You can't pay yourself.")
        if amount <= 0:
            return await ctx.reply("❌ Amount must be positive.")
        giver = _get_global_user(ctx.author.id)
        if giver["wallet"] < amount:
            return await ctx.reply(f"❌ Insufficient funds. You have **${giver['wallet']:,}** in your wallet.")
        receiver = _get_global_user(member.id)
        giver["wallet"] -= amount
        receiver["wallet"] += amount
        _save_global_user(ctx.author.id, giver)
        _save_global_user(member.id, receiver)
        add_transaction(ctx.author.id, "pay_sent", amount, f"Sent payment to {member.display_name}")
        add_transaction(member.id, "pay_received", amount, f"Received payment from {ctx.author.display_name}")
        await ctx.reply(embed=eco_embed("💸 Transfer Complete!", f"{ctx.author.mention} → {member.mention}\n**${amount:,}**", Config.COLOR_OK))

    @eco.command(name="pay", description="Transfer money to another member.")
    @app_commands.describe(member="Recipient", amount="Amount to transfer")
    async def pay_slash(self, interaction: discord.Interaction, member: discord.Member, amount: int):
        ctx = await commands.Context.from_interaction(interaction)
        await self.pay.callback(self, ctx, member, amount)

    @commands.command(name="dep")
    async def deposit(self, ctx, amount: str):
        u = _get_global_user(ctx.author.id)
        amt = u["wallet"] if amount.lower() == "all" else int(amount)
        if amt <= 0 or amt > u["wallet"]:
            return await ctx.reply(f"❌ Invalid amount. Wallet: **${u['wallet']:,}**.")
        u["wallet"] -= amt
        u["bank"] += amt
        _save_global_user(ctx.author.id, u)
        add_transaction(ctx.author.id, "deposit", amt, "Deposited to bank")
        await ctx.reply(embed=eco_embed("🏦 Deposited!", f"**${amt:,}** deposited.\nBank: **${u['bank']:,}** | Wallet: **${u['wallet']:,}**"))

    @eco.command(name="dep", description="Deposit money into your bank.")
    @app_commands.describe(amount="Amount or 'all'")
    async def deposit_slash(self, interaction: discord.Interaction, amount: str):
        ctx = await commands.Context.from_interaction(interaction)
        await self.deposit.callback(self, ctx, amount)

    @commands.command(name="with")
    async def withdraw(self, ctx, amount: str):
        u = _get_global_user(ctx.author.id)
        amt = u["bank"] if amount.lower() == "all" else int(amount)
        if amt <= 0 or amt > u["bank"]:
            return await ctx.reply(f"❌ Invalid amount. Bank: **${u['bank']:,}**.")
        u["bank"] -= amt
        u["wallet"] += amt
        _save_global_user(ctx.author.id, u)
        add_transaction(ctx.author.id, "withdraw", amt, "Withdrawn from bank")
        await ctx.reply(embed=eco_embed("🏦 Withdrawn!", f"**${amt:,}** withdrawn.\nWallet: **${u['wallet']:,}** | Bank: **${u['bank']:,}**"))

    @eco.command(name="with", description="Withdraw money from your bank.")
    @app_commands.describe(amount="Amount or 'all'")
    async def withdraw_slash(self, interaction: discord.Interaction, amount: str):
        ctx = await commands.Context.from_interaction(interaction)
        await self.withdraw.callback(self, ctx, amount)

    @commands.command(name="rob")
    @commands.cooldown(1, 1800, commands.BucketType.member)
    async def rob(self, ctx, member: discord.Member):
        if member == ctx.author:
            return await ctx.reply("❌ You can't rob yourself.")
        victim = _get_global_user(member.id)
        robber = _get_global_user(ctx.author.id)
        if victim["wallet"] < 100:
            return await ctx.reply(f"❌ {member.mention} doesn't have enough to rob (min $100 in wallet).")
        if random.random() < 0.4:
            fine = random.randint(50, 200)
            robber["wallet"] = max(0, robber["wallet"] - fine)
            _save_global_user(ctx.author.id, robber)
            return await ctx.reply(embed=eco_embed("🚔 Caught!", f"You were caught trying to rob {member.mention}!\nFine: **${fine}**", Config.COLOR_ERR))
        stolen = random.randint(100, min(victim["wallet"], 500))
        victim["wallet"] -= stolen
        robber["wallet"] += stolen
        _save_global_user(ctx.author.id, robber)
        _save_global_user(member.id, victim)
        add_transaction(ctx.author.id, "rob", stolen, f"Robbed {member.display_name} for ${stolen}")
        add_transaction(member.id, "robbed", stolen, f"Robbed by {ctx.author.display_name} for ${stolen}")
        await ctx.reply(embed=eco_embed("🦹 Robbed!", f"You stole **${stolen:,}** from {member.mention}!", Config.COLOR_WARN))

    @eco.command(name="rob", description="Attempt to rob another member's wallet.")
    @app_commands.describe(member="Member to rob")
    async def rob_slash(self, interaction: discord.Interaction, member: discord.Member):
        ctx = await commands.Context.from_interaction(interaction)
        await self.rob.callback(self, ctx, member)

    @commands.command(name="gamble")
    @commands.cooldown(1, 5, commands.BucketType.member)
    async def gamble(self, ctx, amount: str):
        u = _get_global_user(ctx.author.id)
        amt = u["wallet"] if amount.lower() == "all" else int(amount)
        if amt <= 0:
            return await ctx.reply("❌ Amount must be positive.")
        if amt > u["wallet"]:
            return await ctx.reply(f"❌ Insufficient funds (wallet: **${u['wallet']:,}**).")
        if random.random() > 0.5:
            u["wallet"] += amt
            desc = f"🎉 You won! +**${amt:,}**\nBalance: **${u['wallet']:,}**"
            color = Config.COLOR_OK
        else:
            u["wallet"] -= amt
            desc = f"💸 You lost! -**${amt:,}**\nBalance: **${u['wallet']:,}**"
            color = Config.COLOR_ERR
        _save_global_user(ctx.author.id, u)
        add_transaction(ctx.author.id, "gamble", amt, "Gambled")
        await ctx.reply(embed=eco_embed("🎲 Gamble Result", desc, color))

    @eco.command(name="gamble", description="Gamble your money (50% chance to double).")
    @app_commands.describe(amount="Amount to gamble or 'all'")
    async def gamble_slash(self, interaction: discord.Interaction, amount: str):
        ctx = await commands.Context.from_interaction(interaction)
        await self.gamble.callback(self, ctx, amount)

    @commands.command(name="slots")
    @commands.cooldown(1, 5, commands.BucketType.member)
    async def slots(self, ctx, bet: int):
        u = _get_global_user(ctx.author.id)
        if bet <= 0:
            return await ctx.reply("❌ Bet must be positive.")
        if bet > u["wallet"]:
            return await ctx.reply("❌ Insufficient funds.")
        symbols = ["🍒","🍋","🍊","🍇","⭐","💎","7️⃣"]
        weights = [30, 25, 20, 15, 6, 3, 1]
        reels = random.choices(symbols, weights=weights, k=3)
        display = " | ".join(reels)
        if reels[0] == reels[1] == reels[2]:
            mult = {"7️⃣": 50, "💎": 20, "⭐": 10}.get(reels[0], 5)
            winnings = bet * mult
            u["wallet"] += winnings
            result = f"🎰 **JACKPOT!** {display}\n+**${winnings:,}** (x{mult})"
            color = Config.COLOR_OK
        elif reels[0] == reels[1] or reels[1] == reels[2]:
            winnings = bet
            u["wallet"] += winnings
            result = f"🎰 {display}\n**Two of a kind!** +**${winnings:,}**"
            color = Config.COLOR_WARN
        else:
            u["wallet"] -= bet
            result = f"🎰 {display}\n**No match.** -**${bet:,}**"
            color = Config.COLOR_ERR
        _save_global_user(ctx.author.id, u)
        add_transaction(ctx.author.id, "slots", winnings - bet, "Slot machine result")
        result += f"\nBalance: **${u['wallet']:,}**"
        await ctx.reply(embed=eco_embed("🎰 Slot Machine", result, color))

    @eco.command(name="slots", description="Play the slot machine!")
    @app_commands.describe(bet="Amount to bet")
    async def slots_slash(self, interaction: discord.Interaction, bet: int):
        ctx = await commands.Context.from_interaction(interaction)
        await self.slots.callback(self, ctx, bet)

    @commands.command(name="shop")
    async def shop(self, ctx, page: int = 1):
        categories = {}
        for key, item in SHOP_ITEMS.items():
            cat = item.get("category", "other")
            if cat not in categories:
                categories[cat] = []
            categories[cat].append((key, item))
        all_items = []
        for cat in sorted(categories.keys()):
            for key, item in sorted(categories[cat], key=lambda x: x[1]["price"]):
                all_items.append((key, item))
        items_per_page = 10
        total_pages = max(1, (len(all_items) + items_per_page - 1) // items_per_page)
        page = max(1, min(page, total_pages))
        start = (page - 1) * items_per_page
        end = start + items_per_page
        page_items = all_items[start:end]
        embed = build(title="🛒 Item Shop", description=f"**Page {page}/{total_pages}** • {len(all_items)} items total\nBuy with `$buy <item_key>`\n", color=Config.COLOR_GOLD, bot=self.bot)
        for key, item in page_items:
            embed.add_field(
                name=f"{item['name']} • `${item['price']:,}`",
                value=f"{item['desc']}\nKey: `{key}`",
                inline=False
            )
        embed.set_footer(text=f"Page {page}/{total_pages} • Categories: {len(categories)}")
        await ctx.reply(embed=embed)

    @eco.command(name="shop", description="View the item shop.")
    @app_commands.describe(page="Page number")
    async def shop_slash(self, interaction: discord.Interaction, page: int = 1):
        categories = {}
        for key, item in SHOP_ITEMS.items():
            cat = item.get("category", "other")
            if cat not in categories:
                categories[cat] = []
            categories[cat].append((key, item))
        all_items = []
        for cat in sorted(categories.keys()):
            for key, item in sorted(categories[cat], key=lambda x: x[1]["price"]):
                all_items.append((key, item))
        view = ShopPaginationView(all_items, 10, interaction.user.id)
        embed = view._build_embed()
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)
        view.message = await interaction.original_response()

    @commands.command(name="buy")
    async def buy(self, ctx, item: str):
        item = item.lower()
        if item not in SHOP_ITEMS:
            matches = [k for k in SHOP_ITEMS if item in k.lower()]
            if matches:
                return await ctx.reply(f"❌ Did you mean: `{matches[0]}`? Use `$shop` to see all items.")
            return await ctx.reply(f"❌ Item not found. Use `$shop` to browse.")
        shop_item = SHOP_ITEMS[item]
        u = _get_global_user(ctx.author.id)
        if u["wallet"] < shop_item["price"]:
            return await ctx.reply(f"❌ Not enough money. You need **${shop_item['price']:,}**.")
        embed = build(title="🛍️ Confirm Purchase", description=f"You are about to buy **{shop_item['name']}** for **${shop_item['price']:,}**.\n"
                       f"Wallet: **${u['wallet']:,}**\n\n"
                       f"**Confirm** to buy immediately.\n"
                       f"**Bargain** to try a lower price (you have {3 - u.get('bargains_used', 0)} bargains left today).", color=Config.COLOR_WARN, bot=self.bot)
        view = BuyConfirmView(item, shop_item["price"], ctx.author.id, self)
        await ctx.reply(embed=embed, view=view)

    @eco.command(name="buy", description="Buy an item from the shop.")
    @app_commands.describe(item="Item key from the shop")
    async def buy_slash(self, interaction: discord.Interaction, item: str):
        ctx = await commands.Context.from_interaction(interaction)
        await self.buy.callback(self, ctx, item)

    @commands.command(name="sell")
    async def sell(self, ctx, item: str, quantity: int = 1):
        item = item.lower()
        if item not in SHOP_ITEMS:
            matches = [k for k in SHOP_ITEMS if item in k.lower()]
            if matches:
                return await ctx.reply(f"❌ Did you mean: `{matches[0]}`? Use `$inv` to see your items.")
            return await ctx.reply(f"❌ Item not found.")
        if quantity <= 0:
            return await ctx.reply("❌ Quantity must be positive.")
        u = _get_global_user(ctx.author.id)
        inv = u.get("inventory", [])
        count = inv.count(item)
        if count < quantity:
            return await ctx.reply(f"❌ You only have **{count}** of that item.")
        shop_item = SHOP_ITEMS[item]
        price_per = int(shop_item["price"] * 0.6)
        total = price_per * quantity
        embed = build(title="💰 Confirm Sale", description=f"You are about to sell **{quantity}x {shop_item['name']}** for **${total:,}** (${price_per:,} each).\n"
                       f"Current wallet: **${u['wallet']:,}**\n\n"
                       f"Click **Sell** to confirm or **Cancel** to abort.", color=Config.COLOR_WARN, bot=self.bot)
        view = SellConfirmView(item, quantity, price_per, ctx.author.id)
        await ctx.reply(embed=embed, view=view)

    @eco.command(name="sell", description="Sell an item from your inventory at 60% of its buy price.")
    @app_commands.describe(item="Item key", quantity="Number of items to sell (default 1)")
    async def sell_slash(self, interaction: discord.Interaction, item: str, quantity: int = 1):
        ctx = await commands.Context.from_interaction(interaction)
        await self.sell.callback(self, ctx, item, quantity)

    @commands.command(name="inv")
    async def inventory(self, ctx, member: discord.Member = None):
        m = member or ctx.author
        u = _get_global_user(m.id)
        if not u["inventory"]:
            return await ctx.reply(f"📦 {m.mention}'s inventory is empty.")
        from collections import Counter
        inv = Counter(u["inventory"])
        embed = build(title=f"📦 {m.display_name}'s Inventory", color=Config.COLOR_GOLD, bot=self.bot)
        for key, qty in inv.items():
            shop_item = SHOP_ITEMS.get(key, {"name": key})
            embed.add_field(name=shop_item["name"], value=f"x{qty}", inline=True)
        await ctx.reply(embed=embed)

    @eco.command(name="inv", description="View your inventory.")
    @app_commands.describe(member="Member to check (leave empty for yourself)")
    async def inventory_slash(self, interaction: discord.Interaction, member: discord.Member = None):
        ctx = await commands.Context.from_interaction(interaction)
        await self.inventory.callback(self, ctx, member)

    @commands.command(name="use")
    async def use_item(self, ctx, *, item_key: str):
        u = _get_global_user(ctx.author.id)
        inv = u.get("inventory", [])
        if item_key not in inv:
            return await ctx.reply(f"❌ You don't have **{item_key}** in your inventory.")
        effect = ITEM_EFFECTS.get(item_key)
        if not effect:
            return await ctx.reply(f"❌ **{item_key}** cannot be used (no effect defined).")
        embed = build(title="🎒 Using Item", color=Config.COLOR_INFO, bot=self.bot)
        embed.add_field(name="Item", value=f"**{SHOP_ITEMS[item_key]['name']}**", inline=False)
        if effect["type"] == "coins":
            amount = effect["value"]
            u["wallet"] += amount
            embed.description = f"💰 You gained **${amount:,}**!"
            embed.color = Config.COLOR_OK
            add_transaction(ctx.author.id, "use_item", amount, f"Used {SHOP_ITEMS[item_key]['name']} (+${amount})")
        elif effect["type"] == "role":
            role_key = effect.get("role_key")
            if not role_key:
                return await ctx.reply("❌ This role item is not properly configured.")
            config = _get_guild_role_config(ctx.guild.id)
            role_id = config.get(role_key)
            if not role_id:
                return await ctx.reply("❌ This role item is not set up by an admin. Please contact an admin to set it.")
            role = ctx.guild.get_role(role_id)
            if not role:
                return await ctx.reply("❌ The role associated with this item no longer exists.")
            try:
                await ctx.author.add_roles(role, reason=f"Used item: {item_key}")
                embed.description = f"🎭 You received the **{role.name}** role!"
                embed.color = Config.COLOR_OK
                add_transaction(ctx.author.id, "use_item", 0, f"Used {SHOP_ITEMS[item_key]['name']} to get role {role.name}")
            except Exception:
                embed.description = "❌ Failed to assign role. Check bot permissions."
                embed.color = Config.COLOR_ERR
        else:
            embed.description = "❌ Unknown effect type."
            embed.color = Config.COLOR_ERR
        inv.remove(item_key)
        u["inventory"] = inv
        _save_global_user(ctx.author.id, u)
        await ctx.reply(embed=embed)

    @eco.command(name="use", description="Use an item from your inventory.")
    @app_commands.describe(item_key="The key of the item to use")
    async def use_slash(self, interaction: discord.Interaction, item_key: str):
        ctx = await commands.Context.from_interaction(interaction)
        await self.use_item.callback(self, ctx, item_key=item_key)

    @commands.command(name="loan")
    async def loan(self, ctx):
        u = _get_global_user(ctx.author.id)
        if u.get("loan") and not u["loan"].get("completed", False):
            loan = u["loan"]
            embed = build(title="💳 Your Active Loan", description=f"Remaining balance: **${loan['remaining_balance']:,}**\n"
                            f"Daily installment: ${loan['daily_installment']:,}\n"
                            f"Installments paid: {loan.get('installments_paid', 0)}/{loan['tenure_days']}\n"
                            f"Next due: <t:{int(datetime.fromisoformat(loan['next_due']).timestamp())}:R>\n"
                            f"Interest rate: {loan['interest_rate']*100:.0f}%", color=Config.COLOR_INFO, bot=self.bot)
            return await ctx.reply(embed=embed)
        cooldown = u.get("loan_cooldown_until")
        if cooldown:
            cooldown_dt = datetime.fromisoformat(cooldown)
            if datetime.now(timezone.utc) < cooldown_dt:
                remaining = cooldown_dt - datetime.now(timezone.utc)
                days = remaining.days
                hours, rem = divmod(remaining.seconds, 3600)
                mins, _ = divmod(rem, 60)
                return await ctx.reply(f"⏳ You are on cooldown. Please wait **{days}d {hours}h {mins}m** before taking another loan.")
        embed = build(title="💳 Loan Application", description="Select the amount you wish to borrow from the dropdown below.\nThen choose a repayment plan.", color=Config.COLOR_GOLD, bot=self.bot)
        view = LoanAmountView(ctx.author.id)
        await ctx.reply(embed=embed, view=view)

    @eco.command(name="loan", description="Apply for a loan with flexible repayment plans.")
    async def loan_slash(self, interaction: discord.Interaction):
        ctx = await commands.Context.from_interaction(interaction)
        await self.loan.callback(self, ctx)

    @commands.command(name="thistory")
    async def transaction_history(self, ctx, limit: int = 20):
        u = _get_global_user(ctx.author.id)
        transactions = u.get("transactions", [])
        if not transactions:
            return await ctx.reply("📭 No transactions found.")
        entries = transactions[-limit:][::-1]
        embed = build(title="📜 Transaction History", description=f"Showing last {len(entries)} transactions", color=Config.COLOR_INFO, bot=self.bot)
        for t in entries:
            timestamp = datetime.fromisoformat(t["timestamp"])
            emoji = {
                "loan_taken": "💳",
                "loan_payment": "💳",
                "loan_completed": "✅",
                "daily": "📅",
                "work": "💼",
                "pay_sent": "💸",
                "pay_received": "💸",
                "deposit": "🏦",
                "withdraw": "🏦",
                "rob": "🦹",
                "robbed": "🚔",
                "gamble": "🎲",
                "slots": "🎰",
                "use_item": "🎒",
            }.get(t["type"], "📌")

            if t["type"] in ["daily", "work", "pay_received", "gamble", "slots", "use_item", "loan_taken"]:
                sign = "+"
            elif t["type"] in ["pay_sent", "deposit", "withdraw", "rob", "loan_payment"]:
                sign = "-"
            else:
                sign = ""
            embed.add_field(
                name=f"{emoji} {t['type'].replace('_',' ').title()}",
                value=f"{sign}${abs(t['amount']):,} • {t['description']}\n<t:{int(timestamp.timestamp())}:R>",
                inline=False
            )
        embed.set_footer(text=f"Total transactions: {len(transactions)}")
        await ctx.reply(embed=embed)

    @eco.command(name="thistory", description="Show your transaction history (last 20 by default).")
    @app_commands.describe(limit="Number of transactions to show (max 50)")
    async def thistory_slash(self, interaction: discord.Interaction, limit: int = 20):
        ctx = await commands.Context.from_interaction(interaction)
        if limit > 50:
            limit = 50
        await self.transaction_history.callback(self, ctx, limit)

    @commands.command(name="rich")
    async def rich(self, ctx):
        data = load(ECO_FILE).get("global", {})
        if not data:
            return await ctx.reply("No economy data yet. Use `$daily` or `$work` to get started!")

        guild_member_ids = {str(m.id) for m in ctx.guild.members}
        server_data = {uid: d for uid, d in data.items() if uid in guild_member_ids}

        if not server_data:
            return await ctx.reply("No one in this server has started using the economy yet!")

        ranked = sorted(
            ((uid, d.get("wallet", 0) + d.get("bank", 0), d.get("wallet", 0), d.get("bank", 0))
             for uid, d in server_data.items()),
            key=lambda x: x[1], reverse=True
        )[:10]

        medals = ["🥇", "🥈", "🥉"] + [f"`{i}.`" for i in range(4, 11)]
        lines = []
        for i, (uid, total, wallet, bank) in enumerate(ranked):
            member = ctx.guild.get_member(int(uid))
            name = member.display_name if member else f"<@{uid}>"
            lines.append(f"{medals[i]} **{name}** • 👛 `${wallet:,}` | 🏦 `${bank:,}` | Total: `${total:,}`")

        embed = build(title=f"💰 Server Richest Members", description="\n".join(lines), color=Config.COLOR_GOLD, bot=self.bot)
        embed.set_footer(text=f"Your wallet balance: ${data.get(str(ctx.author.id), {}).get('wallet', 0):,}")
        await ctx.reply(embed=embed)

    @eco.command(name="rich", description="Show the richest members in this server.")
    async def rich_slash(self, interaction: discord.Interaction):
        ctx = await commands.Context.from_interaction(interaction)
        await self.rich.callback(self, ctx)

    @commands.command(name="richgl")
    async def rich_global(self, ctx):
        data = load(ECO_FILE).get("global", {})
        if not data:
            return await ctx.reply("No economy data yet. Use `$daily` or `$work` to get started!")

        ranked = sorted(
            ((uid, d.get("wallet", 0) + d.get("bank", 0), d.get("wallet", 0), d.get("bank", 0))
             for uid, d in data.items()),
            key=lambda x: x[1], reverse=True
        )[:10]

        medals = ["🥇", "🥈", "🥉"] + [f"`{i}.`" for i in range(4, 11)]
        lines = []
        for i, (uid, total, wallet, bank) in enumerate(ranked):
            user = self.bot.get_user(int(uid))
            name = user.display_name if user else f"<@{uid}>"
            lines.append(f"{medals[i]} **{name}** • 👛 `${wallet:,}` | 🏦 `${bank:,}` | Total: `${total:,}`")

        embed = build(title=f"🌍 Global Richest Members", description="\n".join(lines), color=Config.COLOR_GOLD, bot=self.bot)
        embed.set_footer(text=f"Your wallet balance: ${data.get(str(ctx.author.id), {}).get('wallet', 0):,}")
        await ctx.reply(embed=embed)

    @eco.command(name="richgl", description="Show the richest members across all servers (global).")
    async def richgl_slash(self, interaction: discord.Interaction):
        ctx = await commands.Context.from_interaction(interaction)
        await self.rich_global.callback(self, ctx)

    @commands.command(name="addmoney")
    async def addmoney(self, ctx, member: discord.Member, amount: str):
        if ctx.author.id not in Config.OWNER_IDS:
            return await ctx.reply("❌ Only the bot owner can use this command.")
        try:
            amt = parse_amount(amount)
        except ValueError:
            return await ctx.reply("❌ Invalid amount format. Use numbers with optional suffix: `1k`, `2.5m`, `10b`, `1t`.")
        if amt <= 0:
            return await ctx.reply("❌ Amount must be positive.")
        u = _get_global_user(member.id)
        u["wallet"] += amt
        _save_global_user(member.id, u)
        add_transaction(member.id, "admin_add", amt, f"Admin added ${amt}")
        embed = build(title="✅ Money Added", description=f"Added **${amt:,}** to {member.mention}'s wallet.\nNew balance: **${u['wallet']:,}**", color=Config.COLOR_OK, bot=self.bot)
        await ctx.reply(embed=embed)

    @commands.command(name="setrolerole")
    async def setrolerole(self, ctx, role_item: str, role: discord.Role):
        if not ctx.author.guild_permissions.administrator:
            return await ctx.reply("❌ You need Administrator permissions.")
        config = _get_guild_role_config(ctx.guild.id)
        config[role_item] = role.id
        _save_guild_role_config(ctx.guild.id, config)
        embed = build(title="✅ Role Item Configured", description=f"**{role_item}** will now grant {role.mention}.", color=Config.COLOR_OK, bot=self.bot)
        await ctx.reply(embed=embed)

    @commands.command(name="removeroleitem")
    async def removeroleitem(self, ctx, role_item: str):
        if not ctx.author.guild_permissions.administrator:
            return await ctx.reply("❌ You need Administrator permissions.")
        config = _get_guild_role_config(ctx.guild.id)
        config[role_item] = None
        _save_guild_role_config(ctx.guild.id, config)
        embed = build(title="✅ Role Item Removed", description=f"**{role_item}** has been disabled.", color=Config.COLOR_OK, bot=self.bot)
        await ctx.reply(embed=embed)

    @commands.command(name="roleitemsconfig")
    async def roleitemsconfig(self, ctx):
        if not ctx.author.guild_permissions.administrator:
            return await ctx.reply("❌ You need Administrator permissions.")
        config = _get_guild_role_config(ctx.guild.id)
        all_role_items = {
            "vip_role_id": "⭐ VIP Role",
            "premium_role_id": "💎 Premium Member",
            "booster_role_id": "🚀 Booster",
            "legend_role_id": "👑 Legend",
            "elite_role_id": "⚡ Elite Member",
            "supporter_role_id": "🤝 Supporter",
            "veteran_role_id": "🎖️ Veteran",
            "champion_role_id": "🏆 Champion",
            "hero_role_id": "🦸 Hero",
            "god_role_id": "⛰️ God",
            "color_red_id": "🔴 Red Role",
            "color_blue_id": "🔵 Blue Role",
            "color_green_id": "🟢 Green Role",
            "color_yellow_id": "🟡 Yellow Role",
            "color_purple_id": "🟣 Purple Role",
            "color_orange_id": "🟠 Orange Role",
            "color_pink_id": "🌸 Pink Role",
            "color_cyan_id": "🩵 Cyan Role",
            "color_brown_id": "🟤 Brown Role",
            "color_white_id": "⚪ White Role",
            "color_black_id": "⬛ Black Role",
            "color_gold_id": "🌟 Gold Role",
            "color_silver_id": "🔘 Silver Role",
            "color_bronze_id": "🥉 Bronze Role",
        }
        embed = build(title="🏪 Role Item Configuration", description="Configured role items for this server:", color=Config.COLOR_INFO, bot=self.bot)
        configured = False
        for key, display_name in all_role_items.items():
            role_id = config.get(key)
            if role_id:
                role = ctx.guild.get_role(role_id)
                embed.add_field(
                    name=display_name,
                    value=role.mention if role else "❌ Role not found",
                    inline=True
                )
                configured = True
        if not configured:
            embed.description = "No role items have been configured yet.\nUse `$setrolerole` to configure a role item."
        embed.set_footer(text="Total 24 role items available")
        await ctx.reply(embed=embed)

    @commands.command(name="removeroleitemsall")
    async def removeroleitemsall(self, ctx):
        if not ctx.author.guild_permissions.administrator:
            return await ctx.reply("❌ You need Administrator permissions.")
        config = _get_guild_role_config(ctx.guild.id)
        role_keys = [
            "vip_role_id", "premium_role_id", "booster_role_id", "legend_role_id",
            "elite_role_id", "supporter_role_id", "veteran_role_id", "champion_role_id",
            "hero_role_id", "god_role_id", "color_red_id", "color_blue_id",
            "color_green_id", "color_yellow_id", "color_purple_id", "color_orange_id",
            "color_pink_id", "color_cyan_id", "color_brown_id", "color_white_id",
            "color_black_id", "color_gold_id", "color_silver_id", "color_bronze_id"
        ]
        for key in role_keys:
            config[key] = None
        _save_guild_role_config(ctx.guild.id, config)
        embed = build(title="✅ All Role Items Removed", description="All role item configurations have been cleared.", color=Config.COLOR_OK, bot=self.bot)
        await ctx.reply(embed=embed)

    async def addmoney_slash_callback(self, interaction: discord.Interaction, member: discord.Member, amount: str):
        if interaction.user.id not in Config.OWNER_IDS:
            return await interaction.response.send_message("❌ Only the bot owner can use this command.", ephemeral=True)
        try:
            amt = parse_amount(amount)
        except ValueError:
            return await interaction.response.send_message("❌ Invalid amount format. Use numbers with optional suffix: `1k`, `2.5m`, `10b`, `1t`.", ephemeral=True)
        if amt <= 0:
            return await interaction.response.send_message("❌ Amount must be positive.", ephemeral=True)
        u = _get_global_user(member.id)
        u["wallet"] += amt
        _save_global_user(member.id, u)
        add_transaction(member.id, "admin_add", amt, f"Admin added ${amt}")
        embed = build(title="✅ Money Added", description=f"Added **${amt:,}** to {member.mention}'s wallet.\nNew balance: **${u['wallet']:,}**", color=Config.COLOR_OK, bot=self.bot)
        await interaction.response.send_message(embed=embed)

    async def set_role_item_slash(self, interaction: discord.Interaction, role_item: str, role: discord.Role):
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message("❌ You need Administrator permissions.", ephemeral=True)
        config = _get_guild_role_config(interaction.guild.id)
        config[role_item] = role.id
        _save_guild_role_config(interaction.guild.id, config)
        embed = build(title="✅ Role Item Configured", description=f"**{role_item}** will now grant {role.mention}.", color=Config.COLOR_OK, bot=self.bot)
        await interaction.response.send_message(embed=embed)

    async def remove_role_item_slash(self, interaction: discord.Interaction, role_item: str):
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message("❌ You need Administrator permissions.", ephemeral=True)
        config = _get_guild_role_config(interaction.guild.id)
        config[role_item] = None
        _save_guild_role_config(interaction.guild.id, config)
        embed = build(title="✅ Role Item Removed", description=f"**{role_item}** has been disabled.", color=Config.COLOR_OK, bot=self.bot)
        await interaction.response.send_message(embed=embed)

    async def role_items_config_slash(self, interaction: discord.Interaction):
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message("❌ You need Administrator permissions.", ephemeral=True)
        config = _get_guild_role_config(interaction.guild.id)
        all_role_items = {
            "vip_role_id": "⭐ VIP Role",
            "premium_role_id": "💎 Premium Member",
            "booster_role_id": "🚀 Booster",
            "legend_role_id": "👑 Legend",
            "elite_role_id": "⚡ Elite Member",
            "supporter_role_id": "🤝 Supporter",
            "veteran_role_id": "🎖️ Veteran",
            "champion_role_id": "🏆 Champion",
            "hero_role_id": "🦸 Hero",
            "god_role_id": "⛰️ God",
            "color_red_id": "🔴 Red Role",
            "color_blue_id": "🔵 Blue Role",
            "color_green_id": "🟢 Green Role",
            "color_yellow_id": "🟡 Yellow Role",
            "color_purple_id": "🟣 Purple Role",
            "color_orange_id": "🟠 Orange Role",
            "color_pink_id": "🌸 Pink Role",
            "color_cyan_id": "🩵 Cyan Role",
            "color_brown_id": "🟤 Brown Role",
            "color_white_id": "⚪ White Role",
            "color_black_id": "⬛ Black Role",
            "color_gold_id": "🌟 Gold Role",
            "color_silver_id": "🔘 Silver Role",
            "color_bronze_id": "🥉 Bronze Role",
        }
        embed = build(title="🏪 Role Item Configuration", description="Configured role items for this server:", color=Config.COLOR_INFO, bot=self.bot)
        configured = False
        for key, display_name in all_role_items.items():
            role_id = config.get(key)
            if role_id:
                role = interaction.guild.get_role(role_id)
                embed.add_field(
                    name=display_name,
                    value=role.mention if role else "❌ Role not found",
                    inline=True
                )
                configured = True
        if not configured:
            embed.description = "No role items have been configured yet.\nUse `/eco admin setrolerole` to configure a role item."
        embed.set_footer(text="Total 24 role items available")
        await interaction.response.send_message(embed=embed)

    async def remove_all_role_items_slash(self, interaction: discord.Interaction):
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message("❌ You need Administrator permissions.", ephemeral=True)
        config = _get_guild_role_config(interaction.guild.id)
        role_keys = [
            "vip_role_id", "premium_role_id", "booster_role_id", "legend_role_id",
            "elite_role_id", "supporter_role_id", "veteran_role_id", "champion_role_id",
            "hero_role_id", "god_role_id", "color_red_id", "color_blue_id",
            "color_green_id", "color_yellow_id", "color_purple_id", "color_orange_id",
            "color_pink_id", "color_cyan_id", "color_brown_id", "color_white_id",
            "color_black_id", "color_gold_id", "color_silver_id", "color_bronze_id"
        ]
        for key in role_keys:
            config[key] = None
        _save_guild_role_config(interaction.guild.id, config)
        embed = build(title="✅ All Role Items Removed", description="All role item configurations have been cleared.", color=Config.COLOR_OK, bot=self.bot)
        await interaction.response.send_message(embed=embed)

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            missing = ", ".join(p.replace("_", " ").title() for p in error.missing_permissions)
            print(f"[Economy] {interaction.user} ({interaction.user.id}) missing permissions: {missing}")
            try:
                await interaction.response.send_message(
                    f"❌ You are missing the required permissions: **{missing}**.",
                    ephemeral=True,
                )
            except discord.InteractionResponded:
                await interaction.followup.send(
                    f"❌ You are missing the required permissions: **{missing}**.",
                    ephemeral=True,
                )

async def setup(bot):
    await bot.add_cog(Economy(bot))
