import re
import json
import traceback
import discord
from discord.ext import commands
from discord import app_commands
from datetime import datetime, timezone
from config import Config
from utils.embed import build
from utils.theme import Theme
from utils.data import load, save

HEX_RE = re.compile(r"^#?([0-9A-Fa-f]{6})$")

def parse_color(value: str | None) -> int:
    if not value:
        return Config.COLOR_INFO
    m = HEX_RE.match(value.strip())
    if m:
        return int(m.group(1), 16)
    return Config.COLOR_INFO

class EmbedBuilderModal(discord.ui.Modal, title="📝 Embed Builder"):
    embed_title = discord.ui.TextInput(label="Title", placeholder="Your embed title…", required=False, max_length=256)
    embed_description = discord.ui.TextInput(label="Description", placeholder="Main body text. Markdown supported.", style=discord.TextStyle.paragraph, required=False, max_length=4000)
    embed_color = discord.ui.TextInput(label="Color (hex, e.g. #5865F2)", placeholder="#5865F2", required=False, max_length=7)
    embed_footer = discord.ui.TextInput(label="Footer text", required=False, max_length=2048)
    embed_image_url = discord.ui.TextInput(label="Image URL (optional)", placeholder="https://example.com/image.png", required=False, max_length=512)

    def __init__(self, channel: discord.TextChannel):
        super().__init__()
        self.channel = channel

    async def on_submit(self, interaction: discord.Interaction):
        try:
            e = discord.Embed(color=parse_color(self.embed_color.value or None))
            if self.embed_title.value:
                e.title = self.embed_title.value
            if self.embed_description.value:
                e.description = self.embed_description.value
            if self.embed_footer.value:
                e.set_footer(text=self.embed_footer.value)
            if self.embed_image_url.value:
                e.set_image(url=self.embed_image_url.value)
            e.timestamp = discord.utils.utcnow()
            await self.channel.send(embed=e)
            await interaction.response.send_message(f"✅ Embed sent to {self.channel.mention}.", ephemeral=True)
        except Exception as e:
            print(f"[Embed] Error in EmbedBuilderModal: {e}")
            traceback.print_exc()
            try:
                await interaction.response.send_message(f"❌ Failed to send embed: {e}", ephemeral=True)
            except:
                pass

class EmbedEditModal(discord.ui.Modal, title="✏️ Edit Embed"):
    embed_title = discord.ui.TextInput(label="New Title (leave blank to keep)", required=False, max_length=256)
    embed_description = discord.ui.TextInput(label="New Description (leave blank to keep)", style=discord.TextStyle.paragraph, required=False, max_length=4000)
    embed_color = discord.ui.TextInput(label="New Color hex (leave blank to keep)", required=False, max_length=7)
    embed_footer = discord.ui.TextInput(label="New Footer (leave blank to keep)", required=False, max_length=2048)

    def __init__(self, message: discord.Message):
        super().__init__()
        self.target_message = message

    async def on_submit(self, interaction: discord.Interaction):
        try:
            if not self.target_message.embeds:
                await interaction.response.send_message("❌ That message has no embeds.", ephemeral=True)
                return
            old = self.target_message.embeds[0]
            e = old.copy()
            if self.embed_title.value:
                e.title = self.embed_title.value
            if self.embed_description.value:
                e.description = self.embed_description.value
            if self.embed_color.value:
                e.colour = parse_color(self.embed_color.value)
            if self.embed_footer.value:
                e.set_footer(text=self.embed_footer.value)
            await self.target_message.edit(embed=e)
            await interaction.response.send_message("✅ Embed updated.", ephemeral=True)
        except discord.Forbidden:
            await interaction.response.send_message("❌ I don't have permission to edit that message.", ephemeral=True)
        except discord.NotFound:
            await interaction.response.send_message("❌ That message no longer exists.", ephemeral=True)
        except Exception as e:
            print(f"[Embed] Error in EmbedEditModal: {e}")
            traceback.print_exc()
            await interaction.response.send_message(f"❌ Failed to edit embed: {e}", ephemeral=True)

class EmbedCog(commands.Cog, name="Embed"):
    slash = app_commands.Group(name="embed", description="Embed creation and editing tools")

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # ========== SLASH COMMANDS ==========
    @slash.command(name="send", description="Open the embed builder and send a rich embed to a channel.")
    @app_commands.describe(channel="Channel to send the embed to (defaults to current)")
    @app_commands.default_permissions(manage_messages=True)
    @app_commands.checks.has_permissions(manage_messages=True)
    async def embed_send(self, interaction: discord.Interaction, channel: discord.TextChannel = None):
        ch = channel or interaction.channel
        await interaction.response.send_modal(EmbedBuilderModal(ch))

    @slash.command(name="quick", description="Send a quick embed with title and description inline.")
    @app_commands.describe(title="Embed title", description="Embed body text", color="Hex color, e.g. #5865F2 (optional)", channel="Target channel (defaults to current)", footer="Footer text (optional)", image="Image URL (optional)", thumbnail="Thumbnail URL (optional)", timestamp="Attach current timestamp? (default: yes)")
    @app_commands.default_permissions(manage_messages=True)
    @app_commands.checks.has_permissions(manage_messages=True)
    async def embed_quick(self, interaction: discord.Interaction, title: str, description: str, color: str = None, channel: discord.TextChannel = None, footer: str = None, image: str = None, thumbnail: str = None, timestamp: bool = True):
        ch = channel or interaction.channel
        e = build(title=title, description=description, color=parse_color(color), bot=self.bot)
        if footer:
            e.set_footer(text=footer)
        if image:
            e.set_image(url=image)
        if thumbnail:
            e.set_thumbnail(url=thumbnail)
        if timestamp:
            e.timestamp = discord.utils.utcnow()
        await ch.send(embed=e)
        await interaction.response.send_message(f"✅ Embed sent to {ch.mention}.", ephemeral=True)

    @slash.command(name="edit", description="Edit an existing embed sent by the bot.")
    @app_commands.describe(message_id="ID of the message containing the embed", channel="Channel where the message is (defaults to current)")
    @app_commands.default_permissions(manage_messages=True)
    @app_commands.checks.has_permissions(manage_messages=True)
    async def embed_edit(self, interaction: discord.Interaction, message_id: str, channel: discord.TextChannel = None):
        ch = channel or interaction.channel
        try:
            msg = await ch.fetch_message(int(message_id))
        except (discord.NotFound, ValueError):
            await interaction.response.send_message("❌ Message not found.", ephemeral=True)
            return
        if msg.author != self.bot.user:
            await interaction.response.send_message("❌ I can only edit my own messages.", ephemeral=True)
            return
        await interaction.response.send_modal(EmbedEditModal(msg))

    @slash.command(name="addfield", description="Add a field to an existing embed sent by the bot.")
    @app_commands.describe(message_id="ID of the message containing the embed", name="Field name", value="Field value", inline="Show fields side by side? (default: False)", channel="Channel where the message is")
    @app_commands.default_permissions(manage_messages=True)
    @app_commands.checks.has_permissions(manage_messages=True)
    async def embed_addfield(self, interaction: discord.Interaction, message_id: str, name: str, value: str, inline: bool = False, channel: discord.TextChannel = None):
        ch = channel or interaction.channel
        try:
            msg = await ch.fetch_message(int(message_id))
        except (discord.NotFound, ValueError):
            await interaction.response.send_message("❌ Message not found.", ephemeral=True)
            return
        if msg.author != self.bot.user:
            await interaction.response.send_message("❌ I can only edit my own messages.", ephemeral=True)
            return
        if not msg.embeds:
            await interaction.response.send_message("❌ That message has no embeds.", ephemeral=True)
            return
        e = msg.embeds[0].copy()
        if len(e.fields) >= 25:
            await interaction.response.send_message("❌ Embeds can have at most 25 fields.", ephemeral=True)
            return
        e.add_field(name=name, value=value, inline=inline)
        await msg.edit(embed=e)
        await interaction.response.send_message("✅ Field added.", ephemeral=True)

    @slash.command(name="clearfields", description="Remove all fields from an existing embed.")
    @app_commands.describe(message_id="ID of the message containing the embed", channel="Channel where the message is")
    @app_commands.default_permissions(manage_messages=True)
    @app_commands.checks.has_permissions(manage_messages=True)
    async def embed_clearfields(self, interaction: discord.Interaction, message_id: str, channel: discord.TextChannel = None):
        ch = channel or interaction.channel
        try:
            msg = await ch.fetch_message(int(message_id))
        except (discord.NotFound, ValueError):
            await interaction.response.send_message("❌ Message not found.", ephemeral=True)
            return
        if msg.author != self.bot.user:
            await interaction.response.send_message("❌ I can only edit my own messages.", ephemeral=True)
            return
        if not msg.embeds:
            await interaction.response.send_message("❌ That message has no embeds.", ephemeral=True)
            return
        e = msg.embeds[0].copy()
        e.clear_fields()
        await msg.edit(embed=e)
        await interaction.response.send_message("✅ All fields cleared.", ephemeral=True)

    @slash.command(name="setauthor", description="Set the author line on an existing embed.")
    @app_commands.describe(message_id="ID of the message containing the embed", name="Author name", icon_url="Author icon URL (optional)", url="Author URL link (optional)", channel="Channel where the message is")
    @app_commands.default_permissions(manage_messages=True)
    @app_commands.checks.has_permissions(manage_messages=True)
    async def embed_setauthor(self, interaction: discord.Interaction, message_id: str, name: str, icon_url: str = None, url: str = None, channel: discord.TextChannel = None):
        ch = channel or interaction.channel
        try:
            msg = await ch.fetch_message(int(message_id))
        except (discord.NotFound, ValueError):
            await interaction.response.send_message("❌ Message not found.", ephemeral=True)
            return
        if msg.author != self.bot.user:
            await interaction.response.send_message("❌ I can only edit my own messages.", ephemeral=True)
            return
        if not msg.embeds:
            await interaction.response.send_message("❌ That message has no embeds.", ephemeral=True)
            return
        e = msg.embeds[0].copy()
        e.set_author(name=name, icon_url=icon_url, url=url)
        await msg.edit(embed=e)
        await interaction.response.send_message("✅ Author set.", ephemeral=True)

    @slash.command(name="json", description="Send an embed from a Discohook-compatible JSON payload.")
    @app_commands.describe(payload="JSON string representing a Discord embed object", channel="Target channel (defaults to current)")
    @app_commands.default_permissions(manage_messages=True)
    @app_commands.checks.has_permissions(manage_messages=True)
    async def embed_json(self, interaction: discord.Interaction, payload: str, channel: discord.TextChannel = None):
        ch = channel or interaction.channel
        try:
            data = json.loads(payload)
            if isinstance(data, dict) and "embeds" in data:
                embeds = [discord.Embed.from_dict(em) for em in data["embeds"]]
            elif isinstance(data, dict):
                embeds = [discord.Embed.from_dict(data)]
            elif isinstance(data, list):
                embeds = [discord.Embed.from_dict(em) for em in data]
            else:
                raise ValueError("Unknown payload format")
        except (json.JSONDecodeError, Exception) as exc:
            await interaction.response.send_message(f"❌ Failed to parse JSON: {exc}", ephemeral=True)
            return
        if len(embeds) > 10:
            await interaction.response.send_message("❌ Maximum 10 embeds per message.", ephemeral=True)
            return
        await ch.send(embeds=embeds)
        await interaction.response.send_message(f"✅ {len(embeds)} embed(s) sent to {ch.mention}.", ephemeral=True)

    @slash.command(name="preview", description="Preview an embed privately before sending it.")
    @app_commands.describe(title="Title", description="Body text", color="Hex color (optional)", footer="Footer text (optional)", image="Image URL (optional)", thumbnail="Thumbnail URL (optional)")
    @app_commands.default_permissions(manage_messages=True)
    @app_commands.checks.has_permissions(manage_messages=True)
    async def embed_preview(self, interaction: discord.Interaction, title: str = None, description: str = None, color: str = None, footer: str = None, image: str = None, thumbnail: str = None):
        if not title and not description:
            await interaction.response.send_message("❌ Provide at least a title or description.", ephemeral=True)
            return
        e = build(title=title, description=description, color=parse_color(color), bot=self.bot)
        if footer:
            e.set_footer(text=footer)
        if image:
            e.set_image(url=image)
        if thumbnail:
            e.set_thumbnail(url=thumbnail)
        await interaction.response.send_message("👀 Here's how your embed will look:", embed=e, ephemeral=True)

    # ========== PREFIX COMMANDS ==========
    @commands.command(name="embed")
    @commands.has_permissions(manage_messages=True)
    async def p_embed(self, ctx, action: str = None, *, args: str = None):
        if not action:
            return await ctx.reply("Usage: `//embed send|quick|edit|addfield|clearfields|setauthor|json|preview`")
        if action.lower() == "send":
            await ctx.reply("Please use `/embed send` to open the modal.")
        elif action.lower() == "quick":
            await ctx.reply("Usage: `//embed quick <title> | <description> [color] [#channel] [footer] [image] [thumbnail] [timestamp]`\nBetter to use `/embed quick`.")
        elif action.lower() == "edit":
            await ctx.reply("Usage: `//embed edit <message_id> [#channel]`\nBetter to use `/embed edit`.")
        elif action.lower() == "addfield":
            await ctx.reply("Usage: `//embed addfield <message_id> <name> <value> [inline] [#channel]`\nBetter to use `/embed addfield`.")
        elif action.lower() == "clearfields":
            await ctx.reply("Usage: `//embed clearfields <message_id> [#channel]`\nBetter to use `/embed clearfields`.")
        elif action.lower() == "setauthor":
            await ctx.reply("Usage: `//embed setauthor <message_id> <name> [icon_url] [url] [#channel]`\nBetter to use `/embed setauthor`.")
        elif action.lower() == "json":
            await ctx.reply("Usage: `//embed json <payload> [#channel]`\nBetter to use `/embed json`.")
        elif action.lower() == "preview":
            await ctx.reply("Usage: `//embed preview [title] [description] [color] [footer] [image] [thumbnail]`\nBetter to use `/embed preview`.")
        else:
            await ctx.reply(f"❌ Unknown action `{action}`. Available: send, quick, edit, addfield, clearfields, setauthor, json, preview")

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        print(f"[Embed] Error in command {interaction.command.name if interaction.command else 'unknown'}:")
        traceback.print_exception(type(error), error, error.__traceback__)
        if isinstance(error, app_commands.MissingPermissions):
            missing = ", ".join(p.replace("_", " ").title() for p in error.missing_permissions)
            msg = f"❌ You are missing the required permissions: **{missing}**."
        elif isinstance(error, app_commands.CommandNotFound):
            msg = "❌ That command does not exist."
        elif isinstance(error, app_commands.BotMissingPermissions):
            missing = ", ".join(p.replace("_", " ").title() for p in error.missing_permissions)
            msg = f"❌ I am missing the required permissions: **{missing}**."
        elif isinstance(error, app_commands.CheckFailure):
            msg = "❌ You don't have permission to use this command."
        else:
            msg = f"❌ An error occurred: {error}"
        try:
            if interaction.response.is_done():
                await interaction.followup.send(msg, ephemeral=True)
            else:
                await interaction.response.send_message(msg, ephemeral=True)
        except (discord.NotFound, discord.Forbidden, discord.HTTPException) as e:
            print(f"[Embed] Could not deliver error message: {e}")

RULES_FILE = "rules.json"

def _load_rules(guild_id: int) -> dict:
    return load(RULES_FILE).get(str(guild_id), {})

def _save_rules(guild_id: int, data: dict):
    full = load(RULES_FILE)
    full[str(guild_id)] = data
    save(RULES_FILE, full)

def _get_panel(guild_id: int, name: str) -> dict | None:
    return _load_rules(guild_id).get(name.lower())

def _save_panel(guild_id: int, name: str, panel: dict):
    d = _load_rules(guild_id)
    d[name.lower()] = panel
    _save_rules(guild_id, d)

def _all_rules_panels() -> list[dict]:
    data = load(RULES_FILE)
    out = []
    for guild_data in data.values():
        for panel in guild_data.values():
            out.append(panel)
    return out

class RulesSelect(discord.ui.Select):
    def __init__(self, panel_name: str, items: list[dict]):
        self.panel_name = panel_name
        options = [
            discord.SelectOption(label=item["label"][:100], value=str(i), description=(item.get("hint") or item["content"])[:100] or None)
            for i, item in enumerate(items[:25])
        ]
        super().__init__(custom_id=f"rules_select:{panel_name}", placeholder="Select a rule to view…", options=options, min_values=1, max_values=1)

    async def callback(self, interaction: discord.Interaction):
        try:
            panel = _get_panel(interaction.guild_id, self.panel_name)
            if not panel:
                await interaction.response.send_message("❌ This rules panel no longer exists.", ephemeral=True)
                return
            items = panel.get("items", [])
            idx = int(self.values[0])
            if idx >= len(items):
                await interaction.response.send_message("❌ That option is no longer available.", ephemeral=True)
                return
            item = items[idx]
            e = build(title=item["label"], description=item["content"], color=Config.COLOR_INFO, bot=self.bot)
            panel_title = panel.get("title")
            if panel_title:
                e.set_author(name=panel_title)
            await interaction.response.send_message(embed=e, ephemeral=True)
        except Exception as e:
            print(f"[Rules] Error in RulesSelect callback: {e}")
            traceback.print_exc()
            await interaction.response.send_message(f"❌ Failed to display rule: {e}", ephemeral=True)

class RulesView(discord.ui.View):
    def __init__(self, panel_name: str, items: list[dict]):
        super().__init__(timeout=None)
        self.panel_name = panel_name
        self.add_item(RulesSelect(panel_name, items))

class RulesCreateModal(discord.ui.Modal, title="Create Rules Panel"):
    panel_name = discord.ui.TextInput(label="Panel name (internal ID, e.g. server-rules)", placeholder="server-rules", max_length=50)
    panel_title = discord.ui.TextInput(label="Embed title", placeholder="Server Rules", max_length=256)
    panel_description = discord.ui.TextInput(label="Embed description (optional)", placeholder="Select a rule from the dropdown to read it.", style=discord.TextStyle.paragraph, required=False, max_length=2000)

    def __init__(self, guild_id: int, bot):
        super().__init__()
        self.guild_id = guild_id
        self.bot = bot

    async def on_submit(self, interaction: discord.Interaction):
        try:
            name = self.panel_name.value.strip().lower().replace(" ", "-")
            if _get_panel(self.guild_id, name):
                await interaction.response.send_message(f"❌ A panel called `{name}` already exists.", ephemeral=True)
                return
            _save_panel(self.guild_id, name, {
                "name": name,
                "title": self.panel_title.value.strip(),
                "description": self.panel_description.value.strip(),
                "items": [],
                "posted": [],
            })
            await interaction.response.send_message(embed=build(title=f"✅ Panel `{name}` created", description=f"**Title:** {self.panel_title.value.strip()}\nAdd items with `/rules additem name:{name}`\nThen post with `/rules post name:{name}`", color=Config.COLOR_OK, bot=self.bot), ephemeral=True)
        except Exception as e:
            print(f"[Rules] Error in RulesCreateModal: {e}")
            traceback.print_exc()
            await interaction.response.send_message(f"❌ Failed to create panel: {e}", ephemeral=True)

class RulesAddItemModal(discord.ui.Modal, title="Add Rule Item"):
    item_label = discord.ui.TextInput(label="Dropdown label (shown in the menu)", placeholder="Rule 1 • Be Respectful", max_length=100)
    item_description = discord.ui.TextInput(label="Dropdown hint (shown under label, optional)", placeholder="Short one-line summary", required=False, max_length=100)
    item_content = discord.ui.TextInput(label="Full rule text (shown when selected)", placeholder="Treat all members with respect...", style=discord.TextStyle.paragraph, max_length=4000)

    def __init__(self, guild_id: int, panel_name: str):
        super().__init__()
        self.guild_id = guild_id
        self.panel_name = panel_name

    async def on_submit(self, interaction: discord.Interaction):
        try:
            panel = _get_panel(self.guild_id, self.panel_name)
            if not panel:
                await interaction.response.send_message(f"❌ Panel `{self.panel_name}` not found.", ephemeral=True)
                return
            if len(panel["items"]) >= 25:
                await interaction.response.send_message("❌ A panel can have at most 25 items (Discord dropdown limit).", ephemeral=True)
                return
            label = self.item_label.value.strip()
            hint = self.item_description.value.strip()
            content = self.item_content.value.strip()
            panel["items"].append({"label": label, "hint": hint, "content": content})
            _save_panel(self.guild_id, self.panel_name, panel)
            await interaction.response.send_message(embed=build(title=f"✅ Item added to `{self.panel_name}`", description=f"**{label}**\n{content[:200]}{'…' if len(content) > 200 else ''}", color=Config.COLOR_OK, bot=self.bot), ephemeral=True)
        except Exception as e:
            print(f"[Rules] Error in RulesAddItemModal: {e}")
            traceback.print_exc()
            await interaction.response.send_message(f"❌ Failed to add item: {e}", ephemeral=True)

class RulesEditItemModal(discord.ui.Modal, title="Edit Rule Item"):
    item_label = discord.ui.TextInput(label="Dropdown label (blank = keep current)", required=False, max_length=100)
    item_description = discord.ui.TextInput(label="Dropdown hint (blank = keep current)", required=False, max_length=100)
    item_content = discord.ui.TextInput(label="Full rule text (blank = keep current)", style=discord.TextStyle.paragraph, required=False, max_length=4000)

    def __init__(self, guild_id: int, panel_name: str, item_index: int, current: dict):
        super().__init__()
        self.guild_id = guild_id
        self.panel_name = panel_name
        self.item_index = item_index
        self.item_label.default = current.get("label", "")[:100]
        self.item_description.default = current.get("hint", "")[:100]
        self.item_content.default = current.get("content", "")[:4000]

    async def on_submit(self, interaction: discord.Interaction):
        try:
            panel = _get_panel(self.guild_id, self.panel_name)
            if not panel or self.item_index >= len(panel.get("items", [])):
                await interaction.response.send_message("❌ Item not found.", ephemeral=True)
                return
            item = panel["items"][self.item_index]
            if self.item_label.value.strip():
                item["label"] = self.item_label.value.strip()
            if self.item_description.value.strip():
                item["hint"] = self.item_description.value.strip()
            if self.item_content.value.strip():
                item["content"] = self.item_content.value.strip()
            panel["items"][self.item_index] = item
            _save_panel(self.guild_id, self.panel_name, panel)
            await interaction.response.send_message(embed=build(title="✅ Item updated", description=f"**{item['label']}** has been updated.", color=Config.COLOR_OK, bot=self.bot), ephemeral=True)
        except Exception as e:
            print(f"[Rules] Error in RulesEditItemModal: {e}")
            traceback.print_exc()
            await interaction.response.send_message(f"❌ Failed to edit item: {e}", ephemeral=True)

class RulesPostModal(discord.ui.Modal, title="Post Rules Panel"):
    custom_title = discord.ui.TextInput(label="Embed title (blank = keep panel title)", required=False, max_length=256)
    custom_description = discord.ui.TextInput(label="Embed description (blank = keep panel)", style=discord.TextStyle.paragraph, required=False, max_length=2000)

    def __init__(self, guild_id: int, panel_name: str, channel: discord.TextChannel, bot):
        super().__init__()
        self.guild_id = guild_id
        self.panel_name = panel_name
        self.channel = channel
        self.bot = bot

    async def on_submit(self, interaction: discord.Interaction):
        try:
            panel = _get_panel(self.guild_id, self.panel_name)
            if not panel:
                await interaction.response.send_message(f"❌ Panel `{self.panel_name}` not found.", ephemeral=True)
                return
            items = panel.get("items", [])
            if not items:
                await interaction.response.send_message("❌ This panel has no items. Add some with `/rules additem` first.", ephemeral=True)
                return
            title = self.custom_title.value.strip() or panel.get("title", self.panel_name)
            desc = self.custom_description.value.strip() or panel.get("description") or "Select a rule from the dropdown below."
            e = build(title=title, description=desc, color=Config.COLOR_INFO, bot=self.bot)
            e.set_footer(text=f"{len(items)} option(s) available")
            view = RulesView(self.panel_name, items)
            self.bot.add_view(view)
            msg = await self.channel.send(embed=e, view=view)
            panel.setdefault("posted", []).append({"channel_id": self.channel.id, "message_id": msg.id})
            _save_panel(self.guild_id, self.panel_name, panel)
            await interaction.response.send_message(embed=build(title="✅ Rules panel posted", description=f"Posted `{self.panel_name}` in {self.channel.mention}.", color=Config.COLOR_OK, bot=self.bot), ephemeral=True)
        except Exception as e:
            print(f"[Rules] Error in RulesPostModal: {e}")
            traceback.print_exc()
            await interaction.response.send_message(f"❌ Failed to post panel: {e}", ephemeral=True)

class RulesCog(commands.Cog, name="Rules"):
    slash = app_commands.Group(name="rules", description="Create and manage rules dropdown panels", parent=None)

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # ========== SLASH COMMANDS ==========
    @slash.command(name="create", description="Create a new rules panel (opens a modal).")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def rules_create(self, interaction: discord.Interaction):
        await interaction.response.send_modal(RulesCreateModal(interaction.guild_id, self.bot))

    @slash.command(name="additem", description="Add a rule item to a panel (opens a modal).")
    @app_commands.describe(name="Panel name to add a rule to")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def rules_additem(self, interaction: discord.Interaction, name: str):
        panel = _get_panel(interaction.guild_id, name.lower())
        if not panel:
            await interaction.response.send_message(f"❌ Panel `{name}` not found.", ephemeral=True)
            return
        if len(panel.get("items", [])) >= 25:
            await interaction.response.send_message("❌ This panel already has 25 items (Discord dropdown limit).", ephemeral=True)
            return
        await interaction.response.send_modal(RulesAddItemModal(interaction.guild_id, name.lower()))

    @slash.command(name="edititem", description="Edit an existing rule item (opens a modal).")
    @app_commands.describe(name="Panel name", number="Item number (see /rules preview)")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def rules_edititem(self, interaction: discord.Interaction, name: str, number: int):
        panel = _get_panel(interaction.guild_id, name.lower())
        if not panel:
            await interaction.response.send_message(f"❌ Panel `{name}` not found.", ephemeral=True)
            return
        idx = number - 1
        if idx < 0 or idx >= len(panel.get("items", [])):
            await interaction.response.send_message("❌ Invalid item number.", ephemeral=True)
            return
        await interaction.response.send_modal(RulesEditItemModal(interaction.guild_id, name.lower(), idx, panel["items"][idx]))

    @slash.command(name="removeitem", description="Remove a rule item from a panel.")
    @app_commands.describe(name="Panel name", number="Item number (see /rules preview)")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def rules_removeitem(self, interaction: discord.Interaction, name: str, number: int):
        panel = _get_panel(interaction.guild_id, name.lower())
        if not panel:
            await interaction.response.send_message(f"❌ Panel `{name}` not found.", ephemeral=True)
            return
        idx = number - 1
        if idx < 0 or idx >= len(panel["items"]):
            await interaction.response.send_message("❌ Invalid item number.", ephemeral=True)
            return
        removed = panel["items"].pop(idx)
        _save_panel(interaction.guild_id, name.lower(), panel)
        await interaction.response.send_message(embed=build(title=f"✅ Removed item from `{name}`", description=f"Removed: **{removed['label']}**", color=Config.COLOR_OK, bot=self.bot), ephemeral=True)

    @slash.command(name="preview", description="Preview a rules panel privately.")
    @app_commands.describe(name="Panel name")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def rules_preview(self, interaction: discord.Interaction, name: str):
        panel = _get_panel(interaction.guild_id, name.lower())
        if not panel:
            await interaction.response.send_message(f"❌ Panel `{name}` not found.", ephemeral=True)
            return
        items = panel.get("items", [])
        e = build(title=panel.get("title", name), description=panel.get("description") or "No description set.", color=Config.COLOR_INFO, bot=self.bot)
        if not items:
            e.add_field(name="Items", value="No items yet. Use `/rules additem`.", inline=False)
        else:
            for i, item in enumerate(items):
                val = item["content"][:200] + ("…" if len(item["content"]) > 200 else "")
                if item.get("hint"):
                    val = f"*{item['hint']}*\n{val}"
                e.add_field(name=f"{i + 1}. {item['label']}", value=val, inline=False)
        await interaction.response.send_message(embed=e, ephemeral=True)

    @slash.command(name="list", description="List all rules panels in this server.")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def rules_list(self, interaction: discord.Interaction):
        panels = _load_rules(interaction.guild_id)
        if not panels:
            await interaction.response.send_message(embed=build(description="No rules panels yet. Use `/rules create` to make one.", color=Config.COLOR_INFO, bot=self.bot), ephemeral=True)
            return
        e = build(title=f"Rules Panels ({len(panels)})", color=Config.COLOR_INFO, bot=self.bot)
        for pname, panel in panels.items():
            item_count = len(panel.get("items", []))
            posted = len(panel.get("posted", []))
            e.add_field(name=pname, value=f"{item_count} item(s) | {posted} posted message(s)", inline=True)
        await interaction.response.send_message(embed=e, ephemeral=True)

    @slash.command(name="post", description="Post a rules dropdown panel to a channel (opens a modal).")
    @app_commands.describe(name="Panel name", channel="Channel to post in (defaults to current)")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def rules_post(self, interaction: discord.Interaction, name: str, channel: discord.TextChannel = None):
        panel = _get_panel(interaction.guild_id, name.lower())
        if not panel:
            await interaction.response.send_message(f"❌ Panel `{name}` not found.", ephemeral=True)
            return
        if not panel.get("items"):
            await interaction.response.send_message("❌ This panel has no items. Add some with `/rules additem` first.", ephemeral=True)
            return
        ch = channel or interaction.channel
        await interaction.response.send_modal(RulesPostModal(interaction.guild_id, name.lower(), ch, self.bot))

    @slash.command(name="delete", description="Permanently delete a rules panel.")
    @app_commands.describe(name="Panel name")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def rules_delete(self, interaction: discord.Interaction, name: str):
        d = _load_rules(interaction.guild_id)
        if name.lower() not in d:
            await interaction.response.send_message(f"❌ Panel `{name}` not found.", ephemeral=True)
            return
        del d[name.lower()]
        _save_rules(interaction.guild_id, d)
        await interaction.response.send_message(embed=build(title="✅ Deleted", description=f"Panel `{name}` has been deleted.", color=Config.COLOR_OK, bot=self.bot), ephemeral=True)

    # ========== PREFIX COMMANDS ==========
    @commands.command(name="rules")
    @commands.has_permissions(manage_guild=True)
    async def p_rules(self, ctx, action: str = None, *, args: str = None):
        if not action:
            return await ctx.reply("Usage: `//rules create|additem|edititem|removeitem|preview|list|post|delete`")
        if action.lower() == "create":
            await ctx.reply("Please use `/rules create` to open the modal.")
        elif action.lower() == "additem":
            if not args:
                return await ctx.reply("Usage: `//rules additem <panel_name>`")
            await self.rules_additem.callback(self, await commands.Context.from_interaction(ctx), args)
        elif action.lower() == "edititem":
            parts = args.split() if args else []
            if len(parts) < 2:
                return await ctx.reply("Usage: `//rules edititem <panel_name> <item_number>`")
            await self.rules_edititem.callback(self, await commands.Context.from_interaction(ctx), parts[0], int(parts[1]))
        elif action.lower() == "removeitem":
            parts = args.split() if args else []
            if len(parts) < 2:
                return await ctx.reply("Usage: `//rules removeitem <panel_name> <item_number>`")
            await self.rules_removeitem.callback(self, await commands.Context.from_interaction(ctx), parts[0], int(parts[1]))
        elif action.lower() == "preview":
            if not args:
                return await ctx.reply("Usage: `//rules preview <panel_name>`")
            await self.rules_preview.callback(self, await commands.Context.from_interaction(ctx), args)
        elif action.lower() == "list":
            await self.rules_list.callback(self, await commands.Context.from_interaction(ctx))
        elif action.lower() == "post":
            parts = args.split() if args else []
            if len(parts) < 1:
                return await ctx.reply("Usage: `//rules post <panel_name> [#channel]`")
            name = parts[0]
            channel = None
            if len(parts) > 1 and parts[1].startswith("#"):
                channel = discord.utils.get(ctx.guild.text_channels, name=parts[1][1:])
            await self.rules_post.callback(self, await commands.Context.from_interaction(ctx), name, channel)
        elif action.lower() == "delete":
            if not args:
                return await ctx.reply("Usage: `//rules delete <panel_name>`")
            await self.rules_delete.callback(self, await commands.Context.from_interaction(ctx), args)
        else:
            await ctx.reply(f"❌ Unknown action `{action}`. Available: create, additem, edititem, removeitem, preview, list, post, delete")

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        print(f"[Rules] Error in command {interaction.command.name if interaction.command else 'unknown'}:")
        traceback.print_exception(type(error), error, error.__traceback__)
        if isinstance(error, app_commands.MissingPermissions):
            missing = ", ".join(p.replace("_", " ").title() for p in error.missing_permissions)
            msg = f"❌ You are missing the required permissions: **{missing}**."
        elif isinstance(error, app_commands.CommandNotFound):
            msg = "❌ That command does not exist."
        elif isinstance(error, app_commands.BotMissingPermissions):
            missing = ", ".join(p.replace("_", " ").title() for p in error.missing_permissions)
            msg = f"❌ I am missing the required permissions: **{missing}**."
        elif isinstance(error, app_commands.CheckFailure):
            msg = "❌ You don't have permission to use this command."
        else:
            msg = f"❌ An error occurred: {error}"
        try:
            if interaction.response.is_done():
                await interaction.followup.send(msg, ephemeral=True)
            else:
                await interaction.response.send_message(msg, ephemeral=True)
        except (discord.NotFound, discord.Forbidden, discord.HTTPException) as e:
            print(f"[Rules] Could not deliver error message: {e}")

async def setup(bot: commands.Bot):
    await bot.add_cog(EmbedCog(bot))
    await bot.add_cog(RulesCog(bot))
    registered: set[str] = set()
    for panel in _all_rules_panels():
        pname = panel.get("name", "")
        items = panel.get("items", [])
        if pname and pname not in registered and items:
            bot.add_view(RulesView(pname, items))
            registered.add(pname)