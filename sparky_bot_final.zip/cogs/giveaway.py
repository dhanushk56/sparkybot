import discord
from discord.ext import commands
from discord import app_commands
import asyncio
import random
import string
from datetime import datetime, timezone, timedelta
from config import Config
from utils.embed import build
from utils.theme import Theme
from utils.data import load, save

GW_FILE = "giveaways.json"

def _generate_id() -> str:
    return ''.join(random.choices(string.digits, k=4))

def _parse_time(s: str):
    units = {"s": 1, "m": 60, "h": 3600, "d": 86400, "w": 604800}
    unit = s[-1].lower()
    if unit not in units or not s[:-1].isdigit():
        return None
    return int(s[:-1]) * units[unit]

def _format_duration(seconds: int) -> str:
    if seconds <= 0:
        return "0s"

    days = seconds // 86400
    seconds %= 86400
    hours = seconds // 3600
    seconds %= 3600
    minutes = seconds // 60
    seconds %= 60

    parts = []
    if days:
        parts.append(f"{days}d")
    if hours:
        parts.append(f"{hours}h")
    if minutes:
        parts.append(f"{minutes}m")
    if seconds:
        parts.append(f"{seconds}s")

    return " ".join(parts) if parts else "0s"

def _get_giveaway(guild_id: int, giveaway_id: str) -> dict | None:
    data = load(GW_FILE)
    guild_data = data.get(str(guild_id), {})
    for msg_id, gw in guild_data.items():
        if gw.get("custom_id") == giveaway_id:
            gw["message_id"] = int(msg_id)
            return gw
    return None

def _update_giveaway(guild_id: int, giveaway_id: str, updates: dict) -> bool:
    data = load(GW_FILE)
    guild_data = data.get(str(guild_id), {})
    for msg_id, gw in guild_data.items():
        if gw.get("custom_id") == giveaway_id:
            gw.update(updates)
            save(GW_FILE, data)
            return True
    return False

async def _update_embed(bot, guild_id: int, message_id: int, gw: dict):
    guild = bot.get_guild(guild_id)
    if not guild:
        return
    channel = guild.get_channel(gw["channel_id"])
    if not channel:
        return
    try:
        msg = await channel.fetch_message(message_id)
    except Exception:
        return

    total_entries = len(gw.get("entries", []))

    ends_at = datetime.fromisoformat(gw["ends_at"])

    req_text = "✅ No requirements"
    if gw.get("requirements"):
        reqs = gw["requirements"]
        lines = []
        if reqs.get("min_messages"):
            lines.append(f"📊 Min Messages: {reqs['min_messages']}")
        if reqs.get("min_weekly_messages"):
            lines.append(f"📊 Min Weekly Messages: {reqs['min_weekly_messages']}")
        if reqs.get("min_daily_messages"):
            lines.append(f"📊 Min Daily Messages: {reqs['min_daily_messages']}")
        if reqs.get("required_roles"):
            roles = [f"<@&{r}>" for r in reqs["required_roles"]]
            lines.append(f"🎭 Required Roles: {', '.join(roles)}")
        if reqs.get("bypass_roles"):
            roles = [f"<@&{r}>" for r in reqs["bypass_roles"]]
            lines.append(f"⭐ Bypass Roles: {', '.join(roles)}")
        if reqs.get("bonus_roles"):
            bonus_lines = []
            for role_id, bonus in reqs["bonus_roles"].items():
                bonus_lines.append(f"<@&{role_id}>: +{bonus} entries")
            lines.append(f"🎯 Bonus Entries: {', '.join(bonus_lines)}")
        req_text = "\n".join(lines) if lines else "✅ No requirements"

    if gw.get("custom_text"):
        description = f"{gw['custom_text']}\n\n**Total Entries:** {total_entries}"
    else:
        description = f"Click the button below to enter!\n\n" \
                     f"**Ends:** {discord.utils.format_dt(ends_at, 'R')}\n" \
                     f"**Winners:** {gw['winners']}\n" \
                     f"**Hosted by:** <@{gw['host_id']}>\n" \
                     f"**Total Entries:** {total_entries}"

    embed = build(title=f"🎉 {gw['prize']}", description=description, color=Config.COLOR_GOLD)
    embed.add_field(name="📋 Requirements", value=req_text, inline=False)
    embed.set_footer(text=f"ID: {gw['custom_id']} • Ends at")

    view = GiveawayView(gw["custom_id"], bot)
    await msg.edit(embed=embed, view=view)

async def _end_giveaway(bot, guild_id: int, channel_id: int, message_id: int, giveaway_id: str):
    data = load(GW_FILE)
    gw = data.get(str(guild_id), {}).get(str(message_id))
    if not gw or gw.get("ended"):
        return

    guild = bot.get_guild(guild_id)
    if not guild:
        return
    channel = guild.get_channel(channel_id)
    if not channel:
        return
    try:
        msg = await channel.fetch_message(message_id)
    except Exception:
        return

    entries = gw.get("entries", [])
    total_entries = len(entries)
    unique_entries = list(set(entries))
    prize = gw.get("prize", "Mystery Prize")
    host_id = gw.get("host_id")
    num_winners = gw.get("winners", 1)

    winner_mentions = "No valid entries"
    winners = []

    if unique_entries:

        weighted_entries = []
        for user_id in unique_entries:

            weighted_entries.append(user_id)

            requirements = gw.get("requirements", {})
            bonus_roles = requirements.get("bonus_roles", {})
            member = guild.get_member(user_id)
            if member:
                for role_id, bonus_count in bonus_roles.items():
                    role = guild.get_role(int(role_id))
                    if role and role in member.roles:
                        for _ in range(bonus_count):
                            weighted_entries.append(user_id)

        winners = random.sample(weighted_entries, min(num_winners, len(weighted_entries)))
        winner_mentions = ", ".join(f"<@{w}>" for w in winners)

        e = build(title=f"🎉 Giveaway Ended • {prize}", description=f"**Winner(s):** {winner_mentions}\n**Hosted by:** <@{host_id}>", color=Config.COLOR_OK)
        await channel.send(embed=e)
        await channel.send(f"🎊 Congratulations {winner_mentions}! You won **{prize}**!")
        gw["winner_ids"] = winners

    gw["ended"] = True
    data[str(guild_id)][str(message_id)] = gw
    save(GW_FILE, data)

    try:
        ended_embed = build(title=f"🎉 {prize} • ENDED", description=f"**Winners:** {winner_mentions}\n**Unique Entries:** {len(unique_entries)}\n**Total Entries (with bonuses):** {total_entries}", color=Config.COLOR_ERR)
        await msg.edit(embed=ended_embed, view=None)
    except Exception:
        pass

class EntriesPaginationView(discord.ui.View):

    def __init__(self, entries: list, author_id: int, giveaway_id: str):
        super().__init__(timeout=120)
        self.entries = entries
        self.author_id = author_id
        self.giveaway_id = giveaway_id
        self.current_page = 0
        self.items_per_page = 10
        self.total_pages = max(1, (len(entries) + self.items_per_page - 1) // self.items_per_page)
        self.message = None
        self._update_buttons()

    def _update_buttons(self):
        self.clear_items()

        self.add_item(self.first_btn)
        self.add_item(self.prev_btn)
        self.add_item(self.page_counter)
        self.add_item(self.next_btn)
        self.add_item(self.last_btn)
        self.add_item(self.close_btn)

        self.first_btn.disabled = self.current_page == 0
        self.prev_btn.disabled = self.current_page == 0
        self.next_btn.disabled = self.current_page >= self.total_pages - 1
        self.last_btn.disabled = self.current_page >= self.total_pages - 1

    def _get_page_entries(self) -> list:
        start = self.current_page * self.items_per_page
        end = start + self.items_per_page
        return self.entries[start:end]

    def _build_embed(self) -> discord.Embed:
        page_entries = self._get_page_entries()

        embed = build(title=f"👥 Giveaway Entries • {self.giveaway_id}", description=f"**Total Entries:** {len(self.entries)}\n\n", color=Config.COLOR_INFO, bot=self.bot)

        if not page_entries:
            embed.description += "*No entries yet*"
        else:
            for i, entry in enumerate(page_entries, start=self.current_page * self.items_per_page + 1):
                embed.description += f"**{i}.** <@{entry}>\n"

        embed.set_footer(
            text=f"Page {self.current_page + 1}/{self.total_pages} • {len(self.entries)} total entries"
        )

        return embed

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.author_id:
            await interaction.response.send_message(
                "❌ Only the person who requested the entries can navigate this menu.",
                ephemeral=True
            )
            return False
        return True

    @discord.ui.button(label="⏮️", style=discord.ButtonStyle.secondary, row=0)
    async def first_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.current_page = 0
        self._update_buttons()
        await interaction.response.edit_message(embed=self._build_embed(), view=self)

    @discord.ui.button(label="◀️", style=discord.ButtonStyle.secondary, row=0)
    async def prev_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.current_page > 0:
            self.current_page -= 1
        self._update_buttons()
        await interaction.response.edit_message(embed=self._build_embed(), view=self)

    @discord.ui.button(label="📄", style=discord.ButtonStyle.primary, row=0, disabled=True)
    async def page_counter(self, interaction: discord.Interaction, button: discord.ui.Button):
        pass

    @discord.ui.button(label="▶️", style=discord.ButtonStyle.secondary, row=0)
    async def next_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.current_page < self.total_pages - 1:
            self.current_page += 1
        self._update_buttons()
        await interaction.response.edit_message(embed=self._build_embed(), view=self)

    @discord.ui.button(label="⏭️", style=discord.ButtonStyle.secondary, row=0)
    async def last_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.current_page = self.total_pages - 1
        self._update_buttons()
        await interaction.response.edit_message(embed=self._build_embed(), view=self)

    @discord.ui.button(label="✖ Close", style=discord.ButtonStyle.danger, row=1)
    async def close_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(
            embed=build(title="👥 Entries Closed", description="The entries list has been closed.", color=Config.COLOR_ERR, bot=self.bot),
            view=None
        )
        self.stop()

    async def on_timeout(self):
        if self.message:
            try:
                await self.message.edit(
                    embed=build(title="⏰ Entries Menu Timed Out", description="The entries list has expired.", color=Config.COLOR_ERR, bot=self.bot),
                    view=None
                )
            except Exception:
                pass

class BonusEntryView(discord.ui.View):

    def __init__(self, giveaway_id: str, bot, user_id: int):
        super().__init__(timeout=60)
        self.giveaway_id = giveaway_id
        self.bot = bot
        self.user_id = user_id

    @discord.ui.button(label="➕ Add Bonus Entry", style=discord.ButtonStyle.success, emoji="⭐")
    async def add_bonus_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id:
            return await interaction.response.send_message("❌ This isn't for you.", ephemeral=True)

        gw = _get_giveaway(interaction.guild_id, self.giveaway_id)
        if not gw:
            return await interaction.response.send_message("❌ This giveaway no longer exists.", ephemeral=True)

        if gw.get("ended"):
            return await interaction.response.send_message("❌ This giveaway has already ended.", ephemeral=True)

        entries = gw.get("entries", [])
        user_id = interaction.user.id

        requirements = gw.get("requirements", {})
        bonus_roles = requirements.get("bonus_roles", {})
        max_bonus = 0
        for role_id, bonus_count in bonus_roles.items():
            role = interaction.guild.get_role(int(role_id))
            if role and role in interaction.user.roles:
                max_bonus += bonus_count

        current_entries = entries.count(user_id)

        if current_entries >= max_bonus + 1:
            return await interaction.response.send_message(
                f"❌ You already have the maximum number of entries ({max_bonus + 1}) for this giveaway!",
                ephemeral=True
            )

        entries.append(user_id)
        gw["entries"] = entries
        data = load(GW_FILE)
        data[str(interaction.guild_id)][str(gw["message_id"])] = gw
        save(GW_FILE, data)

        await interaction.response.send_message(
            f"✅ Added a bonus entry! You now have **{entries.count(user_id)}** entries in this giveaway.",
            ephemeral=True
        )
        await _update_embed(self.bot, interaction.guild_id, gw["message_id"], gw)

    @discord.ui.button(label="❌ Remove Bonus Entry", style=discord.ButtonStyle.danger, emoji="🗑️")
    async def remove_bonus_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id:
            return await interaction.response.send_message("❌ This isn't for you.", ephemeral=True)

        gw = _get_giveaway(interaction.guild_id, self.giveaway_id)
        if not gw:
            return await interaction.response.send_message("❌ This giveaway no longer exists.", ephemeral=True)

        if gw.get("ended"):
            return await interaction.response.send_message("❌ This giveaway has already ended.", ephemeral=True)

        entries = gw.get("entries", [])
        user_id = interaction.user.id

        entry_count = entries.count(user_id)

        if entry_count <= 1:
            return await interaction.response.send_message(
                "❌ You only have 1 entry (your base entry). Use the main Enter button to remove it.",
                ephemeral=True
            )

        entries.remove(user_id)
        gw["entries"] = entries
        data = load(GW_FILE)
        data[str(interaction.guild_id)][str(gw["message_id"])] = gw
        save(GW_FILE, data)

        await interaction.response.send_message(
            f"✅ Removed a bonus entry! You now have **{entries.count(user_id)}** entries in this giveaway.",
            ephemeral=True
        )
        await _update_embed(self.bot, interaction.guild_id, gw["message_id"], gw)

    async def on_timeout(self):
        pass

class GiveawayView(discord.ui.View):

    def __init__(self, giveaway_id: str, bot):
        super().__init__(timeout=None)
        self.giveaway_id = giveaway_id
        self.bot = bot

    async def _check_requirements(self, interaction: discord.Interaction, gw: dict) -> tuple[bool, str]:
        requirements = gw.get("requirements", {})

        if interaction.user.id == gw.get("host_id"):
            return True, "Host can always enter"

        if interaction.user.id == interaction.guild.owner_id:
            return True, "Server owner bypass"

        bypass_roles = requirements.get("bypass_roles", [])
        user_roles = [r.id for r in interaction.user.roles]
        if any(r in user_roles for r in bypass_roles):
            return True, "Bypass role detected"

        required_roles = requirements.get("required_roles", [])
        if required_roles:
            if not any(r in user_roles for r in required_roles):
                return False, f"You need one of these roles: {', '.join([f'<@&{r}>' for r in required_roles])}"

        from utils.data import load as data_load
        msg_stats = data_load("message_stats.json").get(str(interaction.guild_id), {}).get(str(interaction.user.id), {})

        min_messages = requirements.get("min_messages", 0)
        if min_messages and msg_stats.get("total", 0) < min_messages:
            return False, f"You need at least {min_messages} total messages. You have {msg_stats.get('total', 0)}."

        min_weekly = requirements.get("min_weekly_messages", 0)
        if min_weekly and msg_stats.get("week", 0) < min_weekly:
            return False, f"You need at least {min_weekly} messages this week. You have {msg_stats.get('week', 0)}."

        min_daily = requirements.get("min_daily_messages", 0)
        if min_daily and msg_stats.get("today", 0) < min_daily:
            return False, f"You need at least {min_daily} messages today. You have {msg_stats.get('today', 0)}."

        return True, "Requirements met"

    @discord.ui.button(label="🎉 Enter", style=discord.ButtonStyle.primary, custom_id="giveaway_enter")
    async def enter_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        gw = _get_giveaway(interaction.guild_id, self.giveaway_id)
        if not gw:
            return await interaction.response.send_message("❌ This giveaway no longer exists.", ephemeral=True)

        if gw.get("ended"):
            return await interaction.response.send_message("❌ This giveaway has already ended.", ephemeral=True)

        ends_at = datetime.fromisoformat(gw["ends_at"])
        if datetime.now(timezone.utc) > ends_at:
            return await interaction.response.send_message("❌ This giveaway has already ended.", ephemeral=True)

        passed, message = await self._check_requirements(interaction, gw)
        if not passed:
            return await interaction.response.send_message(f"❌ {message}", ephemeral=True)

        entries = gw.get("entries", [])
        user_id = interaction.user.id

        requirements = gw.get("requirements", {})
        bonus_roles = requirements.get("bonus_roles", {})

        if user_id in entries:

            entries = [e for e in entries if e != user_id]
            gw["entries"] = entries
            data = load(GW_FILE)
            data[str(interaction.guild_id)][str(gw["message_id"])] = gw
            save(GW_FILE, data)
            await interaction.response.send_message("✅ You have been **removed** from the giveaway!", ephemeral=True)
            await _update_embed(self.bot, interaction.guild_id, gw["message_id"], gw)
        else:

            entries.append(user_id)

            bonus_entries_added = 0
            for role_id, bonus_count in bonus_roles.items():
                role = interaction.guild.get_role(int(role_id))
                if role and role in interaction.user.roles:
                    for _ in range(bonus_count):
                        entries.append(user_id)
                        bonus_entries_added += 1

            gw["entries"] = entries
            data = load(GW_FILE)
            data[str(interaction.guild_id)][str(gw["message_id"])] = gw
            save(GW_FILE, data)

            total_entries = entries.count(user_id)
            response_msg = f"✅ You have been **entered** into the giveaway with **{total_entries}** entries!"
            if bonus_entries_added > 0:
                response_msg += f"\n\n⭐ **+{bonus_entries_added} bonus entries** added from your roles!"

                view = BonusEntryView(self.giveaway_id, self.bot, user_id)
                await interaction.response.send_message(response_msg, ephemeral=True, view=view)
                return

            await interaction.response.send_message(response_msg, ephemeral=True)
            await _update_embed(self.bot, interaction.guild_id, gw["message_id"], gw)

    @discord.ui.button(label="👥 Entries", style=discord.ButtonStyle.secondary, custom_id="giveaway_entries")
    async def entries_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        gw = _get_giveaway(interaction.guild_id, self.giveaway_id)
        if not gw:
            return await interaction.response.send_message("❌ This giveaway no longer exists.", ephemeral=True)

        entries = list(set(gw.get("entries", [])))
        entries_count = len(entries)

        if entries_count == 0:
            return await interaction.response.send_message(
                embed=build(title="👥 Giveaway Entries", description="No entries yet! Be the first to enter! 🎉", color=Config.COLOR_INFO, bot=self.bot),
                ephemeral=True
            )

        entries.sort()

        view = EntriesPaginationView(entries, interaction.user.id, self.giveaway_id)
        embed = view._build_embed()

        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)
        view.message = await interaction.original_response()

class EditGiveawayModal(discord.ui.Modal, title="✏️ Edit Giveaway"):
    prize = discord.ui.TextInput(
        label="Prize",
        placeholder="What's the new prize?",
        max_length=100,
        required=False
    )
    winners = discord.ui.TextInput(
        label="Number of Winners",
        placeholder="Enter a number (e.g. 1)",
        max_length=3,
        required=False
    )
    custom_text = discord.ui.TextInput(
        label="Custom Embed Text",
        style=discord.TextStyle.paragraph,
        placeholder="Custom description for the embed...",
        max_length=2000,
        required=False
    )
    min_messages = discord.ui.TextInput(
        label="Min Total Messages",
        placeholder="0 (no requirement)",
        max_length=6,
        required=False
    )
    min_weekly = discord.ui.TextInput(
        label="Min Weekly Messages",
        placeholder="0 (no requirement)",
        max_length=6,
        required=False
    )
    min_daily = discord.ui.TextInput(
        label="Min Daily Messages",
        placeholder="0 (no requirement)",
        max_length=6,
        required=False
    )
    required_roles = discord.ui.TextInput(
        label="Required Role IDs (comma-separated)",
        placeholder="123456789,987654321",
        max_length=200,
        required=False
    )
    bypass_roles = discord.ui.TextInput(
        label="Bypass Role IDs (comma-separated)",
        placeholder="123456789,987654321",
        max_length=200,
        required=False
    )
    bonus_roles = discord.ui.TextInput(
        label="Bonus Entries (role:bonus)",
        placeholder="123456789:2,987654321:1",
        max_length=200,
        required=False
    )

    def __init__(self, giveaway_id: str, bot):
        super().__init__()
        self.giveaway_id = giveaway_id
        self.bot = bot

        gw = _get_giveaway(int(bot.guilds[0].id), giveaway_id) if bot.guilds else None
        if gw:
            reqs = gw.get("requirements", {})
            self.min_messages.default = str(reqs.get("min_messages", 0))
            self.min_weekly.default = str(reqs.get("min_weekly_messages", 0))
            self.min_daily.default = str(reqs.get("min_daily_messages", 0))
            self.required_roles.default = ",".join(str(r) for r in reqs.get("required_roles", []))
            self.bypass_roles.default = ",".join(str(r) for r in reqs.get("bypass_roles", []))
            bonus_parts = []
            for role_id, bonus in reqs.get("bonus_roles", {}).items():
                bonus_parts.append(f"{role_id}:{bonus}")
            self.bonus_roles.default = ",".join(bonus_parts)

    async def on_submit(self, interaction: discord.Interaction):
        gw = _get_giveaway(interaction.guild_id, self.giveaway_id)
        if not gw:
            return await interaction.response.send_message("❌ Giveaway not found.", ephemeral=True)

        updates = {}
        requirements = gw.get("requirements", {})

        if self.prize.value:
            updates["prize"] = self.prize.value

        if self.winners.value and self.winners.value.isdigit():
            updates["winners"] = int(self.winners.value)

        if self.custom_text.value:
            updates["custom_text"] = self.custom_text.value

        if self.min_messages.value and self.min_messages.value.isdigit():
            val = int(self.min_messages.value)
            if val > 0:
                requirements["min_messages"] = val
            elif "min_messages" in requirements:
                del requirements["min_messages"]

        if self.min_weekly.value and self.min_weekly.value.isdigit():
            val = int(self.min_weekly.value)
            if val > 0:
                requirements["min_weekly_messages"] = val
            elif "min_weekly_messages" in requirements:
                del requirements["min_weekly_messages"]

        if self.min_daily.value and self.min_daily.value.isdigit():
            val = int(self.min_daily.value)
            if val > 0:
                requirements["min_daily_messages"] = val
            elif "min_daily_messages" in requirements:
                del requirements["min_daily_messages"]

        if self.required_roles.value.strip():
            roles = [int(r.strip()) for r in self.required_roles.value.split(",") if r.strip().isdigit()]
            if roles:
                requirements["required_roles"] = roles
            elif "required_roles" in requirements:
                del requirements["required_roles"]
        elif "required_roles" in requirements:
            del requirements["required_roles"]

        if self.bypass_roles.value.strip():
            roles = [int(r.strip()) for r in self.bypass_roles.value.split(",") if r.strip().isdigit()]
            if roles:
                requirements["bypass_roles"] = roles
            elif "bypass_roles" in requirements:
                del requirements["bypass_roles"]
        elif "bypass_roles" in requirements:
            del requirements["bypass_roles"]

        if self.bonus_roles.value.strip():
            bonus_dict = {}
            for part in self.bonus_roles.value.split(","):
                if ":" in part:
                    role_id, bonus = part.split(":")
                    if role_id.strip().isdigit() and bonus.strip().isdigit():
                        bonus_dict[int(role_id.strip())] = int(bonus.strip())
            if bonus_dict:
                requirements["bonus_roles"] = bonus_dict
            elif "bonus_roles" in requirements:
                del requirements["bonus_roles"]
        elif "bonus_roles" in requirements:
            del requirements["bonus_roles"]

        if not requirements:
            requirements = {}

        updates["requirements"] = requirements

        if updates:
            _update_giveaway(interaction.guild_id, self.giveaway_id, updates)
            await _update_embed(self.bot, interaction.guild_id, gw["message_id"], gw)
            await interaction.response.send_message("✅ Giveaway updated successfully!", ephemeral=True)
        else:
            await interaction.response.send_message("❌ No valid changes provided.", ephemeral=True)

class EditGiveawayView(discord.ui.View):
    def __init__(self, giveaway_id: str, bot):
        super().__init__(timeout=60)
        self.giveaway_id = giveaway_id
        self.bot = bot

    @discord.ui.button(label="✏️ Edit Giveaway", style=discord.ButtonStyle.primary)
    async def edit_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        gw = _get_giveaway(interaction.guild_id, self.giveaway_id)
        if not gw:
            return await interaction.response.send_message("❌ Giveaway not found.", ephemeral=True)

        if interaction.user.id != gw.get("host_id") and not interaction.user.guild_permissions.manage_guild:
            return await interaction.response.send_message("❌ Only the host or admins can edit this giveaway.", ephemeral=True)

        modal = EditGiveawayModal(self.giveaway_id, self.bot)
        await interaction.response.send_modal(modal)

class Giveaway(commands.Cog):

    gwy = app_commands.Group(name="gwy", description="Giveaway management commands")

    def __init__(self, bot):
        self.bot = bot
        self._running = {}
        self.bot.loop.create_task(self._resume_giveaways())

    async def _resume_giveaways(self):
        await self.bot.wait_until_ready()
        data = load(GW_FILE)
        now = datetime.now(timezone.utc)
        for guild_id_str, giveaways in data.items():
            for msg_id_str, gw in giveaways.items():
                if gw.get("ended"):
                    continue
                ends_at = datetime.fromisoformat(gw["ends_at"])
                delay = (ends_at - now).total_seconds()
                if delay <= 0:
                    await _end_giveaway(self.bot, int(guild_id_str), gw["channel_id"], int(msg_id_str), gw.get("custom_id"))
                else:
                    task = self.bot.loop.create_task(self._timer(int(guild_id_str), gw["channel_id"], int(msg_id_str), gw.get("custom_id"), delay))
                    self._running[int(msg_id_str)] = task

    async def _timer(self, guild_id, channel_id, message_id, giveaway_id, delay):
        await asyncio.sleep(delay)
        await _end_giveaway(self.bot, guild_id, channel_id, message_id, giveaway_id)

    @commands.command(name="gwy")
    @commands.has_permissions(manage_guild=True)
    async def gstart(self, ctx, duration: str, winners: int = 1, *, prize: str):
        await self._do_gstart(ctx, duration, winners, prize)

    @gwy.command(name="start", description="Start a giveaway.")
    @app_commands.describe(
        duration="Duration e.g. 30m, 2h, 1d, 1w",
        prize="Prize to give away",
        winners="Number of winners",
        channel="Channel to post the giveaway in",
        min_messages="Minimum total messages required",
        min_weekly="Minimum weekly messages required",
        min_daily="Minimum daily messages required",
        required_roles="Comma-separated role IDs required to enter",
        bypass_roles="Comma-separated role IDs that bypass requirements",
        bonus_roles="Role ID:bonus entries (e.g. 123:2)",
        custom_text="Custom description for the embed"
    )
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def gstart_slash(
        self,
        interaction: discord.Interaction,
        duration: str,
        prize: str,
        winners: int = 1,
        channel: discord.TextChannel = None,
        min_messages: int = 0,
        min_weekly: int = 0,
        min_daily: int = 0,
        required_roles: str = None,
        bypass_roles: str = None,
        bonus_roles: str = None,
        custom_text: str = None
    ):
        await interaction.response.defer(ephemeral=True)
        ctx = await commands.Context.from_interaction(interaction)
        await self._do_gstart(
            ctx, duration, winners, prize, channel,
            min_messages, min_weekly, min_daily,
            required_roles, bypass_roles, bonus_roles,
            custom_text
        )

    async def _do_gstart(
        self,
        ctx,
        duration: str,
        winners: int,
        prize: str,
        channel: discord.TextChannel = None,
        min_messages: int = 0,
        min_weekly: int = 0,
        min_daily: int = 0,
        required_roles: str = None,
        bypass_roles: str = None,
        bonus_roles: str = None,
        custom_text: str = None
    ):
        seconds = _parse_time(duration)
        if not seconds:
            return await ctx.reply("❌ Invalid duration. Use `30m`, `2h`, `1d`, `1w` etc.")
        if winners < 1 or winners > 20:
            return await ctx.reply("❌ Winners must be between 1 and 20.")

        ch = channel or ctx.channel
        ends_at = datetime.now(timezone.utc) + timedelta(seconds=seconds)
        giveaway_id = _generate_id()

        requirements = {}
        if min_messages > 0:
            requirements["min_messages"] = min_messages
        if min_weekly > 0:
            requirements["min_weekly_messages"] = min_weekly
        if min_daily > 0:
            requirements["min_daily_messages"] = min_daily

        if required_roles:
            requirements["required_roles"] = [int(r.strip()) for r in required_roles.split(",") if r.strip().isdigit()]

        if bypass_roles:
            requirements["bypass_roles"] = [int(r.strip()) for r in bypass_roles.split(",") if r.strip().isdigit()]

        if bonus_roles:
            bonus_dict = {}
            for part in bonus_roles.split(","):
                if ":" in part:
                    role_id, bonus = part.split(":")
                    if role_id.strip().isdigit() and bonus.strip().isdigit():
                        bonus_dict[int(role_id.strip())] = int(bonus.strip())
            requirements["bonus_roles"] = bonus_dict

        req_text = "✅ No requirements"
        if requirements:
            lines = []
            if requirements.get("min_messages"):
                lines.append(f"📊 Min Messages: {requirements['min_messages']}")
            if requirements.get("min_weekly_messages"):
                lines.append(f"📊 Min Weekly Messages: {requirements['min_weekly_messages']}")
            if requirements.get("min_daily_messages"):
                lines.append(f"📊 Min Daily Messages: {requirements['min_daily_messages']}")
            if requirements.get("required_roles"):
                roles = [f"<@&{r}>" for r in requirements["required_roles"]]
                lines.append(f"🎭 Required Roles: {', '.join(roles)}")
            if requirements.get("bypass_roles"):
                roles = [f"<@&{r}>" for r in requirements["bypass_roles"]]
                lines.append(f"⭐ Bypass Roles: {', '.join(roles)}")
            if requirements.get("bonus_roles"):
                bonus_lines = []
                for role_id, bonus in requirements["bonus_roles"].items():
                    bonus_lines.append(f"<@&{role_id}>: +{bonus} entries")
                lines.append(f"🎯 Bonus Entries: {', '.join(bonus_lines)}")
            req_text = "\n".join(lines)

        embed = build(title=f"🎉 {prize}", description=custom_text if custom_text else f"Click the button below to enter!\n\n"
                       f"**Ends:** {discord.utils.format_dt(ends_at, 'R')}\n"
                       f"**Winners:** {winners}\n"
                       f"**Hosted by:** {ctx.author.mention}\n"
                       f"**Total Entries:** 0", color=Config.COLOR_GOLD, bot=self.bot)
        embed.add_field(name="📋 Requirements", value=req_text, inline=False)
        embed.set_footer(text=f"ID: {giveaway_id} • Ends at")

        view = GiveawayView(giveaway_id, self.bot)
        msg = await ch.send(embed=embed, view=view)

        data = load(GW_FILE)
        data.setdefault(str(ctx.guild.id), {})[str(msg.id)] = {
            "prize": prize,
            "winners": winners,
            "host_id": ctx.author.id,
            "channel_id": ch.id,
            "ends_at": ends_at.isoformat(),
            "ended": False,
            "winner_ids": [],
            "entries": [],
            "custom_id": giveaway_id,
            "custom_text": custom_text,
            "requirements": requirements,
        }
        save(GW_FILE, data)

        task = self.bot.loop.create_task(self._timer(ctx.guild.id, ch.id, msg.id, giveaway_id, seconds))
        self._running[msg.id] = task

        await ctx.reply(f"🎉 Giveaway started! ID: `{giveaway_id}`", delete_after=5)

    @commands.command(name="gend")
    @commands.has_permissions(manage_guild=True)
    async def gend(self, ctx, giveaway_id: str):
        await self._do_gend(ctx, giveaway_id)

    @gwy.command(name="end", description="End a giveaway early by its 4-digit ID.")
    @app_commands.describe(giveaway_id="The 4-digit ID of the giveaway")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def gend_slash(self, interaction: discord.Interaction, giveaway_id: str):
        ctx = await commands.Context.from_interaction(interaction)
        await self._do_gend(ctx, giveaway_id)

    async def _do_gend(self, ctx, giveaway_id: str):
        if len(giveaway_id) != 4 or not giveaway_id.isdigit():
            return await ctx.reply("❌ Please provide a valid 4-digit giveaway ID.")

        gw = _get_giveaway(ctx.guild.id, giveaway_id)
        if not gw:
            return await ctx.reply("❌ Giveaway not found. Please check the ID.")

        if ctx.author.id != gw.get("host_id") and not ctx.author.guild_permissions.manage_guild:
            return await ctx.reply("❌ Only the host or admins can end this giveaway.")

        message_id = gw.get("message_id")
        task = self._running.pop(message_id, None)
        if task:
            task.cancel()

        await _end_giveaway(self.bot, ctx.guild.id, gw["channel_id"], message_id, giveaway_id)
        await ctx.reply(f"✅ Giveaway `{giveaway_id}` ended.")

    @commands.command(name="greroll")
    @commands.has_permissions(manage_guild=True)
    async def greroll(self, ctx, giveaway_id: str, winners: int = 1):
        await self._do_greroll(ctx, giveaway_id, winners)

    @gwy.command(name="reroll", description="Reroll a giveaway winner by its 4-digit ID.")
    @app_commands.describe(giveaway_id="The 4-digit ID of the ended giveaway", winners="Number of new winners")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def greroll_slash(self, interaction: discord.Interaction, giveaway_id: str, winners: int = 1):
        ctx = await commands.Context.from_interaction(interaction)
        await self._do_greroll(ctx, giveaway_id, winners)

    async def _do_greroll(self, ctx, giveaway_id: str, winners: int):
        if len(giveaway_id) != 4 or not giveaway_id.isdigit():
            return await ctx.reply("❌ Please provide a valid 4-digit giveaway ID.")

        gw = _get_giveaway(ctx.guild.id, giveaway_id)
        if not gw:
            return await ctx.reply("❌ Giveaway not found. Please check the ID.")

        if not gw.get("ended"):
            return await ctx.reply("❌ Giveaway hasn't ended yet.")

        entries = gw.get("entries", [])
        unique_entries = list(set(entries))

        if not unique_entries:
            return await ctx.reply("❌ No valid entries to reroll.")

        new_winners = random.sample(unique_entries, min(winners, len(unique_entries)))
        winner_mentions = ", ".join(f"<@{w}>" for w in new_winners)
        await ctx.reply(f"🎊 New winner(s) for **{gw['prize']}**: {winner_mentions}!")

    @commands.command(name="glist")
    @commands.has_permissions(manage_guild=True)
    async def glist(self, ctx):
        await self._do_glist(ctx)

    @gwy.command(name="list", description="List all active giveaways.")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def glist_slash(self, interaction: discord.Interaction):
        ctx = await commands.Context.from_interaction(interaction)
        await self._do_glist(ctx)

    async def _do_glist(self, ctx):
        data = load(GW_FILE).get(str(ctx.guild.id), {})
        active = [(mid, gw) for mid, gw in data.items() if not gw.get("ended")]
        if not active:
            return await ctx.reply("✅ No active giveaways.")

        lines = []
        for mid, gw in active:
            ch = ctx.guild.get_channel(gw["channel_id"])
            ends = datetime.fromisoformat(gw["ends_at"])
            entries = len(gw.get("entries", []))
            lines.append(f"• `{gw['custom_id']}` • **{gw['prize']}** in {ch.mention if ch else 'unknown'} • {entries} entries • ends {discord.utils.format_dt(ends, 'R')}")

        e = build(title="🎉 Active Giveaways", description="\n".join(lines), color=Config.COLOR_GOLD, bot=self.bot)
        await ctx.reply(embed=e)

    @commands.command(name="gedit")
    @commands.has_permissions(manage_guild=True)
    async def gedit(self, ctx, giveaway_id: str):
        await self._do_gedit(ctx, giveaway_id)

    @gwy.command(name="edit", description="Edit a giveaway by its 4-digit ID.")
    @app_commands.describe(giveaway_id="The 4-digit ID of the giveaway")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def gedit_slash(self, interaction: discord.Interaction, giveaway_id: str):
        ctx = await commands.Context.from_interaction(interaction)
        await self._do_gedit(ctx, giveaway_id)

    async def _do_gedit(self, ctx, giveaway_id: str):
        if len(giveaway_id) != 4 or not giveaway_id.isdigit():
            return await ctx.reply("❌ Please provide a valid 4-digit giveaway ID.")

        gw = _get_giveaway(ctx.guild.id, giveaway_id)
        if not gw:
            return await ctx.reply("❌ Giveaway not found. Please check the ID.")

        if gw.get("ended"):
            return await ctx.reply("❌ This giveaway has already ended.")

        if ctx.author.id != gw.get("host_id") and not ctx.author.guild_permissions.manage_guild:
            return await ctx.reply("❌ Only the host or admins can edit this giveaway.")

        view = EditGiveawayView(giveaway_id, self.bot)
        await ctx.reply(f"Click the button below to edit giveaway `{giveaway_id}`:", view=view)

    @commands.command(name="ginfo")
    @commands.has_permissions(manage_guild=True)
    async def ginfo(self, ctx, giveaway_id: str):
        await self._do_ginfo(ctx, giveaway_id)

    @gwy.command(name="info", description="Get info about a giveaway by its 4-digit ID.")
    @app_commands.describe(giveaway_id="The 4-digit ID of the giveaway")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def ginfo_slash(self, interaction: discord.Interaction, giveaway_id: str):
        ctx = await commands.Context.from_interaction(interaction)
        await self._do_ginfo(ctx, giveaway_id)

    async def _do_ginfo(self, ctx, giveaway_id: str):
        if len(giveaway_id) != 4 or not giveaway_id.isdigit():
            return await ctx.reply("❌ Please provide a valid 4-digit giveaway ID.")

        gw = _get_giveaway(ctx.guild.id, giveaway_id)
        if not gw:
            return await ctx.reply("❌ Giveaway not found. Please check the ID.")

        entries = gw.get("entries", [])
        unique_entries = list(set(entries))

        e = build(title=f"📋 Giveaway Info • {giveaway_id}", color=Config.COLOR_INFO, bot=self.bot)
        e.add_field(name="Prize", value=gw.get("prize", "Unknown"), inline=True)
        e.add_field(name="Winners", value=str(gw.get("winners", 1)), inline=True)
        e.add_field(name="Host", value=f"<@{gw.get('host_id')}>", inline=True)
        e.add_field(name="Status", value="✅ Active" if not gw.get("ended") else "❌ Ended", inline=True)
        e.add_field(name="Unique Entries", value=f"{len(unique_entries)}", inline=True)
        e.add_field(name="Total Entries", value=f"{len(entries)} (with bonuses)", inline=True)

        if gw.get("requirements"):
            reqs = gw["requirements"]
            req_lines = []
            if reqs.get("min_messages"):
                req_lines.append(f"Min Messages: {reqs['min_messages']}")
            if reqs.get("min_weekly_messages"):
                req_lines.append(f"Min Weekly: {reqs['min_weekly_messages']}")
            if reqs.get("min_daily_messages"):
                req_lines.append(f"Min Daily: {reqs['min_daily_messages']}")
            if reqs.get("bonus_roles"):
                bonus_lines = []
                for role_id, bonus in reqs["bonus_roles"].items():
                    bonus_lines.append(f"<@&{role_id}>: +{bonus}")
                req_lines.append(f"Bonus Roles: {', '.join(bonus_lines)}")
            e.add_field(name="Requirements", value="\n".join(req_lines) or "None", inline=False)

        ends_at = datetime.fromisoformat(gw["ends_at"])
        e.set_footer(text=f"Ends: {discord.utils.format_dt(ends_at, 'F')}")

        await ctx.reply(embed=e)

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            missing = ", ".join(p.replace("_", " ").title() for p in error.missing_permissions)
            print(f"[Giveaway] {interaction.user} ({interaction.user.id}) missing permissions: {missing}")
            try:
                await interaction.response.send_message(
                    f"❌ You are missing the required permissions: **{missing}**.",
                    ephemeral=True,
                )
            except discord.InteractionResponded:
                await interaction.followup.send(
                    f"❌ You are missing the required permissions: **{missing}**.",
                    ephemeral=True,
                )

async def setup(bot):
    await bot.add_cog(Giveaway(bot))
