import discord
from discord.ext import commands
from discord import app_commands
import asyncio
import random
import io
import os
import re
from datetime import datetime, timedelta, timezone
from config import Config
from utils.embed import build
from utils.theme import Theme
from utils.data import load, save
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageOps

VERIFY_FILE = "verification.json"
CAPTCHA_IMAGES_DIR = "captcha_images"

os.makedirs(CAPTCHA_IMAGES_DIR, exist_ok=True)

def _get_guild_data(guild_id: int) -> dict:
    data = load(VERIFY_FILE)
    return data.get(str(guild_id), {})

def _save_guild_data(guild_id: int, guild_data: dict):
    data = load(VERIFY_FILE)
    data[str(guild_id)] = guild_data
    save(VERIFY_FILE, data)

def _get_user_data(guild_id: int, user_id: int) -> dict:
    guild_data = _get_guild_data(guild_id)
    return guild_data.get("users", {}).get(str(user_id), {"verified": False, "verified_at": None})

def _save_user_data(guild_id: int, user_id: int, user_data: dict):
    guild_data = _get_guild_data(guild_id)
    if "users" not in guild_data:
        guild_data["users"] = {}
    guild_data["users"][str(user_id)] = user_data
    _save_guild_data(guild_id, guild_data)

class CaptchaGenerator:
    def __init__(self):
        self.font_path = None
        self._find_font()

    def _find_font(self):
        possible_fonts = [
            "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
            "/usr/share/fonts/truetype/arial/arialbd.ttf",
            "/System/Library/Fonts/Helvetica.ttc",
            "/Library/Fonts/Arial Bold.ttf",
            "C:/Windows/Fonts/arialbd.ttf",
        ]
        for font in possible_fonts:
            if os.path.exists(font):
                self.font_path = font
                break

    def generate_captcha(self, length: int = 6) -> tuple[str, io.BytesIO]:
        chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        text = ''.join(random.choices(chars, k=length))

        width, height = 280, 90
        bg_color = (245, 245, 245)
        image = Image.new('RGB', (width, height), bg_color)
        draw = ImageDraw.Draw(image)

        try:
            font = ImageFont.truetype(self.font_path, 36) if self.font_path else ImageFont.load_default()
        except Exception:
            font = ImageFont.load_default()

        for _ in range(5):
            draw.line([(random.randint(0, width), random.randint(0, height)) for _ in range(2)], fill=(200,200,200), width=2)
        for _ in range(200):
            draw.point((random.randint(0, width), random.randint(0, height)), fill=(180,180,180))

        x_offset = 20
        for i, char in enumerate(text):
            color = (random.randint(30, 150), random.randint(30, 150), random.randint(30, 150))
            angle = random.randint(-25, 25)
            size = 32 + random.randint(-6, 6)
            try:
                font = ImageFont.truetype(self.font_path, size) if self.font_path else ImageFont.load_default()
            except Exception:
                font = ImageFont.load_default()

            char_img = Image.new('RGBA', (40, 60), (0, 0, 0, 0))
            char_draw = ImageDraw.Draw(char_img)
            char_draw.text((5, 5), char, fill=color, font=font)
            char_img = char_img.rotate(angle, expand=1, fillcolor=(0, 0, 0, 0))

            y_pos = random.randint(10, 25)
            x_pos = x_offset + i * 35
            if x_pos + char_img.width > width:
                x_pos = width - char_img.width - 5
            image.paste(char_img, (x_pos, y_pos), char_img)

        image = image.filter(ImageFilter.SMOOTH)
        img_bytes = io.BytesIO()
        image.save(img_bytes, format='PNG', quality=85)
        img_bytes.seek(0)
        return text, img_bytes

class VerificationPanelView(discord.ui.View):
    def __init__(self, guild_id: int, role_id: int, log_channel_id: int = None):
        super().__init__(timeout=None)
        self.guild_id = guild_id
        self.role_id = role_id
        self.log_channel_id = log_channel_id

    @discord.ui.button(label="🔐 Start Verification", style=discord.ButtonStyle.primary, emoji="🔐", custom_id="verify_start")
    async def start_verification(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True)
        guild = interaction.guild
        if not guild:
            return await interaction.followup.send("❌ This command must be used in a server.", ephemeral=True)

        user_data = _get_user_data(guild.id, interaction.user.id)
        if user_data.get("verified", False):
            return await interaction.followup.send("✅ You are already verified!", ephemeral=True)

        guild_data = _get_guild_data(guild.id)
        active_channels = guild_data.get("active_channels", {})

        if str(interaction.user.id) in active_channels:
            channel = guild.get_channel(active_channels[str(interaction.user.id)])
            if channel:
                return await interaction.followup.send(f"📌 You already have a verification channel: {channel.mention}", ephemeral=True)
            else:
                del active_channels[str(interaction.user.id)]
                _save_guild_data(guild.id, guild_data)

        # Pass the bot/client to the creation method
        bot = interaction.client
        try:
            await self._create_verification_channel(guild, interaction.user, guild_data, interaction, bot)
        except Exception as e:
            await interaction.followup.send(f"❌ An error occurred: {str(e)[:100]}", ephemeral=True)

    async def _create_verification_channel(self, guild: discord.Guild, user: discord.Member, guild_data: dict, interaction: discord.Interaction, bot):
        try:
            category_name = guild_data.get("category", "Verification")
            category = discord.utils.get(guild.categories, name=category_name)
            if not category:
                category = await guild.create_category(category_name)

            overwrites = {
                guild.default_role: discord.PermissionOverwrite(read_messages=False, view_channel=False),
                user: discord.PermissionOverwrite(read_messages=True, send_messages=True, view_channel=True, attach_files=True),
                guild.me: discord.PermissionOverwrite(read_messages=True, send_messages=True, view_channel=True, manage_channels=True, manage_permissions=True),
            }

            channel_name = f"verify-{user.name[:10].lower()}"
            channel = await category.create_text_channel(
                channel_name,
                overwrites=overwrites,
                topic=f"Verification for {user.name} | 3 attempts remaining"
            )

            active_channels = guild_data.get("active_channels", {})
            active_channels[str(user.id)] = channel.id
            guild_data["active_channels"] = active_channels
            _save_guild_data(guild.id, guild_data)

            captcha = CaptchaGenerator()
            text, image_bytes = captcha.generate_captcha(length=6)

            if "captcha_sessions" not in guild_data:
                guild_data["captcha_sessions"] = {}
            guild_data["captcha_sessions"][str(user.id)] = {
                "text": text,
                "attempts": 0,
                "max_attempts": 3,
                "channel_id": channel.id,
                "created_at": datetime.now(timezone.utc).isoformat()
            }
            _save_guild_data(guild.id, guild_data)

            embed = build(title="🔐 Verification Required", description=(
                    f"Welcome {user.mention}!\n\n"
                    "You have **3 attempts** to complete the captcha verification.\n"
                    "Type the characters you see in the captcha image below.\n\n"
                    "**Rules:**\n"
                    "• Type the exact characters shown in the image\n"
                    "• Case-insensitive (uppercase/lowercase both work)\n"
                    "• You have 3 attempts\n"
                    "• You have 2 minutes to complete verification\n"
                    "• If you fail all attempts, you will be kicked from the server"
                ), color=Config.COLOR_INFO, bot=bot)
            await channel.send(embed=embed)

            file = discord.File(image_bytes, filename="captcha.png")
            await channel.send(content="**📷 Type the characters you see in the image below in this channel:**", file=file)

            view = CaptchaRegenerateView(guild.id, user.id)
            await channel.send(content="🔄 Need a new captcha? Click the button below.", view=view)

            embed_instruction = build(title="⌨️ Type Your Answer", description="Type the captcha text in **this channel**. You have **3 attempts** and **2 minutes**.", color=Config.COLOR_INFO, bot=bot)
            await channel.send(embed=embed_instruction)

            asyncio.create_task(self._start_timeout(guild.id, user.id, channel))

            await interaction.followup.send(f"✅ Verification channel created: {channel.mention}\nPlease complete the captcha. You have **2 minutes**.", ephemeral=True)

        except Exception as e:
            await interaction.followup.send(f"❌ An error occurred: {str(e)[:100]}", ephemeral=True)

    async def _start_timeout(self, guild_id: int, user_id: int, channel: discord.TextChannel):
        await asyncio.sleep(120)
        guild_data = _get_guild_data(guild_id)
        session = guild_data.get("captcha_sessions", {}).get(str(user_id), {})
        if not session:
            return
        if not channel or not channel.guild.get_channel(channel.id):
            return
        embed = build(title="⏰ Verification Timed Out", description="You took too long. The channel will be deleted.", color=Config.COLOR_ERR, bot=channel.guild.me if channel.guild else None)
        await channel.send(embed=embed)
        log_channel_id = guild_data.get("log_channel")
        if log_channel_id:
            log_channel = channel.guild.get_channel(log_channel_id)
            if log_channel:
                log_embed = build(title="⏰ Verification Timed Out", description=f"<@{user_id}> failed to complete verification within 2 minutes.", color=Config.COLOR_ERR, bot=channel.guild.me if channel.guild else None)
                await log_channel.send(embed=log_embed)
        await self._cleanup_verification(channel.guild, user_id, channel, 5)

    async def _verify_user(self, guild: discord.Guild, user: discord.Member, channel: discord.TextChannel, guild_data: dict, session: dict):
        role_id = guild_data.get("role_id")
        role = guild.get_role(role_id)
        if not role:
            await channel.send("❌ Verification role not found. Contact an admin.")
            await self._cleanup_verification(guild, user.id, channel)
            return
        try:
            await user.add_roles(role, reason="Verified via captcha")
        except Exception:
            await channel.send("❌ I don't have permission to give you that role.")
            await self._cleanup_verification(guild, user.id, channel)
            return
        _save_user_data(guild.id, user.id, {
            "verified": True,
            "verified_at": datetime.now(timezone.utc).isoformat(),
            "method": "captcha"
        })
        embed = build(title="✅ Verification Successful!", description=f"Congratulations {user.mention}! You are now verified!\n\nThis channel will be deleted in **10 seconds**.", color=Config.COLOR_OK, bot=guild.me)
        await channel.send(embed=embed)
        log_channel_id = guild_data.get("log_channel")
        if log_channel_id:
            log_channel = guild.get_channel(log_channel_id)
            if log_channel:
                log_embed = build(title="✅ User Verified", description=f"{user.mention} ({user}) verified via captcha.", color=Config.COLOR_OK, bot=guild.me)
                log_embed.add_field(name="Attempts", value=f"{session.get('attempts', 0) + 1} of 3", inline=True)
                log_embed.set_thumbnail(url=user.display_avatar.url)
                await log_channel.send(embed=log_embed)
        await self._cleanup_verification(guild, user.id, channel)

    async def _fail_verification(self, guild: discord.Guild, user: discord.Member, channel: discord.TextChannel, guild_data: dict):
        embed = build(title="❌ Verification Failed", description=f"{user.mention} has used all 3 attempts.\n\nYou will be kicked in **10 seconds**.", color=Config.COLOR_ERR, bot=guild.me)
        await channel.send(embed=embed)
        log_channel_id = guild_data.get("log_channel")
        if log_channel_id:
            log_channel = guild.get_channel(log_channel_id)
            if log_channel:
                log_embed = build(title="❌ Verification Failed", description=f"{user.mention} ({user}) failed verification after 3 attempts.", color=Config.COLOR_ERR, bot=guild.me)
                log_embed.set_thumbnail(url=user.display_avatar.url)
                await log_channel.send(embed=log_embed)
        try:
            await user.kick(reason="Failed verification (3 incorrect attempts)")
        except Exception as e:
            await channel.send(f"❌ Error kicking user: {str(e)[:100]}")
        await self._cleanup_verification(guild, user.id, channel, 10)

    async def _cleanup_verification(self, guild: discord.Guild, user_id: int, channel: discord.TextChannel, delay: int = 10):
        await asyncio.sleep(delay)
        guild_data = _get_guild_data(guild.id)
        active_channels = guild_data.get("active_channels", {})
        if str(user_id) in active_channels:
            del active_channels[str(user_id)]
            guild_data["active_channels"] = active_channels
        captcha_sessions = guild_data.get("captcha_sessions", {})
        if str(user_id) in captcha_sessions:
            del captcha_sessions[str(user_id)]
            guild_data["captcha_sessions"] = captcha_sessions
        _save_guild_data(guild.id, guild_data)
        try:
            await channel.delete(reason="Verification completed")
        except Exception:
            pass

class CaptchaRegenerateView(discord.ui.View):
    def __init__(self, guild_id: int, user_id: int):
        super().__init__(timeout=120)
        self.guild_id = guild_id
        self.user_id = user_id

    @discord.ui.button(label="🔄 New Captcha", style=discord.ButtonStyle.secondary, emoji="🔄")
    async def regenerate_captcha(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id:
            return await interaction.response.send_message("❌ This isn't for you.", ephemeral=True)
        await interaction.response.defer()
        guild_data = _get_guild_data(self.guild_id)
        session = guild_data.get("captcha_sessions", {}).get(str(self.user_id), {})
        if not session:
            return await interaction.followup.send("❌ No verification session found.", ephemeral=True)
        captcha = CaptchaGenerator()
        text, image_bytes = captcha.generate_captcha(length=6)
        session["text"] = text
        guild_data["captcha_sessions"][str(self.user_id)] = session
        _save_guild_data(self.guild_id, guild_data)
        file = discord.File(image_bytes, filename="captcha.png")
        await interaction.channel.send(content="📷 **New captcha generated. Type the characters you see:**", file=file)
        await interaction.followup.send("🔄 New captcha generated!", ephemeral=True)

class Verification(commands.Cog):

    def __init__(self, bot):
        self.bot = bot

    verify = app_commands.Group(name="verify", description="Verification commands")

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild:
            return
        guild_data = _get_guild_data(message.guild.id)
        active_channels = guild_data.get("active_channels", {})
        channel_id = str(message.channel.id)
        user_id_for_channel = None
        for uid, ch_id in active_channels.items():
            if ch_id == message.channel.id:
                user_id_for_channel = int(uid)
                break
        if user_id_for_channel is None:
            return
        if message.author.id != user_id_for_channel:
            try:
                await message.delete()
            except Exception:
                pass
            return
        captcha_sessions = guild_data.get("captcha_sessions", {})
        session = captcha_sessions.get(str(user_id_for_channel), {})
        if not session:
            return
        correct_text = session.get("text", "")
        attempts = session.get("attempts", 0)
        max_attempts = session.get("max_attempts", 3)
        user_answer = message.content.strip()
        try:
            await message.delete()
        except Exception:
            pass
        if user_answer.upper() == correct_text.upper():
            await self._verify_user(message.guild, message.author, message.channel, guild_data, session)
        else:
            attempts += 1
            session["attempts"] = attempts
            guild_data["captcha_sessions"][str(user_id_for_channel)] = session
            _save_guild_data(message.guild.id, guild_data)
            remaining = max_attempts - attempts
            if remaining <= 0:
                await self._fail_verification(message.guild, message.author, message.channel, guild_data)
            else:
                embed = build(title="❌ Incorrect Captcha", description=f"You have **{remaining}** attempt(s) remaining.\n\n**Hint:** The captcha is case-insensitive.\nType your answer in this channel.", color=Config.COLOR_ERR, bot=self.bot)
                await message.channel.send(embed=embed)

    async def _verify_user(self, guild: discord.Guild, user: discord.Member, channel: discord.TextChannel, guild_data: dict, session: dict):
        role_id = guild_data.get("role_id")
        role = guild.get_role(role_id)
        if not role:
            await channel.send("❌ Verification role not found. Contact an admin.")
            await self._cleanup_verification(guild, user.id, channel)
            return
        try:
            await user.add_roles(role, reason="Verified via captcha")
        except Exception:
            await channel.send("❌ I don't have permission to give you that role.")
            await self._cleanup_verification(guild, user.id, channel)
            return
        _save_user_data(guild.id, user.id, {
            "verified": True,
            "verified_at": datetime.now(timezone.utc).isoformat(),
            "method": "captcha"
        })
        embed = build(title="✅ Verification Successful!", description=f"Congratulations {user.mention}! You are now verified!\n\nThis channel will be deleted in **10 seconds**.", color=Config.COLOR_OK, bot=self.bot)
        await channel.send(embed=embed)
        log_channel_id = guild_data.get("log_channel")
        if log_channel_id:
            log_channel = guild.get_channel(log_channel_id)
            if log_channel:
                log_embed = build(title="✅ User Verified", description=f"{user.mention} ({user}) verified via captcha.", color=Config.COLOR_OK, bot=self.bot)
                log_embed.add_field(name="Attempts", value=f"{session.get('attempts', 0) + 1} of 3", inline=True)
                log_embed.set_thumbnail(url=user.display_avatar.url)
                await log_channel.send(embed=log_embed)
        await self._cleanup_verification(guild, user.id, channel)

    async def _fail_verification(self, guild: discord.Guild, user: discord.Member, channel: discord.TextChannel, guild_data: dict):
        embed = build(title="❌ Verification Failed", description=f"{user.mention} has used all 3 attempts.\n\nYou will be kicked in **10 seconds**.", color=Config.COLOR_ERR, bot=self.bot)
        await channel.send(embed=embed)
        log_channel_id = guild_data.get("log_channel")
        if log_channel_id:
            log_channel = guild.get_channel(log_channel_id)
            if log_channel:
                log_embed = build(title="❌ Verification Failed", description=f"{user.mention} ({user}) failed verification after 3 attempts.", color=Config.COLOR_ERR, bot=self.bot)
                log_embed.set_thumbnail(url=user.display_avatar.url)
                await log_channel.send(embed=log_embed)
        try:
            await user.kick(reason="Failed verification (3 incorrect attempts)")
        except Exception as e:
            await channel.send(f"❌ Error kicking user: {str(e)[:100]}")
        await self._cleanup_verification(guild, user.id, channel, 10)

    async def _cleanup_verification(self, guild: discord.Guild, user_id: int, channel: discord.TextChannel, delay: int = 10):
        await asyncio.sleep(delay)
        guild_data = _get_guild_data(guild.id)
        active_channels = guild_data.get("active_channels", {})
        if str(user_id) in active_channels:
            del active_channels[str(user_id)]
            guild_data["active_channels"] = active_channels
        captcha_sessions = guild_data.get("captcha_sessions", {})
        if str(user_id) in captcha_sessions:
            del captcha_sessions[str(user_id)]
            guild_data["captcha_sessions"] = captcha_sessions
        _save_guild_data(guild.id, guild_data)
        try:
            await channel.delete(reason="Verification completed")
        except Exception:
            pass

    # ========== SLASH COMMANDS ==========
    @verify.command(name="setup", description="Setup verification system")
    @app_commands.describe(role="Role to give to verified members", log_channel="Channel for verification logs (optional)", category="Category name for verification channels")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def verify_setup(self, interaction: discord.Interaction, role: discord.Role, log_channel: discord.TextChannel = None, category: str = "Verification"):
        await interaction.response.defer(ephemeral=True)
        guild_data = _get_guild_data(interaction.guild.id)
        guild_data["role_id"] = role.id
        guild_data["log_channel"] = log_channel.id if log_channel else None
        guild_data["category"] = category
        _save_guild_data(interaction.guild.id, guild_data)
        embed = build(title="✅ Verification Setup Complete", description=f"**Verified Role:** {role.mention}\n**Log Channel:** {log_channel.mention if log_channel else 'Not set'}\n**Category:** {category}\n\nUse `/verify panel` to post the verification panel.", color=Config.COLOR_OK, bot=self.bot)
        await interaction.followup.send(embed=embed, ephemeral=True)

    @verify.command(name="panel", description="Post the verification panel")
    @app_commands.describe(channel="Channel to post the panel in", title="Custom title for the panel", description="Custom description for the panel")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def verify_panel(self, interaction: discord.Interaction, channel: discord.TextChannel = None, title: str = "🔐 Verification Required", description: str = "Click the button below to start the verification process."):
        await interaction.response.defer(ephemeral=True)
        guild_data = _get_guild_data(interaction.guild.id)
        role_id = guild_data.get("role_id")
        log_channel_id = guild_data.get("log_channel")
        if not role_id:
            return await interaction.followup.send("❌ Verification system not set up. Use `/verify setup` first.", ephemeral=True)
        ch = channel or interaction.channel
        embed = build(title=title, description=description, color=Config.COLOR_INFO, bot=self.bot)
        embed.add_field(name="📋 How it works", value="1. Click the **Start Verification** button\n2. A private channel will be created for you\n3. Solve the captcha image by typing the characters\n4. You have **3 attempts** to get it right\n5. You have **2 minutes** to complete it\n6. After 3 failed attempts, you will be kicked\n7. After successful verification, you get the verified role", inline=False)
        embed.set_footer(text="Click the button below to start")
        view = VerificationPanelView(interaction.guild.id, role_id, log_channel_id)
        await ch.send(embed=embed, view=view)
        await interaction.followup.send(f"✅ Verification panel sent to {ch.mention}.", ephemeral=True)

    @verify.command(name="status", description="Check verification status")
    @app_commands.describe(member="Member to check (leave empty for yourself)")
    @app_commands.default_permissions(manage_messages=True)
    @app_commands.checks.has_permissions(manage_messages=True)
    async def verify_status(self, interaction: discord.Interaction, member: discord.Member = None):
        target = member or interaction.user
        user_data = _get_user_data(interaction.guild.id, target.id)
        embed = build(title=f"🔐 Verification Status", color=Config.COLOR_INFO, bot=self.bot)
        embed.set_thumbnail(url=target.display_avatar.url)
        embed.add_field(name="Member", value=target.mention, inline=True)
        embed.add_field(name="Status", value="✅ Verified" if user_data.get("verified", False) else "❌ Not Verified", inline=True)
        if user_data.get("verified_at"):
            verified_at = datetime.fromisoformat(user_data["verified_at"])
            embed.add_field(name="Verified At", value=discord.utils.format_dt(verified_at, "F"), inline=False)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @verify.command(name="user", description="Manually verify a user")
    @app_commands.describe(user="User to verify", method="Verification method (optional)")
    @app_commands.default_permissions(manage_messages=True)
    @app_commands.checks.has_permissions(manage_messages=True)
    async def verify_user(self, interaction: discord.Interaction, user: discord.Member, method: str = "manual"):
        await interaction.response.defer(ephemeral=True)
        guild_data = _get_guild_data(interaction.guild.id)
        role_id = guild_data.get("role_id")
        if not role_id:
            return await interaction.followup.send("❌ Verification system not set up.", ephemeral=True)
        user_data = _get_user_data(interaction.guild.id, user.id)
        if user_data.get("verified", False):
            return await interaction.followup.send(f"✅ {user.mention} is already verified!", ephemeral=True)
        role = interaction.guild.get_role(role_id)
        if not role:
            return await interaction.followup.send("❌ Verification role not found.", ephemeral=True)
        try:
            await user.add_roles(role, reason=f"Manually verified by {interaction.user}")
        except Exception:
            return await interaction.followup.send("❌ I don't have permission to give that role.", ephemeral=True)
        _save_user_data(interaction.guild.id, user.id, {"verified": True, "verified_at": datetime.now(timezone.utc).isoformat(), "method": method, "verified_by": interaction.user.id})
        await interaction.followup.send(f"✅ {user.mention} has been verified!", ephemeral=True)
        log_channel_id = guild_data.get("log_channel")
        if log_channel_id:
            log_channel = interaction.guild.get_channel(log_channel_id)
            if log_channel:
                embed = build(title="✅ User Verified (Manual)", description=f"{user.mention} ({user}) verified by {interaction.user.mention}", color=Config.COLOR_OK, bot=self.bot)
                embed.add_field(name="Method", value=method, inline=True)
                embed.set_thumbnail(url=user.display_avatar.url)
                await log_channel.send(embed=embed)

    @verify.command(name="unverify", description="Unverify a user")
    @app_commands.describe(user="User to unverify")
    @app_commands.default_permissions(manage_messages=True)
    @app_commands.checks.has_permissions(manage_messages=True)
    async def verify_unverify(self, interaction: discord.Interaction, user: discord.Member):
        await interaction.response.defer(ephemeral=True)
        guild_data = _get_guild_data(interaction.guild.id)
        role_id = guild_data.get("role_id")
        if not role_id:
            return await interaction.followup.send("❌ Verification system not set up.", ephemeral=True)
        role = interaction.guild.get_role(role_id)
        if not role:
            return await interaction.followup.send("❌ Verification role not found.", ephemeral=True)
        try:
            await user.remove_roles(role, reason=f"Unverified by {interaction.user}")
        except Exception:
            return await interaction.followup.send("❌ I don't have permission to remove that role.", ephemeral=True)
        _save_user_data(interaction.guild.id, user.id, {"verified": False, "verified_at": None, "method": None, "unverified_by": interaction.user.id, "unverified_at": datetime.now(timezone.utc).isoformat()})
        await interaction.followup.send(f"✅ {user.mention} has been unverified.", ephemeral=True)
        log_channel_id = guild_data.get("log_channel")
        if log_channel_id:
            log_channel = interaction.guild.get_channel(log_channel_id)
            if log_channel:
                embed = build(title="❌ User Unverified", description=f"{user.mention} ({user}) unverified by {interaction.user.mention}", color=Config.COLOR_ERR, bot=self.bot)
                embed.set_thumbnail(url=user.display_avatar.url)
                await log_channel.send(embed=embed)

    @verify.command(name="reset", description="Reset all verification data for this server")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def verify_reset(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        guild_data = _get_guild_data(interaction.guild.id)
        if not guild_data:
            return await interaction.followup.send("ℹ️ No verification data to reset.", ephemeral=True)
        user_count = len(guild_data.get("users", {}))
        active_channels = len(guild_data.get("active_channels", {}))
        guild_data["users"] = {}
        guild_data["active_channels"] = {}
        guild_data["captcha_sessions"] = {}
        _save_guild_data(interaction.guild.id, guild_data)
        embed = build(title="✅ Verification Data Reset", description=f"Reset data for {user_count} users.\nCleared {active_channels} active channels.\nSettings were preserved.", color=Config.COLOR_OK, bot=self.bot)
        await interaction.followup.send(embed=embed, ephemeral=True)

    @verify.command(name="cleanup", description="Clean up stale verification channels")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def verify_cleanup(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        guild_data = _get_guild_data(interaction.guild.id)
        active_channels = guild_data.get("active_channels", {})
        if not active_channels:
            return await interaction.followup.send("ℹ️ No active verification channels to clean up.", ephemeral=True)
        cleaned = 0
        for user_id, channel_id in list(active_channels.items()):
            channel = interaction.guild.get_channel(channel_id)
            if not channel:
                del active_channels[user_id]
                cleaned += 1
            else:
                try:
                    if channel.created_at and (datetime.now(timezone.utc) - channel.created_at) > timedelta(hours=1):
                        await channel.delete(reason="Stale verification channel")
                        del active_channels[user_id]
                        cleaned += 1
                except Exception:
                    pass
        if cleaned > 0:
            guild_data["active_channels"] = active_channels
            _save_guild_data(interaction.guild.id, guild_data)
            await interaction.followup.send(f"✅ Cleaned up {cleaned} stale channel(s).", ephemeral=True)
        else:
            await interaction.followup.send("ℹ️ All verification channels are valid.", ephemeral=True)

    # ========== PREFIX COMMANDS ==========
    @commands.command(name="verify")
    @commands.has_permissions(administrator=True)
    async def p_verify_setup(self, ctx, role: discord.Role, log_channel: discord.TextChannel = None, *, category: str = "Verification"):
        guild_data = _get_guild_data(ctx.guild.id)
        guild_data["role_id"] = role.id
        guild_data["log_channel"] = log_channel.id if log_channel else None
        guild_data["category"] = category
        _save_guild_data(ctx.guild.id, guild_data)
        embed = build(title="✅ Verification Setup Complete", description=f"**Verified Role:** {role.mention}\n**Log Channel:** {log_channel.mention if log_channel else 'Not set'}\n**Category:** {category}\n\nUse `//verifypanel` to post the verification panel.", color=Config.COLOR_OK, bot=self.bot)
        await ctx.reply(embed=embed)

    @commands.command(name="verifypanel")
    @commands.has_permissions(administrator=True)
    async def p_verify_panel(self, ctx, channel: discord.TextChannel = None, *, title: str = "🔐 Verification Required"):
        guild_data = _get_guild_data(ctx.guild.id)
        role_id = guild_data.get("role_id")
        log_channel_id = guild_data.get("log_channel")
        if not role_id:
            return await ctx.reply("❌ Verification system not set up. Use `//verify` first.")
        ch = channel or ctx.channel
        embed = build(title=title, description="Click the button below to start the verification process.", color=Config.COLOR_INFO, bot=self.bot)
        embed.add_field(name="📋 How it works", value="1. Click the **Start Verification** button\n2. A private channel will be created for you\n3. Solve the captcha image by typing the characters\n4. You have **3 attempts** to get it right\n5. You have **2 minutes** to complete it\n6. After 3 failed attempts, you will be kicked\n7. After successful verification, you get the verified role", inline=False)
        embed.set_footer(text="Click the button below to start")
        view = VerificationPanelView(ctx.guild.id, role_id, log_channel_id)
        await ch.send(embed=embed, view=view)
        await ctx.reply(f"✅ Verification panel sent to {ch.mention}.")

    @commands.command(name="verifystatus")
    @commands.has_permissions(manage_messages=True)
    async def p_verify_status(self, ctx, member: discord.Member = None):
        target = member or ctx.author
        user_data = _get_user_data(ctx.guild.id, target.id)
        embed = build(title=f"🔐 Verification Status", color=Config.COLOR_INFO, bot=self.bot)
        embed.set_thumbnail(url=target.display_avatar.url)
        embed.add_field(name="Member", value=target.mention, inline=True)
        embed.add_field(name="Status", value="✅ Verified" if user_data.get("verified", False) else "❌ Not Verified", inline=True)
        if user_data.get("verified_at"):
            verified_at = datetime.fromisoformat(user_data["verified_at"])
            embed.add_field(name="Verified At", value=discord.utils.format_dt(verified_at, "F"), inline=False)
        await ctx.reply(embed=embed)

    @commands.command(name="verifyuser")
    @commands.has_permissions(manage_messages=True)
    async def p_verify_user(self, ctx, user: discord.Member, *, method: str = "manual"):
        guild_data = _get_guild_data(ctx.guild.id)
        role_id = guild_data.get("role_id")
        if not role_id:
            return await ctx.reply("❌ Verification system not set up.")
        user_data = _get_user_data(ctx.guild.id, user.id)
        if user_data.get("verified", False):
            return await ctx.reply(f"✅ {user.mention} is already verified!")
        role = ctx.guild.get_role(role_id)
        if not role:
            return await ctx.reply("❌ Verification role not found.")
        try:
            await user.add_roles(role, reason=f"Manually verified by {ctx.author}")
        except Exception:
            return await ctx.reply("❌ I don't have permission to give that role.")
        _save_user_data(ctx.guild.id, user.id, {"verified": True, "verified_at": datetime.now(timezone.utc).isoformat(), "method": method, "verified_by": ctx.author.id})
        await ctx.reply(f"✅ {user.mention} has been verified!")
        log_channel_id = guild_data.get("log_channel")
        if log_channel_id:
            log_channel = ctx.guild.get_channel(log_channel_id)
            if log_channel:
                embed = build(title="✅ User Verified (Manual)", description=f"{user.mention} ({user}) verified by {ctx.author.mention}", color=Config.COLOR_OK, bot=self.bot)
                embed.add_field(name="Method", value=method, inline=True)
                embed.set_thumbnail(url=user.display_avatar.url)
                await log_channel.send(embed=embed)

    @commands.command(name="unverify")
    @commands.has_permissions(manage_messages=True)
    async def p_unverify(self, ctx, user: discord.Member):
        guild_data = _get_guild_data(ctx.guild.id)
        role_id = guild_data.get("role_id")
        if not role_id:
            return await ctx.reply("❌ Verification system not set up.")
        role = ctx.guild.get_role(role_id)
        if not role:
            return await ctx.reply("❌ Verification role not found.")
        try:
            await user.remove_roles(role, reason=f"Unverified by {ctx.author}")
        except Exception:
            return await ctx.reply("❌ I don't have permission to remove that role.")
        _save_user_data(ctx.guild.id, user.id, {"verified": False, "verified_at": None, "method": None, "unverified_by": ctx.author.id, "unverified_at": datetime.now(timezone.utc).isoformat()})
        await ctx.reply(f"✅ {user.mention} has been unverified.")
        log_channel_id = guild_data.get("log_channel")
        if log_channel_id:
            log_channel = ctx.guild.get_channel(log_channel_id)
            if log_channel:
                embed = build(title="❌ User Unverified", description=f"{user.mention} ({user}) unverified by {ctx.author.mention}", color=Config.COLOR_ERR, bot=self.bot)
                embed.set_thumbnail(url=user.display_avatar.url)
                await log_channel.send(embed=embed)

    @commands.command(name="verifyreset")
    @commands.has_permissions(administrator=True)
    async def p_verify_reset(self, ctx):
        guild_data = _get_guild_data(ctx.guild.id)
        if not guild_data:
            return await ctx.reply("ℹ️ No verification data to reset.")
        user_count = len(guild_data.get("users", {}))
        active_channels = len(guild_data.get("active_channels", {}))
        guild_data["users"] = {}
        guild_data["active_channels"] = {}
        guild_data["captcha_sessions"] = {}
        _save_guild_data(ctx.guild.id, guild_data)
        embed = build(title="✅ Verification Data Reset", description=f"Reset data for {user_count} users.\nCleared {active_channels} active channels.\nSettings were preserved.", color=Config.COLOR_OK, bot=self.bot)
        await ctx.reply(embed=embed)

    @commands.command(name="verifycleanup")
    @commands.has_permissions(administrator=True)
    async def p_verify_cleanup(self, ctx):
        guild_data = _get_guild_data(ctx.guild.id)
        active_channels = guild_data.get("active_channels", {})
        if not active_channels:
            return await ctx.reply("ℹ️ No active verification channels to clean up.")
        cleaned = 0
        for user_id, channel_id in list(active_channels.items()):
            channel = ctx.guild.get_channel(channel_id)
            if not channel:
                del active_channels[user_id]
                cleaned += 1
            else:
                try:
                    if channel.created_at and (datetime.now(timezone.utc) - channel.created_at) > timedelta(hours=1):
                        await channel.delete(reason="Stale verification channel")
                        del active_channels[user_id]
                        cleaned += 1
                except Exception:
                    pass
        if cleaned > 0:
            guild_data["active_channels"] = active_channels
            _save_guild_data(ctx.guild.id, guild_data)
            await ctx.reply(f"✅ Cleaned up {cleaned} stale channel(s).")
        else:
            await ctx.reply("ℹ️ All verification channels are valid.")

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            missing = ", ".join(p.replace("_", " ").title() for p in error.missing_permissions)
            print(f"[Verification] {interaction.user} ({interaction.user.id}) missing permissions: {missing}")
            try:
                await interaction.response.send_message(f"❌ You are missing: **{missing}**.", ephemeral=True)
            except discord.InteractionResponded:
                await interaction.followup.send(f"❌ You are missing: **{missing}**.", ephemeral=True)
        else:
            print(f"[Verification] Error: {error}")
            try:
                await interaction.response.send_message(f"❌ Error: {str(error)[:100]}", ephemeral=True)
            except discord.InteractionResponded:
                await interaction.followup.send(f"❌ Error: {str(error)[:100]}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Verification(bot))