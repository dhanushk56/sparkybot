import discord
from discord.ext import commands
from discord import app_commands
import asyncio
import time
import re
from datetime import datetime, timedelta, timezone
from config import Config
from utils.data import load, save
from utils.theme import Theme
from utils.embed import build

WARNS_FILE = "warnings.json"
JAIL_FILE = "jail.json"

def mod_embed(title: str, desc: str, color=Config.COLOR_MOD) -> discord.Embed:
    return build(title=title, description=desc, color=color)

async def log_action(guild: discord.Guild, embed: discord.Embed):
    data = load("guild_settings.json")
    guild_data = data.get(str(guild.id), {})
    ch_id = guild_data.get("mod_log_channel")
    if ch_id:
        ch = guild.get_channel(ch_id)
        if ch:
            try:
                await ch.send(embed=embed)
            except Exception:
                pass

def get_warns(guild_id: int, user_id: int) -> list:
    return load(WARNS_FILE).get(str(guild_id), {}).get(str(user_id), [])

def add_warn(guild_id: int, user_id: int, reason: str, mod: str):
    data = load(WARNS_FILE)
    data.setdefault(str(guild_id), {}).setdefault(str(user_id), [])
    data[str(guild_id)][str(user_id)].append({
        "reason": reason, "mod": mod,
        "time": datetime.now(timezone.utc).isoformat()
    })
    save(WARNS_FILE, data)

def clear_warns(guild_id: int, user_id: int):
    data = load(WARNS_FILE)
    data.get(str(guild_id), {}).pop(str(user_id), None)
    save(WARNS_FILE, data)

def parse_duration(duration: str) -> int:
    units = {"w": 604800, "d": 86400, "h": 3600, "m": 60, "s": 1}
    if duration.isdigit():
        return int(duration)
    for unit, seconds in units.items():
        if duration.endswith(unit) and duration[:-1].isdigit():
            return int(duration[:-1]) * seconds
    raise ValueError("Invalid duration")

def format_duration(seconds: int) -> str:
    parts = []
    for unit, label in [(86400, "d"), (3600, "h"), (60, "m")]:
        if seconds >= unit:
            parts.append(f"{seconds//unit}{label}")
            seconds %= unit
    if seconds or not parts:
        parts.append(f"{seconds}s")
    return " ".join(parts)

def _jail_data(guild_id: int) -> dict:
    return load(JAIL_FILE).get(str(guild_id), {})

def _save_jail(guild_id: int, data: dict):
    full = load(JAIL_FILE)
    full[str(guild_id)] = data
    save(JAIL_FILE, full)

def _get_jailed(guild_id: int) -> dict:
    return _jail_data(guild_id).get("jailed", {})

def _set_jailed(guild_id: int, user_id: int, roles: list, auto_at: float = None):
    d = _jail_data(guild_id)
    entry = {"roles": roles}
    if auto_at:
        entry["auto_unjail_at"] = auto_at
    d.setdefault("jailed", {})[str(user_id)] = entry
    _save_jail(guild_id, d)

def _remove_jailed(guild_id: int, user_id: int):
    d = _jail_data(guild_id)
    d.setdefault("jailed", {}).pop(str(user_id), None)
    _save_jail(guild_id, d)

class Moderation(commands.Cog):

    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self._auto_unjail())

    async def _auto_unjail(self):
        await self.bot.wait_until_ready()
        while not self.bot.is_closed():
            await asyncio.sleep(30)
            data = load(JAIL_FILE)
            now = time.time()
            for gid_str, gd in data.items():
                guild = self.bot.get_guild(int(gid_str))
                if not guild:
                    continue
                jailed = gd.get("jailed", {})
                for uid_str, entry in list(jailed.items()):
                    if isinstance(entry, list):
                        entry = {"roles": entry}
                        jailed[uid_str] = entry
                    if entry.get("auto_unjail_at") and now >= entry["auto_unjail_at"]:
                        member = guild.get_member(int(uid_str))
                        if member:
                            await self._unjail_member(guild, member, "Auto unjail")
                        _remove_jailed(guild.id, int(uid_str))

    async def _unjail_member(self, guild: discord.Guild, member: discord.Member, reason: str):
        jailed = _get_jailed(guild.id)
        entry = jailed.get(str(member.id))
        if not entry:
            return
        saved = entry.get("roles", []) if isinstance(entry, dict) else entry
        config = _jail_data(guild.id).get("config", {})
        jail_role_id = config.get("role")
        jail_role = guild.get_role(jail_role_id) if jail_role_id else None

        if jail_role and jail_role in member.roles:
            try:
                await member.remove_roles(jail_role, reason=reason)
            except Exception:
                pass

        restored = 0
        for rid in saved:
            role = guild.get_role(rid)
            if role and role.is_assignable():
                try:
                    await member.add_roles(role, reason=reason)
                    restored += 1
                except Exception:
                    pass

        _remove_jailed(guild.id, member.id)
        e = mod_embed("🔓 Unjailed", f"{member.mention} unjailed.\nReason: {reason}\nRoles restored: {restored}", Config.COLOR_OK)
        await log_action(guild, e)

    mod = app_commands.Group(name="mod", description="Moderation commands")

    @mod.command(name="kick", description="Kick a member")
    @app_commands.describe(member="Member to kick", reason="Reason")
    @app_commands.default_permissions(kick_members=True)
    @app_commands.checks.has_permissions(kick_members=True)
    async def mod_kick(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason"):
        try:
            if member.top_role >= interaction.user.top_role and interaction.user != interaction.guild.owner:
                return await interaction.response.send_message("❌ Cannot kick someone with equal/higher role.", ephemeral=True)
            try:
                await member.send(embed=mod_embed("👢 Kicked", f"Kicked from {interaction.guild.name}\nReason: {reason}", Config.COLOR_WARN))
            except Exception:
                pass
            await member.kick(reason=f"{interaction.user} • {reason}")
            e = mod_embed("👢 Kicked", f"{member.mention} kicked by {interaction.user.mention}\nReason: {reason}")
            await interaction.response.send_message(embed=e)
            await log_action(interaction.guild, e)
        except discord.Forbidden:
            await interaction.response.send_message("❌ I don't have permission to kick that member. Please check my role position and permissions.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)[:100]}", ephemeral=True)

    @mod.command(name="ban", description="Ban a member")
    @app_commands.describe(member="Member to ban", days="Days of messages to delete (0-7)", reason="Reason")
    @app_commands.default_permissions(ban_members=True)
    @app_commands.checks.has_permissions(ban_members=True)
    async def mod_ban(self, interaction: discord.Interaction, member: discord.Member, days: int = 0, reason: str = "No reason"):
        try:
            if member.top_role >= interaction.user.top_role and interaction.user != interaction.guild.owner:
                return await interaction.response.send_message("❌ Cannot ban someone with equal/higher role.", ephemeral=True)
            days = max(0, min(7, days))
            try:
                await member.send(embed=mod_embed("🔨 Banned", f"Banned from {interaction.guild.name}\nReason: {reason}", Config.COLOR_ERR))
            except Exception:
                pass
            await member.ban(reason=f"{interaction.user} • {reason}", delete_message_days=days)
            e = mod_embed("🔨 Banned", f"{member.mention} banned by {interaction.user.mention}\nReason: {reason}")
            await interaction.response.send_message(embed=e)
            await log_action(interaction.guild, e)
        except discord.Forbidden:
            await interaction.response.send_message("❌ I don't have permission to ban that member. Please check my role position and permissions.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)[:100]}", ephemeral=True)

    @mod.command(name="unban", description="Unban a user by ID")
    @app_commands.describe(user_id="User ID", reason="Reason")
    @app_commands.default_permissions(ban_members=True)
    @app_commands.checks.has_permissions(ban_members=True)
    async def mod_unban(self, interaction: discord.Interaction, user_id: str, reason: str = "No reason"):
        try:
            user = await self.bot.fetch_user(int(user_id))
            await interaction.guild.unban(user, reason=f"{interaction.user} • {reason}")
            e = mod_embed("✅ Unbanned", f"{user} unbanned by {interaction.user.mention}", Config.COLOR_OK)
            await interaction.response.send_message(embed=e)
            await log_action(interaction.guild, e)
        except discord.Forbidden:
            await interaction.response.send_message("❌ I don't have permission to unban users.", ephemeral=True)
        except discord.NotFound:
            await interaction.response.send_message("❌ User not found or not banned.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)[:100]}", ephemeral=True)

    @mod.command(name="mute", description="Timeout a member")
    @app_commands.describe(member="Member to mute", duration="Duration (e.g. 10m, 1h, 1d)", reason="Reason")
    @app_commands.default_permissions(moderate_members=True)
    @app_commands.checks.has_permissions(moderate_members=True)
    async def mod_mute(self, interaction: discord.Interaction, member: discord.Member, duration: str = "10m", reason: str = "No reason"):
        try:
            try:
                seconds = parse_duration(duration)
                if seconds < 60:
                    return await interaction.response.send_message("❌ Minimum 1 minute.", ephemeral=True)
                if seconds > 2419200:
                    return await interaction.response.send_message("❌ Maximum 28 days.", ephemeral=True)
            except ValueError:
                return await interaction.response.send_message("❌ Invalid duration. Use: 10m, 1h, 1d", ephemeral=True)

            until = discord.utils.utcnow() + timedelta(seconds=seconds)
            await member.timeout(until, reason=f"{interaction.user} • {reason}")
            e = mod_embed("🔇 Muted", f"{member.mention} muted for {format_duration(seconds)}\nReason: {reason}", Config.COLOR_WARN)
            await interaction.response.send_message(embed=e)
            await log_action(interaction.guild, e)
        except discord.Forbidden:
            await interaction.response.send_message("❌ I don't have permission to mute that member. Please check my role position and permissions.", ephemeral=True)
        except discord.HTTPException as e:
            if "400" in str(e) or "timeout" in str(e).lower():
                await interaction.response.send_message("❌ Failed to mute that member. They may already be timed out or I don't have the correct permissions.", ephemeral=True)
            else:
                await interaction.response.send_message(f"❌ An error occurred: {str(e)[:100]}", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)[:100]}", ephemeral=True)

    @mod.command(name="unmute", description="Remove timeout")
    @app_commands.describe(member="Member to unmute", reason="Reason")
    @app_commands.default_permissions(moderate_members=True)
    @app_commands.checks.has_permissions(moderate_members=True)
    async def mod_unmute(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason"):
        try:
            await member.timeout(None, reason=f"{interaction.user} • {reason}")
            e = mod_embed("🔊 Unmuted", f"{member.mention} unmuted by {interaction.user.mention}", Config.COLOR_OK)
            await interaction.response.send_message(embed=e)
            await log_action(interaction.guild, e)
        except discord.Forbidden:
            await interaction.response.send_message("❌ I don't have permission to unmute that member.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)[:100]}", ephemeral=True)

    @mod.command(name="warn", description="Warn a member")
    @app_commands.describe(member="Member to warn", reason="Reason")
    @app_commands.default_permissions(manage_messages=True)
    @app_commands.checks.has_permissions(manage_messages=True)
    async def mod_warn(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason"):
        try:
            add_warn(interaction.guild.id, member.id, reason, str(interaction.user))
            warns = get_warns(interaction.guild.id, member.id)
            e = mod_embed("⚠️ Warned", f"{member.mention} warned\nReason: {reason}\nTotal: {len(warns)}", Config.COLOR_WARN)
            await interaction.response.send_message(embed=e)
            await log_action(interaction.guild, e)
        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)[:100]}", ephemeral=True)

    @mod.command(name="warnings", description="View warnings")
    @app_commands.describe(member="Member to check")
    @app_commands.default_permissions(manage_messages=True)
    @app_commands.checks.has_permissions(manage_messages=True)
    async def mod_warnings(self, interaction: discord.Interaction, member: discord.Member):
        try:
            warns = get_warns(interaction.guild.id, member.id)
            if not warns:
                return await interaction.response.send_message(f"✅ {member.mention} has no warnings.", ephemeral=True)
            desc = "\n".join([f"`{i+1}.` {w['reason']} • by {w['mod']} on {w['time'][:10]}" for i, w in enumerate(warns)])
            e = mod_embed(f"⚠️ Warnings for {member}", desc, Config.COLOR_WARN)
            await interaction.response.send_message(embed=e, ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)[:100]}", ephemeral=True)

    @mod.command(name="clearwarns", description="Clear all warnings")
    @app_commands.describe(member="Member to clear")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def mod_clearwarns(self, interaction: discord.Interaction, member: discord.Member):
        try:
            clear_warns(interaction.guild.id, member.id)
            await interaction.response.send_message(f"✅ Cleared warnings for {member.mention}.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)[:100]}", ephemeral=True)

    @mod.command(name="purge", description="Delete messages")
    @app_commands.describe(amount="Number (1-500)", member="Only delete from this member")
    @app_commands.default_permissions(manage_messages=True)
    @app_commands.checks.has_permissions(manage_messages=True)
    async def mod_purge(self, interaction: discord.Interaction, amount: int, member: discord.Member = None):
        if not 1 <= amount <= 500:
            return await interaction.response.send_message("❌ Amount 1-500.", ephemeral=True)

        await interaction.response.defer(ephemeral=True)

        try:
            def check(m):
                return True if not member else m.author == member

            deleted = await interaction.channel.purge(limit=amount, check=check, bulk=True)
            msg = f"🗑️ Deleted {len(deleted)} messages" + (f" from {member.mention}" if member else "")
            await interaction.followup.send(msg, ephemeral=True)
        except discord.Forbidden:
            await interaction.followup.send("❌ I don't have permission to delete messages in this channel.", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"❌ An error occurred: {str(e)[:100]}", ephemeral=True)

    # ---- FIX: Changed permission from manage_channels to manage_roles ----
    @mod.command(name="lock", description="Lock channel")
    @app_commands.describe(channel="Channel (defaults to current)")
    @app_commands.default_permissions(manage_roles=True)
    @app_commands.checks.has_permissions(manage_roles=True)
    async def mod_lock(self, interaction: discord.Interaction, channel: discord.TextChannel = None):
        try:
            ch = channel or interaction.channel
            await ch.set_permissions(interaction.guild.default_role, send_messages=False)
            await interaction.response.send_message(f"🔒 {ch.mention} locked.")
        except discord.Forbidden:
            await interaction.response.send_message("❌ I don't have permission to lock this channel.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)[:100]}", ephemeral=True)

    # ---- FIX: Changed permission from manage_channels to manage_roles ----
    @mod.command(name="unlock", description="Unlock channel")
    @app_commands.describe(channel="Channel (defaults to current)")
    @app_commands.default_permissions(manage_roles=True)
    @app_commands.checks.has_permissions(manage_roles=True)
    async def mod_unlock(self, interaction: discord.Interaction, channel: discord.TextChannel = None):
        try:
            ch = channel or interaction.channel
            await ch.set_permissions(interaction.guild.default_role, send_messages=None)
            await interaction.response.send_message(f"🔓 {ch.mention} unlocked.")
        except discord.Forbidden:
            await interaction.response.send_message("❌ I don't have permission to unlock this channel.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)[:100]}", ephemeral=True)

    @mod.command(name="slowmode", description="Set slowmode (0 to disable)")
    @app_commands.describe(seconds="Seconds (0-21600)")
    @app_commands.default_permissions(manage_channels=True)
    @app_commands.checks.has_permissions(manage_channels=True)
    async def mod_slowmode(self, interaction: discord.Interaction, seconds: int = 0):
        if not 0 <= seconds <= 21600:
            return await interaction.response.send_message("❌ 0-21600 seconds.", ephemeral=True)
        try:
            await interaction.channel.edit(slowmode_delay=seconds)
            await interaction.response.send_message(f"⏱️ Slowmode: {seconds}s" if seconds else "⏱️ Slowmode disabled.")
        except discord.Forbidden:
            await interaction.response.send_message("❌ I don't have permission to edit this channel.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)[:100]}", ephemeral=True)

    @mod.command(name="nick", description="Change nickname")
    @app_commands.describe(member="Member", nickname="New nickname (empty to reset)")
    @app_commands.default_permissions(manage_nicknames=True)
    @app_commands.checks.has_permissions(manage_nicknames=True)
    async def mod_nick(self, interaction: discord.Interaction, member: discord.Member, nickname: str = None):
        try:
            await member.edit(nick=nickname)
            await interaction.response.send_message(f"✏️ Nickname updated for {member.mention}.")
        except discord.Forbidden:
            await interaction.response.send_message("❌ I don't have permission to change that member's nickname.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)[:100]}", ephemeral=True)

    @mod.command(name="role", description="Add/remove role")
    @app_commands.describe(member="Member", role="Role")
    @app_commands.default_permissions(manage_roles=True)
    @app_commands.checks.has_permissions(manage_roles=True)
    async def mod_role(self, interaction: discord.Interaction, member: discord.Member, role: discord.Role):
        try:
            if role in member.roles:
                await member.remove_roles(role)
                await interaction.response.send_message(f"➖ Removed {role.mention} from {member.mention}.")
            else:
                await member.add_roles(role)
                await interaction.response.send_message(f"➕ Added {role.mention} to {member.mention}.")
        except discord.Forbidden:
            await interaction.response.send_message("❌ I don't have permission to manage that role.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)[:100]}", ephemeral=True)

    @mod.command(name="setlog", description="Set mod log channel")
    @app_commands.describe(channel="Channel")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def mod_setlog(self, interaction: discord.Interaction, channel: discord.TextChannel):
        try:
            data = load("guild_settings.json")
            data.setdefault(str(interaction.guild.id), {})["mod_log_channel"] = channel.id
            save("guild_settings.json", data)
            await interaction.response.send_message(f"📝 Logs → {channel.mention}.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)[:100]}", ephemeral=True)

    @mod.command(name="jail", description="Jail a member")
    @app_commands.describe(member="Member", reason="Reason", duration="Duration (e.g. 1h, 2d)")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def mod_jail(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason", duration: str = None):
        try:
            config = _jail_data(interaction.guild.id).get("config", {})
            jail_role_id = config.get("role")
            jail_role = interaction.guild.get_role(jail_role_id) if jail_role_id else None

            if not jail_role:
                return await interaction.response.send_message("❌ Jail role not set. Use `/mod setjailrole`", ephemeral=True)

            if str(member.id) in _get_jailed(interaction.guild.id):
                return await interaction.response.send_message(f"❌ {member.mention} is already jailed.", ephemeral=True)

            await interaction.response.defer(ephemeral=True)

            seconds = None
            if duration:
                try:
                    seconds = parse_duration(duration)
                except ValueError:
                    return await interaction.followup.send("❌ Invalid duration. Use: 10m, 1h, 1d", ephemeral=True)

            roles = [r.id for r in member.roles if r != interaction.guild.default_role and r != jail_role]
            _set_jailed(interaction.guild.id, member.id, roles, time.time() + seconds if seconds else None)

            await member.remove_roles(*[r for r in member.roles if r != interaction.guild.default_role], reason=f"Jailed: {reason}")
            await member.add_roles(jail_role, reason=f"Jailed: {reason}")

            dur_text = f" for {format_duration(seconds)}" if seconds else " (permanent)"
            e = mod_embed("🔒 Jailed", f"{member.mention} jailed{dur_text}\nReason: {reason}", Config.COLOR_ERR)
            await interaction.followup.send(embed=e)
            await log_action(interaction.guild, e)
        except discord.Forbidden:
            await interaction.followup.send("❌ I don't have permission to jail that member. Please check my role position and permissions.", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"❌ An error occurred: {str(e)[:100]}", ephemeral=True)

    @mod.command(name="unjail", description="Unjail a member")
    @app_commands.describe(member="Member", reason="Reason")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def mod_unjail(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason"):
        try:
            await interaction.response.defer(ephemeral=True)
            await self._unjail_member(interaction.guild, member, f"Unjailed by {interaction.user} • {reason}")
            await interaction.followup.send(f"🔓 {member.mention} unjailed.", ephemeral=True)
        except discord.Forbidden:
            await interaction.followup.send("❌ I don't have permission to unjail that member.", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"❌ An error occurred: {str(e)[:100]}", ephemeral=True)

    @mod.command(name="jaillist", description="List jailed members")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def mod_jaillist(self, interaction: discord.Interaction):
        try:
            jailed = _get_jailed(interaction.guild.id)
            if not jailed:
                return await interaction.response.send_message("✅ No jailed members.", ephemeral=True)
            lines = []
            for uid, entry in jailed.items():
                member = interaction.guild.get_member(int(uid))
                name = member.mention if member else f"`{uid}`"
                if isinstance(entry, dict):
                    auto = entry.get("auto_unjail_at")
                    if auto:
                        remaining = max(0, int(auto - time.time()))
                        lines.append(f"• {name} • {format_duration(remaining)} left")
                    else:
                        lines.append(f"• {name} • permanent")
                else:
                    lines.append(f"• {name}")
            e = mod_embed("🔒 Jailed Members", "\n".join(lines), Config.COLOR_WARN)
            await interaction.response.send_message(embed=e, ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)[:100]}", ephemeral=True)

    @mod.command(name="setjailrole", description="Set the jail role")
    @app_commands.describe(role="Role")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def mod_setjailrole(self, interaction: discord.Interaction, role: discord.Role):
        try:
            d = _jail_data(interaction.guild.id)
            d.setdefault("config", {})["role"] = role.id
            _save_jail(interaction.guild.id, d)
            await interaction.response.send_message(f"✅ Jail role: {role.mention}", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ An error occurred: {str(e)[:100]}", ephemeral=True)

    # ---------- Prefix command versions ----------
    @commands.command(name="kick")
    @commands.has_permissions(kick_members=True)
    @commands.bot_has_permissions(kick_members=True)
    async def p_kick(self, ctx, member: discord.Member, *, reason: str = "No reason"):
        try:
            if member.top_role >= ctx.author.top_role and ctx.author != ctx.guild.owner:
                return await ctx.reply("❌ Cannot kick someone with equal/higher role.")
            await member.kick(reason=f"{ctx.author} • {reason}")
            await ctx.reply(f"👢 {member} kicked.")
        except discord.Forbidden:
            await ctx.reply("❌ I don't have permission to kick that member.")
        except Exception as e:
            await ctx.reply(f"❌ An error occurred: {str(e)[:100]}")

    @commands.command(name="ban")
    @commands.has_permissions(ban_members=True)
    @commands.bot_has_permissions(ban_members=True)
    async def p_ban(self, ctx, member: discord.Member, days: int = 0, *, reason: str = "No reason"):
        try:
            if member.top_role >= ctx.author.top_role and ctx.author != ctx.guild.owner:
                return await ctx.reply("❌ Cannot ban someone with equal/higher role.")
            await member.ban(reason=f"{ctx.author} • {reason}", delete_message_days=max(0, min(7, days)))
            await ctx.reply(f"🔨 {member} banned.")
        except discord.Forbidden:
            await ctx.reply("❌ I don't have permission to ban that member.")
        except Exception as e:
            await ctx.reply(f"❌ An error occurred: {str(e)[:100]}")

    @commands.command(name="unban")
    @commands.has_permissions(ban_members=True)
    @commands.bot_has_permissions(ban_members=True)
    async def p_unban(self, ctx, user_id: str, *, reason: str = "No reason"):
        try:
            user = await self.bot.fetch_user(int(user_id))
            await ctx.guild.unban(user, reason=f"{ctx.author} • {reason}")
            await ctx.reply(f"✅ {user} unbanned.")
        except discord.Forbidden:
            await ctx.reply("❌ I don't have permission to unban users.")
        except discord.NotFound:
            await ctx.reply("❌ User not found or not banned.")
        except Exception as e:
            await ctx.reply(f"❌ An error occurred: {str(e)[:100]}")

    @commands.command(name="mute")
    @commands.has_permissions(moderate_members=True)
    @commands.bot_has_permissions(moderate_members=True)
    async def p_mute(self, ctx, member: discord.Member, duration: str = "10m", *, reason: str = "No reason"):
        try:
            try:
                seconds = parse_duration(duration)
                if seconds < 60 or seconds > 2419200:
                    return await ctx.reply("❌ 1 min to 28 days.")
            except ValueError:
                return await ctx.reply("❌ Invalid duration. Use: 10m, 1h, 1d")
            await member.timeout(discord.utils.utcnow() + timedelta(seconds=seconds), reason=f"{ctx.author} • {reason}")
            await ctx.reply(f"🔇 {member} muted for {format_duration(seconds)}")
        except discord.Forbidden:
            await ctx.reply("❌ I don't have permission to mute that member.")
        except Exception as e:
            await ctx.reply(f"❌ An error occurred: {str(e)[:100]}")

    @commands.command(name="unmute")
    @commands.has_permissions(moderate_members=True)
    @commands.bot_has_permissions(moderate_members=True)
    async def p_unmute(self, ctx, member: discord.Member, *, reason: str = "No reason"):
        try:
            await member.timeout(None, reason=f"{ctx.author} • {reason}")
            await ctx.reply(f"🔊 {member} unmuted.")
        except discord.Forbidden:
            await ctx.reply("❌ I don't have permission to unmute that member.")
        except Exception as e:
            await ctx.reply(f"❌ An error occurred: {str(e)[:100]}")

    @commands.command(name="warn")
    @commands.has_permissions(manage_messages=True)
    async def p_warn(self, ctx, member: discord.Member, *, reason: str = "No reason"):
        try:
            add_warn(ctx.guild.id, member.id, reason, str(ctx.author))
            warns = get_warns(ctx.guild.id, member.id)
            await ctx.reply(f"⚠️ {member} warned ({len(warns)} total)")
        except Exception as e:
            await ctx.reply(f"❌ An error occurred: {str(e)[:100]}")

    @commands.command(name="warnings")
    @commands.has_permissions(manage_messages=True)
    async def p_warnings(self, ctx, member: discord.Member):
        try:
            warns = get_warns(ctx.guild.id, member.id)
            if not warns:
                return await ctx.reply(f"✅ {member} has no warnings.")
            desc = "\n".join([f"`{i+1}.` {w['reason']} • {w['mod']} ({w['time'][:10]})" for i, w in enumerate(warns)])
            await ctx.reply(embed=mod_embed(f"⚠️ Warnings for {member}", desc, Config.COLOR_WARN))
        except Exception as e:
            await ctx.reply(f"❌ An error occurred: {str(e)[:100]}")

    @commands.command(name="clearwarns")
    @commands.has_permissions(manage_guild=True)
    async def p_clearwarns(self, ctx, member: discord.Member):
        try:
            clear_warns(ctx.guild.id, member.id)
            await ctx.reply(f"✅ Cleared warnings for {member}.")
        except Exception as e:
            await ctx.reply(f"❌ An error occurred: {str(e)[:100]}")

    @commands.command(name="purge")
    @commands.has_permissions(manage_messages=True)
    @commands.bot_has_permissions(manage_messages=True)
    async def p_purge(self, ctx, amount: int, member: discord.Member = None):
        if not 1 <= amount <= 500:
            return await ctx.reply("❌ Amount 1-500.")
        try:
            await ctx.message.delete()
            def check(m):
                return True if not member else m.author == member
            deleted = await ctx.channel.purge(limit=amount, check=check, bulk=True)
            msg = await ctx.send(f"🗑️ Deleted {len(deleted)} messages" + (f" from {member.mention}" if member else ""))
            await asyncio.sleep(5)
            await msg.delete()
        except discord.Forbidden:
            await ctx.reply("❌ I don't have permission to delete messages in this channel.")
        except Exception as e:
            await ctx.reply(f"❌ An error occurred: {str(e)[:100]}")

    # ---- FIX: Changed permission from manage_channels to manage_roles ----
    @commands.command(name="lock")
    @commands.has_permissions(manage_roles=True)
    @commands.bot_has_permissions(manage_roles=True)
    async def p_lock(self, ctx, channel: discord.TextChannel = None):
        try:
            ch = channel or ctx.channel
            await ch.set_permissions(ctx.guild.default_role, send_messages=False)
            await ctx.reply(f"🔒 {ch.mention} locked.")
        except discord.Forbidden:
            await ctx.reply("❌ I don't have permission to lock this channel.")
        except Exception as e:
            await ctx.reply(f"❌ An error occurred: {str(e)[:100]}")

    # ---- FIX: Changed permission from manage_channels to manage_roles ----
    @commands.command(name="unlock")
    @commands.has_permissions(manage_roles=True)
    @commands.bot_has_permissions(manage_roles=True)
    async def p_unlock(self, ctx, channel: discord.TextChannel = None):
        try:
            ch = channel or ctx.channel
            await ch.set_permissions(ctx.guild.default_role, send_messages=None)
            await ctx.reply(f"🔓 {ch.mention} unlocked.")
        except discord.Forbidden:
            await ctx.reply("❌ I don't have permission to unlock this channel.")
        except Exception as e:
            await ctx.reply(f"❌ An error occurred: {str(e)[:100]}")

    @commands.command(name="slowmode")
    @commands.has_permissions(manage_channels=True)
    async def p_slowmode(self, ctx, seconds: int = 0):
        if not 0 <= seconds <= 21600:
            return await ctx.reply("❌ 0-21600 seconds.")
        try:
            await ctx.channel.edit(slowmode_delay=seconds)
            await ctx.reply(f"⏱️ Slowmode: {seconds}s" if seconds else "⏱️ Slowmode disabled.")
        except discord.Forbidden:
            await ctx.reply("❌ I don't have permission to edit this channel.")
        except Exception as e:
            await ctx.reply(f"❌ An error occurred: {str(e)[:100]}")

    @commands.command(name="nick")
    @commands.has_permissions(manage_nicknames=True)
    @commands.bot_has_permissions(manage_nicknames=True)
    async def p_nick(self, ctx, member: discord.Member, *, nickname: str = None):
        try:
            await member.edit(nick=nickname)
            await ctx.reply(f"✏️ Nickname updated for {member}.")
        except discord.Forbidden:
            await ctx.reply("❌ I don't have permission to change that member's nickname.")
        except Exception as e:
            await ctx.reply(f"❌ An error occurred: {str(e)[:100]}")

    @commands.command(name="role")
    @commands.has_permissions(manage_roles=True)
    @commands.bot_has_permissions(manage_roles=True)
    async def p_role(self, ctx, member: discord.Member, role: discord.Role):
        try:
            if role in member.roles:
                await member.remove_roles(role)
                await ctx.reply(f"➖ Removed {role} from {member}.")
            else:
                await member.add_roles(role)
                await ctx.reply(f"➕ Added {role} to {member}.")
        except discord.Forbidden:
            await ctx.reply("❌ I don't have permission to manage that role.")
        except Exception as e:
            await ctx.reply(f"❌ An error occurred: {str(e)[:100]}")

    @commands.command(name="setmodlog")
    @commands.has_permissions(administrator=True)
    async def p_setmodlog(self, ctx, channel: discord.TextChannel):
        try:
            data = load("guild_settings.json")
            data.setdefault(str(ctx.guild.id), {})["mod_log_channel"] = channel.id
            save("guild_settings.json", data)
            await ctx.reply(f"📝 Logs → {channel.mention}.")
        except Exception as e:
            await ctx.reply(f"❌ An error occurred: {str(e)[:100]}")

    @commands.command(name="jail")
    @commands.has_permissions(administrator=True)
    async def p_jail(self, ctx, member: discord.Member, duration: str = None, *, reason: str = "No reason"):
        try:
            config = _jail_data(ctx.guild.id).get("config", {})
            jail_role_id = config.get("role")
            jail_role = ctx.guild.get_role(jail_role_id) if jail_role_id else None

            if not jail_role:
                return await ctx.reply("❌ Jail role not set. Use `//setjailrole`")
            if str(member.id) in _get_jailed(ctx.guild.id):
                return await ctx.reply(f"❌ {member} is already jailed.")

            seconds = None
            if duration:
                try:
                    seconds = parse_duration(duration)
                except ValueError:
                    return await ctx.reply("❌ Invalid duration. Use: 10m, 1h, 1d")

            roles = [r.id for r in member.roles if r != ctx.guild.default_role and r != jail_role]
            _set_jailed(ctx.guild.id, member.id, roles, time.time() + seconds if seconds else None)
            await member.remove_roles(*[r for r in member.roles if r != ctx.guild.default_role], reason=f"Jailed: {reason}")
            await member.add_roles(jail_role, reason=f"Jailed: {reason}")
            dur_text = f" for {format_duration(seconds)}" if seconds else " (permanent)"
            await ctx.reply(f"🔒 {member} jailed{dur_text}")
        except discord.Forbidden:
            await ctx.reply("❌ I don't have permission to jail that member.")
        except Exception as e:
            await ctx.reply(f"❌ An error occurred: {str(e)[:100]}")

    @commands.command(name="unjail")
    @commands.has_permissions(administrator=True)
    async def p_unjail(self, ctx, member: discord.Member, *, reason: str = "No reason"):
        try:
            await self._unjail_member(ctx.guild, member, f"Unjailed by {ctx.author} • {reason}")
            await ctx.reply(f"🔓 {member} unjailed.")
        except discord.Forbidden:
            await ctx.reply("❌ I don't have permission to unjail that member.")
        except Exception as e:
            await ctx.reply(f"❌ An error occurred: {str(e)[:100]}")

    @commands.command(name="jaillist")
    @commands.has_permissions(manage_guild=True)
    async def p_jaillist(self, ctx):
        try:
            jailed = _get_jailed(ctx.guild.id)
            if not jailed:
                return await ctx.reply("✅ No jailed members.")
            lines = []
            for uid, entry in jailed.items():
                member = ctx.guild.get_member(int(uid))
                name = member.mention if member else f"`{uid}`"
                if isinstance(entry, dict):
                    auto = entry.get("auto_unjail_at")
                    if auto:
                        remaining = max(0, int(auto - time.time()))
                        lines.append(f"• {name} • {format_duration(remaining)} left")
                    else:
                        lines.append(f"• {name} • permanent")
                else:
                    lines.append(f"• {name}")
            await ctx.reply(embed=mod_embed("🔒 Jailed Members", "\n".join(lines), Config.COLOR_WARN))
        except Exception as e:
            await ctx.reply(f"❌ An error occurred: {str(e)[:100]}")

    @commands.command(name="setjailrole")
    @commands.has_permissions(administrator=True)
    async def p_setjailrole(self, ctx, role: discord.Role):
        try:
            d = _jail_data(ctx.guild.id)
            d.setdefault("config", {})["role"] = role.id
            _save_jail(ctx.guild.id, d)
            await ctx.reply(f"✅ Jail role: {role.mention}")
        except Exception as e:
            await ctx.reply(f"❌ An error occurred: {str(e)[:100]}")

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            missing = ", ".join(p.replace("_", " ").title() for p in error.missing_permissions)
            print(f"[Moderation] {interaction.user} ({interaction.user.id}) missing permissions: {missing}")
            try:
                await interaction.response.send_message(f"❌ You are missing the required permissions: **{missing}**.", ephemeral=True)
            except discord.InteractionResponded:
                await interaction.followup.send(f"❌ You are missing the required permissions: **{missing}**.", ephemeral=True)
        elif isinstance(error, app_commands.BotMissingPermissions):
            missing = ", ".join(p.replace("_", " ").title() for p in error.missing_permissions)
            print(f"[Moderation] Bot missing permissions: {missing}")
            try:
                await interaction.response.send_message(f"❌ I am missing the required permissions: **{missing}**. Please check my role and permissions.", ephemeral=True)
            except discord.InteractionResponded:
                await interaction.followup.send(f"❌ I am missing the required permissions: **{missing}**. Please check my role and permissions.", ephemeral=True)
        elif isinstance(error, app_commands.CommandOnCooldown):
            try:
                await interaction.response.send_message(f"⏳ This command is on cooldown. Try again in {error.retry_after:.1f} seconds.", ephemeral=True)
            except discord.InteractionResponded:
                await interaction.followup.send(f"⏳ This command is on cooldown. Try again in {error.retry_after:.1f} seconds.", ephemeral=True)
        else:
            print(f"[Moderation] Unhandled error: {error}")
            try:
                await interaction.response.send_message(f"❌ An error occurred: {str(error)[:100]}", ephemeral=True)
            except discord.InteractionResponded:
                await interaction.followup.send(f"❌ An error occurred: {str(error)[:100]}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Moderation(bot))