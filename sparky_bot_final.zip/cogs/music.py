import discord
from discord.ext import commands, tasks
from discord import app_commands
import asyncio
import yt_dlp
import re
import random
import aiohttp
import time
from datetime import datetime, timezone
from config import Config
from utils.embed import build
from utils.theme import Theme
from utils.emojis import Emojis
from utils.data import load, save
from utils.prefix_manager import get_prefixes

try:
    import spotipy
    from spotipy.oauth2 import SpotifyClientCredentials
    HAS_SPOTIFY = True
    print("[Music] spotipy imported successfully")
except ImportError:
    HAS_SPOTIFY = False
    print("[Music] spotipy not installed. Install with: pip install spotipy")

FFMPEG_OPTIONS = {
    'before_options': '-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5',
    'options': '-vn -b:a 128k'
}

YDL_OPTIONS = {
    'format': 'bestaudio/best',
    'extractaudio': True,
    'audioformat': 'mp3',
    'outtmpl': '%(extractor)s-%(id)s-%(title)s.%(ext)s',
    'restrictfilenames': True,
    'noplaylist': False,
    'nocheckcertificate': True,
    'ignoreerrors': True,
    'logtostderr': False,
    'quiet': True,
    'no_warnings': True,
    'default_search': 'auto',
    'source_address': '0.0.0.0',
    'extract_flat': False,
    'user_agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'headers': {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-us,en;q=0.5',
        'Sec-Fetch-Mode': 'navigate',
    },
    'cookiefile': 'cookies.txt' if __import__('os').path.exists('cookies.txt') else None,
    'youtube_include_dash_manifest': False,
    'youtube_include_hls_manifest': False,
    'extractor_args': {
        'youtube': {
            'skip': ['dash', 'hls'],
            'player_client': ['android', 'web'],
            'player_skip': ['configs'],
        }
    }
}

MUSIC_DATA_FILE = "music.json"

class SearchModal(discord.ui.Modal, title="🔍 Search YouTube"):
    query = discord.ui.TextInput(label="Search query", placeholder="Enter song name or YouTube URL...", required=True, max_length=200)

    def __init__(self, cog, interaction: discord.Interaction):
        super().__init__()
        self.cog = cog
        self.interaction = interaction

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        await self.cog._play(interaction, self.query.value)

class MusicControlView(discord.ui.View):
    def __init__(self, cog, guild_id: int, is_paused: bool = False, loop_mode: str = "off"):
        super().__init__(timeout=None)
        self.cog = cog
        self.guild_id = guild_id

        # Row 0
        pause_btn = discord.ui.Button(emoji="▶️" if is_paused else "⏸️", style=discord.ButtonStyle.primary, custom_id=f"sparky_music:playpause:{guild_id}", row=0)
        pause_btn.callback = self._make(self._on_playpause)
        self.add_item(pause_btn)

        search_btn = discord.ui.Button(label="🔍 Search", style=discord.ButtonStyle.primary, custom_id=f"sparky_music:search:{guild_id}", row=0)
        search_btn.callback = self._make(self._on_search)
        self.add_item(search_btn)

        disconnect_btn = discord.ui.Button(label="📤 Disconnect", style=discord.ButtonStyle.primary, custom_id=f"sparky_music:disconnect:{guild_id}", row=0)
        disconnect_btn.callback = self._make(self._on_disconnect)
        self.add_item(disconnect_btn)

        # Row 1
        vol_down = discord.ui.Button(label="🔉", style=discord.ButtonStyle.primary, custom_id=f"sparky_music:voldown:{guild_id}", row=1)
        vol_down.callback = self._make(self._on_vol_down)
        self.add_item(vol_down)

        vol_up = discord.ui.Button(label="🔊", style=discord.ButtonStyle.primary, custom_id=f"sparky_music:volup:{guild_id}", row=1)
        vol_up.callback = self._make(self._on_vol_up)
        self.add_item(vol_up)

        queue_btn = discord.ui.Button(label="📋 Queue", style=discord.ButtonStyle.primary, custom_id=f"sparky_music:queue:{guild_id}", row=1)
        queue_btn.callback = self._make(self._on_queue)
        self.add_item(queue_btn)

        # Row 2 – Lyrics button
        lyrics_btn = discord.ui.Button(label="📝 Lyrics", style=discord.ButtonStyle.primary, custom_id=f"sparky_music:lyrics:{guild_id}", row=2)
        lyrics_btn.callback = self._make(self._on_lyrics)
        self.add_item(lyrics_btn)

    def _make(self, handler):
        async def wrapped(interaction: discord.Interaction):
            if not interaction.guild or interaction.guild.id != self.guild_id:
                return
            member = interaction.guild.get_member(interaction.user.id)
            voice_state = member.voice if member else None
            voice_client = discord.utils.get(self.cog.bot.voice_clients, guild=interaction.guild)
            if voice_client and (not voice_state or voice_state.channel != voice_client.channel):
                await interaction.response.send_message(f"{Emojis.WRONG} Join the voice channel to control playback.", ephemeral=True)
                return
            await handler(interaction)
        return wrapped

    async def _on_playpause(self, interaction: discord.Interaction):
        guild_id = interaction.guild_id
        voice_client = discord.utils.get(self.cog.bot.voice_clients, guild=interaction.guild)
        if not voice_client or not voice_client.is_playing() and not voice_client.is_paused():
            await interaction.response.send_message(f"{Emojis.WRONG} Nothing is playing.", ephemeral=True)
            return
        if voice_client.is_paused():
            paused_offset = self.cog.song_paused_offset.get(guild_id, 0)
            self.cog.song_start_time[guild_id] = time.time() - paused_offset
            self.cog.song_paused_time.pop(guild_id, None)
            self.cog.song_paused_offset.pop(guild_id, None)
            voice_client.resume()
            await interaction.response.send_message(f"{Emojis.TICK} Resumed.", ephemeral=True)
        else:
            elapsed, _ = self.cog._get_current_progress(guild_id)
            self.cog.song_paused_time[guild_id] = time.time()
            self.cog.song_paused_offset[guild_id] = elapsed
            voice_client.pause()
            await interaction.response.send_message(f"{Emojis.TICK} Paused.", ephemeral=True)

    async def _on_search(self, interaction: discord.Interaction):
        await interaction.response.send_modal(SearchModal(self.cog, interaction))

    async def _on_disconnect(self, interaction: discord.Interaction):
        voice_client = discord.utils.get(self.cog.bot.voice_clients, guild=interaction.guild)
        if not voice_client:
            await interaction.response.send_message(f"{Emojis.WRONG} I'm not in a voice channel.", ephemeral=True)
            return
        guild_id = interaction.guild_id
        if self.cog.twenty_four_seven.get(guild_id, False):
            await interaction.response.send_message(f"{Emojis.WRONG} 24/7 mode is enabled. Disable it first with `/music 247 disable`.", ephemeral=True)
            return
        self.cog.queues[guild_id] = []
        self.cog.now_playing[guild_id] = None
        self.cog.song_start_time.pop(guild_id, None)
        self.cog.song_paused_time.pop(guild_id, None)
        self.cog.song_paused_offset.pop(guild_id, None)
        self.cog.current_sources.pop(guild_id, None)
        voice_client.stop()
        await voice_client.disconnect()
        await interaction.response.send_message(f"{Emojis.TICK} Disconnected.", ephemeral=True)

    async def _on_vol_down(self, interaction: discord.Interaction):
        await self._adjust_volume(interaction, -10)

    async def _on_vol_up(self, interaction: discord.Interaction):
        await self._adjust_volume(interaction, 10)

    async def _adjust_volume(self, interaction: discord.Interaction, delta: int):
        guild_id = interaction.guild_id
        voice_client = discord.utils.get(self.cog.bot.voice_clients, guild=interaction.guild)
        if not voice_client:
            await interaction.response.send_message(f"{Emojis.WRONG} I'm not in a voice channel.", ephemeral=True)
            return
        current = self.cog.volume_levels.get(guild_id, 100)
        new_volume = max(1, min(200, current + delta))
        self.cog.volume_levels[guild_id] = new_volume
        self.cog._save_guild_data(guild_id)
        source = self.cog.current_sources.get(guild_id)
        if source and isinstance(source, discord.PCMVolumeTransformer):
            source.volume = new_volume / 100
        await interaction.response.send_message(f"{Emojis.TICK} Volume: **{new_volume}%**", ephemeral=True)

    async def _on_queue(self, interaction: discord.Interaction):
        guild_id = interaction.guild_id
        queue = self.cog.get_queue(guild_id)
        now_playing = self.cog.now_playing.get(guild_id)
        if not queue and not now_playing:
            await interaction.response.send_message(f"{Emojis.TICK} Queue is empty.", ephemeral=True)
            return
        items = []
        if now_playing:
            items.append(("Now Playing", now_playing))
        for i, track in enumerate(queue[:10], 1):
            items.append((f"#{i}", track))
        embed = build(title="Queue", color=Theme.COLOR_PRIMARY, emoji=Emojis.MUSIC, bot=self.cog.bot, note=f"{len(queue)} tracks queued")
        for label, track in items:
            artist, song = self.cog._get_artist_and_song(track)
            embed.add_field(name=label, value=f"**{song}** {Emojis.DOT} *{artist}*", inline=False)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    async def _on_lyrics(self, interaction: discord.Interaction):
        """Fetch lyrics for the currently playing song."""
        guild_id = interaction.guild_id
        track = self.cog.now_playing.get(guild_id)
        if not track:
            await interaction.response.send_message(f"{Emojis.WRONG} No song is currently playing.", ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        artist, song = self.cog._get_artist_and_song(track)
        await self.cog._lyrics(interaction, song, artist)

class Music(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.queues = {}
        self.now_playing = {}
        self.loop_modes = {}
        self.volume_levels = {}
        self.music_vc = {}
        self.status_enabled = {}
        self.song_start_time = {}
        self.song_paused_time = {}
        self.song_paused_offset = {}
        self.current_sources = {}
        self.disconnect_timers = {}
        self.spotify = None
        self.original_queues = {}
        self.panel_data = {}
        self.live_lyrics_tasks = {}
        self.silence_skipped = {}
        self.twenty_four_seven = {}
        self._247_approved_servers = set()
        self._panel_error_cooldown = {}
        self._load_persistent_data()

        if HAS_SPOTIFY:
            client_id = getattr(Config, 'SPOTIFY_CLIENT_ID', None)
            client_secret = getattr(Config, 'SPOTIFY_CLIENT_SECRET', None)
            if client_id and client_secret:
                try:
                    self.spotify = spotipy.Spotify(client_credentials_manager=SpotifyClientCredentials(client_id=client_id, client_secret=client_secret))
                    print("[Music] Spotify client initialized")
                except Exception as e:
                    print(f"[Music] Spotify initialization failed: {e}")
                    self.spotify = None
            else:
                print("[Music] Spotify credentials not found in config. Spotify features disabled.")
                self.spotify = None
        else:
            self.spotify = None

        self.auto_disconnect_loop.start()
        self.panel_update_loop.start()
        self._last_state = {}
        # Start VC status update task
        self.bot.loop.create_task(self._update_vc_status())

    def cog_unload(self):
        self.auto_disconnect_loop.cancel()
        self.panel_update_loop.cancel()
        for task in self.live_lyrics_tasks.values():
            if not task.done():
                task.cancel()
        for task in self.disconnect_timers.values():
            if not task.done():
                task.cancel()
        self._save_persistent_data()

    # ---------- Data persistence ----------
    def _load_persistent_data(self):
        data = load(MUSIC_DATA_FILE)
        if "twenty_four_seven_approved" in data:
            self._247_approved_servers = set(data["twenty_four_seven_approved"])
            print(f"[Music] Loaded {len(self._247_approved_servers)} approved 24/7 servers")
        for guild_id_str, guild_data in data.items():
            if guild_id_str == "twenty_four_seven_approved":
                continue
            guild_id = int(guild_id_str)
            if "music_vc" in guild_data:
                self.music_vc[guild_id] = guild_data["music_vc"]
            if "status_enabled" in guild_data:
                self.status_enabled[guild_id] = guild_data["status_enabled"]
            if "volume" in guild_data:
                self.volume_levels[guild_id] = guild_data["volume"]
            if "loop_mode" in guild_data:
                self.loop_modes[guild_id] = guild_data["loop_mode"]
            if "panel_data" in guild_data:
                self.panel_data[guild_id] = guild_data["panel_data"]
            if "twenty_four_seven" in guild_data:
                self.twenty_four_seven[guild_id] = guild_data["twenty_four_seven"]
        if self.panel_data:
            print(f"[Music] Loaded {len(self.panel_data)} panels")
            for guild_id in self.panel_data:
                try:
                    self.bot.add_view(MusicControlView(self, guild_id, loop_mode=self.loop_modes.get(guild_id, "off")))
                except Exception as e:
                    print(f"[Music] Failed to re-register panel view for {guild_id}: {e}")
        if self.twenty_four_seven:
            print(f"[Music] Loaded {len(self.twenty_four_seven)} 24/7 guilds")

    def _save_persistent_data(self):
        data = {}
        all_guilds = set(list(self.music_vc.keys()) + list(self.status_enabled.keys()) + list(self.volume_levels.keys()) + list(self.loop_modes.keys()) + list(self.panel_data.keys()) + list(self.twenty_four_seven.keys()))
        for guild_id in all_guilds:
            guild_data = {}
            if guild_id in self.music_vc:
                guild_data["music_vc"] = self.music_vc[guild_id]
            if guild_id in self.status_enabled:
                guild_data["status_enabled"] = self.status_enabled[guild_id]
            if guild_id in self.volume_levels:
                guild_data["volume"] = self.volume_levels[guild_id]
            if guild_id in self.loop_modes:
                guild_data["loop_mode"] = self.loop_modes[guild_id]
            if guild_id in self.panel_data:
                guild_data["panel_data"] = self.panel_data[guild_id]
            if guild_id in self.twenty_four_seven:
                guild_data["twenty_four_seven"] = self.twenty_four_seven[guild_id]
            if guild_data:
                data[str(guild_id)] = guild_data
        data["twenty_four_seven_approved"] = list(self._247_approved_servers)
        save(MUSIC_DATA_FILE, data)

    def _save_guild_data(self, guild_id: int):
        guild_data = {}
        if guild_id in self.music_vc:
            guild_data["music_vc"] = self.music_vc[guild_id]
        if guild_id in self.status_enabled:
            guild_data["status_enabled"] = self.status_enabled[guild_id]
        if guild_id in self.volume_levels:
            guild_data["volume"] = self.volume_levels[guild_id]
        if guild_id in self.loop_modes:
            guild_data["loop_mode"] = self.loop_modes[guild_id]
        if guild_id in self.panel_data:
            guild_data["panel_data"] = self.panel_data[guild_id]
        if guild_id in self.twenty_four_seven:
            guild_data["twenty_four_seven"] = self.twenty_four_seven[guild_id]
        if guild_data:
            data = load(MUSIC_DATA_FILE)
            data[str(guild_id)] = guild_data
            save(MUSIC_DATA_FILE, data)
        else:
            data = load(MUSIC_DATA_FILE)
            if str(guild_id) in data:
                del data[str(guild_id)]
                save(MUSIC_DATA_FILE, data)

    def _save_247_approvals(self):
        data = load(MUSIC_DATA_FILE)
        data["twenty_four_seven_approved"] = list(self._247_approved_servers)
        save(MUSIC_DATA_FILE, data)

    # ---------- Helper methods ----------
    def get_queue(self, guild_id: int) -> list:
        if guild_id not in self.queues:
            self.queues[guild_id] = []
        return self.queues[guild_id]

    def _format_duration(self, seconds: int) -> str:
        if not seconds or seconds < 0:
            return "0:00"
        if seconds > 86400:
            seconds = 0
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        secs = seconds % 60
        if hours > 0:
            return f"{hours:02d}:{minutes:02d}:{secs:02d}"
        return f"{minutes:02d}:{secs:02d}"

    def _progress_bar(self, current: float, total: float, length: int = 20) -> str:
        if total <= 0:
            return "🔘" + "─" * (length - 1)
        progress = min(1.0, current / total)
        filled = int(progress * length)
        empty = length - filled - 1
        return "─" * filled + "🔘" + "─" * empty

    def _clean_song_name(self, song: str) -> str:
        patterns = [
            r'\s*\([^)]*Official[^)]*\)',
            r'\s*\([^)]*Video[^)]*\)',
            r'\s*\([^)]*Audio[^)]*\)',
            r'\s*\([^)]*Lyrics[^)]*\)',
            r'\s*\([^)]*Visualizer[^)]*\)',
            r'\s*\([^)]*Full[^)]*\)',
            r'\s*\[[^]]*Official[^]]*\]',
            r'\s*\[[^]]*Video[^]]*\]',
            r'\s*\[[^]]*Audio[^]]*\]',
            r'\s*\[[^]]*Lyrics[^]]*\]',
            r'\s*\|.*$',
            r'\s*ft\..*$',
            r'\s*feat\..*$',
            r'\s*featuring\..*$',
            r'\s*\(.*$',
            r'\s*\[.*$',
            r'\s*-\s*.*$',
            r'\s*\d{1,2}:\d{2}$',
            r'\s*\|.*$',
            r'\s*from\s+.*$',
            r'\s*Full\s+Video.*$',
            r'\s*Official\s+Video.*$',
            r'\s*Movie.*$',
            r'\s*Song.*$',
            r'\s*-\s*[A-Za-z]+\s*\|.*$',
        ]
        cleaned = song
        for pattern in patterns:
            cleaned = re.sub(pattern, '', cleaned, flags=re.IGNORECASE)
        cleaned = ' '.join(cleaned.split())
        cleaned = re.sub(r'\s*[-–•|]\s*$', '', cleaned)
        return cleaned.strip()

    def _parse_soundcloud_title(self, title: str) -> tuple[str, str]:
        if ' - ' in title:
            parts = title.split(' - ', 1)
            artist = parts[0].strip()
            song = parts[1].strip()
            song = self._clean_song_name(song)
            return artist, song
        if ' – ' in title:
            parts = title.split(' – ', 1)
            artist = parts[0].strip()
            song = parts[1].strip()
            song = self._clean_song_name(song)
            return artist, song
        return "Unknown Artist", self._clean_song_name(title)

    def _parse_youtube_title(self, title: str) -> tuple[str, str]:
        separators = [' - ', ' – ', ' • ', ' | ', ' • ', ' :: ', ' // ']
        best_artist = "Unknown Artist"
        best_song = self._clean_song_name(title)
        for sep in separators:
            if sep in title:
                parts = title.split(sep, 1)
                artist = parts[0].strip()
                song = parts[1].strip()
                if not re.match(r'^(Official|Video|Lyrics|Audio|Full|Movie|Song)', artist, re.IGNORECASE):
                    song = self._clean_song_name(song)
                    if len(song) > 50:
                        song = self._clean_song_name(song)
                    return artist, song
        match = re.search(r'^(.*?)\s*[|(]\s*(?:.*?)\s*[|)]?\s*(.*?)$', title)
        if match:
            song = self._clean_song_name(match.group(1))
            artist = self._clean_song_name(match.group(2))
            if song and artist:
                return artist, song
        return best_artist, best_song

    def _get_artist_and_song(self, track: dict) -> tuple[str, str]:
        artist = track.get('artist')
        song = track.get('title_clean')
        if artist and song:
            return artist, song
        title = track.get('title', 'Unknown')
        extractor = track.get('extractor', '')
        if 'soundcloud' in extractor.lower():
            return self._parse_soundcloud_title(title)
        elif 'youtube' in extractor.lower():
            return self._parse_youtube_title(title)
        else:
            return self._parse_youtube_title(title)

    def _get_current_progress(self, guild_id: int) -> tuple[int, int]:
        track = self.now_playing.get(guild_id)
        if not track:
            return 0, 0
        duration = track.get('duration', 0)
        if guild_id in self.song_paused_time:
            return self.song_paused_offset.get(guild_id, 0), duration
        start_time = self.song_start_time.get(guild_id)
        if start_time:
            elapsed = int(time.time() - start_time)
            if duration > 0 and elapsed > duration:
                elapsed = duration
            return elapsed, duration
        voice_client = discord.utils.get(self.bot.voice_clients, guild=self.bot.get_guild(guild_id))
        if voice_client and hasattr(voice_client, 'timestamp') and voice_client.timestamp is not None:
            elapsed = int(voice_client.timestamp)
            if elapsed > 86400:
                return 0, duration
            if duration > 0 and elapsed > duration * 2:
                return 0, duration
            return elapsed, duration
        return 0, duration

    async def _fetch_lrclib_lyrics(self, track_name: str, artist_name: str = None) -> dict | None:
        try:
            clean_track = self._clean_song_name(track_name)
            if artist_name:
                url = f"https://lrclib.net/api/get?artist_name={artist_name.replace(' ', '%20')}&track_name={clean_track.replace(' ', '%20')}"
            else:
                url = f"https://lrclib.net/api/search?q={clean_track.replace(' ', '%20')}"
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=10)) as session:
                async with session.get(url) as response:
                    if response.status == 200:
                        data = await response.json()
                        if isinstance(data, list) and data:
                            data = data[0]
                        if data and (data.get('plainLyrics') or data.get('syncedLyrics')):
                            synced_lines = self._parse_lrclib_synced(data.get('syncedLyrics'))
                            return {
                                'lyrics': data.get('plainLyrics') or data.get('syncedLyrics'),
                                'has_synced': bool(data.get('syncedLyrics')),
                                'synced_lines': synced_lines,
                                'artist': data.get('artistName', artist_name),
                                'track': data.get('trackName', track_name),
                                'source': 'LRCLib',
                                'is_rtl': False
                            }
        except Exception as e:
            print(f"[Music] LRCLib error: {e}")
        return None

    def _parse_lrclib_synced(self, synced_lyrics: str) -> list:
        if not synced_lyrics:
            return []
        lines = []
        pattern = r'\[(\d{2}):(\d{2})\.?(\d{0,3})\](.*?)(?=\n|$)'
        for match in re.finditer(pattern, synced_lyrics):
            minutes = int(match.group(1))
            seconds = int(match.group(2))
            centiseconds = int(match.group(3)) if match.group(3) else 0
            text = match.group(4).strip()
            if text:
                total_seconds = minutes * 60 + seconds + centiseconds / 1000
                lines.append({'time': total_seconds, 'text': text})
        return lines

    async def fetch_lyrics(self, track_name: str, artist_name: str = None) -> dict | None:
        return await self._fetch_lrclib_lyrics(track_name, artist_name)

    def _is_soundcloud_url(self, query: str) -> bool:
        return re.match(r'(https?://)?(soundcloud\.com/|soundcloud\.app\.goo\.gl/)', query) is not None

    def _is_spotify_url(self, query: str) -> bool:
        return re.match(r'(https?://)?(open\.spotify\.com/|spotify:)', query) is not None

    def _is_youtube_url(self, query: str) -> bool:
        return 'youtube.com' in query or 'youtu.be' in query

    async def _resolve_spotify_url(self, url: str) -> list[dict]:
        if not self.spotify:
            return []
        try:
            if 'track' in url:
                track = self.spotify.track(url)
                if track:
                    return [{
                        'artist': track['artists'][0]['name'],
                        'title': track['name'],
                        'duration': track['duration_ms'] // 1000,
                        'thumbnail': track['album']['images'][0]['url'] if track['album']['images'] else None,
                        'url': track['external_urls']['spotify']
                    }]
            elif 'playlist' in url:
                results = self.spotify.playlist_tracks(url)
                tracks = []
                for item in results['items']:
                    t = item['track']
                    if t:
                        tracks.append({
                            'artist': t['artists'][0]['name'],
                            'title': t['name'],
                            'duration': t['duration_ms'] // 1000,
                            'thumbnail': t['album']['images'][0]['url'] if t['album']['images'] else None,
                            'url': t['external_urls']['spotify']
                        })
                return tracks
            elif 'album' in url:
                results = self.spotify.album_tracks(url)
                album_id = url.split('/')[-1].split('?')[0]
                album = self.spotify.album(album_id)
                thumbnail = album['images'][0]['url'] if album['images'] else None
                tracks = []
                for t in results['items']:
                    tracks.append({
                        'artist': t['artists'][0]['name'],
                        'title': t['name'],
                        'duration': t['duration_ms'] // 1000,
                        'thumbnail': thumbnail,
                        'url': t['external_urls']['spotify']
                    })
                return tracks
        except Exception as e:
            print(f"[Music] Spotify resolve error: {e}")
        return []

    async def _search_spotify(self, query: str) -> dict | None:
        if not self.spotify:
            return None
        try:
            results = self.spotify.search(q=query, type='track', limit=1)
            items = results.get('tracks', {}).get('items', [])
            if items:
                t = items[0]
                return {
                    'artist': t['artists'][0]['name'],
                    'title': t['name'],
                    'duration': t['duration_ms'] // 1000,
                    'thumbnail': t['album']['images'][0]['url'] if t['album']['images'] else None,
                    'url': t['external_urls']['spotify']
                }
        except Exception as e:
            print(f"[Music] Spotify search error: {e}")
        return None

    async def search_youtube(self, query: str, retry: int = 0) -> dict | None:
        loop = asyncio.get_event_loop()
        user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        ]
        ydl_opts = YDL_OPTIONS.copy()
        if retry > 0:
            ydl_opts['user_agent'] = random.choice(user_agents)
            ydl_opts['headers']['User-Agent'] = ydl_opts['user_agent']
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            try:
                data = await loop.run_in_executor(None, lambda: ydl.extract_info(query, download=False))
                if not data:
                    return None
                return data
            except Exception as e:
                print(f"[Music] Search error (attempt {retry+1}): {e}")
                if "403" in str(e) and retry < 3:
                    await asyncio.sleep(1)
                    return await self.search_youtube(query, retry + 1)
                return None

    async def _get_track_from_query(self, query: str) -> list[dict] | dict | None:
        if self._is_spotify_url(query):
            tracks = await self._resolve_spotify_url(query)
            if tracks:
                return tracks
            return None
        data = await self.search_youtube(query)
        if not data:
            return None
        if 'entries' in data:
            tracks = []
            for entry in data['entries']:
                if not entry:
                    continue
                if entry.get('duration', 0) < 10:
                    continue
                track = {
                    'url': entry.get('url'),
                    'title': entry.get('title', 'Unknown'),
                    'duration': entry.get('duration', 0),
                    'thumbnail': entry.get('thumbnail', None),
                    'uploader': entry.get('uploader', 'Unknown'),
                    'webpage_url': entry.get('webpage_url', ''),
                    'extractor': entry.get('extractor', 'unknown')
                }
                if 'soundcloud' in track['extractor'].lower():
                    artist, song = self._parse_soundcloud_title(track['title'])
                else:
                    artist, song = self._parse_youtube_title(track['title'])
                track['artist'] = artist
                track['title_clean'] = song
                tracks.append(track)
            if not tracks:
                return None
            return tracks
        else:
            track = {
                'url': data.get('url'),
                'title': data.get('title', 'Unknown'),
                'duration': data.get('duration', 0),
                'thumbnail': data.get('thumbnail', None),
                'uploader': data.get('uploader', 'Unknown'),
                'webpage_url': data.get('webpage_url', ''),
                'extractor': data.get('extractor', 'unknown')
            }
            if not track['url'] and data.get('id'):
                track['url'] = data.get('webpage_url')
                if not track['url']:
                    track['url'] = f"https://youtube.com/watch?v={data['id']}"
            if not track['url']:
                return None
            if 'soundcloud' in track['extractor'].lower():
                artist, song = self._parse_soundcloud_title(track['title'])
            else:
                artist, song = self._parse_youtube_title(track['title'])
            track['artist'] = artist
            track['title_clean'] = song
            return track

    async def _play_track(self, ctx_or_interaction, guild_id: int, voice_client, track: dict, retry: int = 0):
        try:
            loop = asyncio.get_event_loop()
            ydl_opts = YDL_OPTIONS.copy()
            if retry > 0:
                user_agents = [
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                ]
                ydl_opts['user_agent'] = random.choice(user_agents)
                ydl_opts['headers']['User-Agent'] = ydl_opts['user_agent']
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                try:
                    data = await loop.run_in_executor(None, lambda: ydl.extract_info(track['url'], download=False))
                    audio_url = data.get('url') if data else track.get('url')
                    if not audio_url:
                        await self._send_response(ctx_or_interaction, "❌ Failed to get audio URL.")
                        await self._play_next(ctx_or_interaction, guild_id, voice_client)
                        return
                except Exception as e:
                    print(f"[Music] URL extraction error (attempt {retry+1}): {e}")
                    if "403" in str(e) and retry < 3:
                        await asyncio.sleep(1)
                        await self._play_track(ctx_or_interaction, guild_id, voice_client, track, retry + 1)
                        return
                    await self._send_response(ctx_or_interaction, f"❌ Error: {str(e)[:100]}")
                    await self._play_next(ctx_or_interaction, guild_id, voice_client)
                    return
            try:
                source = discord.FFmpegPCMAudio(audio_url, **FFMPEG_OPTIONS)
            except Exception as e:
                print(f"[Music] FFmpeg error: {e}")
                alt_options = {'options': '-vn -b:a 128k'}
                source = discord.FFmpegPCMAudio(audio_url, **alt_options)
            volume = self.volume_levels.get(guild_id, 100) / 100
            volume_source = discord.PCMVolumeTransformer(source, volume=volume)
            self.current_sources[guild_id] = volume_source
            self.silence_skipped[guild_id] = False

            def after_callback(error):
                if error:
                    print(f"[Music] Playback error: {error}")
                if self.silence_skipped.get(guild_id, False):
                    return
                elapsed, duration = self._get_current_progress(guild_id)
                if duration > 0 and duration - elapsed < 2:
                    print(f"[Music] Skipping silence at end of song")
                    self.silence_skipped[guild_id] = True
                    self.song_start_time.pop(guild_id, None)
                    self.song_paused_time.pop(guild_id, None)
                    self.song_paused_offset.pop(guild_id, None)
                    self.current_sources.pop(guild_id, None)
                    asyncio.run_coroutine_threadsafe(
                        self._play_next(ctx_or_interaction, guild_id, voice_client),
                        self.bot.loop
                    )
                    return
                self.song_start_time.pop(guild_id, None)
                self.song_paused_time.pop(guild_id, None)
                self.song_paused_offset.pop(guild_id, None)
                self.current_sources.pop(guild_id, None)
                asyncio.run_coroutine_threadsafe(
                    self._play_next(ctx_or_interaction, guild_id, voice_client),
                    self.bot.loop
                )

            voice_client.play(volume_source, after=after_callback)
            self.song_start_time[guild_id] = time.time()
            self.song_paused_time.pop(guild_id, None)
            self.song_paused_offset.pop(guild_id, None)
            if voice_client.channel:
                try:
                    artist, song = self._get_artist_and_song(track)
                    status_text = f"🎵 {artist} - {song}"
                    if len(status_text) > 100:
                        status_text = status_text[:97] + "..."
                    await voice_client.channel.edit(status=status_text)
                except Exception as e:
                    print(f"[Music] Failed to set initial VC status: {e}")
        except Exception as e:
            print(f"[Music] Play error: {e}")
            self.song_start_time.pop(guild_id, None)
            self.song_paused_time.pop(guild_id, None)
            self.song_paused_offset.pop(guild_id, None)
            self.current_sources.pop(guild_id, None)
            await self._send_response(ctx_or_interaction, f"❌ Error: {str(e)[:100]}")
            await self._play_next(ctx_or_interaction, guild_id, voice_client)

    async def _play_next(self, ctx_or_interaction, guild_id: int, voice_client):
        if not voice_client or not voice_client.is_connected():
            return

        # Clean panel channel BEFORE playing the next song
        await self._clean_panel_channel(guild_id, voice_client.guild)

        queue = self.get_queue(guild_id)
        loop_mode = self.loop_modes.get(guild_id, 'off')

        if loop_mode == 'track' and self.now_playing.get(guild_id):
            track = self.now_playing[guild_id]
            if track:
                await self._play_track(ctx_or_interaction, guild_id, voice_client, track)
                return

        if not queue:
            self.now_playing[guild_id] = None
            self.song_start_time.pop(guild_id, None)
            self.song_paused_time.pop(guild_id, None)
            self.song_paused_offset.pop(guild_id, None)
            self.current_sources.pop(guild_id, None)
            self.silence_skipped.pop(guild_id, None)
            if guild_id in self.live_lyrics_tasks:
                if not self.live_lyrics_tasks[guild_id].done():
                    self.live_lyrics_tasks[guild_id].cancel()
                del self.live_lyrics_tasks[guild_id]
            if not self.twenty_four_seven.get(guild_id, False):
                if voice_client and voice_client.channel:
                    try:
                        await voice_client.channel.edit(status=None)
                    except Exception:
                        pass
            return

        track = queue.pop(0)
        if loop_mode == 'queue':
            queue.append(track)

        self.now_playing[guild_id] = track
        await self._play_track(ctx_or_interaction, guild_id, voice_client, track)

    async def _clean_panel_channel(self, guild_id: int, guild: discord.Guild):
        panel_info = self.panel_data.get(guild_id)
        if not panel_info:
            return
        channel_id = panel_info.get("channel_id")
        message_id = panel_info.get("message_id")
        if not channel_id or not message_id:
            return
        channel = guild.get_channel(channel_id)
        if not channel:
            return
        try:
            async for msg in channel.history(limit=200, oldest_first=False):
                if msg.id != message_id:
                    try:
                        await msg.delete()
                    except:
                        pass
        except Exception as e:
            print(f"[Music] Failed to clean panel channel: {e}")

    async def _send_response(self, ctx_or_interaction, content: str = None, embed: discord.Embed = None, ephemeral: bool = True):
        try:
            if hasattr(ctx_or_interaction, 'response'):
                if ctx_or_interaction.response.is_done():
                    await ctx_or_interaction.followup.send(content=content, embed=embed, ephemeral=ephemeral)
                else:
                    await ctx_or_interaction.response.send_message(content=content, embed=embed, ephemeral=ephemeral)
            else:
                if content and embed:
                    await ctx_or_interaction.reply(content=content, embed=embed)
                elif content:
                    await ctx_or_interaction.reply(content=content)
                elif embed:
                    await ctx_or_interaction.reply(embed=embed)
        except Exception as e:
            print(f"[Music] Failed to send response: {e}")

    # ---------- Core command methods ----------
    async def _play(self, ctx_or_interaction, query: str):
        # Determine guild and user
        if hasattr(ctx_or_interaction, 'guild_id'):
            guild_id = ctx_or_interaction.guild_id
            guild = ctx_or_interaction.guild
            user = ctx_or_interaction.user
        else:
            guild = ctx_or_interaction.guild
            guild_id = guild.id
            user = ctx_or_interaction.author

        if not user.voice:
            return await self._send_response(ctx_or_interaction, "❌ You need to be in a voice channel.", ephemeral=True)
        voice_channel = user.voice.channel

        if guild_id in self.music_vc:
            config = self.music_vc[guild_id]
            music_vc_id = config["channel_id"]
            music_vc = guild.get_channel(music_vc_id)
            if music_vc and voice_channel.id != music_vc_id:
                if config.get("drag_users", True):
                    try:
                        await user.move_to(music_vc, reason="Moved to designated music VC")
                        voice_channel = music_vc
                        await self._send_response(ctx_or_interaction, f"🚀 Moved to {music_vc.mention}!", ephemeral=True)
                    except discord.Forbidden:
                        return await self._send_response(ctx_or_interaction, f"❌ I don't have permission to move you to {music_vc.mention}.", ephemeral=True)
                    except Exception as e:
                        return await self._send_response(ctx_or_interaction, f"❌ Failed to move you: {str(e)[:100]}", ephemeral=True)
                else:
                    return await self._send_response(ctx_or_interaction, f"❌ Please join {music_vc.mention} to play music.", ephemeral=True)

        voice_client = discord.utils.get(self.bot.voice_clients, guild=guild)
        if not voice_client:
            try:
                voice_client = await voice_channel.connect()
            except Exception as e:
                return await self._send_response(ctx_or_interaction, f"❌ Failed to connect: {str(e)[:100]}", ephemeral=True)
        elif voice_client.channel != voice_channel:
            try:
                await voice_client.move_to(voice_channel)
            except Exception as e:
                return await self._send_response(ctx_or_interaction, f"❌ Failed to move: {str(e)[:100]}", ephemeral=True)

        result = await self._get_track_from_query(query)
        if not result:
            return await self._send_response(ctx_or_interaction, "❌ No results found.", ephemeral=True)

        if isinstance(result, list):
            queue = self.get_queue(guild_id)
            added = 0
            for track in result:
                queue.append(track)
                added += 1
                await asyncio.sleep(0.1)
            if added == 0:
                return await self._send_response(ctx_or_interaction, "❌ No tracks could be resolved from the playlist.", ephemeral=True)
            if not voice_client.is_playing() and not voice_client.is_paused():
                self.now_playing[guild_id] = queue.pop(0)
                await self._play_track(ctx_or_interaction, guild_id, voice_client, self.now_playing[guild_id])
                await self._send_response(ctx_or_interaction, f"▶️ Now playing the first track from the playlist! ({added} tracks added)", ephemeral=True)
            else:
                await self._send_response(ctx_or_interaction, f"✅ Added {added} tracks to the queue.", ephemeral=True)
            return

        track = result
        queue = self.get_queue(guild_id)
        if voice_client.is_playing() or voice_client.is_paused():
            queue.append(track)
            artist, song = self._get_artist_and_song(track)
            await self._send_response(ctx_or_interaction, f"✅ Added to queue: **{song}** by {artist}", ephemeral=True)
        else:
            self.now_playing[guild_id] = track
            await self._play_track(ctx_or_interaction, guild_id, voice_client, track)
            await self._send_response(ctx_or_interaction, "▶️ Now playing!", ephemeral=True)

    async def _pause(self, ctx_or_interaction):
        guild = getattr(ctx_or_interaction, 'guild', None) or ctx_or_interaction.guild
        voice_client = discord.utils.get(self.bot.voice_clients, guild=guild)
        if not voice_client:
            return await self._send_response(ctx_or_interaction, "❌ I'm not in a voice channel.", ephemeral=True)
        if not voice_client.is_playing():
            return await self._send_response(ctx_or_interaction, "❌ Nothing is playing.", ephemeral=True)
        if voice_client.is_paused():
            return await self._send_response(ctx_or_interaction, "⏸️ Already paused.", ephemeral=True)
        elapsed, _ = self._get_current_progress(guild.id)
        self.song_paused_time[guild.id] = time.time()
        self.song_paused_offset[guild.id] = elapsed
        voice_client.pause()
        await self._send_response(ctx_or_interaction, "⏸️ Paused.", ephemeral=True)

    async def _resume(self, ctx_or_interaction):
        guild = getattr(ctx_or_interaction, 'guild', None) or ctx_or_interaction.guild
        voice_client = discord.utils.get(self.bot.voice_clients, guild=guild)
        if not voice_client:
            return await self._send_response(ctx_or_interaction, "❌ I'm not in a voice channel.", ephemeral=True)
        if not voice_client.is_paused():
            return await self._send_response(ctx_or_interaction, "❌ Nothing is paused.", ephemeral=True)
        paused_offset = self.song_paused_offset.get(guild.id, 0)
        self.song_start_time[guild.id] = time.time() - paused_offset
        self.song_paused_time.pop(guild.id, None)
        self.song_paused_offset.pop(guild.id, None)
        voice_client.resume()
        await self._send_response(ctx_or_interaction, "▶️ Resumed.", ephemeral=True)

    async def _skip(self, ctx_or_interaction):
        guild = getattr(ctx_or_interaction, 'guild', None) or ctx_or_interaction.guild
        voice_client = discord.utils.get(self.bot.voice_clients, guild=guild)
        if not voice_client:
            return await self._send_response(ctx_or_interaction, "❌ I'm not in a voice channel.", ephemeral=True)
        if not voice_client.is_playing():
            return await self._send_response(ctx_or_interaction, "❌ Nothing is playing.", ephemeral=True)
        voice_client.stop()
        self.song_start_time.pop(guild.id, None)
        self.song_paused_time.pop(guild.id, None)
        self.song_paused_offset.pop(guild.id, None)
        await self._send_response(ctx_or_interaction, "⏭️ Skipped.", ephemeral=True)

    async def _stop(self, ctx_or_interaction):
        guild = getattr(ctx_or_interaction, 'guild', None) or ctx_or_interaction.guild
        voice_client = discord.utils.get(self.bot.voice_clients, guild=guild)
        if not voice_client:
            return await self._send_response(ctx_or_interaction, "❌ I'm not in a voice channel.", ephemeral=True)
        self.queues[guild.id] = []
        self.now_playing[guild.id] = None
        self.song_start_time.pop(guild.id, None)
        self.song_paused_time.pop(guild.id, None)
        self.song_paused_offset.pop(guild.id, None)
        self.current_sources.pop(guild.id, None)
        voice_client.stop()
        await self._send_response(ctx_or_interaction, "⏹️ Stopped and cleared the queue.", ephemeral=True)

    async def _queue(self, ctx_or_interaction, page: int = 1):
        guild_id = getattr(ctx_or_interaction, 'guild_id', None)
        if not guild_id:
            guild = getattr(ctx_or_interaction, 'guild', None) or ctx_or_interaction.guild
            guild_id = guild.id
        queue = self.get_queue(guild_id)
        now_playing = self.now_playing.get(guild_id)
        if not queue and not now_playing:
            return await self._send_response(ctx_or_interaction, "✅ Queue is empty.", ephemeral=True)
        items = []
        if now_playing:
            items.append(("▶️ Now Playing", now_playing))
        for i, track in enumerate(queue, 1):
            items.append((f"#{i}", track))
        items_per_page = 10
        total_pages = max(1, (len(items) + items_per_page - 1) // items_per_page)
        page = max(1, min(page, total_pages))
        start = (page - 1) * items_per_page
        end = start + items_per_page
        page_items = items[start:end]
        embed = build(title="🎵 Music Queue", description=f"**{len(queue)}** tracks in queue | Page {page}/{total_pages}", color=Config.COLOR_INFO, bot=self.bot)
        for label, track in page_items:
            artist, song = self._get_artist_and_song(track)
            embed.add_field(name=label, value=f"**{song}** • *{artist}* - `{self._format_duration(track.get('duration', 0))}`", inline=False)
        await self._send_response(ctx_or_interaction, embed=embed, ephemeral=True)

    async def _nowplaying(self, ctx_or_interaction):
        guild = getattr(ctx_or_interaction, 'guild', None) or ctx_or_interaction.guild
        voice_client = discord.utils.get(self.bot.voice_clients, guild=guild)
        if not voice_client or not voice_client.is_playing():
            return await self._send_response(ctx_or_interaction, "❌ Nothing is playing.", ephemeral=True)
        track = self.now_playing.get(guild.id)
        if not track:
            return await self._send_response(ctx_or_interaction, "❌ No track info available.", ephemeral=True)
        current_time, duration = self._get_current_progress(guild.id)
        artist, song = self._get_artist_and_song(track)
        volume = self.volume_levels.get(guild.id, 100)
        if duration <= 0:
            progress_display = "🔴 LIVE"
        else:
            progress_bar = self._progress_bar(current_time, duration)
            progress_display = f"`{self._format_duration(current_time)}` {progress_bar} `{self._format_duration(duration)}`"
        embed = build(title=f"🎵 Now Playing", description=f"**{song}** • *{artist}*", color=Config.COLOR_INFO, bot=self.bot)
        embed.add_field(name="Progress", value=progress_display, inline=False)
        embed.add_field(name="Artist", value=artist, inline=True)
        embed.add_field(name="Duration", value=self._format_duration(duration), inline=True)
        embed.add_field(name="Status", value="⏸️ Paused" if voice_client.is_paused() else "▶️ Playing", inline=True)
        embed.add_field(name="Volume", value=f"{volume}%", inline=True)
        if self.twenty_four_seven.get(guild.id, False):
            embed.add_field(name="🔄 24/7 Mode", value="✅ Enabled", inline=True)
        elif guild.id in self._247_approved_servers:
            embed.add_field(name="🔄 24/7 Mode", value="ℹ️ Available - Use /music 247 enable", inline=True)
        if track.get('thumbnail'):
            embed.set_thumbnail(url=track['thumbnail'])
        await self._send_response(ctx_or_interaction, embed=embed, ephemeral=True)

    async def _disconnect(self, ctx_or_interaction):
        guild = getattr(ctx_or_interaction, 'guild', None) or ctx_or_interaction.guild
        voice_client = discord.utils.get(self.bot.voice_clients, guild=guild)
        if not voice_client:
            return await self._send_response(ctx_or_interaction, "❌ I'm not in a voice channel.", ephemeral=True)
        if self.twenty_four_seven.get(guild.id, False):
            return await self._send_response(ctx_or_interaction, "❌ 24/7 mode is enabled! Disable it first.", ephemeral=True)
        self.queues[guild.id] = []
        self.now_playing[guild.id] = None
        self.song_start_time.pop(guild.id, None)
        self.song_paused_time.pop(guild.id, None)
        self.song_paused_offset.pop(guild.id, None)
        self.current_sources.pop(guild.id, None)
        voice_client.stop()
        await voice_client.disconnect()
        await self._send_response(ctx_or_interaction, "👋 Disconnected.", ephemeral=True)

    async def _shuffle(self, ctx_or_interaction):
        guild_id = getattr(ctx_or_interaction, 'guild_id', None)
        if not guild_id:
            guild = getattr(ctx_or_interaction, 'guild', None) or ctx_or_interaction.guild
            guild_id = guild.id
        queue = self.get_queue(guild_id)
        if len(queue) < 2:
            return await self._send_response(ctx_or_interaction, "❌ Need at least 2 songs to shuffle.", ephemeral=True)
        self.original_queues[guild_id] = queue.copy()
        random.shuffle(queue)
        await self._send_response(ctx_or_interaction, "🔀 Shuffled the queue! Use /music unshuffle to restore order.", ephemeral=True)

    async def _unshuffle(self, ctx_or_interaction):
        guild_id = getattr(ctx_or_interaction, 'guild_id', None)
        if not guild_id:
            guild = getattr(ctx_or_interaction, 'guild', None) or ctx_or_interaction.guild
            guild_id = guild.id
        queue = self.get_queue(guild_id)
        if len(queue) < 2:
            return await self._send_response(ctx_or_interaction, "❌ Queue has less than 2 songs. Nothing to unshuffle.", ephemeral=True)
        original_queue = self.original_queues.get(guild_id)
        if original_queue and len(original_queue) == len(queue):
            self.queues[guild_id] = original_queue.copy()
            del self.original_queues[guild_id]
            await self._send_response(ctx_or_interaction, "📋 Queue restored to original order!", ephemeral=True)
        else:
            queue.sort(key=lambda x: x.get('title_clean', x.get('title', '')).lower())
            await self._send_response(ctx_or_interaction, "ℹ️ No original order found. Sorted alphabetically instead.", ephemeral=True)

    async def _loop(self, ctx_or_interaction, mode: str):
        guild_id = getattr(ctx_or_interaction, 'guild_id', None)
        if not guild_id:
            guild = getattr(ctx_or_interaction, 'guild', None) or ctx_or_interaction.guild
            guild_id = guild.id
        valid_modes = ['off', 'track', 'queue']
        if mode not in valid_modes:
            return await self._send_response(ctx_or_interaction, f"❌ Invalid mode. Options: {', '.join(valid_modes)}", ephemeral=True)
        self.loop_modes[guild_id] = mode
        self._save_guild_data(guild_id)
        await self._send_response(ctx_or_interaction, f"🔁 Loop: **{mode.title()}**", ephemeral=True)

    async def _remove(self, ctx_or_interaction, position: int):
        guild_id = getattr(ctx_or_interaction, 'guild_id', None)
        if not guild_id:
            guild = getattr(ctx_or_interaction, 'guild', None) or ctx_or_interaction.guild
            guild_id = guild.id
        queue = self.get_queue(guild_id)
        if position < 1 or position > len(queue):
            return await self._send_response(ctx_or_interaction, f"❌ Position must be between 1 and {len(queue)}.", ephemeral=True)
        removed = queue.pop(position - 1)
        await self._send_response(ctx_or_interaction, f"✅ Removed: **{removed.get('title_clean') or removed['title']}**", ephemeral=True)

    async def _clear(self, ctx_or_interaction):
        guild_id = getattr(ctx_or_interaction, 'guild_id', None)
        if not guild_id:
            guild = getattr(ctx_or_interaction, 'guild', None) or ctx_or_interaction.guild
            guild_id = guild.id
        queue = self.get_queue(guild_id)
        queue.clear()
        await self._send_response(ctx_or_interaction, "🗑️ Cleared the queue.", ephemeral=True)

    async def _volume(self, ctx_or_interaction, volume: int):
        guild = getattr(ctx_or_interaction, 'guild', None) or ctx_or_interaction.guild
        if not 1 <= volume <= 200:
            return await self._send_response(ctx_or_interaction, "❌ Volume must be between 1 and 200.", ephemeral=True)
        voice_client = discord.utils.get(self.bot.voice_clients, guild=guild)
        if not voice_client:
            return await self._send_response(ctx_or_interaction, "❌ I'm not in a voice channel.", ephemeral=True)
        self.volume_levels[guild.id] = volume
        self._save_guild_data(guild.id)
        source = self.current_sources.get(guild.id)
        if source and isinstance(source, discord.PCMVolumeTransformer):
            source.volume = volume / 100
            await self._send_response(ctx_or_interaction, f"🔊 Volume set to **{volume}%**", ephemeral=True)
        else:
            await self._send_response(ctx_or_interaction, f"🔊 Volume set to **{volume}%** (will apply to next song)", ephemeral=True)

    # ---------- Admin commands for prefix ----------
    async def _vc(self, ctx, channel: discord.VoiceChannel, drag_users: bool = True):
        if not ctx.author.guild_permissions.manage_channels:
            return await ctx.reply("❌ You need **Manage Channels** permission.")
        if not isinstance(channel, discord.VoiceChannel):
            return await ctx.reply("❌ Please select a voice channel.")
        if not channel.permissions_for(ctx.guild.me).view_channel or not channel.permissions_for(ctx.guild.me).connect:
            return await ctx.reply(f"❌ I don't have permission to view/connect to {channel.mention}.")
        self.music_vc[ctx.guild.id] = {"channel_id": channel.id, "drag_users": drag_users}
        self._save_guild_data(ctx.guild.id)
        embed = build(title="🎵 Music VC Set", description=f"Music will now be played in {channel.mention}", color=Config.COLOR_OK, bot=self.bot)
        embed.add_field(name="🚀 Drag Users", value="Enabled" if drag_users else "Disabled", inline=True)
        await ctx.reply(embed=embed)

    async def _remove_vc(self, ctx):
        if not ctx.author.guild_permissions.manage_channels:
            return await ctx.reply("❌ You need **Manage Channels** permission.")
        if ctx.guild.id not in self.music_vc:
            return await ctx.reply("❌ No music VC has been set.")
        del self.music_vc[ctx.guild.id]
        self._save_guild_data(ctx.guild.id)
        await ctx.reply("✅ Music VC removed.")

    async def _vc_info(self, ctx):
        if not ctx.author.guild_permissions.manage_channels:
            return await ctx.reply("❌ You need **Manage Channels** permission.")
        if ctx.guild.id not in self.music_vc:
            return await ctx.reply("ℹ️ No music VC has been set.")
        config = self.music_vc[ctx.guild.id]
        channel = ctx.guild.get_channel(config["channel_id"])
        embed = build(title="🎵 Music VC Configuration", color=Config.COLOR_INFO, bot=self.bot)
        embed.add_field(name="📌 Voice Channel", value=channel.mention if channel else "❌ Not found", inline=False)
        embed.add_field(name="🚀 Drag Users", value="✅ Enabled" if config.get("drag_users", True) else "❌ Disabled", inline=True)
        await ctx.reply(embed=embed)

    async def _status(self, ctx, enabled: bool):
        if not ctx.author.guild_permissions.manage_channels:
            return await ctx.reply("❌ You need **Manage Channels** permission.")
        self.status_enabled[ctx.guild.id] = enabled
        self._save_guild_data(ctx.guild.id)
        embed = build(title="🎵 VC Status Updates", color=Config.COLOR_OK, bot=self.bot)
        embed.description = "✅ Enabled" if enabled else "❌ Disabled"
        await ctx.reply(embed=embed)

    async def _247(self, ctx, enabled: bool):
        if not ctx.author.guild_permissions.administrator:
            return await ctx.reply("❌ You need **Administrator** permission.")
        if ctx.guild.id not in self._247_approved_servers:
            return await ctx.reply("❌ This server is not approved for 24/7 mode.\nContact the bot owner to request approval.")
        voice_client = discord.utils.get(self.bot.voice_clients, guild=ctx.guild)
        if not voice_client or not voice_client.is_connected():
            return await ctx.reply("❌ I'm not in a voice channel. Play a song first before enabling 24/7.")
        if enabled:
            self.twenty_four_seven[ctx.guild.id] = True
            self._save_guild_data(ctx.guild.id)
            if ctx.guild.id in self.disconnect_timers:
                if not self.disconnect_timers[ctx.guild.id].done():
                    self.disconnect_timers[ctx.guild.id].cancel()
                del self.disconnect_timers[ctx.guild.id]
            embed = build(title="🔄 24/7 Mode Enabled", description="Bot stays in VC even when empty.", color=Config.COLOR_OK, bot=self.bot)
            await ctx.reply(embed=embed)
        else:
            self.twenty_four_seven.pop(ctx.guild.id, None)
            self._save_guild_data(ctx.guild.id)
            embed = build(title="🔄 24/7 Mode Disabled", description="Bot will disconnect when empty.", color=Config.COLOR_INFO, bot=self.bot)
            await ctx.reply(embed=embed)

    async def _247_status(self, ctx):
        if not ctx.author.guild_permissions.administrator:
            return await ctx.reply("❌ You need **Administrator** permission.")
        is_enabled = self.twenty_four_seven.get(ctx.guild.id, False)
        is_approved = ctx.guild.id in self._247_approved_servers
        voice_client = discord.utils.get(self.bot.voice_clients, guild=ctx.guild)
        embed = build(title="🔄 24/7 Mode Status", color=Config.COLOR_INFO, bot=self.bot)
        embed.add_field(name="Status", value="✅ Enabled" if is_enabled else "❌ Disabled", inline=True)
        embed.add_field(name="Approved", value="✅ Yes" if is_approved else "❌ No", inline=True)
        embed.add_field(name="Connected", value=voice_client.channel.mention if voice_client else "Not connected", inline=True)
        await ctx.reply(embed=embed)

    async def _panel(self, ctx, channel: discord.TextChannel = None):
        if not ctx.author.guild_permissions.manage_channels:
            return await ctx.reply("❌ You need **Manage Channels** permission.")
        ch = channel or ctx.channel
        if ctx.guild.id in self.panel_data:
            try:
                old_info = self.panel_data[ctx.guild.id]
                old_channel = ctx.guild.get_channel(old_info.get("channel_id"))
                if old_channel:
                    old_msg = await old_channel.fetch_message(old_info.get("message_id"))
                    await old_msg.delete()
            except Exception:
                pass
            del self.panel_data[ctx.guild.id]
        embed = build(title="🎵 Music Player", description="No song is currently playing.", color=Config.COLOR_INFO, bot=self.bot)
        embed.set_footer(text="🎵 Sparky Bot • Use /music play to start")
        if self.twenty_four_seven.get(ctx.guild.id, False):
            embed.add_field(name="🔄 24/7 Mode", value="✅ Enabled", inline=True)
        elif ctx.guild.id in self._247_approved_servers:
            embed.add_field(name="🔄 24/7 Mode", value="ℹ️ Available - Use /music 247 enable", inline=True)
        msg = await ch.send(embed=embed, view=MusicControlView(self, ctx.guild.id))
        self.panel_data[ctx.guild.id] = {"message_id": msg.id, "channel_id": ch.id}
        self._save_guild_data(ctx.guild.id)
        await ctx.reply(f"✅ Music panel sent to {ch.mention}!")

    async def _remove_panel(self, ctx):
        if not ctx.author.guild_permissions.manage_channels:
            return await ctx.reply("❌ You need **Manage Channels** permission.")
        if ctx.guild.id not in self.panel_data:
            return await ctx.reply("❌ No music panel found for this server.")
        panel_info = self.panel_data[ctx.guild.id]
        channel = ctx.guild.get_channel(panel_info.get("channel_id"))
        if channel:
            try:
                msg = await channel.fetch_message(panel_info.get("message_id"))
                await msg.delete()
            except Exception:
                pass
        del self.panel_data[ctx.guild.id]
        self._save_guild_data(ctx.guild.id)
        await ctx.reply("✅ Music panel removed.")

    async def _lyrics(self, ctx_or_interaction, track: str = None, artist: str = None):
        """Fetch lyrics for a track (used by both prefix and panel button)."""
        if hasattr(ctx_or_interaction, 'guild_id'):
            # Interaction
            if not track:
                current_track = self.now_playing.get(ctx_or_interaction.guild_id)
                if current_track:
                    artist, track = self._get_artist_and_song(current_track)
                else:
                    return await self._send_response(ctx_or_interaction, "❌ No song is currently playing. Please provide a track name.", ephemeral=True)
        else:
            # Context
            if not track:
                current_track = self.now_playing.get(ctx_or_interaction.guild.id)
                if current_track:
                    artist, track = self._get_artist_and_song(current_track)
                else:
                    return await ctx_or_interaction.reply("❌ No song is currently playing. Please provide a track name.")

        if not track:
            return await self._send_response(ctx_or_interaction, "❌ Please provide a track name.", ephemeral=True)

        lyrics_data = await self.fetch_lyrics(track, artist)
        if not lyrics_data:
            return await self._send_response(ctx_or_interaction, f"❌ No lyrics found for **{track}**.", ephemeral=True)

        lyrics = lyrics_data.get('lyrics')
        if not lyrics:
            return await self._send_response(ctx_or_interaction, f"❌ No lyrics found for **{track}**.", ephemeral=True)

        MAX_EMBED_LENGTH = 4000
        if len(lyrics) <= MAX_EMBED_LENGTH:
            embed = build(title=f"📝 Lyrics: {lyrics_data.get('track', track)}", description=lyrics, color=Config.COLOR_INFO, bot=self.bot)
            if lyrics_data.get('artist'):
                embed.add_field(name="Artist", value=lyrics_data.get('artist'), inline=True)
            embed.add_field(name="📌 Source", value="LRCLib", inline=True)
            if lyrics_data.get('has_synced'):
                embed.add_field(name="🎵 Type", value="Synced Lyrics Available", inline=True)
            await self._send_response(ctx_or_interaction, embed=embed, ephemeral=True)
        else:
            import io
            filename = f"{lyrics_data.get('track', track).replace(' ', '_')}_lyrics.txt"
            content = f"Artist: {lyrics_data.get('artist', artist)}\nTrack: {lyrics_data.get('track', track)}\nSource: LRCLib\n{'='*50}\n\n{lyrics}"
            file_bytes = io.BytesIO(content.encode('utf-8'))
            file = discord.File(file_bytes, filename=filename)
            if hasattr(ctx_or_interaction, 'guild_id'):
                await ctx_or_interaction.followup.send(file=file, ephemeral=True)
            else:
                await ctx_or_interaction.reply(file=file)

    async def _live_lyrics(self, ctx, auto_update: bool = True):
        guild_id = ctx.guild.id
        current_track = self.now_playing.get(guild_id)
        if not current_track:
            return await ctx.reply("❌ No song is currently playing.")
        voice_client = discord.utils.get(self.bot.voice_clients, guild=ctx.guild)
        if not voice_client or not voice_client.is_playing():
            return await ctx.reply("❌ No song is currently playing.")
        artist, track_name = self._get_artist_and_song(current_track)
        lyrics_data = await self.fetch_lyrics(track_name, artist)
        if not lyrics_data or not lyrics_data.get('has_synced'):
            return await ctx.reply("❌ No synced lyrics found for the current song.")
        synced_lines = lyrics_data.get('synced_lines', [])
        if not synced_lines:
            return await ctx.reply("❌ No time-synced lyrics available for this song.")
        current_time, _ = self._get_current_progress(guild_id)
        current_line_idx = self._find_current_line(synced_lines, current_time)
        embed = self._build_live_lyrics_embed(track_name, artist, synced_lines, current_line_idx, current_time, current_track.get('duration', 0))
        await ctx.reply(embed=embed)
        if auto_update:
            if guild_id in self.live_lyrics_tasks:
                if not self.live_lyrics_tasks[guild_id].done():
                    self.live_lyrics_tasks[guild_id].cancel()
                del self.live_lyrics_tasks[guild_id]
            msg = await ctx.original_response()
            self.live_lyrics_tasks[guild_id] = asyncio.create_task(self._update_live_lyrics(msg, synced_lines, track_name, artist, current_track.get('duration', 0), voice_client, guild_id))

    def _find_current_line(self, synced_lines: list, current_time: float) -> int:
        if not synced_lines:
            return 0
        for i, line in enumerate(synced_lines):
            if line['time'] <= current_time:
                continue
            return max(0, i - 1)
        return len(synced_lines) - 1

    def _build_live_lyrics_embed(self, track_name, artist, synced_lines, current_line_idx, current_time, duration):
        total_lines = len(synced_lines)
        start_idx = max(0, current_line_idx - 2)
        end_idx = min(total_lines, current_line_idx + 3)
        lines_display = []
        for i in range(start_idx, end_idx):
            line = synced_lines[i]
            if i == current_line_idx:
                lines_display.append(f"> **{line['text']}**")
            else:
                lines_display.append(line['text'])
        description = "\n".join(lines_display) or "*Lyrics loading...*"
        embed = build(title=f"🎵 Live Lyrics: {track_name}", description=description, color=Config.COLOR_INFO, bot=self.bot)
        if artist:
            embed.add_field(name="Artist", value=artist, inline=True)
        embed.add_field(name="📌 Source", value="LRCLib", inline=True)
        current_time_formatted = self._format_duration(int(current_time))
        total_duration = self._format_duration(duration)
        embed.set_footer(text=f"⏱️ {current_time_formatted} / {total_duration} | Line {current_line_idx + 1}/{total_lines}")
        return embed

    async def _update_live_lyrics(self, message: discord.Message, synced_lines: list, track_name: str, artist: str, duration: int, voice_client, guild_id: int):
        try:
            total_lines = len(synced_lines)
            current_line_idx = 0
            update_counter = 0
            while True:
                if not voice_client or not voice_client.is_playing():
                    break
                current_track = self.now_playing.get(guild_id)
                if not current_track:
                    break
                current_track_name = current_track.get('title_clean') or current_track.get('title')
                if current_track_name != track_name:
                    break
                current_time, _ = self._get_current_progress(guild_id)
                new_idx = self._find_current_line(synced_lines, current_time)
                if new_idx != current_line_idx or update_counter % 2 == 0:
                    current_line_idx = new_idx
                    embed = self._build_live_lyrics_embed(track_name, artist, synced_lines, current_line_idx, current_time, duration)
                    try:
                        await message.edit(embed=embed)
                    except Exception:
                        break
                update_counter += 1
                await asyncio.sleep(0.5)
                if duration > 0 and current_time >= duration:
                    break
        except asyncio.CancelledError:
            raise
        except Exception as e:
            print(f"[Music] Live lyrics update error: {e}")
        finally:
            if guild_id in self.live_lyrics_tasks:
                del self.live_lyrics_tasks[guild_id]

    # ---------- Background tasks ----------
    @tasks.loop(seconds=10)
    async def auto_disconnect_loop(self):
        await self.bot.wait_until_ready()
        for guild in self.bot.guilds:
            voice_client = discord.utils.get(self.bot.voice_clients, guild=guild)
            if not voice_client or not voice_client.is_connected():
                continue
            if self.twenty_four_seven.get(guild.id, False):
                guild_id = guild.id
                if guild_id in self.disconnect_timers and not self.disconnect_timers[guild_id].done():
                    self.disconnect_timers[guild_id].cancel()
                self.disconnect_timers.pop(guild_id, None)
                continue
            members = [m for m in voice_client.channel.members if not m.bot]
            if len(members) == 0:
                guild_id = guild.id
                if guild_id not in self.disconnect_timers or self.disconnect_timers[guild_id].done():
                    self.disconnect_timers[guild_id] = asyncio.create_task(self._delayed_disconnect(guild_id))
            else:
                guild_id = guild.id
                if guild_id in self.disconnect_timers and not self.disconnect_timers[guild_id].done():
                    self.disconnect_timers[guild_id].cancel()
                self.disconnect_timers.pop(guild_id, None)

    async def _delayed_disconnect(self, guild_id: int):
        try:
            await asyncio.sleep(30)
            guild = self.bot.get_guild(guild_id)
            if not guild:
                return
            if self.twenty_four_seven.get(guild_id, False):
                return
            voice_client = discord.utils.get(self.bot.voice_clients, guild=guild)
            if not voice_client or not voice_client.is_connected():
                return
            if self.twenty_four_seven.get(guild_id, False):
                return
            members = [m for m in voice_client.channel.members if not m.bot]
            if len(members) == 0:
                print(f"[Music] Disconnecting from {guild.name} (empty for 30 seconds)")
                self.queues.pop(guild_id, None)
                self.now_playing.pop(guild_id, None)
                self.song_start_time.pop(guild_id, None)
                self.song_paused_time.pop(guild_id, None)
                self.song_paused_offset.pop(guild_id, None)
                self.current_sources.pop(guild_id, None)
                self.loop_modes.pop(guild_id, None)
                self.original_queues.pop(guild_id, None)
                if guild_id in self.live_lyrics_tasks:
                    if not self.live_lyrics_tasks[guild_id].done():
                        self.live_lyrics_tasks[guild_id].cancel()
                    del self.live_lyrics_tasks[guild_id]
                await voice_client.disconnect()
                print(f"[Music] Disconnected from {guild.name}")
        except asyncio.CancelledError:
            raise
        except Exception as e:
            print(f"[Music] Error in delayed disconnect: {e}")

    @tasks.loop(seconds=5)
    async def panel_update_loop(self):
        await self.bot.wait_until_ready()
        panel_items = list(self.panel_data.items())
        if not panel_items:
            return
        now = time.time()
        for guild_id, panel_info in panel_items:
            if guild_id in self._panel_error_cooldown:
                if now - self._panel_error_cooldown[guild_id] < 60:
                    continue
            guild = self.bot.get_guild(guild_id)
            if not guild:
                del self.panel_data[guild_id]
                self._save_guild_data(guild_id)
                continue
            message_id = panel_info.get("message_id")
            channel_id = panel_info.get("channel_id")
            if not message_id or not channel_id:
                del self.panel_data[guild_id]
                self._save_guild_data(guild_id)
                continue
            channel = guild.get_channel(channel_id)
            if not channel:
                del self.panel_data[guild_id]
                self._save_guild_data(guild_id)
                continue
            try:
                msg = await channel.fetch_message(message_id)
            except discord.NotFound:
                del self.panel_data[guild_id]
                self._save_guild_data(guild_id)
                continue
            except discord.Forbidden:
                del self.panel_data[guild_id]
                self._save_guild_data(guild_id)
                continue
            except discord.HTTPException as e:
                if e.status == 503:
                    print(f"[Music] Discord API temporarily unavailable for guild {guild_id}, skipping update")
                    self._panel_error_cooldown[guild_id] = now
                    continue
                else:
                    print(f"[Music] HTTP error {e.status} fetching panel for guild {guild_id}: {e}")
                    continue

            track = self.now_playing.get(guild_id)
            voice_client = discord.utils.get(self.bot.voice_clients, guild=guild)
            is_247_enabled = self.twenty_four_seven.get(guild_id, False)
            is_connected = voice_client and voice_client.is_connected()

            if not track or not is_connected:
                if not hasattr(self, '_last_state') or self._last_state.get(guild_id) != 'idle':
                    idle_embed = build(title="🎵 Music Player", description="No song is currently playing." if not is_connected else "Queue is empty.", color=Config.COLOR_INFO, bot=self.bot)
                    idle_embed.set_footer(text="🎵 Sparky Bot • Use /music play to start")
                    if is_247_enabled:
                        idle_embed.add_field(name="🔄 24/7 Mode", value="✅ **Enabled** - Bot will stay in voice channel", inline=False)
                    elif guild_id in self._247_approved_servers:
                        idle_embed.add_field(name="🔄 24/7 Mode", value="ℹ️ **Available** - Use `/music 247 enable` to activate", inline=False)
                    try:
                        await msg.edit(embed=idle_embed, view=MusicControlView(self, guild_id))
                    except Exception:
                        pass
                    if not hasattr(self, '_last_state'):
                        self._last_state = {}
                    self._last_state[guild_id] = 'idle'
                continue

            artist = track.get('artist')
            song = track.get('title_clean')
            if not artist or not song:
                if ' - ' in track.get('title', ''):
                    parts = track['title'].split(' - ', 1)
                    artist = parts[0].strip()
                    song = parts[1].strip()
                else:
                    artist = "Unknown Artist"
                    song = track.get('title', 'Unknown')

            current_time, duration = self._get_current_progress(guild_id)
            is_paused = voice_client.is_paused() if is_connected else False
            volume = self.volume_levels.get(guild_id, 100)

            state_hash = f"{artist}|{song}|{current_time//5}|{duration}|{is_paused}|{volume}|{is_247_enabled}"
            if not hasattr(self, '_last_state'):
                self._last_state = {}
            last_hash = self._last_state.get(f"{guild_id}_hash")
            last_update = self._last_state.get(f"{guild_id}_time", 0)
            time_since_update = time.time() - last_update
            should_update = (last_hash != state_hash) or (time_since_update > 30)

            if should_update:
                if duration > 0 and current_time > 0:
                    progress_bar = self._progress_bar(current_time, duration)
                    progress_text = f"`{self._format_duration(current_time)}` {progress_bar} `{self._format_duration(duration)}`"
                else:
                    progress_text = "🔴 LIVE"

                embed = build(title="🎵 Now Playing", description=f"**{song}** • *{artist}*", color=Config.COLOR_INFO)
                embed.add_field(name="Progress", value=progress_text, inline=False)
                embed.add_field(name="Artist", value=artist, inline=True)
                embed.add_field(name="Duration", value=self._format_duration(duration), inline=True)
                embed.add_field(name="Status", value="⏸️ Paused" if is_paused else "▶️ Playing", inline=True)
                embed.add_field(name="Volume", value=f"{volume}%", inline=True)
                queue = self.get_queue(guild_id)
                embed.add_field(name="Queue Length", value=f"{len(queue)} songs", inline=True)
                loop_mode = self.loop_modes.get(guild_id, 'off')
                loop_labels = {'off': 'Off', 'track': '🔁 Track', 'queue': '🔁 Queue'}
                embed.add_field(name="Loop Mode", value=loop_labels.get(loop_mode, 'Off'), inline=True)
                if is_247_enabled:
                    embed.add_field(name="🔄 24/7 Mode", value="✅ Enabled", inline=True)
                elif guild_id in self._247_approved_servers:
                    embed.add_field(name="🔄 24/7 Mode", value="ℹ️ Available - Use /music 247 enable", inline=True)
                if track.get('thumbnail'):
                    embed.set_thumbnail(url=track['thumbnail'])
                embed.set_footer(text="🎵 Sparky Bot • Updates every 5s")

                try:
                    control_view = MusicControlView(self, guild_id, is_paused=is_paused, loop_mode=loop_mode)
                    await msg.edit(embed=embed, view=control_view)
                    self._last_state[f"{guild_id}_hash"] = state_hash
                    self._last_state[f"{guild_id}_time"] = time.time()
                    self._last_state[guild_id] = 'playing'
                except discord.HTTPException as e:
                    if e.status == 429:
                        print(f"[Music] Panel update rate limited for guild {guild_id}, waiting...")
                        await asyncio.sleep(5)
                    else:
                        print(f"[Music] Panel update error: {e}")
                except Exception as e:
                    print(f"[Music] Panel update error: {e}")

    @panel_update_loop.before_loop
    async def before_panel_update_loop(self):
        await self.bot.wait_until_ready()
        self._last_state = {}

    # ---------- Voice channel status ----------
    async def _update_vc_status(self):
        await self.bot.wait_until_ready()
        while not self.bot.is_closed():
            try:
                for guild_id, track in self.now_playing.items():
                    if track:
                        guild = self.bot.get_guild(guild_id)
                        if not guild:
                            continue
                        voice_client = discord.utils.get(self.bot.voice_clients, guild=guild)
                        if voice_client and voice_client.is_connected():
                            if not self.status_enabled.get(guild_id, True):
                                continue
                            if voice_client.channel:
                                try:
                                    artist, song = self._get_artist_and_song(track)
                                    status_text = f"🎵 {artist} - {song}"
                                    if len(status_text) > 100:
                                        status_text = status_text[:97] + "..."
                                    await voice_client.channel.edit(status=status_text, reason="Music playback status update")
                                except discord.Forbidden:
                                    pass
                                except Exception as e:
                                    print(f"[Music] Failed to update VC status: {e}")
            except Exception as e:
                print(f"[Music] Status update error: {e}")
            await asyncio.sleep(5)

    # ---------- Voice state update ----------
    @commands.Cog.listener()
    async def on_voice_state_update(self, member: discord.Member, before: discord.VoiceState, after: discord.VoiceState):
        if member.id != self.bot.user.id:
            return
        voice_client = discord.utils.get(self.bot.voice_clients, guild=member.guild)
        if not voice_client or not voice_client.is_connected():
            return
        if self.twenty_four_seven.get(member.guild.id, False):
            guild_id = member.guild.id
            if guild_id in self.disconnect_timers and not self.disconnect_timers[guild_id].done():
                self.disconnect_timers[guild_id].cancel()
            self.disconnect_timers.pop(guild_id, None)
            return
        members = [m for m in voice_client.channel.members if not m.bot]
        if len(members) == 0:
            guild_id = member.guild.id
            if guild_id in self.disconnect_timers and not self.disconnect_timers[guild_id].done():
                self.disconnect_timers[guild_id].cancel()
            self.disconnect_timers[guild_id] = asyncio.create_task(self._delayed_disconnect(guild_id))
        else:
            guild_id = member.guild.id
            if guild_id in self.disconnect_timers and not self.disconnect_timers[guild_id].done():
                self.disconnect_timers[guild_id].cancel()
            self.disconnect_timers.pop(guild_id, None)

    # ---------- Channel cleaning ----------
    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild:
            return
        panel_info = self.panel_data.get(message.guild.id)
        if not panel_info:
            return
        if message.channel.id != panel_info.get("channel_id"):
            return
        if message.id == panel_info.get("message_id"):
            return

        is_music_command = False
        from utils.prefix_manager import get_prefixes
        prefixes = get_prefixes(message.guild.id)
        for p in prefixes:
            if message.content.startswith(p):
                cmd = message.content[len(p):].strip().split()[0].lower()
                if cmd in ["music", "play", "pause", "resume", "skip", "stop", "queue", "np", "nowplaying", "disconnect", "shuffle", "unshuffle", "loop", "remove", "clear", "volume"]:
                    is_music_command = True
                    break
        if not is_music_command:
            try:
                await message.delete()
                warn = await message.channel.send(f"{message.author.mention}, only music commands are allowed in this channel.", delete_after=3)
            except Exception:
                pass

    # ---------- SLASH COMMANDS ----------
    music = app_commands.Group(name="music", description="Music commands")

    @music.command(name="play", description="Play a song or add to queue")
    @app_commands.describe(query="Song name, YouTube URL, Spotify URL, or SoundCloud URL")
    async def music_play(self, interaction: discord.Interaction, query: str):
        await interaction.response.defer(ephemeral=True)
        await self._play(interaction, query)

    @music.command(name="pause", description="Pause the current song")
    async def music_pause(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        await self._pause(interaction)

    @music.command(name="resume", description="Resume the paused song")
    async def music_resume(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        await self._resume(interaction)

    @music.command(name="skip", description="Skip the current song")
    async def music_skip(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        await self._skip(interaction)

    @music.command(name="stop", description="Stop playback and clear the queue")
    async def music_stop(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        await self._stop(interaction)

    @music.command(name="queue", description="View the current queue")
    @app_commands.describe(page="Page number")
    async def music_queue(self, interaction: discord.Interaction, page: int = 1):
        await interaction.response.defer(ephemeral=True)
        await self._queue(interaction, page)

    @music.command(name="nowplaying", description="Show currently playing song with live progress")
    async def music_nowplaying(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        await self._nowplaying(interaction)

    @music.command(name="disconnect", description="Disconnect from voice channel")
    async def music_disconnect(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        await self._disconnect(interaction)

    @music.command(name="shuffle", description="Shuffle the queue")
    async def music_shuffle(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        await self._shuffle(interaction)

    @music.command(name="unshuffle", description="Restore the queue to its original order")
    async def music_unshuffle(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        await self._unshuffle(interaction)

    @music.command(name="loop", description="Toggle loop mode")
    @app_commands.choices(mode=[app_commands.Choice(name="Off", value="off"), app_commands.Choice(name="Track (loop current song)", value="track"), app_commands.Choice(name="Queue (loop all songs)", value="queue")])
    async def music_loop(self, interaction: discord.Interaction, mode: str):
        await interaction.response.defer(ephemeral=True)
        await self._loop(interaction, mode)

    @music.command(name="remove", description="Remove a song from the queue by position")
    @app_commands.describe(position="Position of the song to remove")
    async def music_remove(self, interaction: discord.Interaction, position: int):
        await interaction.response.defer(ephemeral=True)
        await self._remove(interaction, position)

    @music.command(name="clear", description="Clear the queue")
    async def music_clear(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        await self._clear(interaction)

    @music.command(name="volume", description="Set volume (1-200) - NO RESTART")
    @app_commands.describe(volume="Volume level (1-200)")
    async def music_volume(self, interaction: discord.Interaction, volume: int):
        await interaction.response.defer(ephemeral=True)
        await self._volume(interaction, volume)

    @music.command(name="vc", description="[ADMIN] Set the designated music voice channel")
    @app_commands.default_permissions(manage_channels=True)
    @app_commands.checks.has_permissions(manage_channels=True)
    @app_commands.describe(channel="Voice channel for music", drag_users="Automatically drag users to this VC")
    async def music_vc(self, interaction: discord.Interaction, channel: discord.VoiceChannel, drag_users: bool = True):
        if not interaction.user.guild_permissions.manage_channels:
            await interaction.response.send_message("❌ You are missing the following permissions: **Manage Channels**", ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        if not isinstance(channel, discord.VoiceChannel):
            return await self._send_response(interaction, "❌ Please select a **voice channel**.", ephemeral=True)
        if not channel.permissions_for(interaction.guild.me).view_channel or not channel.permissions_for(interaction.guild.me).connect:
            return await self._send_response(interaction, f"❌ I don't have permission to view/connect to {channel.mention}.", ephemeral=True)
        self.music_vc[interaction.guild_id] = {"channel_id": channel.id, "drag_users": drag_users}
        self._save_guild_data(interaction.guild_id)
        embed = build(title="🎵 Music VC Set", description=f"Music will now be played in {channel.mention}", color=Config.COLOR_OK, bot=self.bot)
        embed.add_field(name="🚀 Drag Users", value="Enabled" if drag_users else "Disabled", inline=True)
        await self._send_response(interaction, embed=embed, ephemeral=True)

    @music.command(name="removevc", description="[ADMIN] Remove the designated music voice channel")
    @app_commands.default_permissions(manage_channels=True)
    @app_commands.checks.has_permissions(manage_channels=True)
    async def music_remove_vc(self, interaction: discord.Interaction):
        if not interaction.user.guild_permissions.manage_channels:
            await interaction.response.send_message("❌ You need **Manage Channels**.", ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        if interaction.guild_id not in self.music_vc:
            return await self._send_response(interaction, "❌ No music VC has been set.", ephemeral=True)
        del self.music_vc[interaction.guild_id]
        self._save_guild_data(interaction.guild_id)
        await self._send_response(interaction, "✅ Music VC removed.", ephemeral=True)

    @music.command(name="vcinfo", description="[ADMIN] View the current music VC configuration")
    @app_commands.default_permissions(manage_channels=True)
    @app_commands.checks.has_permissions(manage_channels=True)
    async def music_vc_info(self, interaction: discord.Interaction):
        if not interaction.user.guild_permissions.manage_channels:
            await interaction.response.send_message("❌ You need **Manage Channels**.", ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        if interaction.guild_id not in self.music_vc:
            return await self._send_response(interaction, "ℹ️ No music VC has been set.", ephemeral=True)
        config = self.music_vc[interaction.guild_id]
        channel = interaction.guild.get_channel(config["channel_id"])
        embed = build(title="🎵 Music VC Configuration", color=Config.COLOR_INFO, bot=self.bot)
        embed.add_field(name="📌 Voice Channel", value=channel.mention if channel else "❌ Not found", inline=False)
        embed.add_field(name="🚀 Drag Users", value="✅ Enabled" if config.get("drag_users", True) else "❌ Disabled", inline=True)
        await self._send_response(interaction, embed=embed, ephemeral=True)

    @music.command(name="status", description="[ADMIN] Toggle VC status updates")
    @app_commands.default_permissions(manage_channels=True)
    @app_commands.checks.has_permissions(manage_channels=True)
    @app_commands.describe(enabled="Enable or disable status updates")
    async def music_status(self, interaction: discord.Interaction, enabled: bool = True):
        if not interaction.user.guild_permissions.manage_channels:
            await interaction.response.send_message("❌ You need **Manage Channels**.", ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        self.status_enabled[interaction.guild_id] = enabled
        self._save_guild_data(interaction.guild_id)
        embed = build(title="🎵 VC Status Updates", color=Config.COLOR_OK, bot=self.bot)
        embed.description = "✅ Enabled" if enabled else "❌ Disabled"
        await self._send_response(interaction, embed=embed, ephemeral=True)

    @music.command(name="247", description="[ADMIN] Enable 24/7 mode (bot stays in VC even when empty)")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    @app_commands.describe(enabled="Enable or disable 24/7 mode")
    async def music_247(self, interaction: discord.Interaction, enabled: bool = True):
        await interaction.response.defer(ephemeral=True)
        if interaction.guild_id not in self._247_approved_servers:
            return await self._send_response(interaction, "❌ This server is not approved for 24/7 mode.\nContact the bot owner to request approval.", ephemeral=True)
        voice_client = discord.utils.get(self.bot.voice_clients, guild=interaction.guild)
        if not voice_client or not voice_client.is_connected():
            return await self._send_response(interaction, "❌ I'm not in a voice channel. Play a song first.", ephemeral=True)
        if enabled:
            self.twenty_four_seven[interaction.guild_id] = True
            self._save_guild_data(interaction.guild_id)
            if interaction.guild_id in self.disconnect_timers:
                if not self.disconnect_timers[interaction.guild_id].done():
                    self.disconnect_timers[interaction.guild_id].cancel()
                del self.disconnect_timers[interaction.guild_id]
            embed = build(title="🔄 24/7 Mode Enabled", description="Bot stays in VC even when empty.", color=Config.COLOR_OK, bot=self.bot)
            await self._send_response(interaction, embed=embed, ephemeral=True)
        else:
            self.twenty_four_seven.pop(interaction.guild_id, None)
            self._save_guild_data(interaction.guild_id)
            embed = build(title="🔄 24/7 Mode Disabled", description="Bot will disconnect when empty.", color=Config.COLOR_INFO, bot=self.bot)
            await self._send_response(interaction, embed=embed, ephemeral=True)

    @music.command(name="247status", description="[ADMIN] Check the 24/7 mode status")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def music_247_status(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        is_enabled = self.twenty_four_seven.get(interaction.guild_id, False)
        is_approved = interaction.guild_id in self._247_approved_servers
        voice_client = discord.utils.get(self.bot.voice_clients, guild=interaction.guild)
        embed = build(title="🔄 24/7 Mode Status", color=Config.COLOR_INFO, bot=self.bot)
        embed.add_field(name="Status", value="✅ Enabled" if is_enabled else "❌ Disabled", inline=True)
        embed.add_field(name="Approved", value="✅ Yes" if is_approved else "❌ No", inline=True)
        embed.add_field(name="Connected", value=voice_client.channel.mention if voice_client else "Not connected", inline=True)
        await self._send_response(interaction, embed=embed, ephemeral=True)

    @music.command(name="panel", description="[ADMIN] Send the music control panel to a channel")
    @app_commands.default_permissions(manage_channels=True)
    @app_commands.checks.has_permissions(manage_channels=True)
    @app_commands.describe(channel="Channel to send the panel to (defaults to current)")
    async def music_panel(self, interaction: discord.Interaction, channel: discord.TextChannel = None):
        if not interaction.user.guild_permissions.manage_channels:
            await interaction.response.send_message("❌ You need **Manage Channels**.", ephemeral=True)
            return
        await interaction.response.defer(ephemeral=False)
        ch = channel or interaction.channel
        if interaction.guild_id in self.panel_data:
            try:
                old_info = self.panel_data[interaction.guild_id]
                old_channel = interaction.guild.get_channel(old_info.get("channel_id"))
                if old_channel:
                    old_msg = await old_channel.fetch_message(old_info.get("message_id"))
                    await old_msg.delete()
            except Exception:
                pass
            del self.panel_data[interaction.guild_id]
        embed = build(title="🎵 Music Player", description="No song is currently playing.", color=Config.COLOR_INFO, bot=self.bot)
        embed.set_footer(text="🎵 Sparky Bot • Use /music play to start")
        if self.twenty_four_seven.get(interaction.guild_id, False):
            embed.add_field(name="🔄 24/7 Mode", value="✅ Enabled", inline=True)
        elif interaction.guild_id in self._247_approved_servers:
            embed.add_field(name="🔄 24/7 Mode", value="ℹ️ Available - Use /music 247 enable", inline=True)
        msg = await ch.send(embed=embed, view=MusicControlView(self, interaction.guild_id))
        self.panel_data[interaction.guild_id] = {"message_id": msg.id, "channel_id": ch.id}
        self._save_guild_data(interaction.guild_id)
        await interaction.followup.send(f"✅ Music panel sent to {ch.mention}!", ephemeral=True)

    @music.command(name="removepanel", description="[ADMIN] Remove the music panel")
    @app_commands.default_permissions(manage_channels=True)
    @app_commands.checks.has_permissions(manage_channels=True)
    async def music_remove_panel(self, interaction: discord.Interaction):
        if not interaction.user.guild_permissions.manage_channels:
            await interaction.response.send_message("❌ You need **Manage Channels**.", ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        if interaction.guild_id not in self.panel_data:
            return await self._send_response(interaction, "❌ No music panel found.", ephemeral=True)
        panel_info = self.panel_data[interaction.guild_id]
        channel = interaction.guild.get_channel(panel_info.get("channel_id"))
        if channel:
            try:
                msg = await channel.fetch_message(panel_info.get("message_id"))
                await msg.delete()
            except Exception:
                pass
        del self.panel_data[interaction.guild_id]
        self._save_guild_data(interaction.guild_id)
        await self._send_response(interaction, "✅ Music panel removed.", ephemeral=True)

    @music.command(name="lyrics", description="Fetch lyrics for the currently playing song (LRCLib)")
    @app_commands.describe(track="Track name (optional, uses current song if not provided)", artist="Artist name (optional)")
    async def music_lyrics(self, interaction: discord.Interaction, track: str = None, artist: str = None):
        await interaction.response.defer(ephemeral=True)
        await self._lyrics(interaction, track, artist)

    @music.command(name="livelyrics", description="Show live, time-synced lyrics for the current song (LRCLib)")
    @app_commands.describe(auto_update="Automatically update the message with current lyrics line (True/False)")
    async def music_live_lyrics(self, interaction: discord.Interaction, auto_update: bool = True):
        await interaction.response.defer(ephemeral=True)
        guild_id = interaction.guild_id
        current_track = self.now_playing.get(guild_id)
        if not current_track:
            return await self._send_response(interaction, "❌ No song is currently playing.", ephemeral=True)
        voice_client = discord.utils.get(self.bot.voice_clients, guild=interaction.guild)
        if not voice_client or not voice_client.is_playing():
            return await self._send_response(interaction, "❌ No song is currently playing.", ephemeral=True)
        artist, track_name = self._get_artist_and_song(current_track)
        lyrics_data = await self.fetch_lyrics(track_name, artist)
        if not lyrics_data or not lyrics_data.get('has_synced'):
            return await self._send_response(interaction, "❌ No synced lyrics found for the current song.", ephemeral=True)
        synced_lines = lyrics_data.get('synced_lines', [])
        if not synced_lines:
            return await self._send_response(interaction, "❌ No time-synced lyrics available for this song.", ephemeral=True)
        current_time, _ = self._get_current_progress(guild_id)
        current_line_idx = self._find_current_line(synced_lines, current_time)
        embed = self._build_live_lyrics_embed(track_name, artist, synced_lines, current_line_idx, current_time, current_track.get('duration', 0))
        await self._send_response(interaction, embed=embed, ephemeral=True)
        if auto_update:
            if guild_id in self.live_lyrics_tasks:
                if not self.live_lyrics_tasks[guild_id].done():
                    self.live_lyrics_tasks[guild_id].cancel()
                del self.live_lyrics_tasks[guild_id]
            msg = await interaction.original_response()
            self.live_lyrics_tasks[guild_id] = asyncio.create_task(self._update_live_lyrics(msg, synced_lines, track_name, artist, current_track.get('duration', 0), voice_client, guild_id))

    # ---------- PREFIX COMMANDS ----------
    @commands.command(name="music")
    async def p_music(self, ctx, action: str = None, *, args: str = None):
        if not action:
            return await ctx.reply("Usage: `//music play|pause|resume|skip|stop|queue|nowplaying|disconnect|shuffle|unshuffle|loop|remove|clear|volume|vc|removevc|vcinfo|status|247|247status|panel|removepanel|lyrics|livelyrics`")

        if action.lower() == "play":
            if not args:
                return await ctx.reply("Usage: `//music play <song or URL>`")
            await self._play(ctx, args)

        elif action.lower() == "pause":
            await self._pause(ctx)

        elif action.lower() == "resume":
            await self._resume(ctx)

        elif action.lower() == "skip":
            await self._skip(ctx)

        elif action.lower() == "stop":
            await self._stop(ctx)

        elif action.lower() == "queue":
            page = 1
            if args and args.isdigit():
                page = int(args)
            await self._queue(ctx, page)

        elif action.lower() in ("nowplaying", "np"):
            await self._nowplaying(ctx)

        elif action.lower() == "disconnect":
            await self._disconnect(ctx)

        elif action.lower() == "shuffle":
            await self._shuffle(ctx)

        elif action.lower() == "unshuffle":
            await self._unshuffle(ctx)

        elif action.lower() == "loop":
            mode = args or "off"
            if mode not in ["off", "track", "queue"]:
                return await ctx.reply("❌ Invalid mode. Options: off, track, queue")
            await self._loop(ctx, mode)

        elif action.lower() == "remove":
            if not args or not args.isdigit():
                return await ctx.reply("Usage: `//music remove <position>`")
            await self._remove(ctx, int(args))

        elif action.lower() == "clear":
            await self._clear(ctx)

        elif action.lower() == "volume":
            if not args or not args.isdigit():
                return await ctx.reply("Usage: `//music volume <1-200>`")
            await self._volume(ctx, int(args))

        elif action.lower() == "vc":
            parts = args.split() if args else []
            if len(parts) < 1:
                return await ctx.reply("Usage: `//music vc #voice-channel [drag:true/false]`")
            channel = discord.utils.get(ctx.guild.voice_channels, name=parts[0]) or discord.utils.get(ctx.guild.voice_channels, mention=parts[0])
            if not channel:
                return await ctx.reply(f"❌ Voice channel `{parts[0]}` not found.")
            drag = True
            if len(parts) > 1:
                drag = parts[1].lower() in ("true", "yes", "1")
            await self._vc(ctx, channel, drag)

        elif action.lower() == "removevc":
            await self._remove_vc(ctx)

        elif action.lower() == "vcinfo":
            await self._vc_info(ctx)

        elif action.lower() == "status":
            enabled = True
            if args:
                enabled = args.lower() in ("true", "yes", "1", "enable")
            await self._status(ctx, enabled)

        elif action.lower() == "247":
            if not args:
                return await ctx.reply("Usage: `//music 247 enable|disable`")
            enabled = args.lower() in ("true", "yes", "1", "enable")
            await self._247(ctx, enabled)

        elif action.lower() == "247status":
            await self._247_status(ctx)

        elif action.lower() == "panel":
            channel = None
            if args:
                channel = discord.utils.get(ctx.guild.text_channels, name=args) or discord.utils.get(ctx.guild.text_channels, mention=args)
            await self._panel(ctx, channel)

        elif action.lower() == "removepanel":
            await self._remove_panel(ctx)

        elif action.lower() == "lyrics":
            parts = args.split() if args else []
            track = None
            artist = None
            if len(parts) >= 1:
                track = parts[0]
            if len(parts) >= 2:
                artist = " ".join(parts[1:])
            await self._lyrics(ctx, track, artist)

        elif action.lower() == "livelyrics":
            auto = True
            if args:
                auto = args.lower() in ("true", "yes", "1", "auto")
            await self._live_lyrics(ctx, auto)

        else:
            await ctx.reply(f"❌ Unknown action `{action}`. Available: play, pause, resume, skip, stop, queue, nowplaying, disconnect, shuffle, unshuffle, loop, remove, clear, volume, vc, removevc, vcinfo, status, 247, 247status, panel, removepanel, lyrics, livelyrics")

    # ---------- Error handler ----------
    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            missing = ", ".join(p.replace("_", " ").title() for p in error.missing_permissions)
            await interaction.response.send_message(f"❌ You are missing the following permissions: **{missing}**", ephemeral=True)
            return
        if isinstance(error, app_commands.MissingRole):
            await interaction.response.send_message("❌ You are missing the required role to use this command.", ephemeral=True)
            return
        if isinstance(error, app_commands.MissingAnyRole):
            await interaction.response.send_message("❌ You are missing one of the required roles to use this command.", ephemeral=True)
            return
        if isinstance(error, app_commands.BotMissingPermissions):
            missing = ", ".join(p.replace("_", " ").title() for p in error.missing_permissions)
            await interaction.response.send_message(f"❌ I am missing the following permissions: **{missing}**", ephemeral=True)
            return
        print(f"[Music] Error: {error}")
        try:
            await interaction.response.send_message(f"❌ An error occurred: {str(error)[:100]}", ephemeral=True)
        except discord.InteractionResponded:
            await interaction.followup.send(f"❌ An error occurred: {str(error)[:100]}", ephemeral=True)

async def setup(bot):
    cog = Music(bot)
    await bot.add_cog(cog)