import discord
from discord.ext import commands
from discord import app_commands
import asyncio
import re
import time
from datetime import datetime, timezone
from config import Config
from utils.embed import build
from utils.theme import Theme
from utils.emojis import Emojis
from utils.data import load, save

APP_FILE = "applications.json"

QUESTION_TYPES = [
    "short_answer", "long_answer", "multiple_choice", "dropdown",
    "numeric", "range", "yes_no", "paragraph", "url",
]

TYPE_LABELS = {
    "short_answer":    "Short Answer",
    "long_answer":     "Long Answer",
    "multiple_choice": "Multiple Choice",
    "dropdown":        "Dropdown",
    "numeric":         "Numeric Only",
    "range":           "Range (min–max)",
    "yes_no":          "Yes / No",
    "paragraph":       "Paragraph",
    "url":             "URL",
}

DEFAULT_COOLDOWN = 300

_submission_times: dict[tuple, float] = {}
_active_sessions:  set[tuple]         = set()

def _load_guild(guild_id: int) -> dict:
    data = load(APP_FILE)
    return data.get(str(guild_id), {})

def _save_guild(guild_id: int, guild_data: dict):
    data = load(APP_FILE)
    data[str(guild_id)] = guild_data
    save(APP_FILE, data)

def _get_app(guild_id: int, app_name: str) -> dict | None:
    return _load_guild(guild_id).get(app_name.lower())

def _save_app(guild_id: int, app_name: str, app_data: dict):
    gd = _load_guild(guild_id)
    gd[app_name.lower()] = app_data
    _save_guild(guild_id, gd)

def _delete_app(guild_id: int, app_name: str) -> bool:
    gd = _load_guild(guild_id)
    if app_name.lower() in gd:
        del gd[app_name.lower()]
        _save_guild(guild_id, gd)
        return True
    return False

def _list_apps(guild_id: int) -> list[str]:
    return list(_load_guild(guild_id).keys())

def _check_cooldown(guild_id: int, user_id: int, app_name: str) -> float | None:
    app = _get_app(guild_id, app_name)
    cooldown = app.get("cooldown", DEFAULT_COOLDOWN) if app else DEFAULT_COOLDOWN
    key = (guild_id, user_id, app_name)
    last = _submission_times.get(key)
    if last is None:
        return None
    remaining = cooldown - (time.time() - last)
    return remaining if remaining > 0 else None

def parse_duration(text: str) -> int:
    text = text.strip().lower()
    if not text:
        raise ValueError("Empty duration string")
    units = {
        "month":  30 * 24 * 3600,
        "months": 30 * 24 * 3600,
        "week":   7 * 24 * 3600,
        "weeks":  7 * 24 * 3600,
        "day":    24 * 3600,
        "days":   24 * 3600,
        "hour":   3600,
        "hours":  3600,
        "minute": 60,
        "minutes":60,
        "second": 1,
        "seconds":1,
        "s":      1,
        "m":      60,
        "h":      3600,
        "d":      24 * 3600,
        "w":      7 * 24 * 3600,
    }
    tokens = re.findall(r"([\d.]+)\s*([a-zA-Z]+)", text)
    total_seconds = 0
    found_unit = False
    for number_str, unit_str in tokens:
        number = float(number_str)
        if number < 0:
            raise ValueError("Negative values are not allowed")
        unit_str = unit_str.strip().lower()
        if unit_str.endswith('s') and unit_str not in ('months', 'weeks', 'days', 'hours', 'minutes', 'seconds'):
            unit_str = unit_str[:-1]
        if unit_str in units:
            total_seconds += int(number * units[unit_str])
            found_unit = True
        else:
            raise ValueError(f"Unknown time unit: '{unit_str}'")
    if not found_unit:
        try:
            total_seconds = int(text)
        except ValueError:
            raise ValueError(f"Invalid duration: '{text}'")
        if total_seconds < 0:
            raise ValueError("Negative duration not allowed")
    return max(0, total_seconds)

def _ok(title: str, desc: str = "") -> discord.Embed:
    return build(title=title, description=desc or None, color=Theme.COLOR_SUCCESS, emoji=Emojis.TICK)

def _err(desc: str) -> discord.Embed:
    return build(title="Error", description=desc, color=Theme.COLOR_ERROR, emoji=Emojis.WRONG)

def _info(title: str, desc: str = "") -> discord.Embed:
    return build(title=title, description=desc or None, color=Theme.COLOR_INFO, emoji=Emojis.STAR)

def _word_count(text: str) -> int:
    return len(text.split())

def _validate_answer(answer: str, question: dict) -> str | None:
    qtype = question["type"]
    answer = answer.strip()
    if qtype == "short_answer":
        min_c = question.get("min_chars", 1)
        max_c = question.get("max_chars", 200)
        min_w = question.get("min_words")
        max_w = question.get("max_words")
        if len(answer) < min_c:
            return f"Answer too short (min {min_c} characters)."
        if len(answer) > max_c:
            return f"Answer too long (max {max_c} characters)."
        if min_w and _word_count(answer) < min_w:
            return f"Needs at least {min_w} words."
        if max_w and _word_count(answer) > max_w:
            return f"Too long (max {max_w} words)."
    elif qtype in ("long_answer", "paragraph"):
        min_c = question.get("min_chars", 1)
        max_c = question.get("max_chars", 4000)
        min_w = question.get("min_words")
        max_w = question.get("max_words")
        if len(answer) < min_c:
            return f"Answer too short (min {min_c} characters)."
        if len(answer) > max_c:
            return f"Answer too long (max {max_c} characters)."
        if min_w and _word_count(answer) < min_w:
            return f"Needs at least {min_w} words."
        if max_w and _word_count(answer) > max_w:
            return f"Too long (max {max_w} words)."
    elif qtype == "numeric":
        if not answer.lstrip("-").isdigit():
            return "Answer must be a whole number."
    elif qtype == "range":
        try:
            val = float(answer)
        except ValueError:
            return "Answer must be a number."
        rmin = question.get("range_min")
        rmax = question.get("range_max")
        if rmin is not None and val < rmin:
            return f"Value must be at least {rmin}."
        if rmax is not None and val > rmax:
            return f"Value must be at most {rmax}."
    elif qtype == "yes_no":
        if answer.lower() not in ("yes", "no", "y", "n"):
            return "Answer must be Yes or No."
    elif qtype == "url":
        if not re.match(r"^https?://\S+\.\S+", answer):
            return "Must be a valid URL starting with http:// or https://"
    return None

class AddQuestionModal(discord.ui.Modal, title="Add Question"):
    q_text = discord.ui.TextInput(label="Question text", placeholder="What is your question?", required=True, max_length=300)
    q_type = discord.ui.TextInput(label="Type", placeholder="short | long | mcq | dropdown | numeric | range | yes_no | paragraph | url", required=True, max_length=30)
    q_options = discord.ui.TextInput(label="Options (MCQ/Dropdown, comma separated)", placeholder="Option A, Option B, Option C", required=False, max_length=500)
    q_constraints = discord.ui.TextInput(label="Constraints (key:value pairs)", placeholder="min_chars:10, max_chars:200, range_min:1, range_max:100", required=False, max_length=300)
    q_required = discord.ui.TextInput(label="Required? (yes/no)", placeholder="yes", required=True, max_length=3, default="yes")

    def __init__(self, app_name: str, guild_id: int):
        super().__init__()
        self.app_name = app_name
        self.guild_id = guild_id

    async def on_submit(self, interaction: discord.Interaction):
        try:
            raw_type = self.q_type.value.strip().lower().replace(" ", "_").replace("-", "_")
            aliases = {
                "short": "short_answer",
                "long": "long_answer",
                "mcq": "multiple_choice",
                "mc": "multiple_choice",
                "multiple": "multiple_choice",
                "drop": "dropdown",
                "num": "numeric",
                "number": "numeric",
                "yesno": "yes_no",
                "bool": "yes_no",
                "para": "paragraph",
                "link": "url",
            }
            qtype = aliases.get(raw_type, raw_type)
            if qtype not in QUESTION_TYPES:
                return await interaction.response.send_message(embed=_err(f"Unknown type `{raw_type}`. Valid: {', '.join(QUESTION_TYPES)}"), ephemeral=True)
            options = []
            if self.q_options.value.strip():
                options = [o.strip() for o in self.q_options.value.split(",") if o.strip()]
            if qtype == "multiple_choice" and not (2 <= len(options) <= 5):
                return await interaction.response.send_message(embed=_err("Multiple choice requires 2–5 options."), ephemeral=True)
            if qtype == "dropdown" and not (2 <= len(options) <= 25):
                return await interaction.response.send_message(embed=_err("Dropdown requires 2–25 options."), ephemeral=True)
            constraints = {}
            for part in self.q_constraints.value.split(","):
                part = part.strip()
                if ":" in part:
                    k, v = part.split(":", 1)
                    try:
                        constraints[k.strip()] = int(v.strip()) if "." not in v else float(v.strip())
                    except ValueError:
                        constraints[k.strip()] = v.strip()
            question = {
                "text": self.q_text.value.strip(),
                "type": qtype,
                "options": options,
                "required": self.q_required.value.strip().lower() not in ("no", "n", "false"),
                **constraints,
            }
            app = _get_app(self.guild_id, self.app_name)
            if app is None:
                return await interaction.response.send_message(embed=_err("Application not found."), ephemeral=True)
            app.setdefault("questions", []).append(question)
            _save_app(self.guild_id, self.app_name, app)
            q_num = len(app["questions"])
            await interaction.response.send_message(embed=_ok(f"Question #{q_num} Added", f"**{question['text']}**\nType: `{TYPE_LABELS.get(qtype, qtype)}`" + (f"\nOptions: {', '.join(options)}" if options else "")), ephemeral=True)
        except Exception as e:
            print(f"[Application] Error in AddQuestionModal: {e}")
            await interaction.response.send_message(embed=_err(f"An error occurred: {str(e)[:100]}"), ephemeral=True)

class EditQuestionModal(discord.ui.Modal, title="Edit Question"):
    q_text = discord.ui.TextInput(label="New question text (blank = keep)", required=False, max_length=300)
    q_options = discord.ui.TextInput(label="New options, comma separated (blank=keep)", required=False, max_length=500)
    q_constraints = discord.ui.TextInput(label="New constraints (blank = keep)", required=False, max_length=300)
    q_required = discord.ui.TextInput(label="Required? yes/no (blank = keep)", required=False, max_length=3)

    def __init__(self, app_name: str, guild_id: int, q_index: int):
        super().__init__()
        self.app_name = app_name
        self.guild_id = guild_id
        self.q_index = q_index

    async def on_submit(self, interaction: discord.Interaction):
        try:
            app = _get_app(self.guild_id, self.app_name)
            if not app or self.q_index >= len(app.get("questions", [])):
                return await interaction.response.send_message(embed=_err("Question not found."), ephemeral=True)
            q = app["questions"][self.q_index]
            if self.q_text.value.strip():
                q["text"] = self.q_text.value.strip()
            if self.q_options.value.strip():
                q["options"] = [o.strip() for o in self.q_options.value.split(",") if o.strip()]
            for part in self.q_constraints.value.split(","):
                if ":" in part:
                    k, v = part.split(":", 1)
                    try:
                        q[k.strip()] = int(v.strip()) if "." not in v else float(v.strip())
                    except ValueError:
                        q[k.strip()] = v.strip()
            if self.q_required.value.strip():
                q["required"] = self.q_required.value.strip().lower() not in ("no", "n", "false")
            app["questions"][self.q_index] = q
            _save_app(self.guild_id, self.app_name, app)
            await interaction.response.send_message(embed=_ok("Question Updated", q["text"]), ephemeral=True)
        except Exception as e:
            print(f"[Application] Error in EditQuestionModal: {e}")
            await interaction.response.send_message(embed=_err(f"An error occurred: {str(e)[:100]}"), ephemeral=True)

class TextAnswerModal(discord.ui.Modal):
    answer = discord.ui.TextInput(label="Your answer", style=discord.TextStyle.paragraph, required=True, max_length=4000)

    def __init__(self, question: dict, q_num: int, total: int):
        prefix = f"Q{q_num}/{total}: "
        max_q = 45 - len(prefix)
        q_text = question["text"].replace('\n', ' ')[:max_q]
        super().__init__(title=f"{prefix}{q_text}")
        self.question = question
        self.given_answer = None
        qtype = question["type"]
        if qtype == "short_answer":
            self.answer.style = discord.TextStyle.short
            self.answer.max_length = question.get("max_chars", 200)
            self.answer.placeholder = f"Short answer (max {question.get('max_chars', 200)} chars)"
        elif qtype in ("long_answer", "paragraph"):
            self.answer.style = discord.TextStyle.paragraph
            self.answer.max_length = question.get("max_chars", 4000)
            self.answer.placeholder = "Detailed answer..."
        elif qtype == "numeric":
            self.answer.style = discord.TextStyle.short
            self.answer.max_length = 20
            self.answer.placeholder = "Numbers only"
        elif qtype == "range":
            self.answer.style = discord.TextStyle.short
            self.answer.max_length = 20
            self.answer.placeholder = f"Enter a number between {question.get('range_min', '')} and {question.get('range_max', '')}"
        elif qtype == "url":
            self.answer.style = discord.TextStyle.short
            self.answer.max_length = 500
            self.answer.placeholder = "https://..."
        if not question["required"]:
            self.answer.required = False
            self.answer.placeholder = (self.answer.placeholder or "") + " (optional)"

    async def on_submit(self, interaction: discord.Interaction):
        self.given_answer = self.answer.value.strip()
        self.interaction = interaction
        await interaction.response.defer(ephemeral=True)
        self.stop()

class MCQView(discord.ui.View):
    def __init__(self, options: list[str]):
        super().__init__(timeout=120)
        self.chosen = None
        for opt in options[:5]:
            btn = discord.ui.Button(label=opt, style=discord.ButtonStyle.secondary)
            btn.callback = self._make_cb(opt)
            self.add_item(btn)

    def _make_cb(self, option: str):
        async def cb(interaction: discord.Interaction):
            self.chosen = option
            self.stop()
            for child in self.children:
                child.disabled = True
                if hasattr(child, "label") and child.label == option:
                    child.style = discord.ButtonStyle.primary
            await interaction.response.edit_message(view=self)
        return cb

class DropdownSelect(discord.ui.Select):
    def __init__(self, options: list[str]):
        super().__init__(placeholder="Choose an option…", options=[discord.SelectOption(label=o, value=o) for o in options[:25]])
        self.chosen = None

    async def callback(self, interaction: discord.Interaction):
        self.chosen = self.values[0]
        self.view.chosen = self.chosen
        self.view.stop()
        self.disabled = True
        await interaction.response.edit_message(view=self.view)

class DropdownView(discord.ui.View):
    def __init__(self, options: list[str]):
        super().__init__(timeout=120)
        self.chosen = None
        self.add_item(DropdownSelect(options))

class YesNoView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=120)
        self.chosen = None

    @discord.ui.button(label="Yes", style=discord.ButtonStyle.success)
    async def yes(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.chosen = "Yes"
        self.stop()
        for c in self.children:
            c.disabled = True
        button.style = discord.ButtonStyle.primary
        await interaction.response.edit_message(view=self)

    @discord.ui.button(label="No", style=discord.ButtonStyle.danger)
    async def no(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.chosen = "No"
        self.stop()
        for c in self.children:
            c.disabled = True
        button.style = discord.ButtonStyle.primary
        await interaction.response.edit_message(view=self)

def _fmt_duration(seconds: float) -> str:
    m, s = divmod(int(seconds), 60)
    return f"{m}m {s}s" if m else f"{s}s"

def _build_constraint_hint(q: dict) -> str:
    hints = []
    for k, label in [
        ("min_chars", "Min chars"),
        ("max_chars", "Max chars"),
        ("min_words", "Min words"),
        ("max_words", "Max words"),
        ("range_min", "Min value"),
        ("range_max", "Max value"),
    ]:
        if k in q:
            hints.append(f"{label}: {q[k]}")
    return " | ".join(hints) if hints else ""

class ApplicationSessionView(discord.ui.View):
    def __init__(self, session, questions, member):
        super().__init__(timeout=600)
        self.session = session
        self.questions = questions
        self.member = member
        self.answers = [None] * len(questions)
        self.index = 0
        self.started = time.time()
        self.message = None
        self._update_buttons()

    def _update_buttons(self):
        total = len(self.questions)
        self.btn_first.disabled = self.index == 0
        self.btn_prev.disabled = self.index == 0
        self.btn_next.disabled = self.index == total - 1
        self.btn_last.disabled = self.index == total - 1
        unanswered_required = [i for i, q in enumerate(self.questions) if q.get("required", True) and not self.answers[i]]
        self.btn_submit.disabled = bool(unanswered_required)

    def build_embed(self) -> discord.Embed:
        total = len(self.questions)
        q = self.questions[self.index]
        answered = sum(1 for a in self.answers if a)
        elapsed = _fmt_duration(time.time() - self.started)
        embed = build(title=f"📋 {self.session.app_name.title()} • Question {self.index + 1}/{total}", color=Config.COLOR_INFO, bot=self.bot)
        progress_text = f"**Progress:** {self.index + 1}/{total} • {answered}/{total} answered"
        embed.description = progress_text
        embed.add_field(name="❓ Question", value=q["text"], inline=False)
        type_label = TYPE_LABELS.get(q["type"], q["type"])
        type_str = f"**Type:** {type_label}"
        if q.get("options"):
            type_str += f"\n**Options:** {', '.join(q['options'])}"
        embed.add_field(name="ℹ️ Info", value=type_str, inline=True)
        hint = _build_constraint_hint(q)
        if hint:
            embed.add_field(name="📏 Constraints", value=hint, inline=True)
        embed.add_field(name="Required", value="Yes ✅" if q.get("required", True) else "No (optional) ⏭️", inline=True)
        current = self.answers[self.index]
        embed.add_field(name="✏️ Your Answer", value=current if current else "*Not answered yet*", inline=False)
        embed.set_footer(text=f"⏱️ Time elapsed: {elapsed} | Use ◀️ ▶️ to navigate")
        return embed

    async def _refresh(self, interaction: discord.Interaction | None = None):
        self._update_buttons()
        embed = self.build_embed()
        if interaction:
            try:
                if interaction.response.is_done():
                    await interaction.edit_original_response(embed=embed, view=self)
                else:
                    await interaction.response.edit_message(embed=embed, view=self)
            except discord.InteractionResponded:
                await interaction.edit_original_response(embed=embed, view=self)
        elif self.message:
            try:
                await self.message.edit(embed=embed, view=self)
            except Exception:
                pass

    @discord.ui.button(emoji="⏮️", style=discord.ButtonStyle.secondary, row=0)
    async def btn_first(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.member.id:
            return await interaction.response.send_message("Not your application.", ephemeral=True)
        self.index = 0
        await self._refresh(interaction)

    @discord.ui.button(emoji="◀️", style=discord.ButtonStyle.secondary, row=0)
    async def btn_prev(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.member.id:
            return await interaction.response.send_message("Not your application.", ephemeral=True)
        if self.index > 0:
            self.index -= 1
        await self._refresh(interaction)

    @discord.ui.button(emoji="▶️", style=discord.ButtonStyle.secondary, row=0)
    async def btn_next(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.member.id:
            return await interaction.response.send_message("Not your application.", ephemeral=True)
        if self.index < len(self.questions) - 1:
            self.index += 1
        await self._refresh(interaction)

    @discord.ui.button(emoji="⏭️", style=discord.ButtonStyle.secondary, row=0)
    async def btn_last(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.member.id:
            return await interaction.response.send_message("Not your application.", ephemeral=True)
        self.index = len(self.questions) - 1
        await self._refresh(interaction)

    @discord.ui.button(label="✏️ Answer", style=discord.ButtonStyle.primary, row=1)
    async def btn_answer(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.member.id:
            return await interaction.response.send_message("Not your application.", ephemeral=True)
        q = self.questions[self.index]
        qtype = q["type"]
        q_title = f"Q{self.index + 1}: {q['text'][:40]}"
        if qtype == "multiple_choice":
            view = MCQView(q.get("options", []))
            await interaction.response.defer(ephemeral=True)
            await interaction.followup.send(embed=build(title=q_title, description="Select one of the options below:", color=Config.COLOR_MOD, bot=self.bot), view=view, ephemeral=True)
            await view.wait()
            if view.chosen:
                self.answers[self.index] = view.chosen
                await self._refresh(interaction)
            return
        elif qtype == "dropdown":
            view = DropdownView(q.get("options", []))
            await interaction.response.defer(ephemeral=True)
            await interaction.followup.send(embed=build(title=q_title, description="Pick from the dropdown:", color=Config.COLOR_MOD, bot=self.bot), view=view, ephemeral=True)
            await view.wait()
            if view.chosen:
                self.answers[self.index] = view.chosen
                await self._refresh(interaction)
            return
        elif qtype == "yes_no":
            view = YesNoView()
            await interaction.response.defer(ephemeral=True)
            await interaction.followup.send(embed=build(title=q_title, color=Config.COLOR_MOD, bot=self.bot), view=view, ephemeral=True)
            await view.wait()
            if view.chosen:
                self.answers[self.index] = view.chosen
                await self._refresh(interaction)
            return
        else:
            modal = TextAnswerModal(q, self.index + 1, len(self.questions))
            await interaction.response.send_modal(modal)
            await modal.wait()
            if modal.given_answer:
                err = _validate_answer(modal.given_answer, q)
                if err:
                    await self._send_error(modal.interaction, err)
                else:
                    self.answers[self.index] = modal.given_answer
                    await self._refresh(interaction)

    @discord.ui.button(label="🗑️ Clear", style=discord.ButtonStyle.secondary, row=1)
    async def btn_clear(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.member.id:
            return await interaction.response.send_message("Not your application.", ephemeral=True)
        self.answers[self.index] = None
        await self._refresh(interaction)

    @discord.ui.button(label="📨 Submit", style=discord.ButtonStyle.success, row=2)
    async def btn_submit(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.member.id:
            return await interaction.response.send_message("Not your application.", ephemeral=True)
        missing = [i + 1 for i, q in enumerate(self.questions) if q.get("required", True) and not self.answers[i]]
        if missing:
            return await interaction.response.send_message(embed=build(description=f"⚠️ Please answer required question(s): **{', '.join(f'Q{n}' for n in missing)}**", color=Config.COLOR_ERR, bot=self.bot), ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        self.stop()
        self.session.answers = [{"question": q["text"], "answer": a or "Skipped"} for q, a in zip(self.questions, self.answers)]
        self.session.elapsed = _fmt_duration(time.time() - self.started)
        self.session._submit_event.set()

    @discord.ui.button(label="✖ Cancel", style=discord.ButtonStyle.danger, row=2)
    async def btn_cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.member.id:
            return await interaction.response.send_message("Not your application.", ephemeral=True)
        self.stop()
        self.session._cancel_event.set()
        await interaction.response.edit_message(embed=build(title="Application Cancelled", description="Your session has been cancelled. You can apply again later.", color=Config.COLOR_ERR, bot=self.bot), view=None)
        self.stop()

    async def _send_error(self, interaction: discord.Interaction, msg: str):
        try:
            await interaction.followup.send(embed=build(description="⚠️ " + msg, color=Config.COLOR_ERR, bot=self.bot), ephemeral=True)
        except Exception:
            pass

    async def on_timeout(self):
        self.session._cancel_event.set()
        if self.message:
            try:
                await self.message.edit(embed=build(title="⏰ Session Timed Out", description="Your application session expired due to inactivity.", color=Config.COLOR_ERR, bot=self.bot), view=None)
            except Exception:
                pass

class ApplicationSession:
    def __init__(self, bot: commands.Bot, interaction: discord.Interaction, app: dict, app_name: str):
        self.bot = bot
        self.interaction = interaction
        self.app = app
        self.app_name = app_name
        self.answers: list[dict] = []
        self.elapsed = "0s"
        self._submit_event = asyncio.Event()
        self._cancel_event = asyncio.Event()

    async def run(self):
        questions = self.app.get("questions", [])
        session_key = (self.interaction.guild_id, self.interaction.user.id, self.app_name)
        if not questions:
            await self.interaction.followup.send(embed=_err("This application has no questions yet."), ephemeral=True)
            return
        _active_sessions.add(session_key)
        try:
            view = ApplicationSessionView(self, questions, self.interaction.user)
            intro = build(title=f"📋 {self.app_name.title()} Application", description=((self.app.get("description", "") + "\n\n" if self.app.get("description") else "") + f"You have **{len(questions)}** question(s).\n\nUse **◀️ ▶️** to navigate, **✏️ Answer** to respond to each question.\nWhen all required questions are answered the **Submit** button will unlock.\nOnly you can see this message."), color=Config.COLOR_INFO, bot=self.bot)
            await self.interaction.followup.send(embed=intro, ephemeral=True)
            msg = await self.interaction.followup.send(embed=view.build_embed(), view=view, ephemeral=True)
            view.message = msg
            done, _ = await asyncio.wait([asyncio.create_task(self._submit_event.wait()), asyncio.create_task(self._cancel_event.wait())], return_when=asyncio.FIRST_COMPLETED)
            if self._cancel_event.is_set():
                return
            await self._submit(self.interaction.channel, self.interaction.user)
        except Exception as e:
            print(f"[Application] Session error: {e}")
            try:
                await self.interaction.followup.send(embed=_err("An unexpected error occurred. Please try again."), ephemeral=True)
            except Exception:
                pass
        finally:
            _active_sessions.discard(session_key)

    async def _submit(self, channel, member: discord.Member):
        elapsed = self.elapsed
        lines = []
        lines.append(f"📋 New Application: {self.app_name.title()}")
        lines.append(f"Applicant: {member} ({member.id})")
        lines.append(f"Time Taken: {elapsed}")
        lines.append("─" * 40)
        lines.append("")
        for i, item in enumerate(self.answers, 1):
            question = item["question"]
            answer = item["answer"] or "(no answer)"
            lines.append(f"Q{i}: {question}")
            lines.append(f"A: {answer}")
            lines.append("")
        content = "\n".join(lines)
        import io
        file_bytes = io.BytesIO(content.encode("utf-8"))
        file = discord.File(file_bytes, filename=f"application_{self.app_name}_{member.id}.txt")
        e = build(title=f"📋 New Application: {self.app_name.title()}", color=Config.COLOR_INFO, bot=self.bot)
        e.set_author(name=str(member), icon_url=member.display_avatar.url)
        e.add_field(name="Applicant", value=member.mention, inline=True)
        e.add_field(name="User ID", value=str(member.id), inline=True)
        e.add_field(name="⏱️ Time Taken", value=elapsed, inline=True)
        e.add_field(name="📄 Full Application", value="See the attached file for all questions and answers.", inline=False)
        e.set_footer(text="Use the buttons below to review this application.")
        log_channel_id = self.app.get("log_channel")
        if log_channel_id:
            log_ch = channel.guild.get_channel(log_channel_id)
            if log_ch:
                grant_role_id = self.app.get("grant_role")
                manager_roles = self.app.get("manager_roles", [])
                view = ReviewView(member, self.app_name, grant_role_id, manager_roles, channel.guild)
                await log_ch.send(embed=e, file=file, view=view)
                if manager_roles:
                    manager_mentions = " ".join(f"<@&{role_id}>" for role_id in manager_roles if channel.guild.get_role(role_id))
                    if manager_mentions:
                        await log_ch.send(content=f"📢 New application from {member.mention}! {manager_mentions}", allowed_mentions=discord.AllowedMentions(roles=True))
        _submission_times[(self.interaction.guild_id, self.interaction.user.id, self.app_name)] = time.time()
        await self.interaction.followup.send(embed=build(title="✅ Application Submitted!", description=f"Your **{self.app_name.title()}** application has been submitted. You'll be notified of the decision.", color=Config.COLOR_OK, bot=self.bot), ephemeral=True)

async def _apply_decision(interaction: discord.Interaction, applicant: discord.Member, app_name: str, grant_role_id: int | None, accepted: bool, reason: str | None = None):
    role_note = ""
    if accepted and grant_role_id:
        role = interaction.guild.get_role(grant_role_id)
        if role:
            try:
                await applicant.add_roles(role, reason=f"Application accepted: {app_name}")
                role_note = f"\n✅ Granted role: **{role.name}**"
            except discord.Forbidden:
                role_note = "\n❌ Could not grant role (missing permissions)."
            except Exception as e:
                role_note = f"\n❌ Error granting role: {e}"
        else:
            role_note = "\n⚠️ Grant role not found (it may have been deleted)."
    decision_word = "✅ ACCEPTED" if accepted else "❌ DENIED"
    decision_val = f"{decision_word} by {interaction.user.mention}"
    if reason:
        decision_val += f"\n📝 Reason: {reason}"
    if role_note:
        decision_val += f"\n{role_note}"
    try:
        if interaction.message:
            original_embed = interaction.message.embeds[0] if interaction.message.embeds else None
            if original_embed:
                new_embed = discord.Embed(title=original_embed.title, description=original_embed.description, color=Config.COLOR_OK if accepted else Config.COLOR_ERR, timestamp=original_embed.timestamp)
                if original_embed.author:
                    new_embed.set_author(name=original_embed.author.name, icon_url=original_embed.author.icon_url, url=original_embed.author.url)
                if original_embed.footer:
                    new_embed.set_footer(text=original_embed.footer.text, icon_url=original_embed.footer.icon_url)
                if original_embed.thumbnail:
                    new_embed.set_thumbnail(url=original_embed.thumbnail.url)
                if original_embed.image:
                    new_embed.set_image(url=original_embed.image.url)
                for field in original_embed.fields:
                    if field.name not in ["Decision", "📌 Decision", "Status"]:
                        new_embed.add_field(name=field.name, value=field.value, inline=field.inline)
                new_embed.add_field(name="📌 Decision", value=decision_val, inline=False)
                await interaction.message.edit(embed=new_embed, view=None)
                print(f"[Application] Successfully updated embed for {applicant.name}")
            else:
                try:
                    await interaction.message.edit(view=None)
                except:
                    pass
        else:
            print(f"[Application] No message found in interaction")
    except discord.NotFound:
        print(f"[Application] Message not found - may have been deleted")
    except discord.Forbidden:
        print(f"[Application] Missing permissions to edit message")
    except discord.HTTPException as e:
        if e.code == 50027 or "Invalid Webhook Token" in str(e):
            print(f"[Application] Webhook token invalid, sending new message")
            try:
                if interaction.message and interaction.message.channel:
                    new_msg = await interaction.message.channel.send(embed=new_embed)
                    await interaction.message.delete()
            except:
                pass
        else:
            print(f"[Application] Failed to edit embed: {e}")
    except Exception as e:
        print(f"[Application] Failed to edit embed: {e}")
        try:
            if interaction.message:
                await interaction.message.edit(view=None)
        except:
            pass
    try:
        if accepted:
            dm = discord.Embed(title="✅ Application Accepted! 🎉", description=f"**Application:** {app_name.title()}\n\nCongratulations! Your application has been accepted." + role_note + (f"\n\n📝 **Note:** {reason}" if reason else ""), color=Config.COLOR_OK)
        else:
            dm = discord.Embed(title="❌ Application Denied", description=f"**Application:** {app_name.title()}\n\nYour application has been denied." + (f"\n\n📝 **Reason:** {reason}" if reason else ""), color=Config.COLOR_ERR)
        await applicant.send(embed=dm)
        print(f"[Application] Sent DM to {applicant.name}")
    except discord.Forbidden:
        print(f"[Application] Could not DM {applicant.name} (DMs closed)")
    except Exception as e:
        print(f"[Application] Failed to DM applicant: {e}")
    result = "Accepted ✅" if accepted else "Denied ❌"
    try:
        if interaction.response.is_done():
            await interaction.followup.send(embed=_ok(f"Application {result}", f"{applicant.mention}'s application has been {result}.\n{role_note}"), ephemeral=True)
        else:
            await interaction.response.send_message(embed=_ok(f"Application {result}", f"{applicant.mention}'s application has been {result}.\n{role_note}"), ephemeral=True)
    except discord.NotFound:
        print(f"[Application] Interaction not found")
    except Exception as e:
        print(f"[Application] Failed to send confirmation: {e}")

class AcceptReasonModal(discord.ui.Modal, title="Accept with Reason"):
    reason = discord.ui.TextInput(label="Note for the applicant (optional)", style=discord.TextStyle.paragraph, required=False, max_length=1000)

    def __init__(self, applicant, app_name, grant_role_id, manager_roles):
        super().__init__()
        self.applicant = applicant
        self.app_name = app_name
        self.grant_role_id = grant_role_id
        self.manager_roles = manager_roles

    async def on_submit(self, interaction: discord.Interaction):
        await _apply_decision(interaction, self.applicant, self.app_name, self.grant_role_id, True, self.reason.value.strip() or None)

class DenyReasonModal(discord.ui.Modal, title="Deny with Reason"):
    reason = discord.ui.TextInput(label="Reason for denial", style=discord.TextStyle.paragraph, required=True, max_length=1000)

    def __init__(self, applicant, app_name, grant_role_id, manager_roles):
        super().__init__()
        self.applicant = applicant
        self.app_name = app_name
        self.grant_role_id = grant_role_id
        self.manager_roles = manager_roles

    async def on_submit(self, interaction: discord.Interaction):
        await _apply_decision(interaction, self.applicant, self.app_name, self.grant_role_id, False, self.reason.value.strip())

class ReviewView(discord.ui.View):
    def __init__(self, applicant: discord.Member, app_name: str, grant_role_id: int | None, manager_roles: list, guild: discord.Guild):
        super().__init__(timeout=None)
        self.applicant = applicant
        self.app_name = app_name
        self.grant_role_id = grant_role_id
        self.manager_roles = manager_roles
        self.guild = guild
        self._processed = False

    def _perm_check(self, interaction: discord.Interaction) -> bool:
        if self.manager_roles:
            user_roles = [r.id for r in interaction.user.roles]
            if any(role_id in user_roles for role_id in self.manager_roles):
                return True
        if interaction.user.guild_permissions.manage_channels:
            return True
        if interaction.user.guild_permissions.administrator:
            return True
        if interaction.user.guild_permissions.manage_guild:
            return True
        return False

    @discord.ui.button(label="✅ Accept", style=discord.ButtonStyle.success, row=0)
    async def accept(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self._processed:
            return await interaction.response.send_message("This application has already been processed.", ephemeral=True)
        if not self._perm_check(interaction):
            return await interaction.response.send_message("❌ You don't have permission to do this.", ephemeral=True)
        self._processed = True
        await interaction.response.defer(ephemeral=False)
        await _apply_decision(interaction, self.applicant, self.app_name, self.grant_role_id, True, None)

    @discord.ui.button(label="📝 Accept w/ Reason", style=discord.ButtonStyle.primary, row=0)
    async def accept_reason(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self._processed:
            return await interaction.response.send_message("This application has already been processed.", ephemeral=True)
        if not self._perm_check(interaction):
            return await interaction.response.send_message("❌ You don't have permission to do this.", ephemeral=True)
        await interaction.response.send_modal(AcceptReasonModal(self.applicant, self.app_name, self.grant_role_id, self.manager_roles))

    @discord.ui.button(label="❌ Deny", style=discord.ButtonStyle.danger, row=1)
    async def deny(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self._processed:
            return await interaction.response.send_message("This application has already been processed.", ephemeral=True)
        if not self._perm_check(interaction):
            return await interaction.response.send_message("❌ You don't have permission to do this.", ephemeral=True)
        self._processed = True
        await interaction.response.defer(ephemeral=False)
        await _apply_decision(interaction, self.applicant, self.app_name, self.grant_role_id, False, None)

    @discord.ui.button(label="📝 Deny w/ Reason", style=discord.ButtonStyle.danger, row=1)
    async def deny_reason(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self._processed:
            return await interaction.response.send_message("This application has already been processed.", ephemeral=True)
        if not self._perm_check(interaction):
            return await interaction.response.send_message("❌ You don't have permission to do this.", ephemeral=True)
        await interaction.response.send_modal(DenyReasonModal(self.applicant, self.app_name, self.grant_role_id, self.manager_roles))

    @discord.ui.button(label="🎟️ Open Ticket", style=discord.ButtonStyle.secondary, row=2)
    async def open_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self._processed:
            return await interaction.response.send_message("This application has already been processed.", ephemeral=True)
        if not self._perm_check(interaction):
            return await interaction.response.send_message("❌ You don't have permission to do this.", ephemeral=True)
        self._processed = True
        await interaction.response.defer(ephemeral=False)
        await _open_ticket_for_applicant(interaction, self.applicant, self.app_name)

    @discord.ui.button(label="🔵 Under Consideration", style=discord.ButtonStyle.primary, row=2)
    async def under_consideration(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self._processed:
            return await interaction.response.send_message("This application has already been processed.", ephemeral=True)
        if not self._perm_check(interaction):
            return await interaction.response.send_message("❌ You don't have permission to do this.", ephemeral=True)
        await interaction.response.defer(ephemeral=False)
        if interaction.message and interaction.message.embeds:
            try:
                original_embed = interaction.message.embeds[0]
                new_embed = build(title=original_embed.title, description=original_embed.description, color=discord.Colour.blue(), bot=self.bot)
                if original_embed.author:
                    new_embed.set_author(name=original_embed.author.name, icon_url=original_embed.author.icon_url, url=original_embed.author.url)
                if original_embed.footer:
                    new_embed.set_footer(text=original_embed.footer.text, icon_url=original_embed.footer.icon_url)
                if original_embed.thumbnail:
                    new_embed.set_thumbnail(url=original_embed.thumbnail.url)
                if original_embed.image:
                    new_embed.set_image(url=original_embed.image.url)
                for field in original_embed.fields:
                    if field.name not in ["Status", "Decision", "📌 Decision"]:
                        new_embed.add_field(name=field.name, value=field.value, inline=field.inline)
                new_embed.add_field(name="Status", value=f"🔵 Under Consideration by {interaction.user.mention}", inline=False)
                await interaction.message.edit(embed=new_embed, view=self)
                print(f"[Application] Updated embed to Under Consideration")
            except discord.HTTPException as e:
                if e.code == 50027 or "Invalid Webhook Token" in str(e):
                    print(f"[Application] Webhook token invalid, sending new message")
                    try:
                        if interaction.message and interaction.message.channel:
                            await interaction.message.channel.send(embed=new_embed, view=self)
                            await interaction.message.delete()
                    except:
                        pass
                else:
                    print(f"[Application] Failed to update embed: {e}")
            except Exception as e:
                print(f"[Application] Failed to update embed: {e}")
        try:
            notif = build(title="📋 Application Under Consideration", description=f"**Application:** {self.app_name.title()}\n\nStaff are reviewing your application. You will be notified of the final decision.", color=discord.Colour.blue(), bot=self.bot)
            await self.applicant.send(embed=notif)
        except discord.Forbidden:
            pass
        except Exception as e:
            print(f"[Application] Failed to DM applicant: {e}")
        await interaction.followup.send(embed=_ok("Marked Under Consideration", f"{self.applicant.mention} has been notified. You can still accept or deny using the buttons below."), ephemeral=True)

async def _open_ticket_for_applicant(interaction: discord.Interaction, applicant: discord.Member, app_name: str):
    from utils.data import load as data_load, save as data_save
    guild = interaction.guild
    settings = data_load("guild_settings.json").get(str(guild.id), {})
    cat_name = settings.get("ticket_category", "Tickets")
    category = discord.utils.get(guild.categories, name=cat_name)
    if not category:
        category = await guild.create_category(cat_name)
    overwrites = {
        guild.default_role: discord.PermissionOverwrite(read_messages=False),
        applicant: discord.PermissionOverwrite(read_messages=True, send_messages=True, attach_files=True),
        guild.me: discord.PermissionOverwrite(read_messages=True, send_messages=True, manage_channels=True),
        interaction.user: discord.PermissionOverwrite(read_messages=True, send_messages=True, manage_messages=True),
    }
    for role_id in settings.get("ticket_staff_roles", []):
        role = guild.get_role(int(role_id))
        if role:
            overwrites[role] = discord.PermissionOverwrite(read_messages=True, send_messages=True, manage_messages=True)
    slug = "app-review"
    channel = await category.create_text_channel(f"{slug}-{applicant.name[:16].lower().replace(' ', '-')}", overwrites=overwrites, topic=f"Application review: {app_name} • {applicant}")
    e = discord.Embed(title=f"📋 Application Review • {app_name.title()}", description=f"{applicant.mention} • this channel has been opened by {interaction.user.mention} to discuss your **{app_name}** application.\n\nPlease keep the conversation relevant.", color=Config.COLOR_INFO)
    await channel.send(embed=e)
    await interaction.response.send_message(embed=_ok("Ticket Opened", f"Review channel created: {channel.mention}"), ephemeral=True)

class ManagerRoleModal(discord.ui.Modal, title="Set Manager Roles"):
    role_ids = discord.ui.TextInput(label="Manager Role IDs (comma-separated)", placeholder="123456789,987654321", required=True, max_length=500)

    def __init__(self, app_name: str, guild_id: int):
        super().__init__()
        self.app_name = app_name
        self.guild_id = guild_id

    async def on_submit(self, interaction: discord.Interaction):
        app = _get_app(self.guild_id, self.app_name)
        if not app:
            return await interaction.response.send_message(embed=_err("Application not found."), ephemeral=True)
        role_ids = []
        for part in self.role_ids.value.split(","):
            part = part.strip()
            if part.isdigit():
                role_ids.append(int(part))
        if not role_ids:
            return await interaction.response.send_message(embed=_err("Please provide at least one valid role ID."), ephemeral=True)
        valid_roles = []
        for rid in role_ids:
            role = interaction.guild.get_role(rid)
            if role:
                valid_roles.append(rid)
        if not valid_roles:
            return await interaction.response.send_message(embed=_err("No valid roles found. Please provide existing role IDs."), ephemeral=True)
        app["manager_roles"] = valid_roles
        _save_app(self.guild_id, self.app_name, app)
        role_mentions = " ".join(f"<@&{rid}>" for rid in valid_roles)
        await interaction.response.send_message(embed=_ok("Manager Roles Set", f"Manager roles for **{self.app_name}**: {role_mentions}\n\nThese roles will be pinged when new applications are submitted."), ephemeral=True)

async def _start_application_session(interaction: discord.Interaction, bot: commands.Bot, app_name: str):
    app = _get_app(interaction.guild_id, app_name)
    if not app:
        return await interaction.followup.send(embed=_err("This application no longer exists."), ephemeral=True)
    if not app.get("open", True):
        return await interaction.followup.send(embed=_err("This application is currently closed."), ephemeral=True)
    if (interaction.guild_id, interaction.user.id, app_name) in _active_sessions:
        return await interaction.followup.send(embed=_err("You already have an active session for this application."), ephemeral=True)
    remaining = _check_cooldown(interaction.guild_id, interaction.user.id, app_name)
    if remaining is not None:
        m, s = divmod(int(remaining), 60)
        if m > 0:
            cd_str = f"{m} minutes {s} seconds" if s > 0 else f"{m} minutes"
        else:
            cd_str = f"{s} seconds"
        return await interaction.followup.send(embed=_err(f"Please wait **{cd_str}** before applying again."), ephemeral=True)
    session = ApplicationSession(bot, interaction, app, app_name)
    await session.run()

class ApplyButtonView(discord.ui.View):
    def __init__(self, app_name: str, bot: commands.Bot):
        super().__init__(timeout=None)
        self.app_name = app_name
        self.bot = bot

    @discord.ui.button(label="Apply", style=discord.ButtonStyle.primary, emoji="📋", custom_id="apply_single_btn")
    async def apply_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True)
        await _start_application_session(interaction, self.bot, self.app_name)

class MultiApplySelect(discord.ui.Select):
    def __init__(self, app_names: list[str], guild_id: int, bot: commands.Bot):
        self.bot = bot
        self.guild_id = guild_id
        options = self._build_options(app_names, guild_id)
        super().__init__(placeholder="Choose an application to apply for…", options=options, custom_id="multi_apply_select")

    @staticmethod
    def _build_options(app_names: list[str], guild_id: int) -> list[discord.SelectOption]:
        options = []
        for name in app_names:
            if name == "_placeholder" or guild_id == 0:
                options.append(discord.SelectOption(label=name.title(), value=name, emoji="📋"))
                continue
            app = _get_app(guild_id, name)
            q_count = len(app.get("questions", [])) if app else 0
            desc = (app.get("description") or f"{q_count} question(s)")[:100] if app else ""
            closed = app and not app.get("open", True)
            options.append(discord.SelectOption(label=name.title() + (" [Closed]" if closed else ""), value=name, description=desc, emoji="📋"))
        return options

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        app_name = self.values[0]
        await _start_application_session(interaction, self.bot, app_name)

class MultiApplyView(discord.ui.View):
    def __init__(self, app_names: list[str], guild_id: int, bot: commands.Bot, style: str = "button"):
        super().__init__(timeout=None)
        if style == "dropdown":
            self.add_item(MultiApplySelect(app_names, guild_id, bot))
        else:
            for name in app_names:
                app = _get_app(guild_id, name)
                closed = app and not app.get("open", True)
                label = name.title() + (" [Closed]" if closed else "")
                btn = discord.ui.Button(label=label, style=discord.ButtonStyle.secondary if closed else discord.ButtonStyle.primary, emoji="📋", custom_id=f"multi_apply_btn_{name}")
                btn.callback = self._make_cb(name, bot)
                self.add_item(btn)

    @staticmethod
    def _make_cb(app_name: str, bot: commands.Bot):
        async def cb(interaction: discord.Interaction):
            await interaction.response.defer(ephemeral=True)
            await _start_application_session(interaction, bot, app_name)
        return cb

class PostMultiModal(discord.ui.Modal, title="Post Multi-Application Panel"):
    custom_title = discord.ui.TextInput(label="Embed Title", placeholder="Applications (or leave blank for default)", required=False, max_length=256)
    custom_description = discord.ui.TextInput(label="Embed Description (supports formatting)", placeholder="Select an app below. Supports **bold**, *italics*, `code`, [links].", style=discord.TextStyle.paragraph, required=False, max_length=4000)

    def __init__(self, app_names: list[str], style: str, channel: discord.TextChannel, cog: "ApplicationCog", interaction: discord.Interaction):
        super().__init__()
        self.app_names = app_names
        self.style = style
        self.channel = channel
        self.cog = cog
        self.original_interaction = interaction

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        valid_apps = []
        for name in self.app_names:
            app = _get_app(interaction.guild_id, name)
            if app:
                valid_apps.append((name, app))
        if not valid_apps:
            await interaction.followup.send(embed=_err("No valid applications found."), ephemeral=True)
            return
        title = self.custom_title.value.strip() or "Applications"
        description = self.custom_description.value.strip() or "Select an application below to apply."
        embed = build(title=title, description=description, color=Config.COLOR_INFO, bot=self.bot)
        for name, app in valid_apps:
            q_count = len(app.get("questions", []))
            status = "Open" if app.get("open", True) else "Closed"
            desc = app.get("description")
            value = f"**Status:** {status} | **Questions:** {q_count}"
            if desc:
                value += f"\n{desc[:100]}"
            embed.add_field(name=name.title(), value=value, inline=False)
        embed.set_footer(text=f"{len(valid_apps)} application(s) available")
        view = MultiApplyView(self.app_names, interaction.guild_id, self.cog.bot, self.style)
        await self.channel.send(embed=embed, view=view)
        await interaction.followup.send(embed=_ok("Panel Posted", f"Multi-application panel posted in {self.channel.mention} with {len(valid_apps)} applications."), ephemeral=True)

class ApplicationCog(commands.Cog, name="Applications"):
    slash = app_commands.Group(name="application", description="Application system commands")

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        bot.add_view(ApplyButtonView("_placeholder", bot))
        bot.add_view(MultiApplyView(["_placeholder"], 0, bot, style="dropdown"))
        bot.add_view(MultiApplyView(["_placeholder"], 0, bot, style="button"))

    # ========== SLASH COMMANDS ==========
    @slash.command(name="apply", description="Apply for an application.")
    @app_commands.describe(name="Application name")
    async def app_apply(self, interaction: discord.Interaction, name: str):
        await interaction.response.defer(ephemeral=True)
        await _start_application_session(interaction, self.bot, name.lower())

    @slash.command(name="create", description="Create a new application form.")
    @app_commands.describe(name="Internal name e.g. staff, mod, builder", description="Short description shown to applicants", log_channel="Channel where submissions are sent", grant_role="Role to grant on acceptance (optional)")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def app_create(self, interaction: discord.Interaction, name: str, log_channel: discord.TextChannel, description: str = None, grant_role: discord.Role = None):
        name = name.lower().strip()
        if not name:
            return await interaction.response.send_message(embed=_err("Application name cannot be empty."), ephemeral=True)
        if _get_app(interaction.guild_id, name):
            return await interaction.response.send_message(embed=_err(f"Application `{name}` already exists."), ephemeral=True)
        if not interaction.guild.get_channel(log_channel.id):
            return await interaction.response.send_message(embed=_err(f"Log channel `{log_channel.mention}` not found. Please specify a valid channel in this server."), ephemeral=True)
        if grant_role and not interaction.guild.get_role(grant_role.id):
            return await interaction.response.send_message(embed=_err(f"Role `{grant_role.name}` not found. Please specify a valid role in this server."), ephemeral=True)
        _save_app(interaction.guild_id, name, {
            "name": name,
            "description": description or "",
            "log_channel": log_channel.id,
            "grant_role": grant_role.id if grant_role else None,
            "manager_roles": [],
            "questions": [],
            "open": True,
            "cooldown": DEFAULT_COOLDOWN,
        })
        embed = build(title="✅ Application Created", description=(
                f"Application **{name.title()}** has been created.\n\n"
                f"📋 **Log Channel:** {log_channel.mention}\n"
                f"{'🎭 **Grant Role:** ' + grant_role.mention if grant_role else ''}"
                f"📝 **Description:** {description or 'None'}\n\n"
                "**Next Steps:**\n"
                f"• Add questions: `/application addquestion name:{name}`\n"
                f"• Set manager roles: `/application manager name:{name}`\n"
                f"• Post the application: `/application post name:{name}`"
            ), color=Config.COLOR_OK, bot=self.bot)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @slash.command(name="manager", description="Set manager roles for an application.")
    @app_commands.describe(name="Application name")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def app_manager(self, interaction: discord.Interaction, name: str):
        app = _get_app(interaction.guild_id, name.lower())
        if not app:
            return await interaction.response.send_message(embed=_err(f"Application `{name}` not found."), ephemeral=True)
        await interaction.response.send_modal(ManagerRoleModal(name.lower(), interaction.guild_id))

    @slash.command(name="addquestion", description="Add a question to an application.")
    @app_commands.describe(name="Application name")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def app_addquestion(self, interaction: discord.Interaction, name: str):
        app = _get_app(interaction.guild_id, name.lower())
        if not app:
            return await interaction.response.send_message(embed=_err(f"Application `{name}` not found."), ephemeral=True)
        if len(app.get("questions", [])) >= 100:
            return await interaction.response.send_message(embed=_err("Maximum 100 questions allowed per application."), ephemeral=True)
        await interaction.response.send_modal(AddQuestionModal(name.lower(), interaction.guild_id))

    @slash.command(name="removequestion", description="Remove a question by number.")
    @app_commands.describe(name="Application name", number="Question number to remove")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def app_removequestion(self, interaction: discord.Interaction, name: str, number: int):
        app = _get_app(interaction.guild_id, name.lower())
        if not app:
            return await interaction.response.send_message(embed=_err("Not found."), ephemeral=True)
        questions = app.get("questions", [])
        idx = number - 1
        if idx < 0 or idx >= len(questions):
            return await interaction.response.send_message(embed=_err("Invalid question number."), ephemeral=True)
        removed = questions.pop(idx)
        app["questions"] = questions
        _save_app(interaction.guild_id, name.lower(), app)
        await interaction.response.send_message(embed=_ok("Question Removed", f"Removed: **{removed['text']}**"), ephemeral=True)

    @slash.command(name="editquestion", description="Edit a question.")
    @app_commands.describe(name="Application name", number="Question number to edit")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def app_editquestion(self, interaction: discord.Interaction, name: str, number: int):
        app = _get_app(interaction.guild_id, name.lower())
        if not app:
            return await interaction.response.send_message(embed=_err("Not found."), ephemeral=True)
        idx = number - 1
        if idx < 0 or idx >= len(app.get("questions", [])):
            return await interaction.response.send_message(embed=_err("Invalid question number."), ephemeral=True)
        await interaction.response.send_modal(EditQuestionModal(name.lower(), interaction.guild_id, idx))

    @slash.command(name="reorderquestion", description="Move a question to a different position.")
    @app_commands.describe(name="Application name", from_number="Current position", to_number="New position")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def app_reorder(self, interaction: discord.Interaction, name: str, from_number: int, to_number: int):
        app = _get_app(interaction.guild_id, name.lower())
        if not app:
            return await interaction.response.send_message(embed=_err("Not found."), ephemeral=True)
        questions = app.get("questions", [])
        fi, ti = from_number - 1, to_number - 1
        if not (0 <= fi < len(questions)) or not (0 <= ti < len(questions)):
            return await interaction.response.send_message(embed=_err("Invalid question numbers."), ephemeral=True)
        q = questions.pop(fi)
        questions.insert(ti, q)
        app["questions"] = questions
        _save_app(interaction.guild_id, name.lower(), app)
        await interaction.response.send_message(embed=_ok("Question Moved", f"Moved **{q['text']}** to position {to_number}."), ephemeral=True)

    @slash.command(name="preview", description="Preview an application and its questions.")
    @app_commands.describe(name="Application name")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def app_preview(self, interaction: discord.Interaction, name: str):
        app = _get_app(interaction.guild_id, name.lower())
        if not app:
            return await interaction.response.send_message(embed=_err("Not found."), ephemeral=True)
        questions = app.get("questions", [])
        log_channel_id = app.get("log_channel")
        log_ch = interaction.guild.get_channel(log_channel_id) if log_channel_id else None
        grant_role = interaction.guild.get_role(app.get("grant_role", 0)) if app.get("grant_role") else None
        manager_roles = app.get("manager_roles", [])
        cooldown = app.get("cooldown", DEFAULT_COOLDOWN)
        e = build(title=f"Preview: {name.title()}", description=app.get("description") or "No description.", color=Config.COLOR_INFO, bot=self.bot)
        e.add_field(name="Status", value="Open" if app.get("open") else "Closed", inline=True)
        e.add_field(name="Questions", value=str(len(questions)), inline=True)
        e.add_field(name="Log Channel", value=log_ch.mention if log_ch else "Not set", inline=True)
        e.add_field(name="Cooldown", value=f"{cooldown}s" if cooldown else "None", inline=True)
        if grant_role:
            e.add_field(name="Grant Role", value=grant_role.mention, inline=True)
        if manager_roles:
            role_mentions = " ".join(f"<@&{rid}>" for rid in manager_roles if interaction.guild.get_role(rid))
            e.add_field(name="Manager Roles", value=role_mentions or "Deleted roles", inline=True)
        for i, q in enumerate(questions):
            val = f"Type: `{TYPE_LABELS.get(q['type'], q['type'])}`"
            if q.get("options"):
                val += "\nOptions: " + ", ".join(q["options"])
            val += "\n" + _build_constraint_hint(q)
            val += f"\n{'Required' if q.get('required', True) else 'Optional'}"
            e.add_field(name=f"Q{i+1}: {q['text'][:80]}", value=val.strip(), inline=False)
        await interaction.response.send_message(embed=e, ephemeral=True)

    @slash.command(name="list", description="List all applications.")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def app_list(self, interaction: discord.Interaction):
        apps = _list_apps(interaction.guild_id)
        if not apps:
            return await interaction.response.send_message(embed=_info("No Applications", "Use `/application create` to make one."), ephemeral=True)
        e = _info(f"Applications ({len(apps)})")
        gd = _load_guild(interaction.guild_id)
        for app_name in apps:
            app = gd[app_name]
            cooldown = app.get("cooldown", DEFAULT_COOLDOWN)
            manager_count = len(app.get("manager_roles", []))
            e.add_field(name=app_name.title(), value=f"{'Open' if app.get('open') else 'Closed'} | {len(app.get('questions', []))} question(s) | Cooldown: {cooldown}s | {manager_count} manager role(s)", inline=True)
        await interaction.response.send_message(embed=e, ephemeral=True)

    @slash.command(name="open", description="Open an application for submissions.")
    @app_commands.describe(name="Application name")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def app_open(self, interaction: discord.Interaction, name: str):
        app = _get_app(interaction.guild_id, name.lower())
        if not app:
            return await interaction.response.send_message(embed=_err("Not found."), ephemeral=True)
        app["open"] = True
        _save_app(interaction.guild_id, name.lower(), app)
        await interaction.response.send_message(embed=_ok("Application Opened", f"`{name}` is now accepting submissions."), ephemeral=True)

    @slash.command(name="close", description="Close an application.")
    @app_commands.describe(name="Application name")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def app_close(self, interaction: discord.Interaction, name: str):
        app = _get_app(interaction.guild_id, name.lower())
        if not app:
            return await interaction.response.send_message(embed=_err("Not found."), ephemeral=True)
        app["open"] = False
        _save_app(interaction.guild_id, name.lower(), app)
        await interaction.response.send_message(embed=_ok("Application Closed", f"`{name}` is no longer accepting submissions."), ephemeral=True)

    @slash.command(name="delete", description="Permanently delete an application.")
    @app_commands.describe(name="Application name")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def app_delete(self, interaction: discord.Interaction, name: str):
        if _delete_app(interaction.guild_id, name.lower()):
            await interaction.response.send_message(embed=_ok("Deleted", f"Application `{name}` deleted."), ephemeral=True)
        else:
            await interaction.response.send_message(embed=_err("Not found."), ephemeral=True)

    @slash.command(name="setlogchannel", description="Change the log channel.")
    @app_commands.describe(name="Application name", channel="New log channel")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def app_setlog(self, interaction: discord.Interaction, name: str, channel: discord.TextChannel):
        app = _get_app(interaction.guild_id, name.lower())
        if not app:
            return await interaction.response.send_message(embed=_err("Not found."), ephemeral=True)
        if not interaction.guild.get_channel(channel.id):
            return await interaction.response.send_message(embed=_err(f"Channel `{channel.mention}` not found. Please specify a valid channel."), ephemeral=True)
        app["log_channel"] = channel.id
        _save_app(interaction.guild_id, name.lower(), app)
        await interaction.response.send_message(embed=_ok("Log Channel Updated", f"Submissions for `{name}` → {channel.mention}."), ephemeral=True)

    @slash.command(name="setrole", description="Set the role granted on acceptance.")
    @app_commands.describe(name="Application name", role="Role to grant on acceptance")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def app_setrole(self, interaction: discord.Interaction, name: str, role: discord.Role):
        app = _get_app(interaction.guild_id, name.lower())
        if not app:
            return await interaction.response.send_message(embed=_err("Not found."), ephemeral=True)
        app["grant_role"] = role.id
        _save_app(interaction.guild_id, name.lower(), app)
        await interaction.response.send_message(embed=_ok("Role Set", f"**{role.name}** granted on acceptance of `{name}`."), ephemeral=True)

    @slash.command(name="setcooldown", description="Set the cooldown between applications.")
    @app_commands.describe(name="Application name", duration="Cooldown duration (e.g. '5m', '1h30m', '2 days')")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def app_setcooldown(self, interaction: discord.Interaction, name: str, duration: str):
        app = _get_app(interaction.guild_id, name.lower())
        if not app:
            return await interaction.response.send_message(embed=_err("Not found."), ephemeral=True)
        try:
            seconds = parse_duration(duration)
        except ValueError as e:
            return await interaction.response.send_message(embed=_err(str(e)), ephemeral=True)
        if seconds <= 0:
            seconds = 0
        app["cooldown"] = seconds
        _save_app(interaction.guild_id, name.lower(), app)
        if seconds == 0:
            friendly = "disabled"
        else:
            m, s = divmod(seconds, 60)
            h, m = divmod(m, 60)
            d, h = divmod(h, 24)
            parts = []
            if d: parts.append(f"{d}d")
            if h: parts.append(f"{h}h")
            if m: parts.append(f"{m}m")
            if s: parts.append(f"{s}s")
            friendly = " ".join(parts) if parts else "0s"
        await interaction.response.send_message(embed=_ok("Cooldown Updated", f"Cooldown for `{name}` set to **{friendly}**."), ephemeral=True)

    @slash.command(name="resetcooldown", description="Clear a user's reapply cooldown.")
    @app_commands.describe(name="Application name", user="Member to reset")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def app_resetcooldown(self, interaction: discord.Interaction, name: str, user: discord.Member):
        app_name = name.lower()
        if not _get_app(interaction.guild_id, app_name):
            return await interaction.response.send_message(embed=_err("Not found."), ephemeral=True)
        key = (interaction.guild_id, user.id, app_name)
        s_cleared = key in _active_sessions
        _active_sessions.discard(key)
        c_cleared = _submission_times.pop(key, None) is not None
        parts = []
        if c_cleared:
            parts.append("reapply cooldown")
        if s_cleared:
            parts.append("active session lock")
        desc = f"{user.mention}'s {' and '.join(parts)} for **{name}** cleared." if parts else f"{user.mention} had no active cooldown for **{name}**."
        await interaction.response.send_message(embed=_ok("Cooldown Reset", desc), ephemeral=True)

    @slash.command(name="checkstatus", description="Check a user's cooldown/session status.")
    @app_commands.describe(name="Application name", user="Member to check")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def app_checkstatus(self, interaction: discord.Interaction, name: str, user: discord.Member):
        app_name = name.lower()
        if not _get_app(interaction.guild_id, app_name):
            return await interaction.response.send_message(embed=_err("Not found."), ephemeral=True)
        key = (interaction.guild_id, user.id, app_name)
        has_session = key in _active_sessions
        remaining = _check_cooldown(interaction.guild_id, user.id, app_name)
        if remaining is not None:
            m, s = divmod(int(remaining), 60)
            if m > 0:
                cd_str = f"{m} minutes {s} seconds" if s > 0 else f"{m} minutes"
            else:
                cd_str = f"{s} seconds"
            cd_str = f"On cooldown • **{cd_str}** remaining"
        else:
            cd_str = "No cooldown active"
        e = _info(f"Status: {user.display_name} • {name.title()}", f"**Cooldown:** {cd_str}\n**Session:** {'Active' if has_session else 'None'}")
        e.set_thumbnail(url=user.display_avatar.url)
        await interaction.response.send_message(embed=e, ephemeral=True)

    @slash.command(name="post", description="Post an Apply button in a channel.")
    @app_commands.describe(name="Application name", channel="Channel to post in", message="Custom description (optional)")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def app_post(self, interaction: discord.Interaction, name: str, channel: discord.TextChannel = None, message: str = None):
        app = _get_app(interaction.guild_id, name.lower())
        if not app:
            return await interaction.response.send_message(embed=_err("Not found."), ephemeral=True)
        ch = channel or interaction.channel
        e = build(title=name.title() + " Application", description=message or app.get("description") or "Click the button below to apply.", color=Config.COLOR_INFO, bot=self.bot)
        e.set_footer(text=f"{len(app.get('questions', []))} question(s)")
        await ch.send(embed=e, view=ApplyButtonView(name.lower(), self.bot))
        await interaction.response.send_message(embed=_ok("Posted", f"Apply button posted in {ch.mention}."), ephemeral=True)

    @slash.command(name="postmulti", description="Post a multi-app panel with custom formatting.")
    @app_commands.describe(names="Comma-separated application names", style="Buttons or dropdown", channel="Channel to post in")
    @app_commands.choices(style=[app_commands.Choice(name="Buttons", value="button"), app_commands.Choice(name="Dropdown", value="dropdown")])
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def app_postmulti(self, interaction: discord.Interaction, names: str, style: app_commands.Choice[str] = None, channel: discord.TextChannel = None):
        app_names = [n.strip().lower() for n in names.split(",") if n.strip()]
        if not app_names:
            return await interaction.response.send_message(embed=_err("Provide at least one name."), ephemeral=True)
        if len(app_names) > 25:
            return await interaction.response.send_message(embed=_err("Max 25 applications per panel."), ephemeral=True)
        missing = [n for n in app_names if not _get_app(interaction.guild_id, n)]
        if missing:
            return await interaction.response.send_message(embed=_err(f"Not found: {', '.join(missing)}"), ephemeral=True)
        ch = channel or interaction.channel
        chosen_style = style.value if style else "button"
        modal = PostMultiModal(app_names, chosen_style, ch, self, interaction)
        await interaction.response.send_modal(modal)

    @slash.command(name="ping", description="Test the application cog.")
    async def app_ping(self, interaction: discord.Interaction):
        await interaction.response.send_message("✅ Application cog is alive and registered!", ephemeral=True)

    # ========== PREFIX COMMANDS ==========
    @commands.command(name="app")
    @commands.has_permissions(manage_guild=True)
    async def p_app(self, ctx, action: str = None, *, args: str = None):
        if not action:
            return await ctx.reply("Usage: `//app create|apply|list|open|close|delete|...`")
        # Route to appropriate subcommand
        if action.lower() == "create":
            await ctx.reply("Please use the slash command `/application create` to open the modal.")
        elif action.lower() == "apply":
            if not args:
                return await ctx.reply("Usage: `//app apply <name>`")
            await self.app_apply.callback(self, await commands.Context.from_interaction(ctx), args)
        elif action.lower() == "list":
            await self.app_list.callback(self, await commands.Context.from_interaction(ctx))
        elif action.lower() == "open":
            if not args:
                return await ctx.reply("Usage: `//app open <name>`")
            await self.app_open.callback(self, await commands.Context.from_interaction(ctx), args)
        elif action.lower() == "close":
            if not args:
                return await ctx.reply("Usage: `//app close <name>`")
            await self.app_close.callback(self, await commands.Context.from_interaction(ctx), args)
        elif action.lower() == "delete":
            if not args:
                return await ctx.reply("Usage: `//app delete <name>`")
            await self.app_delete.callback(self, await commands.Context.from_interaction(ctx), args)
        elif action.lower() == "preview":
            if not args:
                return await ctx.reply("Usage: `//app preview <name>`")
            await self.app_preview.callback(self, await commands.Context.from_interaction(ctx), args)
        elif action.lower() == "post":
            if not args:
                return await ctx.reply("Usage: `//app post <name> [#channel] [message]`")
            parts = args.split()
            name = parts[0]
            channel = None
            message = None
            if len(parts) > 1:
                for part in parts[1:]:
                    if part.startswith("#") and len(part) > 1:
                        channel = discord.utils.get(ctx.guild.text_channels, name=part[1:])
                    else:
                        message = " ".join(parts[1:])
                        break
            await self.app_post.callback(self, await commands.Context.from_interaction(ctx), name, channel, message)
        else:
            await ctx.reply(f"❌ Unknown action `{action}`. Available: create, apply, list, open, close, delete, preview, post")

    @commands.command(name="app_addquestion")
    @commands.has_permissions(manage_guild=True)
    async def p_app_addquestion(self, ctx, name: str):
        await ctx.reply("Please use the slash command `/application addquestion` to open the modal.")

    @commands.command(name="app_removequestion")
    @commands.has_permissions(manage_guild=True)
    async def p_app_removequestion(self, ctx, name: str, number: int):
        await self.app_removequestion.callback(self, await commands.Context.from_interaction(ctx), name, number)

    @commands.command(name="app_editquestion")
    @commands.has_permissions(manage_guild=True)
    async def p_app_editquestion(self, ctx, name: str, number: int):
        await ctx.reply("Please use the slash command `/application editquestion` to open the modal.")

    @commands.command(name="app_reorderquestion")
    @commands.has_permissions(manage_guild=True)
    async def p_app_reorderquestion(self, ctx, name: str, from_number: int, to_number: int):
        await self.app_reorder.callback(self, await commands.Context.from_interaction(ctx), name, from_number, to_number)

    @commands.command(name="app_manager")
    @commands.has_permissions(manage_guild=True)
    async def p_app_manager(self, ctx, name: str):
        await ctx.reply("Please use the slash command `/application manager` to open the modal.")

    @commands.command(name="app_setlogchannel")
    @commands.has_permissions(manage_guild=True)
    async def p_app_setlogchannel(self, ctx, name: str, channel: discord.TextChannel):
        await self.app_setlog.callback(self, await commands.Context.from_interaction(ctx), name, channel)

    @commands.command(name="app_setrole")
    @commands.has_permissions(manage_guild=True)
    async def p_app_setrole(self, ctx, name: str, role: discord.Role):
        await self.app_setrole.callback(self, await commands.Context.from_interaction(ctx), name, role)

    @commands.command(name="app_setcooldown")
    @commands.has_permissions(manage_guild=True)
    async def p_app_setcooldown(self, ctx, name: str, duration: str):
        await self.app_setcooldown.callback(self, await commands.Context.from_interaction(ctx), name, duration)

    @commands.command(name="app_resetcooldown")
    @commands.has_permissions(manage_guild=True)
    async def p_app_resetcooldown(self, ctx, name: str, user: discord.Member):
        await self.app_resetcooldown.callback(self, await commands.Context.from_interaction(ctx), name, user)

    @commands.command(name="app_checkstatus")
    @commands.has_permissions(manage_guild=True)
    async def p_app_checkstatus(self, ctx, name: str, user: discord.Member):
        await self.app_checkstatus.callback(self, await commands.Context.from_interaction(ctx), name, user)

    @commands.command(name="app_postmulti")
    @commands.has_permissions(manage_guild=True)
    async def p_app_postmulti(self, ctx, names: str, style: str = "button", channel: discord.TextChannel = None):
        style_choice = app_commands.Choice(name=style, value=style) if style in ["button", "dropdown"] else None
        await self.app_postmulti.callback(self, await commands.Context.from_interaction(ctx), names, style_choice, channel)

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            missing = ", ".join(p.replace("_", " ").title() for p in error.missing_permissions)
            print(f"[Application] {interaction.user} ({interaction.user.id}) missing permissions: {missing}")
            try:
                await interaction.response.send_message(f"❌ You are missing the required permissions: **{missing}**.", ephemeral=True)
            except discord.InteractionResponded:
                await interaction.followup.send(f"❌ You are missing the required permissions: **{missing}**.", ephemeral=True)
        elif isinstance(error, app_commands.TransformerError):
            await interaction.response.send_message(f"❌ Invalid input: {error}", ephemeral=True)
        else:
            print(f"[Application] Unhandled error: {error}")
            try:
                await interaction.response.send_message(f"❌ An error occurred: {str(error)[:100]}", ephemeral=True)
            except discord.InteractionResponded:
                await interaction.followup.send(f"❌ An error occurred: {str(error)[:100]}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(ApplicationCog(bot))