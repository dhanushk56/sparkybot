import discord
from discord.ext import commands
from discord import app_commands
import random
import math
import time
import re
from datetime import datetime, timezone
from config import Config
from utils.embed import build
from utils.theme import Theme
from utils.data import load, save

XP_FILE = "levels.json"

def xp_for_level(level: int) -> int:
    return 5 * (level ** 2) + 50 * level + 100

def level_from_xp(total_xp: int) -> tuple[int, int, int]:
    level = 0
    xp = total_xp
    while xp >= xp_for_level(level):
        xp -= xp_for_level(level)
        level += 1
    return level, xp, xp_for_level(level)

def _get(guild_id: int, user_id: int) -> dict:
    data = load(XP_FILE)
    gk, uk = str(guild_id), str(user_id)
    data.setdefault(gk, {}).setdefault(uk, {"xp": 0, "level": 0, "total_xp": 0})
    return data[gk][uk]

def _save_xp(guild_id: int, user_id: int, user: dict):
    data = load(XP_FILE)
    data.setdefault(str(guild_id), {})[str(user_id)] = user
    save(XP_FILE, data)

def _guild_settings(guild_id: int) -> dict:
    data = load("guild_settings.json")
    return data.get(str(guild_id), {})

def _save_guild_settings(guild_id: int, gd: dict):
    data = load("guild_settings.json")
    data[str(guild_id)] = gd
    save("guild_settings.json", data)

def progress_bar(current: int, total: int, length: int = 20) -> str:
    filled = int((current / total) * length) if total else 0
    return "█" * filled + "░" * (length - filled)

def hex_to_int(hex_color: str) -> int:
    hex_color = hex_color.strip()
    if not hex_color:
        return Config.COLOR_GOLD
    if hex_color.startswith("#"):
        hex_color = hex_color[1:]
    try:
        return int(hex_color, 16)
    except ValueError:
        return Config.COLOR_GOLD

class LevelUpTextModal(discord.ui.Modal, title="✏️ Customize Level-Up Message"):
    outside_text = discord.ui.TextInput(
        label="🔔 Outside Text (Ping/Content)",
        style=discord.TextStyle.paragraph,
        placeholder="Text outside the embed. Use {user} to ping.",
        required=False,
        max_length=2000,
        default="{user}"
    )

    embed_title = discord.ui.TextInput(
        label="📌 Embed Title",
        placeholder="⬆️ Level Up!",
        required=False,
        max_length=256,
        default="⬆️ Level Up!"
    )

    embed_description = discord.ui.TextInput(
        label="📝 Embed Description",
        style=discord.TextStyle.paragraph,
        placeholder="Text inside the embed. Supports Discord markdown!",
        required=False,
        max_length=4000,
        default="🎉 {user} reached **Level {level}**!"
    )

    embed_footer = discord.ui.TextInput(
        label="📌 Embed Footer",
        placeholder="Footer text (optional)",
        required=False,
        max_length=2048
    )

    embed_color = discord.ui.TextInput(
        label="🎨 Embed Color (hex)",
        placeholder="#FFD700 or FFD700",
        required=False,
        max_length=7,
        default="#FFD700"
    )

    def __init__(self, guild_id: int):
        super().__init__()
        self.guild_id = guild_id
        settings = _guild_settings(guild_id)
        level_up_config = settings.get("level_up_config", {})

        self.outside_text.default = level_up_config.get("outside_text", "{user}")
        self.embed_title.default = level_up_config.get("embed_title", "⬆️ Level Up!")
        self.embed_description.default = level_up_config.get("embed_description", "🎉 {user} reached **Level {level}**!")
        self.embed_footer.default = level_up_config.get("embed_footer", "")
        self.embed_color.default = level_up_config.get("embed_color", "#FFD700")

    async def on_submit(self, interaction: discord.Interaction):

        settings = _guild_settings(self.guild_id)
        level_up_config = {
            "outside_text": self.outside_text.value.strip() or "{user}",
            "embed_title": self.embed_title.value.strip() or "⬆️ Level Up!",
            "embed_description": self.embed_description.value.strip() or "🎉 {user} reached **Level {level}**!",
            "embed_footer": self.embed_footer.value.strip() or None,
            "embed_color": self.embed_color.value.strip() or "#FFD700",
        }
        settings["level_up_config"] = level_up_config
        _save_guild_settings(self.guild_id, settings)

        preview_embed = build(title=level_up_config["embed_title"], description=level_up_config["embed_description"]
            .replace("{user}", "@User")
            .replace("{level}", "10")
            .replace("{xp}", "1,234")
            .replace("{xp_needed}", "500")
            .replace("{server}", "Test Server")
            .replace("{rank}", "#5"), color=hex_to_int(level_up_config["embed_color"]), bot=self.bot)
        if level_up_config["embed_footer"]:
            preview_embed.set_footer(text=level_up_config["embed_footer"])

        embed = build(title="✅ Level-Up Message Updated", description=(
                "The level-up message has been updated! Here's a preview:\n\n"
                f"**Outside Text:** `{level_up_config['outside_text']}`\n"
                f"**Title:** `{level_up_config['embed_title']}`\n"
                f"**Color:** `{level_up_config['embed_color']}`\n"
                f"**Footer:** `{level_up_config['embed_footer'] or '(none)'}`\n\n"
                "**Placeholders:**\n"
                "`{user}` – Mention of the user\n"
                "`{level}` – New level\n"
                "`{xp}` – Total XP\n"
                "`{xp_needed}` – XP needed for next level\n"
                "`{rank}` – User's rank\n"
                "`{server}` – Server name"
            ), color=Config.COLOR_OK, bot=self.bot)

        await interaction.response.send_message(
            content="📌 **Preview of how it will look:**",
            embed=preview_embed,
            ephemeral=True
        )
        await interaction.followup.send(embed=embed, ephemeral=True)

class LevelUpToggleModal(discord.ui.Modal, title="🔧 Level-Up Display Mode"):
    mode = discord.ui.TextInput(
        label="Display Mode",
        placeholder="embed, plain, or both",
        required=True,
        max_length=10,
        default="both"
    )

    def __init__(self, guild_id: int):
        super().__init__()
        self.guild_id = guild_id
        settings = _guild_settings(guild_id)
        current_mode = settings.get("level_up_config", {}).get("display_mode", "both")
        self.mode.default = current_mode

    async def on_submit(self, interaction: discord.Interaction):
        mode = self.mode.value.strip().lower()
        if mode not in ["embed", "plain", "both"]:
            await interaction.response.send_message(
                "❌ Invalid mode. Choose `embed`, `plain`, or `both`.",
                ephemeral=True
            )
            return

        settings = _guild_settings(self.guild_id)
        if "level_up_config" not in settings:
            settings["level_up_config"] = {}
        settings["level_up_config"]["display_mode"] = mode
        _save_guild_settings(self.guild_id, settings)

        mode_descriptions = {
            "embed": "📊 **Embed Only** – Only the embed is sent. No ping/outside text.",
            "plain": "📝 **Plain Text Only** – Only plain text is sent. No embed.",
            "both": "📊📝 **Both** – Outside text + embed are sent together."
        }

        embed = build(title="✅ Display Mode Updated", description=f"Level-up messages will now use: **{mode.upper()}** mode.\n\n{mode_descriptions.get(mode, '')}", color=Config.COLOR_OK, bot=self.bot)
        await interaction.response.send_message(embed=embed, ephemeral=True)

class PreviewView(discord.ui.View):
    def __init__(self, guild_id: int):
        super().__init__(timeout=120)
        self.guild_id = guild_id
        self.message = None

    @discord.ui.button(label="✅ Send Preview", style=discord.ButtonStyle.primary)
    async def send_preview(self, interaction: discord.Interaction, button: discord.ui.Button):
        settings = _guild_settings(self.guild_id)
        config = settings.get("level_up_config", {})
        display_mode = config.get("display_mode", "both")
        outside_text = config.get("outside_text", "{user}")
        embed_title = config.get("embed_title", "⬆️ Level Up!")
        embed_description = config.get("embed_description", "🎉 {user} reached **Level {level}**!")
        embed_footer = config.get("embed_footer")
        embed_color = config.get("embed_color", "#FFD700")

        user = interaction.user
        level = 42
        xp = 12450
        xp_needed = 500
        rank = "#7"
        server = interaction.guild.name

        formatted_outside = outside_text.replace("{user}", user.mention)\
                                         .replace("{level}", str(level))\
                                         .replace("{xp}", f"{xp:,}")\
                                         .replace("{xp_needed}", f"{xp_needed:,}")\
                                         .replace("{server}", server)\
                                         .replace("{rank}", rank)

        formatted_title = embed_title.replace("{user}", user.mention)\
                                       .replace("{level}", str(level))\
                                       .replace("{xp}", f"{xp:,}")\
                                       .replace("{xp_needed}", f"{xp_needed:,}")\
                                       .replace("{server}", server)\
                                       .replace("{rank}", rank)

        formatted_desc = embed_description.replace("{user}", user.mention)\
                                           .replace("{level}", str(level))\
                                           .replace("{xp}", f"{xp:,}")\
                                           .replace("{xp_needed}", f"{xp_needed:,}")\
                                           .replace("{server}", server)\
                                           .replace("{rank}", rank)

        embed = build(title=formatted_title, description=formatted_desc, color=hex_to_int(embed_color), bot=self.bot)
        if embed_footer:
            formatted_footer = embed_footer.replace("{user}", user.mention)\
                                           .replace("{level}", str(level))\
                                           .replace("{xp}", f"{xp:,}")\
                                           .replace("{xp_needed}", f"{xp_needed:,}")\
                                           .replace("{server}", server)\
                                           .replace("{rank}", rank)
            embed.set_footer(text=formatted_footer)
        embed.set_thumbnail(url=user.display_avatar.url)

        try:
            if display_mode == "embed":
                await interaction.response.send_message(
                    content=f"📌 **Preview ({display_mode.upper()} mode):**",
                    embed=embed,
                    ephemeral=False
                )
            elif display_mode == "plain":
                await interaction.response.send_message(
                    content=f"📌 **Preview ({display_mode.upper()} mode):**\n\n{formatted_outside}",
                    ephemeral=False
                )
            else:
                if formatted_outside.strip():
                    await interaction.response.send_message(
                        content=f"📌 **Preview ({display_mode.upper()} mode):**\n{formatted_outside}",
                        embed=embed,
                        ephemeral=False
                    )
                else:
                    await interaction.response.send_message(
                        content="📌 **Preview:**",
                        embed=embed,
                        ephemeral=False
                    )
        except discord.Forbidden:
            await interaction.response.send_message("❌ I don't have permission to send messages here.", ephemeral=True)

    @discord.ui.button(label="❌ Close", style=discord.ButtonStyle.secondary)
    async def close_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(
            content="Preview closed.",
            embed=None,
            view=None
        )
        self.stop()

class Leveling(commands.Cog):

    slash = app_commands.Group(name="lv", description="XP and leveling commands")

    def __init__(self, bot):
        self.bot = bot
        self._cooldowns: dict[str, float] = {}

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild:
            return

        settings = _guild_settings(message.guild.id)

        if not settings.get("leveling_enabled", False):
            return

        if message.channel.id in settings.get("xp_blacklist", []):
            return

        role_blacklist = settings.get("xp_role_blacklist", [])
        if role_blacklist:

            for role in message.author.roles:
                if role.id in role_blacklist:
                    return

        key = f"{message.guild.id}:{message.author.id}"
        now = time.time()
        if now - self._cooldowns.get(key, 0) < Config.XP_COOLDOWN_SECONDS:
            return

        self._cooldowns[key] = now
        xp_gain = random.randint(Config.XP_PER_MESSAGE_MIN, Config.XP_PER_MESSAGE_MAX)
        u = _get(message.guild.id, message.author.id)
        old_level = level_from_xp(u["total_xp"])[0]
        u["total_xp"] += xp_gain
        level, rem, needed = level_from_xp(u["total_xp"])
        u["level"] = level
        u["xp"] = rem
        _save_xp(message.guild.id, message.author.id, u)

        if level > old_level:
            lvl_ch_id = settings.get("level_channel")
            if lvl_ch_id:
                ch = message.guild.get_channel(int(lvl_ch_id)) or message.channel
            else:
                ch = message.channel

            config = settings.get("level_up_config", {})
            display_mode = config.get("display_mode", "both")
            outside_text = config.get("outside_text", "{user}")
            embed_title = config.get("embed_title", "⬆️ Level Up!")
            embed_description = config.get("embed_description", "🎉 {user} reached **Level {level}**!")
            embed_footer = config.get("embed_footer")
            embed_color = config.get("embed_color", "#FFD700")

            rank = await self._get_rank(message.guild.id, message.author.id)
            rank_str = f"#{rank}" if rank else "N/A"

            formatted_outside = outside_text.replace("{user}", message.author.mention)\
                                             .replace("{level}", str(level))\
                                             .replace("{xp}", f"{u['total_xp']:,}")\
                                             .replace("{xp_needed}", f"{needed:,}")\
                                             .replace("{server}", message.guild.name)\
                                             .replace("{rank}", rank_str)

            formatted_desc = embed_description.replace("{user}", message.author.mention)\
                                               .replace("{level}", str(level))\
                                               .replace("{xp}", f"{u['total_xp']:,}")\
                                               .replace("{xp_needed}", f"{needed:,}")\
                                               .replace("{server}", message.guild.name)\
                                               .replace("{rank}", rank_str)

            formatted_title = embed_title.replace("{user}", message.author.mention)\
                                          .replace("{level}", str(level))\
                                          .replace("{xp}", f"{u['total_xp']:,}")\
                                          .replace("{xp_needed}", f"{needed:,}")\
                                          .replace("{server}", message.guild.name)\
                                          .replace("{rank}", rank_str)

            embed = None
            if display_mode in ["embed", "both"]:
                embed = build(title=formatted_title, description=formatted_desc, color=hex_to_int(embed_color), bot=self.bot)
                if embed_footer:
                    formatted_footer = embed_footer.replace("{user}", message.author.mention)\
                                                   .replace("{level}", str(level))\
                                                   .replace("{xp}", f"{u['total_xp']:,}")\
                                                   .replace("{xp_needed}", f"{needed:,}")\
                                                   .replace("{server}", message.guild.name)\
                                                   .replace("{rank}", rank_str)
                    embed.set_footer(text=formatted_footer)
                embed.set_thumbnail(url=message.author.display_avatar.url)

            try:
                if display_mode == "embed":
                    await ch.send(embed=embed)
                elif display_mode == "plain":
                    if formatted_outside.strip():
                        await ch.send(formatted_outside)
                    else:
                        await ch.send(f"🎉 {message.author.display_name} reached Level {level}!")
                else:
                    if formatted_outside.strip():
                        await ch.send(content=formatted_outside, embed=embed)
                    else:
                        await ch.send(embed=embed)
            except Exception as e:

                print(f"[Leveling] Failed to send level-up message: {e}")
                await ch.send(f"🎉 {message.author.mention} reached Level {level}!")

            role_map = settings.get("level_roles", {})
            for lvl in range(old_level + 1, level + 1):
                role_id = role_map.get(str(lvl))
                if role_id:
                    role = message.guild.get_role(int(role_id))
                    if role and role not in message.author.roles:
                        try:
                            await message.author.add_roles(role, reason=f"Level {lvl} reward")
                        except Exception:
                            pass

    async def _get_rank(self, guild_id: int, user_id: int) -> int | None:
        data = load(XP_FILE).get(str(guild_id), {})
        if not data:
            return None
        sorted_users = sorted(data.items(), key=lambda x: x[1].get("total_xp", 0), reverse=True)
        for i, (uid, _) in enumerate(sorted_users, 1):
            if uid == str(user_id):
                return i
        return None

    @commands.command(name="lv")
    async def rank(self, ctx, member: discord.Member = None):
        m = member or ctx.author
        u = _get(ctx.guild.id, m.id)
        level, rem, needed = level_from_xp(u["total_xp"])
        data = load(XP_FILE).get(str(ctx.guild.id), {})
        sorted_users = sorted(data.items(), key=lambda x: x[1].get("total_xp", 0), reverse=True)
        rank_pos = next((i + 1 for i, (uid, _) in enumerate(sorted_users) if uid == str(m.id)), "?")
        bar = progress_bar(rem, needed)
        e = discord.Embed(color=m.color or Config.COLOR_GOLD)
        e.set_author(name=str(m), icon_url=m.display_avatar.url)
        e.set_thumbnail(url=m.display_avatar.url)
        e.add_field(name="🏅 Level",    value=f"**{level}**")
        e.add_field(name="🏆 Rank",     value=f"**#{rank_pos}**")
        e.add_field(name="⭐ Total XP", value=f"**{u['total_xp']:,}**")
        e.add_field(name=f"Progress ({rem:,} / {needed:,} XP)", value=f"`{bar}` {int(rem / needed * 100) if needed else 0}%", inline=False)
        e.set_footer(text="Sparky Bot Levels")
        await ctx.reply(embed=e)

    @commands.command(name="lvlb", aliases=["levels", "xplb"])
    async def levels(self, ctx, page: int = 1):
        data = load(XP_FILE).get(str(ctx.guild.id), {})
        if not data:
            return await ctx.reply("No XP data yet. Start chatting to earn XP!")
        sorted_users = sorted(data.items(), key=lambda x: x[1].get("total_xp", 0), reverse=True)
        per_page     = 10
        total_pages  = max(1, math.ceil(len(sorted_users) / per_page))
        page         = max(1, min(page, total_pages))
        start        = (page - 1) * per_page
        chunk        = sorted_users[start:start + per_page]
        medals       = ["🥇","🥈","🥉"] + [f"`{i}.`" for i in range(4, 11)]
        lines = []
        for i, (uid, udata) in enumerate(chunk, start=start):
            member = ctx.guild.get_member(int(uid))
            name   = member.display_name if member else f"<@{uid}>"
            lvl, _, _ = level_from_xp(udata.get("total_xp", 0))
            medal  = medals[i - start] if i - start < 3 else f"`{i + 1}.`"
            lines.append(f"{medal} **{name}** • Level **{lvl}** | `{udata.get('total_xp', 0):,}` XP")
        e = build(title=f"⭐ {ctx.guild.name} • XP Leaderboard", description="\n".join(lines) or "No data.", color=Config.COLOR_GOLD, bot=self.bot)
        user_rank = next((i + 1 for i, (uid, _) in enumerate(sorted_users) if uid == str(ctx.author.id)), None)
        if user_rank:
            user_xp   = data.get(str(ctx.author.id), {}).get("total_xp", 0)
            user_lvl, _, _ = level_from_xp(user_xp)
            e.set_footer(text=f"Your rank: #{user_rank} | Level {user_lvl} | {user_xp:,} XP • Page {page}/{total_pages}")
        else:
            e.set_footer(text=f"Page {page}/{total_pages} • Start chatting to earn XP!")
        if ctx.guild.icon:
            e.set_thumbnail(url=ctx.guild.icon.url)
        await ctx.reply(embed=e)

    @commands.command(name="lvset")
    @commands.has_permissions(administrator=True)
    async def lvset(self, ctx, channel: discord.TextChannel):
        data = load("guild_settings.json")
        data.setdefault(str(ctx.guild.id), {})["level_channel"] = channel.id
        save("guild_settings.json", data)
        await ctx.reply(f"✅ Level-up messages will now be sent to {channel.mention}.")

    @commands.command(name="lvrst")
    @commands.has_permissions(administrator=True)
    async def lvrst(self, ctx):
        data = load("guild_settings.json")
        data.setdefault(str(ctx.guild.id), {}).pop("level_channel", None)
        save("guild_settings.json", data)
        await ctx.reply("✅ Level-up messages will now appear in the channel where the message was sent.")

    @commands.command(name="lvsetxp")
    @commands.has_permissions(administrator=True)
    async def lvsetxp(self, ctx, member: discord.Member, xp: int):
        u = _get(ctx.guild.id, member.id)
        u["total_xp"] = max(0, xp)
        level, rem, needed = level_from_xp(u["total_xp"])
        u["level"] = level
        u["xp"] = rem
        _save_xp(ctx.guild.id, member.id, u)
        await ctx.reply(f"✅ Set {member.mention}'s XP to **{xp:,}** (Level {level}).")

    @commands.command(name="lvrole")
    @commands.has_permissions(administrator=True)
    async def lvrole(self, ctx, level: int, role: discord.Role):
        data = load("guild_settings.json")
        gd = data.setdefault(str(ctx.guild.id), {})
        gd.setdefault("level_roles", {})[str(level)] = role.id
        save("guild_settings.json", data)
        await ctx.reply(f"✅ Members who reach Level **{level}** will receive {role.mention}.")

    @commands.command(name="lvrlv")
    @commands.has_permissions(administrator=True)
    async def lvrlv(self, ctx, level: int):
        data = load("guild_settings.json")
        role_map = data.setdefault(str(ctx.guild.id), {}).get("level_roles", {})
        if str(level) not in role_map:
            return await ctx.reply(f"❌ No role reward is set for Level {level}.")
        removed_id = role_map.pop(str(level))
        save("guild_settings.json", data)
        role = ctx.guild.get_role(int(removed_id))
        await ctx.reply(f"✅ Removed {role.mention if role else f'<@&{removed_id}>'} as the Level {level} reward.")

    @commands.command(name="lvroles")
    async def lvroles(self, ctx):
        settings = _guild_settings(ctx.guild.id)
        role_map = settings.get("level_roles", {})
        if not role_map:
            return await ctx.reply("No level role rewards configured. Use `~lvrole` to add some.")
        lines = []
        for lvl, role_id in sorted(role_map.items(), key=lambda x: int(x[0])):
            role = ctx.guild.get_role(int(role_id))
            lines.append(f"Level **{lvl}** → {role.mention if role else f'<@&{role_id}> *(deleted)*'}")
        e = build(title="🎖️ Level Role Rewards", description="\n".join(lines), color=Config.COLOR_GOLD, bot=self.bot)
        await ctx.reply(embed=e)

    @commands.command(name="lvbl")
    @commands.has_permissions(administrator=True)
    async def lvbl(self, ctx, channel: discord.TextChannel = None):
        ch = channel or ctx.channel
        data = load("guild_settings.json")
        gd = data.setdefault(str(ctx.guild.id), {})
        bl = gd.setdefault("xp_blacklist", [])
        if ch.id in bl:
            bl.remove(ch.id)
            msg = f"✅ XP gain **enabled** in {ch.mention}."
        else:
            bl.append(ch.id)
            msg = f"🚫 XP gain **disabled** in {ch.mention}."
        save("guild_settings.json", data)
        await ctx.reply(msg)

    @commands.command(name="lvblrole")
    @commands.has_permissions(administrator=True)
    async def lvblrole(self, ctx, role: discord.Role):
        data = load("guild_settings.json")
        gd = data.setdefault(str(ctx.guild.id), {})
        bl = gd.setdefault("xp_role_blacklist", [])
        if role.id in bl:
            bl.remove(role.id)
            msg = f"✅ Role {role.mention} **removed** from XP blacklist. Members can now earn XP."
        else:
            bl.append(role.id)
            msg = f"🚫 Role {role.mention} **added** to XP blacklist. Members will no longer earn XP."
        save("guild_settings.json", data)
        await ctx.reply(msg)

    @commands.command(name="lvblroles")
    @commands.has_permissions(administrator=True)
    async def lvblroles(self, ctx):
        settings = _guild_settings(ctx.guild.id)
        bl = settings.get("xp_role_blacklist", [])
        if not bl:
            return await ctx.reply("No roles are currently blacklisted from earning XP.")
        lines = []
        for role_id in bl:
            role = ctx.guild.get_role(int(role_id))
            lines.append(f"• {role.mention if role else f'<@&{role_id}> *(deleted)*'}")
        e = build(title="🚫 XP Blacklisted Roles", description="\n".join(lines), color=Config.COLOR_ERR, bot=self.bot)
        await ctx.reply(embed=e)

    @commands.command(name="lvtoggle")
    @commands.has_permissions(administrator=True)
    async def lvtoggle(self, ctx):
        data = load("guild_settings.json")
        gd = data.setdefault(str(ctx.guild.id), {})
        current = gd.get("leveling_enabled", False)
        gd["leveling_enabled"] = not current
        save("guild_settings.json", data)
        status = "enabled" if gd["leveling_enabled"] else "disabled"
        await ctx.reply(f"⭐ Leveling system is now **{status}**.")

    @commands.command(name="lvtext")
    @commands.has_permissions(administrator=True)
    async def lvtext_prefix(self, ctx):
        await ctx.reply("📝 Please use the slash command `/lv text` to open the customization modal.")

    @commands.command(name="lvdisplay")
    @commands.has_permissions(administrator=True)
    async def lvdisplay_prefix(self, ctx):
        await ctx.reply("📝 Please use the slash command `/lv display` to open the display mode modal.")

    @commands.command(name="lvpreview")
    @commands.has_permissions(administrator=True)
    async def lvpreview_prefix(self, ctx):
        view = PreviewView(ctx.guild.id)
        embed = build(title="📌 Level-Up Preview", description="Click the button below to send a preview of the level-up message in this channel.\n\n"
                        f"**Current Display Mode:** `{_guild_settings(ctx.guild.id).get('level_up_config', {}).get('display_mode', 'both')}`\n\n"
                        "The preview will use your current settings and show you how the message will look.", color=Config.COLOR_INFO, bot=self.bot)
        await ctx.reply(embed=embed, view=view)

    @slash.command(name="text", description="Open a modal to fully customize the level-up message.")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def lvtext_slash(self, interaction: discord.Interaction):
        await interaction.response.send_modal(LevelUpTextModal(interaction.guild.id))

    @slash.command(name="display", description="Toggle between embed only, plain text only, or both.")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def lvdisplay_slash(self, interaction: discord.Interaction):
        await interaction.response.send_modal(LevelUpToggleModal(interaction.guild.id))

    @slash.command(name="preview", description="Preview the level-up message in the current channel.")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def lvpreview_slash(self, interaction: discord.Interaction):
        view = PreviewView(interaction.guild.id)
        embed = build(title="📌 Level-Up Preview", description="Click the button below to send a preview of the level-up message in this channel.\n\n"
                        f"**Current Display Mode:** `{_guild_settings(interaction.guild.id).get('level_up_config', {}).get('display_mode', 'both')}`\n\n"
                        "The preview will use your current settings and show you how the message will look.", color=Config.COLOR_INFO, bot=self.bot)
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

    @slash.command(name="toggle", description="Enable or disable the leveling system.")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def lvtoggle_slash(self, interaction: discord.Interaction):
        data = load("guild_settings.json")
        gd = data.setdefault(str(interaction.guild.id), {})
        current = gd.get("leveling_enabled", False)
        gd["leveling_enabled"] = not current
        save("guild_settings.json", data)
        status = "enabled" if gd["leveling_enabled"] else "disabled"
        embed = build(title="⭐ Leveling System", description=f"Leveling is now **{status}**.", color=Config.COLOR_OK if gd["leveling_enabled"] else Config.COLOR_ERR, bot=self.bot)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @slash.command(name="status", description="Check if the leveling system is enabled.")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def lvstatus_slash(self, interaction: discord.Interaction):
        settings = _guild_settings(interaction.guild.id)
        enabled = settings.get("leveling_enabled", False)
        embed = build(title="⭐ Leveling System Status", color=Config.COLOR_OK if enabled else Config.COLOR_ERR, bot=self.bot)
        embed.add_field(
            name="Status",
            value="✅ **Enabled**" if enabled else "❌ **Disabled**",
            inline=True
        )
        if enabled:
            channel_id = settings.get("level_channel")
            if channel_id:
                channel = interaction.guild.get_channel(int(channel_id))
                embed.add_field(
                    name="Level-Up Channel",
                    value=channel.mention if channel else "Not set",
                    inline=True
                )
            role_count = len(settings.get("level_roles", {}))
            blacklist_count = len(settings.get("xp_blacklist", []))
            role_blacklist_count = len(settings.get("xp_role_blacklist", []))
            embed.add_field(
                name="Settings",
                value=(
                    f"• Level Roles: {role_count}\n"
                    f"• XP Blacklisted Channels: {blacklist_count}\n"
                    f"• XP Blacklisted Roles: {role_blacklist_count}"
                ),
                inline=False
            )
        else:
            embed.add_field(
                name="💡 Tip",
                value="Use `/lv toggle` to enable the leveling system.",
                inline=False
            )
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @slash.command(name="rank", description="View your or another member's rank card.")
    @app_commands.describe(member="Member to check (leave empty for yourself)")
    async def rank_slash(self, interaction: discord.Interaction, member: discord.Member = None):
        ctx = await commands.Context.from_interaction(interaction)
        await self.rank.callback(self, ctx, member)

    @slash.command(name="lb", description="Show the XP leaderboard.")
    @app_commands.describe(page="Page number")
    async def levels_slash(self, interaction: discord.Interaction, page: int = 1):
        ctx = await commands.Context.from_interaction(interaction)
        await self.levels.callback(self, ctx, page)

    @slash.command(name="setchannel", description="Set the channel where level-up messages are sent.")
    @app_commands.describe(channel="Channel for level-up notifications")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def lvset_slash(self, interaction: discord.Interaction, channel: discord.TextChannel):
        ctx = await commands.Context.from_interaction(interaction)
        await self.lvset.callback(self, ctx, channel)

    @slash.command(name="rstchannel", description="Reset level-up messages to show in place.")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def lvrst_slash(self, interaction: discord.Interaction):
        ctx = await commands.Context.from_interaction(interaction)
        await self.lvrst.callback(self, ctx)

    @slash.command(name="setxp", description="Set a user's total XP.")
    @app_commands.describe(member="Target member", xp="Total XP to set")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def lvsetxp_slash(self, interaction: discord.Interaction, member: discord.Member, xp: int):
        ctx = await commands.Context.from_interaction(interaction)
        await self.lvsetxp.callback(self, ctx, member, xp)

    @slash.command(name="role", description="Assign a role reward for reaching a level.")
    @app_commands.describe(level="Level that triggers the reward", role="Role to award")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def lvrole_slash(self, interaction: discord.Interaction, level: int, role: discord.Role):
        ctx = await commands.Context.from_interaction(interaction)
        await self.lvrole.callback(self, ctx, level, role)

    @slash.command(name="rmrole", description="Remove a level role reward.")
    @app_commands.describe(level="Level whose reward to remove")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def lvrlv_slash(self, interaction: discord.Interaction, level: int):
        ctx = await commands.Context.from_interaction(interaction)
        await self.lvrlv.callback(self, ctx, level)

    @slash.command(name="roles", description="List all configured level role rewards.")
    async def lvroles_slash(self, interaction: discord.Interaction):
        ctx = await commands.Context.from_interaction(interaction)
        await self.lvroles.callback(self, ctx)

    @slash.command(name="bl", description="Toggle XP gain on/off in a channel.")
    @app_commands.describe(channel="Channel to toggle (defaults to current)")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def lvbl_slash(self, interaction: discord.Interaction, channel: discord.TextChannel = None):
        ctx = await commands.Context.from_interaction(interaction)
        await self.lvbl.callback(self, ctx, channel)

    @slash.command(name="blrole", description="Toggle role XP blacklist: members with this role will not earn XP.")
    @app_commands.describe(role="Role to blacklist/unblacklist")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def lvblrole_slash(self, interaction: discord.Interaction, role: discord.Role):
        ctx = await commands.Context.from_interaction(interaction)
        await self.lvblrole.callback(self, ctx, role)

    @slash.command(name="blroles", description="List all roles blacklisted from earning XP.")
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def lvblroles_slash(self, interaction: discord.Interaction):
        ctx = await commands.Context.from_interaction(interaction)
        await self.lvblroles.callback(self, ctx)

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            missing = ", ".join(p.replace("_", " ").title() for p in error.missing_permissions)
            print(f"[Leveling] {interaction.user} ({interaction.user.id}) missing permissions: {missing}")
            try:
                await interaction.response.send_message(f"❌ You are missing the required permissions: **{missing}**.", ephemeral=True)
            except discord.InteractionResponded:
                await interaction.followup.send(f"❌ You are missing the required permissions: **{missing}**.", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Leveling(bot))
